--
-- PostgreSQL database dump
--

-- Dumped from database version 14.15 (Debian 14.15-1.pgdg120+1)
-- Dumped by pg_dump version 14.15 (Debian 14.15-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: attachedfiledecrementsizefunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.attachedfiledecrementsizefunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE GlobalIntegers SET value = value - old.compressedSize WHERE key = 0;
  UPDATE GlobalIntegers SET value = value - old.uncompressedSize WHERE key = 1;
  RETURN NULL;
END;
$$;


ALTER FUNCTION public.attachedfiledecrementsizefunc() OWNER TO orthanc;

--
-- Name: attachedfiledeletedfunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.attachedfiledeletedfunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO DeletedFiles VALUES
    (old.uuid, old.filetype, old.compressedSize,
     old.uncompressedSize, old.compressionType,
     old.uncompressedHash, old.compressedHash);
  RETURN NULL;
END;
$$;


ALTER FUNCTION public.attachedfiledeletedfunc() OWNER TO orthanc;

--
-- Name: attachedfileincrementsizefunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.attachedfileincrementsizefunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE GlobalIntegers SET value = value + new.compressedSize WHERE key = 0;
  UPDATE GlobalIntegers SET value = value + new.uncompressedSize WHERE key = 1;
  RETURN NULL;
END;
$$;


ALTER FUNCTION public.attachedfileincrementsizefunc() OWNER TO orthanc;

--
-- Name: countresourcestrackerfunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.countresourcestrackerfunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE GlobalIntegers SET value = value + 1 WHERE key = new.resourceType + 2;
    RETURN new;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE GlobalIntegers SET value = value - 1 WHERE key = old.resourceType + 2;
    RETURN old;
  END IF;
END;
$$;


ALTER FUNCTION public.countresourcestrackerfunc() OWNER TO orthanc;

--
-- Name: createinstance(text, text, text, text); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.createinstance(patient text, study text, series text, instance text, OUT isnewpatient bigint, OUT isnewstudy bigint, OUT isnewseries bigint, OUT isnewinstance bigint, OUT patientkey bigint, OUT studykey bigint, OUT serieskey bigint, OUT instancekey bigint) RETURNS record
    LANGUAGE plpgsql
    AS $$

DECLARE
  patientSeq BIGINT;
  countRecycling BIGINT;

BEGIN
  SELECT internalId FROM Resources INTO instanceKey WHERE publicId = instance AND resourceType = 3;

  IF NOT (instanceKey IS NULL) THEN
    -- This instance already exists, stop here
    isNewInstance := 0;
  ELSE
    SELECT internalId FROM Resources INTO patientKey WHERE publicId = patient AND resourceType = 0;
    SELECT internalId FROM Resources INTO studyKey WHERE publicId = study AND resourceType = 1;
    SELECT internalId FROM Resources INTO seriesKey WHERE publicId = series AND resourceType = 2;

    IF patientKey IS NULL THEN
      -- Must create a new patient
      IF NOT (studyKey IS NULL AND seriesKey IS NULL AND instanceKey IS NULL) THEN
         RAISE EXCEPTION 'Broken invariant';
      END IF;

      INSERT INTO Resources VALUES (DEFAULT, 0, patient, NULL) RETURNING internalId INTO patientKey;
      isNewPatient := 1;
    ELSE
      isNewPatient := 0;
    END IF;
  
    IF (patientKey IS NULL) THEN
       RAISE EXCEPTION 'Broken invariant';
    END IF;

    IF studyKey IS NULL THEN
      -- Must create a new study
      IF NOT (seriesKey IS NULL AND instanceKey IS NULL) THEN
         RAISE EXCEPTION 'Broken invariant';
      END IF;

      INSERT INTO Resources VALUES (DEFAULT, 1, study, patientKey) RETURNING internalId INTO studyKey;
      isNewStudy := 1;
    ELSE
      isNewStudy := 0;
    END IF;

    IF (studyKey IS NULL) THEN
       RAISE EXCEPTION 'Broken invariant';
    END IF;

    IF seriesKey IS NULL THEN
      -- Must create a new series
      IF NOT (instanceKey IS NULL) THEN
         RAISE EXCEPTION 'Broken invariant';
      END IF;

      INSERT INTO Resources VALUES (DEFAULT, 2, series, studyKey) RETURNING internalId INTO seriesKey;
      isNewSeries := 1;
    ELSE
      isNewSeries := 0;
    END IF;
  
    IF (seriesKey IS NULL OR NOT instanceKey IS NULL) THEN
       RAISE EXCEPTION 'Broken invariant';
    END IF;

    INSERT INTO Resources VALUES (DEFAULT, 3, instance, seriesKey) RETURNING internalId INTO instanceKey;
    isNewInstance := 1;

    -- Move the patient to the end of the recycling order
    SELECT seq FROM PatientRecyclingOrder WHERE patientId = patientKey INTO patientSeq;

    IF NOT (patientSeq IS NULL) THEN
       -- The patient is not protected
       SELECT COUNT(*) FROM (SELECT * FROM PatientRecyclingOrder WHERE seq >= patientSeq LIMIT 2) AS tmp INTO countRecycling;
       IF countRecycling = 2 THEN
          -- The patient was not at the end of the recycling order
          DELETE FROM PatientRecyclingOrder WHERE seq = patientSeq;
          INSERT INTO PatientRecyclingOrder VALUES(DEFAULT, patientKey);
       END IF;
    END IF;
  END IF;  
END;

$$;


ALTER FUNCTION public.createinstance(patient text, study text, series text, instance text, OUT isnewpatient bigint, OUT isnewstudy bigint, OUT isnewseries bigint, OUT isnewinstance bigint, OUT patientkey bigint, OUT studykey bigint, OUT serieskey bigint, OUT instancekey bigint) OWNER TO orthanc;

--
-- Name: insertedchangefunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.insertedchangefunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE GlobalIntegers SET value = new.seq WHERE key = 6;
  RETURN NULL;
END;
$$;


ALTER FUNCTION public.insertedchangefunc() OWNER TO orthanc;

--
-- Name: patientaddedfunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.patientaddedfunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- The "0" corresponds to "OrthancPluginResourceType_Patient"
  IF new.resourceType = 0 THEN
    INSERT INTO PatientRecyclingOrder VALUES (DEFAULT, new.internalId);
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION public.patientaddedfunc() OWNER TO orthanc;

--
-- Name: resourcedeletedfunc(); Type: FUNCTION; Schema: public; Owner: orthanc
--

CREATE FUNCTION public.resourcedeletedfunc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  --RAISE NOTICE 'Delete resource %', old.parentId;
  INSERT INTO DeletedResources VALUES (old.resourceType, old.publicId);
  
  -- http://stackoverflow.com/a/11299968/881731
  IF EXISTS (SELECT 1 FROM Resources WHERE parentId = old.parentId) THEN
    -- Signal that the deleted resource has a remaining parent
    INSERT INTO RemainingAncestor
      SELECT resourceType, publicId FROM Resources WHERE internalId = old.parentId;
  ELSE
    -- Delete a parent resource when its unique child is deleted 
    DELETE FROM Resources WHERE internalId = old.parentId;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION public.resourcedeletedfunc() OWNER TO orthanc;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attachedfiles; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.attachedfiles (
    id bigint NOT NULL,
    filetype integer NOT NULL,
    uuid character varying(64) NOT NULL,
    compressedsize bigint,
    uncompressedsize bigint,
    compressiontype integer,
    uncompressedhash character varying(40),
    compressedhash character varying(40),
    revision integer
);


ALTER TABLE public.attachedfiles OWNER TO orthanc;

--
-- Name: changes; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.changes (
    seq bigint NOT NULL,
    changetype integer,
    internalid bigint,
    resourcetype integer,
    date character varying(64)
);


ALTER TABLE public.changes OWNER TO orthanc;

--
-- Name: changes_seq_seq; Type: SEQUENCE; Schema: public; Owner: orthanc
--

CREATE SEQUENCE public.changes_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.changes_seq_seq OWNER TO orthanc;

--
-- Name: changes_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orthanc
--

ALTER SEQUENCE public.changes_seq_seq OWNED BY public.changes.seq;


--
-- Name: deletedfiles; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.deletedfiles (
    uuid character varying(64) NOT NULL,
    filetype integer,
    compressedsize bigint,
    uncompressedsize bigint,
    compressiontype integer,
    uncompressedhash character varying(40),
    compressedhash character varying(40)
);


ALTER TABLE public.deletedfiles OWNER TO orthanc;

--
-- Name: deletedresources; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.deletedresources (
    resourcetype integer NOT NULL,
    publicid character varying(64) NOT NULL
);


ALTER TABLE public.deletedresources OWNER TO orthanc;

--
-- Name: dicomidentifiers; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.dicomidentifiers (
    id bigint NOT NULL,
    taggroup integer NOT NULL,
    tagelement integer NOT NULL,
    value text
);


ALTER TABLE public.dicomidentifiers OWNER TO orthanc;

--
-- Name: exportedresources; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.exportedresources (
    seq bigint NOT NULL,
    resourcetype integer,
    publicid character varying(64),
    remotemodality text,
    patientid character varying(64),
    studyinstanceuid text,
    seriesinstanceuid text,
    sopinstanceuid text,
    date character varying(64)
);


ALTER TABLE public.exportedresources OWNER TO orthanc;

--
-- Name: exportedresources_seq_seq; Type: SEQUENCE; Schema: public; Owner: orthanc
--

CREATE SEQUENCE public.exportedresources_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exportedresources_seq_seq OWNER TO orthanc;

--
-- Name: exportedresources_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orthanc
--

ALTER SEQUENCE public.exportedresources_seq_seq OWNED BY public.exportedresources.seq;


--
-- Name: globalintegers; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.globalintegers (
    key integer NOT NULL,
    value bigint
);


ALTER TABLE public.globalintegers OWNER TO orthanc;

--
-- Name: globalproperties; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.globalproperties (
    property integer NOT NULL,
    value text
);


ALTER TABLE public.globalproperties OWNER TO orthanc;

--
-- Name: labels; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.labels (
    id bigint NOT NULL,
    label text NOT NULL
);


ALTER TABLE public.labels OWNER TO orthanc;

--
-- Name: maindicomtags; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.maindicomtags (
    id bigint NOT NULL,
    taggroup integer NOT NULL,
    tagelement integer NOT NULL,
    value text
);


ALTER TABLE public.maindicomtags OWNER TO orthanc;

--
-- Name: metadata; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.metadata (
    id bigint NOT NULL,
    type integer NOT NULL,
    value text,
    revision integer
);


ALTER TABLE public.metadata OWNER TO orthanc;

--
-- Name: patientrecyclingorder; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.patientrecyclingorder (
    seq bigint NOT NULL,
    patientid bigint
);


ALTER TABLE public.patientrecyclingorder OWNER TO orthanc;

--
-- Name: patientrecyclingorder_seq_seq; Type: SEQUENCE; Schema: public; Owner: orthanc
--

CREATE SEQUENCE public.patientrecyclingorder_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patientrecyclingorder_seq_seq OWNER TO orthanc;

--
-- Name: patientrecyclingorder_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orthanc
--

ALTER SEQUENCE public.patientrecyclingorder_seq_seq OWNED BY public.patientrecyclingorder.seq;


--
-- Name: remainingancestor; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.remainingancestor (
    resourcetype integer NOT NULL,
    publicid character varying(64) NOT NULL
);


ALTER TABLE public.remainingancestor OWNER TO orthanc;

--
-- Name: resources; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.resources (
    internalid bigint NOT NULL,
    resourcetype integer NOT NULL,
    publicid character varying(64) NOT NULL,
    parentid bigint
);


ALTER TABLE public.resources OWNER TO orthanc;

--
-- Name: resources_internalid_seq; Type: SEQUENCE; Schema: public; Owner: orthanc
--

CREATE SEQUENCE public.resources_internalid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resources_internalid_seq OWNER TO orthanc;

--
-- Name: resources_internalid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orthanc
--

ALTER SEQUENCE public.resources_internalid_seq OWNED BY public.resources.internalid;


--
-- Name: serverproperties; Type: TABLE; Schema: public; Owner: orthanc
--

CREATE TABLE public.serverproperties (
    server character varying(64) NOT NULL,
    property integer NOT NULL,
    value text
);


ALTER TABLE public.serverproperties OWNER TO orthanc;

--
-- Name: changes seq; Type: DEFAULT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.changes ALTER COLUMN seq SET DEFAULT nextval('public.changes_seq_seq'::regclass);


--
-- Name: exportedresources seq; Type: DEFAULT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.exportedresources ALTER COLUMN seq SET DEFAULT nextval('public.exportedresources_seq_seq'::regclass);


--
-- Name: patientrecyclingorder seq; Type: DEFAULT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.patientrecyclingorder ALTER COLUMN seq SET DEFAULT nextval('public.patientrecyclingorder_seq_seq'::regclass);


--
-- Name: resources internalid; Type: DEFAULT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.resources ALTER COLUMN internalid SET DEFAULT nextval('public.resources_internalid_seq'::regclass);


--
-- Data for Name: attachedfiles; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.attachedfiles (id, filetype, uuid, compressedsize, uncompressedsize, compressiontype, uncompressedhash, compressedhash, revision) FROM stdin;
4	1	50f92fa8-686e-4c65-ab35-c51df0f2b72e	12824	12824	1	ab3e6cd6f74af4627ca9c9a9dd816e72	ab3e6cd6f74af4627ca9c9a9dd816e72	0
5	1	1ac33635-fb4e-4987-a342-ab05f38ffffb	14814	14814	1	263e357e0ee4256708e8eb24f3906b58	263e357e0ee4256708e8eb24f3906b58	0
6	1	1d89a36a-0273-432f-bae6-575070dfee35	33946	33946	1	ec4345537311ef0df3b428f19f62cdf5	ec4345537311ef0df3b428f19f62cdf5	0
7	1	ecd82e21-db16-4282-a810-b8fe0cf805fb	48350	48350	1	b8f679120b3ad1443a856ea6bddd2e87	b8f679120b3ad1443a856ea6bddd2e87	0
8	1	bded59a7-5388-466c-b4a3-e6d2d3383deb	48204	48204	1	a4023b354af338317c1e3ce564e5b5df	a4023b354af338317c1e3ce564e5b5df	0
9	1	bcf33cb6-c3f7-4b24-9830-599451be5ad2	48110	48110	1	0bc8f0b85d819c6a714f606994438879	0bc8f0b85d819c6a714f606994438879	0
10	1	c42aa252-5e7d-4db4-89ec-6bd1b95d2d00	48008	48008	1	7254200ebf5fc58ffad7876ab39c4f97	7254200ebf5fc58ffad7876ab39c4f97	0
11	1	27506726-25ba-46b6-a78d-3c38cac4211b	47946	47946	1	caf4d6831c1eab78cee9d7a5726f0e72	caf4d6831c1eab78cee9d7a5726f0e72	0
12	1	055d3166-797c-4bd8-9220-1b9f5e8e173a	47864	47864	1	617a0d718cf4ee50a076c0e973645edd	617a0d718cf4ee50a076c0e973645edd	0
13	1	fc77f016-7f9e-4eb2-b3a8-475f6cf65c20	47758	47758	1	818ce0c73d0b3ea66f055a4a7d64e194	818ce0c73d0b3ea66f055a4a7d64e194	0
14	1	43baf492-b2f9-4f6e-8d51-8522c499a0e6	47632	47632	1	983259cb404c7f1c33013836fb7e5e62	983259cb404c7f1c33013836fb7e5e62	0
15	1	5af1f586-ad74-486d-83f5-1c2898e0e00d	47618	47618	1	5dcf8593e0e39fbc890a054d2d30de96	5dcf8593e0e39fbc890a054d2d30de96	0
16	1	bf61f8ba-d9ef-4e18-aefe-b87453aded50	47562	47562	1	1f5aa7fe74218c276098a5935606f64c	1f5aa7fe74218c276098a5935606f64c	0
17	1	f9074786-ede5-49d7-a29b-df77ec8c31c2	36052	36052	1	d333d215edf8d2266532af27ea33ac2f	d333d215edf8d2266532af27ea33ac2f	0
18	1	95986b26-f5d1-4738-a946-ff5911c3bf16	47514	47514	1	cef17be6e84a77d7246e2464bfa4a46c	cef17be6e84a77d7246e2464bfa4a46c	0
19	1	18589a24-b04d-4956-add6-9a2cfa687e6e	47300	47300	1	1d1a45aa80fd3a129d3e55b6c9d7f6a8	1d1a45aa80fd3a129d3e55b6c9d7f6a8	0
20	1	d533853a-6a50-4b6c-8829-3f26632fa404	47350	47350	1	c66c12c3201af60bfd0ffaec64a9e3b3	c66c12c3201af60bfd0ffaec64a9e3b3	0
21	1	ddf238a0-5930-42c4-bd00-802fd976da2c	47284	47284	1	9d51673b6eb1b5f9cf7167b70910da80	9d51673b6eb1b5f9cf7167b70910da80	0
22	1	9645177d-7682-417c-9068-37b58b51021a	47094	47094	1	e61201d2441319adcf3f35d1873389d5	e61201d2441319adcf3f35d1873389d5	0
23	1	bbfaa0a0-810c-4993-ad78-ac32c87a227f	47122	47122	1	10f08dc9f2a9988788e3ce09561135d7	10f08dc9f2a9988788e3ce09561135d7	0
24	1	6e7ff27b-e64f-4ac0-8dc3-b41767cbca3a	47046	47046	1	f73311d2956d2e7e0014398982139671	f73311d2956d2e7e0014398982139671	0
25	1	10b1e717-14fe-48f4-987a-7f1369f06d78	46978	46978	1	ed3e8f84ffadd3f475821d04d0f1b89f	ed3e8f84ffadd3f475821d04d0f1b89f	0
26	1	97c2d2c4-f9c7-45d9-8499-186b62f9a1f8	46878	46878	1	66265cbdc19d85d7ae67f4f768d898a0	66265cbdc19d85d7ae67f4f768d898a0	0
27	1	a6e930de-080e-4a2a-a852-2934c22e4a1f	46766	46766	1	ea88657b1eb2a5bc2c54d131ebb58d0a	ea88657b1eb2a5bc2c54d131ebb58d0a	0
28	1	b6bd86e1-8ad4-4603-acdd-4d3322d3c29d	37604	37604	1	9031433c83b62b0c627c2bf16817d9b1	9031433c83b62b0c627c2bf16817d9b1	0
29	1	9f31a2a2-25b1-4680-9f26-a788ee106b14	46764	46764	1	b22f8750a354c37342e855c51a0461a2	b22f8750a354c37342e855c51a0461a2	0
30	1	f856f8ac-bc75-4acc-a69b-584471863da3	46742	46742	1	928772cdfde1172f79321aa400f7b075	928772cdfde1172f79321aa400f7b075	0
31	1	35bc2d93-7a8e-4819-9de2-7b4cbf3eff51	46540	46540	1	5e00f10322d9e468f7d89bc7453ecbae	5e00f10322d9e468f7d89bc7453ecbae	0
32	1	96fde790-1180-4d8f-816d-ec88d06c72e9	46540	46540	1	2a87d2720a560558407bdda6304d0a66	2a87d2720a560558407bdda6304d0a66	0
33	1	4cdcf775-0085-423d-b991-9151e02e8c11	46680	46680	1	1c3f70ad29ac0e6da2ce7e044c4d70aa	1c3f70ad29ac0e6da2ce7e044c4d70aa	0
34	1	00a3f889-10ed-4a5a-822c-92059d418472	46718	46718	1	d8ee4036befc58785b337bc0a506b48a	d8ee4036befc58785b337bc0a506b48a	0
35	1	97cce584-88e8-4314-b18b-6b9a681bbf74	46544	46544	1	938d4bc2f7671b9b286364805437a4ed	938d4bc2f7671b9b286364805437a4ed	0
36	1	7e83c49a-22bb-433f-a7c6-b9a44fd649be	46456	46456	1	4306270ef3f3b37ccf4beac7b44b4f67	4306270ef3f3b37ccf4beac7b44b4f67	0
37	1	b6f57c32-81b9-4adb-ab0f-d61052ecec97	46342	46342	1	69458da01d8a6d387991573b3e5bb89f	69458da01d8a6d387991573b3e5bb89f	0
38	1	9d0ad4d0-33d7-4bd8-b6f6-1f3f3619cd01	46406	46406	1	1cdadbd12b7e9085037891c81f051dc5	1cdadbd12b7e9085037891c81f051dc5	0
39	1	9bc8f84d-fd9f-4f87-a36c-6e16e85599ad	38824	38824	1	20a24c48862f84baf7eaffde8e9701c6	20a24c48862f84baf7eaffde8e9701c6	0
40	1	e5b69e07-f67a-4320-bda0-3fa8b766990a	46448	46448	1	67d1c6b2afc572f489a8927b7e37bc79	67d1c6b2afc572f489a8927b7e37bc79	0
41	1	7abbc00d-e52b-4482-83bf-cbad1096abf4	46314	46314	1	ab98d278713fd21cc7301917bc2c4d1a	ab98d278713fd21cc7301917bc2c4d1a	0
42	1	25ee31c6-9617-412c-b419-25b1cb413c02	46160	46160	1	e1e03164b4bbf9700d5bc7188bae907b	e1e03164b4bbf9700d5bc7188bae907b	0
43	1	f5621ded-71a0-4a6c-b754-978a7a1fa5dc	46060	46060	1	13797a1ec4957100ac270ac41fee9779	13797a1ec4957100ac270ac41fee9779	0
44	1	dcf75d69-b663-4362-8481-b3f2965f9d5a	45908	45908	1	70fba51e7ec0a20545983782c5a047e5	70fba51e7ec0a20545983782c5a047e5	0
45	1	d546de53-09e3-4d3d-8467-ab6b998e2d80	45920	45920	1	95d04fae7d74deec6ef8e4e2eef0bfa1	95d04fae7d74deec6ef8e4e2eef0bfa1	0
46	1	6e73fc72-c111-4854-a2b1-42b81904099b	46080	46080	1	add27bd16c5ad059170766c6d5bbc1a7	add27bd16c5ad059170766c6d5bbc1a7	0
47	1	17681df0-0e1e-4d0d-9821-f84bd442a87c	45974	45974	1	98e9975a9ea4d29bb965537fdef97a64	98e9975a9ea4d29bb965537fdef97a64	0
48	1	859810df-58ea-412a-9c6b-7b056827ddeb	46096	46096	1	e49fdc8b68b11ad3578d556d905c2755	e49fdc8b68b11ad3578d556d905c2755	0
49	1	1e6aa6ad-f3c4-43d8-9706-14c94c23cd24	46192	46192	1	7b6b355622a7d0201f2c94549b03eec8	7b6b355622a7d0201f2c94549b03eec8	0
50	1	fa3b3312-7145-440e-9cdb-9a72512a0522	39330	39330	1	a223dbf8de3e8925b9697b9ebec30d9c	a223dbf8de3e8925b9697b9ebec30d9c	0
51	1	32f9866f-b08e-4dc0-9909-a20f6acbbe95	46236	46236	1	95290f08dfff7a2b498470fcd62af860	95290f08dfff7a2b498470fcd62af860	0
52	1	de97747a-1cef-44f6-a4d7-2d95a4d14a49	46270	46270	1	b50618cb42ecdae649aa90b990361174	b50618cb42ecdae649aa90b990361174	0
53	1	41d6071c-c2c7-4023-971c-2dc26477ca8d	46340	46340	1	dd7fa73cb41620d8d8a965eb4fbec641	dd7fa73cb41620d8d8a965eb4fbec641	0
54	1	e481fab8-97c2-4bd8-bb84-2742838257a4	46278	46278	1	420b1874041f2d5597cb3a82d3e0a4e0	420b1874041f2d5597cb3a82d3e0a4e0	0
55	1	1116d988-2d91-409c-a197-954076855888	46302	46302	1	d453e66e08e935b65dce3a5f8337d877	d453e66e08e935b65dce3a5f8337d877	0
56	1	716fc5d8-0d60-4ad8-9c33-614cf2549df9	46312	46312	1	f940021861433be2055c5a2885bb9da6	f940021861433be2055c5a2885bb9da6	0
57	1	5e097888-abae-4c69-af24-4858eccb11d7	46294	46294	1	33096f682de679163cea946f8ca156d2	33096f682de679163cea946f8ca156d2	0
58	1	8695ee12-f26b-425c-b745-1e71a77550f6	46268	46268	1	06861d512c302c7ee6f37a8cc381b421	06861d512c302c7ee6f37a8cc381b421	0
59	1	1c56d2ba-14e1-4f1c-bc34-60d74a5f3baf	46194	46194	1	f74b687c327411c3a64f94e3b39205be	f74b687c327411c3a64f94e3b39205be	0
60	1	568d3f30-3d3c-4070-bb6b-fcb76e9d25e4	46322	46322	1	1ec49bb75207fe59abae7bfbd207e25d	1ec49bb75207fe59abae7bfbd207e25d	0
61	1	bd11f2fb-a6c9-48ce-91dc-2259eb04107e	39636	39636	1	6ba9912fac195a918d1e4c0ef7effca3	6ba9912fac195a918d1e4c0ef7effca3	0
62	1	9d2b95ca-8146-4bc7-aefc-326a847be66d	46262	46262	1	0e5137ca532a0631ff15727a9a74f61d	0e5137ca532a0631ff15727a9a74f61d	0
63	1	ab99b371-e989-463a-8078-331511c23bcf	46206	46206	1	ee3c370e1330b2bbc158b6c41bd72097	ee3c370e1330b2bbc158b6c41bd72097	0
64	1	fbf6c591-8029-47ba-b464-8132e064a416	46252	46252	1	1733eb611f74ddcb75c69346d40b941e	1733eb611f74ddcb75c69346d40b941e	0
65	1	58e2d671-7c8f-4d60-bef3-06c3c5902378	46218	46218	1	84e50a4ef2f63fba6a99b386cbd890df	84e50a4ef2f63fba6a99b386cbd890df	0
66	1	aea3fd35-6191-4915-b14f-ad8496f1adb8	46152	46152	1	dc1448bc1cbc959f28ffd1d0ae3bb134	dc1448bc1cbc959f28ffd1d0ae3bb134	0
67	1	2eb848dc-a9c7-4a99-b5fe-a205e15a755e	45996	45996	1	870e8432102e127863b4d6f4328b09b0	870e8432102e127863b4d6f4328b09b0	0
68	1	5a4e231f-c19c-4110-ba02-e65d47fefd4c	45980	45980	1	e9367b930e8dbfd9bca4a2c80f4dde08	e9367b930e8dbfd9bca4a2c80f4dde08	0
69	1	82f13f45-fcf1-45f1-a147-6196b87cef90	45964	45964	1	3efeaad215889b466e1591306a280591	3efeaad215889b466e1591306a280591	0
70	1	c935a66c-9ea0-467a-94b1-ef80a6cb0a18	45908	45908	1	717dc28a05d438401d511e463b2e2c47	717dc28a05d438401d511e463b2e2c47	0
71	1	c762dd4f-58cd-45ac-9359-f42b250044e7	45744	45744	1	e0262a9d90297bc996e9eaf0d525180a	e0262a9d90297bc996e9eaf0d525180a	0
72	1	364e57c8-9350-467e-b429-78cf6cb58876	39832	39832	1	6271669b601e2a1197da0cca8c9a36d2	6271669b601e2a1197da0cca8c9a36d2	0
73	1	9fccd871-6952-4e6b-a197-a94c55753626	45706	45706	1	154416cbde99eedf04698d55339e7f01	154416cbde99eedf04698d55339e7f01	0
74	1	382e033b-7eba-42d0-8c12-791b20279662	45570	45570	1	816cc56ea0535789f79f23a30fe43699	816cc56ea0535789f79f23a30fe43699	0
75	1	49f6cef7-93f1-4af2-b4cd-00cb921a9d24	45538	45538	1	5446413048554eecec7adca62b8e90e7	5446413048554eecec7adca62b8e90e7	0
76	1	f1e59935-d947-40ee-a120-f0912cd8b575	45330	45330	1	74fcd79b8fe5e7acc760eeb2981ba914	74fcd79b8fe5e7acc760eeb2981ba914	0
77	1	5664f6fa-4597-4d18-8ed3-c2a6dfbfae7c	45186	45186	1	7ef1337b7b5bff27c6b23c1cb6a463f3	7ef1337b7b5bff27c6b23c1cb6a463f3	0
78	1	c1532c0b-4f1e-4d2b-b1c0-8fa7714ffef6	45154	45154	1	d245a6c240662319d4e77ed3a66082f1	d245a6c240662319d4e77ed3a66082f1	0
79	1	572b9528-8047-4a34-a2cd-b4da134f56d5	45166	45166	1	f551434c6482ce047cd246081f77dea0	f551434c6482ce047cd246081f77dea0	0
80	1	4ecf8171-792f-4f7e-9136-eed1a3ff01c7	45036	45036	1	69e00d451fe58ada832d3c6a845cbc35	69e00d451fe58ada832d3c6a845cbc35	0
81	1	53089ed2-3d23-469f-951d-815899988723	44890	44890	1	39589263f5a5e2ca42b61a0a919fd321	39589263f5a5e2ca42b61a0a919fd321	0
82	1	b57a99fc-b279-4aaf-8be5-2410204baed1	44754	44754	1	f4e551b286b975950de1c60fbc3e5011	f4e551b286b975950de1c60fbc3e5011	0
83	1	5d028f07-900b-4bd1-9f1b-a190ce86dad3	40040	40040	1	c5bdb8d175fa1e3bbc013ee17201a7b7	c5bdb8d175fa1e3bbc013ee17201a7b7	0
84	1	509035e6-ae6d-426b-95ea-ae73172623f4	44854	44854	1	75669af1ecdbd30d9b07ed2acaaec0f7	75669af1ecdbd30d9b07ed2acaaec0f7	0
85	1	827b6c56-3533-49a2-914f-c632a7f0984b	44860	44860	1	d80b479cc9da055bc638d634a399d0b4	d80b479cc9da055bc638d634a399d0b4	0
86	1	5dd5e52e-fc66-4019-b445-ad7d979251f4	44942	44942	1	030dce3e9d00387884b3269605832bc4	030dce3e9d00387884b3269605832bc4	0
87	1	c6eae2b8-b883-4b4e-a3e8-de5c1028ed61	44988	44988	1	885d0fcd0c80d7d96cff529961d26b05	885d0fcd0c80d7d96cff529961d26b05	0
88	1	51ee0661-2bfe-4ba7-a6de-304b7c7418fb	45042	45042	1	682fd7051b1c0e77ea6e3e8850ca2f9e	682fd7051b1c0e77ea6e3e8850ca2f9e	0
89	1	3379b404-bd28-404b-818e-8765fbc9ef6a	44910	44910	1	5af2392d9fe5ae21b192732b57f2ea17	5af2392d9fe5ae21b192732b57f2ea17	0
90	1	4d31e3d3-cdf5-46a9-afe3-8c1c88b0e62d	45044	45044	1	94d553ad2a625c5b9e0136103dcc3ff8	94d553ad2a625c5b9e0136103dcc3ff8	0
91	1	2935268d-c2dc-4a64-a98b-df601d503949	45040	45040	1	9c1066d001f1f93ff5626da56add624b	9c1066d001f1f93ff5626da56add624b	0
92	1	5aa9fbb5-4e76-44c5-a29c-b359edfdfb96	44946	44946	1	94bd67b8a27251ba1015ce7c78394f7b	94bd67b8a27251ba1015ce7c78394f7b	0
93	1	ab3fb25e-74cd-46c6-9f8b-cd4dd5d01df5	45020	45020	1	6a3a96a19e0f53d6d5db7172bf5031f4	6a3a96a19e0f53d6d5db7172bf5031f4	0
94	1	76be7398-78fa-4ac4-9ef4-f219e9f52a9e	40186	40186	1	33308ad7757da6b784ab70c3169534a6	33308ad7757da6b784ab70c3169534a6	0
95	1	824dffc2-d36a-4435-ba68-b1d4277012ba	44984	44984	1	f8748d7e485388a55945b8f42247ed12	f8748d7e485388a55945b8f42247ed12	0
96	1	1ba2639a-9bdd-4da7-875b-4d39b6881009	44916	44916	1	32398bcf9ced93921a243c2b16e7bfd8	32398bcf9ced93921a243c2b16e7bfd8	0
97	1	2d2bd6e0-9aa0-4309-a09c-ff085d6b787b	45058	45058	1	9e8d6c9c85111fcba45302ae549beac7	9e8d6c9c85111fcba45302ae549beac7	0
98	1	1079a0f1-b123-4f46-89e4-29f1be0e5ae4	45128	45128	1	eead419b38711dba96a92e26337a6464	eead419b38711dba96a92e26337a6464	0
99	1	99c8835f-0dc5-4f2c-9638-ec8f9ba6fb22	45150	45150	1	447d510f9ecc7336986277089b4069b9	447d510f9ecc7336986277089b4069b9	0
100	1	ceae306c-e131-4155-811c-06b83ad34da0	45048	45048	1	b99c65db5951c074b7024d285d2e6ac9	b99c65db5951c074b7024d285d2e6ac9	0
101	1	f1795f41-76b1-4ea1-a622-fb1358773ea8	45096	45096	1	29e50adcdae5c552b567740f6623ad8c	29e50adcdae5c552b567740f6623ad8c	0
102	1	dd4f4986-e195-4527-8107-b713b4846a6b	44960	44960	1	3462ff7e47e79cf9c4f8e51126fc6c1d	3462ff7e47e79cf9c4f8e51126fc6c1d	0
103	1	8c0dfaec-a701-427d-a346-05164dd43e80	44896	44896	1	d03164f0bb4218472293d8f191b828d7	d03164f0bb4218472293d8f191b828d7	0
104	1	797d58a2-d1e4-45c0-83bf-c3e56c9398ad	44742	44742	1	3696b4cb5653d0d60cd21bff03fb2d88	3696b4cb5653d0d60cd21bff03fb2d88	0
105	1	d5a65452-512a-451a-aeee-d34e0c0527fd	40322	40322	1	69963683c35e6b9ee432e115be67b4d9	69963683c35e6b9ee432e115be67b4d9	0
106	1	1bef6cba-096d-454a-b404-51c549f8fb41	44684	44684	1	1822b61e5d9b85c7a87eef0eb381a8e6	1822b61e5d9b85c7a87eef0eb381a8e6	0
107	1	b9a4f7b0-fcaf-4e47-916c-ae580a1be4f6	44746	44746	1	c02b3aae767f6053c9a565ccdb785a83	c02b3aae767f6053c9a565ccdb785a83	0
108	1	3e778ffd-56d9-4bbc-9528-7263a05aa536	44740	44740	1	39ae996d29f40c6e7e2e050b8bbd3074	39ae996d29f40c6e7e2e050b8bbd3074	0
109	1	57573211-5c70-43f7-a939-1ffb8ecddf1e	44574	44574	1	eb9e501a93c38bd4bb167ed47243ee82	eb9e501a93c38bd4bb167ed47243ee82	0
110	1	6caf0257-26f9-4c3e-8012-2ac08d893798	44596	44596	1	43c7a2d7e85766fecb401b99df395461	43c7a2d7e85766fecb401b99df395461	0
111	1	f9d15924-80ea-4217-93f5-2e790acb6d5a	44694	44694	1	bfa6643afe684adb90f99b1e95c825f4	bfa6643afe684adb90f99b1e95c825f4	0
112	1	efd16cb3-42bb-4a73-8807-6e5af45b55e6	44838	44838	1	a75ed68227547537314d5ba6c337ce0b	a75ed68227547537314d5ba6c337ce0b	0
113	1	89cf47f7-2886-4e8d-a240-03c7dc3114c3	44936	44936	1	f1e9ac411ae2c33a64731cdce18ed737	f1e9ac411ae2c33a64731cdce18ed737	0
114	1	f272d0ff-25b2-4698-81bd-a82562fa6ab2	44960	44960	1	af91fa751a8cac90b5dfcaf34027821f	af91fa751a8cac90b5dfcaf34027821f	0
115	1	6db0270c-cff9-4178-8278-5f477cadd808	45002	45002	1	41e1863c29697014cb5e754b83485fad	41e1863c29697014cb5e754b83485fad	0
116	1	03b1cba7-ecfc-4021-88ea-e94245a16dbd	16684	16684	1	e1234e89217d6ac6746450cd02b9d43f	e1234e89217d6ac6746450cd02b9d43f	0
117	1	32b32ab7-e1d6-4fee-bca4-d77bd6ff30ee	40566	40566	1	504cc68cb2f4939070fd162c194808e0	504cc68cb2f4939070fd162c194808e0	0
118	1	1c63cb17-d869-4a71-b15f-774813507cb1	45010	45010	1	0e9815be1b399d8686c37c3985c1aec4	0e9815be1b399d8686c37c3985c1aec4	0
119	1	fac0f3e4-8435-4513-9a79-7fe58dec633e	45084	45084	1	90a494e673908b1fdad09c6ce33f0376	90a494e673908b1fdad09c6ce33f0376	0
120	1	cb2498ec-69b5-49be-90a1-2b183d9d02f5	45102	45102	1	d6948f7e449341c466f3592f631f9644	d6948f7e449341c466f3592f631f9644	0
121	1	c3f2c41e-4e1b-4555-a878-f527114db29c	45188	45188	1	0adabf2093dd4253d743a2bd809d96d8	0adabf2093dd4253d743a2bd809d96d8	0
122	1	b3d0eb64-e0f2-451d-b35d-58b6db5c67e4	45240	45240	1	9a7a4ee46040c8b2af6e3c26618ebc6a	9a7a4ee46040c8b2af6e3c26618ebc6a	0
123	1	7f8fa090-8b3e-47ae-856a-fd6c9d14a6d2	45382	45382	1	15fa6d9a52c95b7c3c35f508a6c44b47	15fa6d9a52c95b7c3c35f508a6c44b47	0
124	1	f7fc4838-e3df-4be1-bc35-a980444f3a72	45156	45156	1	2cbbd38910dfd7bdd87f9d479380e8ff	2cbbd38910dfd7bdd87f9d479380e8ff	0
125	1	5837a180-1afd-4701-9d18-e52ebf000867	45292	45292	1	1c208dd1b78dfcb75dc12de981a16f8b	1c208dd1b78dfcb75dc12de981a16f8b	0
126	1	9d177495-08dd-4f23-a31b-c05e849be454	45274	45274	1	4f6cca2d13e68001c592ac2e60ad3fda	4f6cca2d13e68001c592ac2e60ad3fda	0
127	1	73053c16-43cb-4707-aa45-788f33e9e3e8	45280	45280	1	83a6e07b7a5089839e14ce9e648a8188	83a6e07b7a5089839e14ce9e648a8188	0
128	1	a4cab57e-24fd-4adf-a406-dc08bf427953	40768	40768	1	52075a7f71c7fff97be27816cd09bf94	52075a7f71c7fff97be27816cd09bf94	0
129	1	6f644b9d-d679-4f08-9894-6bd36d4ff720	45178	45178	1	2e2852161cac316a8f6dc3351b2193cc	2e2852161cac316a8f6dc3351b2193cc	0
130	1	3b38f84d-2e38-487a-8d70-4aa64490d989	45234	45234	1	8c7fbbeba270409a5ea85430d8a56a4e	8c7fbbeba270409a5ea85430d8a56a4e	0
131	1	da2b10e0-e586-4b2d-b1ad-69e92dd3795e	45088	45088	1	00ff754991c677e6b03f6e3ed427e51c	00ff754991c677e6b03f6e3ed427e51c	0
132	1	49a430f9-80ed-4d42-8347-018c0cb2892a	45148	45148	1	63381baaf90bb2aa11a68ff4629f8a77	63381baaf90bb2aa11a68ff4629f8a77	0
133	1	13308a76-d305-4d7b-b69c-1b5c2a69337b	44998	44998	1	039452dce9e01d243d8e6505b068f283	039452dce9e01d243d8e6505b068f283	0
134	1	c54d690d-3ff5-46b9-a586-21394322abe4	44942	44942	1	5e436cbc749c102af42e8001c39aab68	5e436cbc749c102af42e8001c39aab68	0
135	1	dd8fde61-9c3e-4c68-bbb5-7d1d53bdb209	44858	44858	1	45626c65e1835cd4bccdd5ef8a5f5ff8	45626c65e1835cd4bccdd5ef8a5f5ff8	0
136	1	b026e299-82f1-4368-a9f4-a6d7c01d0b78	44872	44872	1	4d8fcce3d15a4bc73f04525dcb6b806d	4d8fcce3d15a4bc73f04525dcb6b806d	0
137	1	41f0e930-6e60-40b0-b7ad-e1d9f0a6866a	44764	44764	1	db0e93233f3dd7b1d8529325fec2ebba	db0e93233f3dd7b1d8529325fec2ebba	0
138	1	454abb06-d447-4f2b-a3fb-82219129a3f4	44812	44812	1	7dc5c83c6941ad98ee1ff8da3f81cfd3	7dc5c83c6941ad98ee1ff8da3f81cfd3	0
139	1	561c0f02-362f-4b97-957d-30ac4e69c970	40986	40986	1	b44485b61f62341b182484e9d1f3783d	b44485b61f62341b182484e9d1f3783d	0
140	1	dd1b1ebe-3ba7-4965-8fcf-de9d3cf2960e	44650	44650	1	42386fa6a08155c0e1aca707efa96001	42386fa6a08155c0e1aca707efa96001	0
141	1	0e481a6a-e364-4077-9f24-bf199b7e3949	44582	44582	1	1a8d18340b1bfa77c9aa9912f42a96ed	1a8d18340b1bfa77c9aa9912f42a96ed	0
142	1	e2cbb315-ff33-4fce-a3db-7ec3fdbecb1f	44550	44550	1	af2b8ffac479773fdba17093170718a7	af2b8ffac479773fdba17093170718a7	0
143	1	e42daaff-b251-4ade-a3a4-80573533554c	44770	44770	1	67b8ef024814f0cd40cec17fe7de3a85	67b8ef024814f0cd40cec17fe7de3a85	0
144	1	81183102-9afd-4938-a3e3-f6b1700851b6	44734	44734	1	60b44c95d0b3eb5908d6a3d562a05fa0	60b44c95d0b3eb5908d6a3d562a05fa0	0
145	1	d630a1ee-09b3-4fa8-99d9-203f09cda580	44730	44730	1	97471ee87d35acab370c139fe6fb273a	97471ee87d35acab370c139fe6fb273a	0
146	1	bc82118b-d7d8-4ffb-b451-afc5dbc531d1	44822	44822	1	e8105ece927dbc39a1f89bd716692064	e8105ece927dbc39a1f89bd716692064	0
147	1	0543fe21-78fa-40b7-886f-08d0871b7a57	44822	44822	1	4ec059daafd975e1f1fbb9e10dfad82a	4ec059daafd975e1f1fbb9e10dfad82a	0
148	1	f877b57d-2a6e-40eb-8687-5a54f335e4a7	45020	45020	1	196bde2275784734d5813aa181dc5420	196bde2275784734d5813aa181dc5420	0
149	1	6b1d181e-6f60-474e-96f1-47a515f2fb6e	45110	45110	1	c31384eab436f464769554c71a325259	c31384eab436f464769554c71a325259	0
150	1	c60d736e-f418-41c7-848d-795b65b9be19	41216	41216	1	42698b59dfc16a880f1e4347c05a1b64	42698b59dfc16a880f1e4347c05a1b64	0
151	1	93fe665b-f55f-4631-99e2-2b9308d6d07b	45212	45212	1	4b91919a39639b7efc8473218e1a1beb	4b91919a39639b7efc8473218e1a1beb	0
152	1	70c410e4-6f07-4e24-9288-e7d13105561f	45236	45236	1	c525e57d378c749bd7f9f695c9b8e98a	c525e57d378c749bd7f9f695c9b8e98a	0
153	1	b871bcb4-688d-4224-b4ba-9c1162248202	45218	45218	1	2333619a1c4b018f93f170935f2adad1	2333619a1c4b018f93f170935f2adad1	0
154	1	f4bbfc47-8535-4374-93f4-1c67a613ccad	45196	45196	1	d3f20c313d7b5135daed4c61339542c6	d3f20c313d7b5135daed4c61339542c6	0
155	1	73856daa-7bc3-41ef-9f83-fa050a39df17	45278	45278	1	d47f2ad0661e70d8e60af92485e69a2a	d47f2ad0661e70d8e60af92485e69a2a	0
156	1	6433af0f-b4b7-47aa-91a6-62b149133bdb	45414	45414	1	2d2541dc841e42686de1ef45506d15e7	2d2541dc841e42686de1ef45506d15e7	0
157	1	4ad77711-077a-43c4-bb27-48307863561f	45402	45402	1	f9c3a9d570eb855e0f56ab02567bde45	f9c3a9d570eb855e0f56ab02567bde45	0
158	1	a9353997-3674-4cdd-8901-3673021f6024	45232	45232	1	65de63f0b0c6d1fd3493211ba41c0ee5	65de63f0b0c6d1fd3493211ba41c0ee5	0
159	1	b0c3dfab-a7e3-4660-b26a-b3df4c0983e3	45358	45358	1	915746da30e2efe73adb394cfa60427c	915746da30e2efe73adb394cfa60427c	0
160	1	06431451-33d0-4a61-951e-7bc9eeaf5ea4	45506	45506	1	0e4aea45d968360a33080085deac8243	0e4aea45d968360a33080085deac8243	0
161	1	2a507bbf-bde7-4e2a-af9c-165a16d07718	41440	41440	1	b05cfd24a3a32c63ce04697d0fe1a7fa	b05cfd24a3a32c63ce04697d0fe1a7fa	0
162	1	f9c004af-5bb6-4ae7-972c-2609bcf66350	45550	45550	1	ec91ffb6bd4040d9ef7e7a55df3040b0	ec91ffb6bd4040d9ef7e7a55df3040b0	0
163	1	10faa02a-e0ae-4850-a195-3961a66c44a9	45658	45658	1	ffdb1c712e9f3d1e35be7617a63dae70	ffdb1c712e9f3d1e35be7617a63dae70	0
164	1	2c01263c-e3c8-46dc-a81c-74c516f2d07a	45696	45696	1	ed440ceedeaeff22a96b92c393532516	ed440ceedeaeff22a96b92c393532516	0
165	1	c7f40d51-0d7f-402f-989c-7cb8650276d1	45570	45570	1	febc97c595cc7b742246242ef65d9672	febc97c595cc7b742246242ef65d9672	0
166	1	f298006c-6b7a-4263-8b85-d224faca9581	45504	45504	1	79bc60928639475c67046d1b7d293519	79bc60928639475c67046d1b7d293519	0
167	1	fc663d5a-4fae-4ef7-9224-84e7b40c4b6e	45344	45344	1	ee4998830b178024ea396775bca04204	ee4998830b178024ea396775bca04204	0
168	1	1ea5085c-ff50-4fec-b28a-3040221e5a62	45454	45454	1	fb4a15ea69ead0e6d5968d1c7746556c	fb4a15ea69ead0e6d5968d1c7746556c	0
169	1	3e6e08f3-60a1-4425-94a3-b1a7c7cd747c	45468	45468	1	98321bb916cb60443afb6af4ec3bfc6d	98321bb916cb60443afb6af4ec3bfc6d	0
170	1	ec7f537f-ad29-442d-a518-ef00a50f0a78	45310	45310	1	43d577961917453bc5b2b04f36d41669	43d577961917453bc5b2b04f36d41669	0
171	1	419880df-1f14-4c8f-a55b-f9f0a93d1a57	45458	45458	1	66b7468013fb9274e97627f497888348	66b7468013fb9274e97627f497888348	0
172	1	acd48f6d-8c6a-478f-81ff-1126f0181245	41682	41682	1	dc9b4935e7344fca6b0d74ca2af1fba0	dc9b4935e7344fca6b0d74ca2af1fba0	0
173	1	6762ef2e-df14-4a53-bd1c-3870d7ed13ab	45580	45580	1	444ac5c4e5005267cf741df63e7bfda0	444ac5c4e5005267cf741df63e7bfda0	0
174	1	e9676822-d83d-4f76-bd1b-40f28ff75952	45406	45406	1	c29a2f274cf3a52c067938d2c01da706	c29a2f274cf3a52c067938d2c01da706	0
175	1	169ef5bc-39df-4987-8852-d56678ab95cf	45432	45432	1	4aa636e2e5363abef73a0b7957d9018c	4aa636e2e5363abef73a0b7957d9018c	0
176	1	c1074908-1455-4e1b-8a4b-8b9da405bea3	45482	45482	1	33b9ded598a36f17bbc93d98e18a72b9	33b9ded598a36f17bbc93d98e18a72b9	0
177	1	5efc03d3-553e-427f-9d8d-535f3df84ecb	45302	45302	1	1da549f4a10152e373a053cb794b3fa6	1da549f4a10152e373a053cb794b3fa6	0
178	1	6160b48e-29ef-4b16-9bd7-8ab46c40ba98	45376	45376	1	1d26d2bc9eb1370d0a0368d4f0296d9f	1d26d2bc9eb1370d0a0368d4f0296d9f	0
179	1	6664750b-7838-410d-b19e-0472bf258003	45350	45350	1	ac60c5627fa116a685b63a4a8296fd27	ac60c5627fa116a685b63a4a8296fd27	0
180	1	6e58736c-1c7b-4393-b6e5-2d3df2b8f3fa	45306	45306	1	eef42a2702af7947b3ba74e5581ec858	eef42a2702af7947b3ba74e5581ec858	0
181	1	b12f9c3d-9ca0-4cda-be0c-dabb90a0a454	45220	45220	1	6db76efe49c6a4dc4d7d564c6281889c	6db76efe49c6a4dc4d7d564c6281889c	0
182	1	4a7c6a56-bf26-4a2c-ac38-66bb99b69103	45176	45176	1	1c6eec5d5cdfb524ae24e1fe0f541ceb	1c6eec5d5cdfb524ae24e1fe0f541ceb	0
183	1	9c21de19-be49-4bac-8a8f-3374df0a22a0	41928	41928	1	a1d06e12bbf48b2b32374c402ccc8abe	a1d06e12bbf48b2b32374c402ccc8abe	0
184	1	60adbe7e-49ff-4ba5-8065-3478a86f2067	45198	45198	1	442ed34b4afeab58fcce070e2a6f2eb2	442ed34b4afeab58fcce070e2a6f2eb2	0
185	1	34bd67a5-d132-4134-800a-a3413a6d3369	45224	45224	1	3781fd5ce1f7494fc47239dd620df136	3781fd5ce1f7494fc47239dd620df136	0
186	1	1c2063b1-df6d-4b61-834a-365a899fb7e6	45118	45118	1	ca3b83c7bb8f36392755cf13e5d6fb4c	ca3b83c7bb8f36392755cf13e5d6fb4c	0
187	1	2bcfc109-bccd-4ef0-bc3e-491479e2227e	45124	45124	1	0dc0309172d197c1ee897f84ca4aa1fe	0dc0309172d197c1ee897f84ca4aa1fe	0
188	1	dcec05ab-41e0-4a8c-855f-3424a1f0599b	45234	45234	1	72e0cb9ee2352bb187625599e63019a6	72e0cb9ee2352bb187625599e63019a6	0
189	1	bd21418d-74a4-4319-bd1e-a433ecfffc84	45224	45224	1	c858ba9998f86a55ffc66e9f1e658c67	c858ba9998f86a55ffc66e9f1e658c67	0
190	1	33c8f7e4-f0b3-478c-a7ad-5eda04291071	45160	45160	1	90f254edb54fb53c8bc71791883efe21	90f254edb54fb53c8bc71791883efe21	0
191	1	62468302-8e96-4670-8815-11b3a7e062f4	45090	45090	1	9b4140262df6781e9f56dbc6cf3a73e6	9b4140262df6781e9f56dbc6cf3a73e6	0
192	1	4f28c9ab-dbe2-4bc8-ab15-5147799df3ab	44902	44902	1	69d06c50b0688b56011217e85d7da2ec	69d06c50b0688b56011217e85d7da2ec	0
193	1	8b6dd8cc-2687-482d-bd12-0a9e498d9fe7	44788	44788	1	507eb201aa011441afc45b548571c36e	507eb201aa011441afc45b548571c36e	0
194	1	7047c4ab-a70a-459c-84bc-7ddaf479f3ee	42210	42210	1	07641916715f4969ce39ced76c2ba5a0	07641916715f4969ce39ced76c2ba5a0	0
195	1	1cfd6cf8-3b78-436b-82e1-47cb9c3af739	44622	44622	1	d6c308ceddf53ad4ad6bd53c571bcaef	d6c308ceddf53ad4ad6bd53c571bcaef	0
196	1	96fcc014-1dec-4a2f-8f53-76936d375e9c	44602	44602	1	768e63a3bbe2ba7659f8aab383979fd9	768e63a3bbe2ba7659f8aab383979fd9	0
197	1	55c1e6ac-0903-4d2f-badf-cf05af3e37cd	44806	44806	1	1059a9bafeca4672cebca8fd1383acfb	1059a9bafeca4672cebca8fd1383acfb	0
198	1	20a637f5-45f9-4461-8602-c74ea5350906	44824	44824	1	ee4aa007086d1d3d2a720ee7ec7add73	ee4aa007086d1d3d2a720ee7ec7add73	0
199	1	46509c22-667d-4a0a-8ff5-65cfbcc5f02c	44622	44622	1	892fa8cc36a361ec8215002b4a77d836	892fa8cc36a361ec8215002b4a77d836	0
200	1	3f7fa4bd-98f9-44d4-9edd-e450d469a054	44646	44646	1	cbf7a2e596b8bf9435cf901538f57657	cbf7a2e596b8bf9435cf901538f57657	0
201	1	b8d94755-d0c6-439d-a649-801508cfa9d1	44814	44814	1	1eeabe8a8690f514fb0ebca3ce747632	1eeabe8a8690f514fb0ebca3ce747632	0
202	1	5a5baaf9-0ea7-4481-bebd-fbab077ad614	44842	44842	1	dd08ef15ceecc146560b16261bf85bbb	dd08ef15ceecc146560b16261bf85bbb	0
203	1	4bf1da58-328b-480f-9690-4d8bd4342dc3	44964	44964	1	0cb6d3523593a661e5e22df6189913cf	0cb6d3523593a661e5e22df6189913cf	0
204	1	661eeb47-7446-4826-8662-515e7b3279ac	44960	44960	1	b51ec9c9ebe263cbc3cb16adaa98bb75	b51ec9c9ebe263cbc3cb16adaa98bb75	0
205	1	e015f4a0-c8e8-46a7-a28e-58d184802336	42320	42320	1	24abc943629ac69df4b8497ab335ef43	24abc943629ac69df4b8497ab335ef43	0
206	1	8396959a-9b2c-42ae-af87-de018ae36ccf	44902	44902	1	a91f270804d47f8df3bbfba8c692fd82	a91f270804d47f8df3bbfba8c692fd82	0
207	1	ea619558-8025-4371-9ec4-a2db573ca501	45012	45012	1	bf940937647fdc4d1e6dff177ccf2f0c	bf940937647fdc4d1e6dff177ccf2f0c	0
208	1	c691cce7-a3c6-4fd9-aef0-165c64de4a7a	44926	44926	1	0912afbc5ebf4697168c6a0c97e5180e	0912afbc5ebf4697168c6a0c97e5180e	0
209	1	a2e67815-3ce7-496a-8cc0-9503418812b6	44826	44826	1	1e8794b3081dd72aba68365c85de277e	1e8794b3081dd72aba68365c85de277e	0
210	1	30c2d284-3655-4b65-a55b-e0d9aa2ab82c	44878	44878	1	f25eac1b9857770573dc6bbd9586decf	f25eac1b9857770573dc6bbd9586decf	0
211	1	8f233135-d653-4715-8449-024eb4f1dfd7	44988	44988	1	b6fec71c594230ef02fedf44922662e4	b6fec71c594230ef02fedf44922662e4	0
212	1	13503297-4484-4383-b674-1c626f2b1ed9	45080	45080	1	dd99509ac659ec557c90785fd4c1df49	dd99509ac659ec557c90785fd4c1df49	0
213	1	26bfe37a-d176-424f-ba79-fdd28d350530	45016	45016	1	bfe51605da02e089799f5d48c3d0f6db	bfe51605da02e089799f5d48c3d0f6db	0
214	1	d9935feb-fed5-4504-9551-352e65ce2931	45034	45034	1	3bec7126ba19f7843351a6d6ee296b0a	3bec7126ba19f7843351a6d6ee296b0a	0
215	1	e91c232e-44db-4481-8ff4-7906c3feb255	44970	44970	1	926de00937945a2e0f5d338fcdcbc57e	926de00937945a2e0f5d338fcdcbc57e	0
216	1	10e0b0a9-7ce8-4369-ab67-5fe4ae2c3217	42652	42652	1	e3754c9845a162fd096d9ea0a28c9419	e3754c9845a162fd096d9ea0a28c9419	0
217	1	6edec221-52de-41b1-a266-7db9649d762c	45024	45024	1	8c8b908b7d6d263f77668c1bbffd2f53	8c8b908b7d6d263f77668c1bbffd2f53	0
218	1	38949fd1-1710-4977-9a45-8a68ff1856e8	45010	45010	1	e59462c6afe6750ad7b60f41f69b893e	e59462c6afe6750ad7b60f41f69b893e	0
219	1	e8d2567f-d822-4138-8ea5-81252f070f06	45096	45096	1	6118ee29f39f935fa87ae593fee5cda1	6118ee29f39f935fa87ae593fee5cda1	0
220	1	a0b51d04-2652-448e-a946-29352293f9e9	44968	44968	1	934f680ab846ba48ed5db90baa7acef6	934f680ab846ba48ed5db90baa7acef6	0
221	1	0168f139-8ce3-4650-b304-bbf4044ec1c4	44956	44956	1	7f2a1611c57047bf72acec4cbcd60b47	7f2a1611c57047bf72acec4cbcd60b47	0
222	1	66ddeec7-f611-4cd3-9d4a-2fad73bb26e3	45012	45012	1	cc0ce71eb6c260b866c19f5ff25643e6	cc0ce71eb6c260b866c19f5ff25643e6	0
223	1	a90106ef-32b8-452c-a208-a4c9e7e7ab27	44990	44990	1	64c58f56993ba6f2ff5646cda884af49	64c58f56993ba6f2ff5646cda884af49	0
224	1	5ee2772a-e34c-4d2a-be45-766c473401ea	44990	44990	1	23d6ac744ccc7d491acab782f89b9c8a	23d6ac744ccc7d491acab782f89b9c8a	0
225	1	56e1abab-bf99-4d3f-89f5-b6fb1b831bae	44866	44866	1	fcfb0bb5f3126c352eb1effad37acceb	fcfb0bb5f3126c352eb1effad37acceb	0
226	1	5085d6bc-f39d-4fb9-95d6-0aa50691cab5	44768	44768	1	f1c7793bbb82200b99dbf2fc3b20d47d	f1c7793bbb82200b99dbf2fc3b20d47d	0
227	1	bbf40df3-f5de-4add-86d8-93194916ee2a	18878	18878	1	e268dab4816decec8e8438219f26e78b	e268dab4816decec8e8438219f26e78b	0
228	1	b764d448-2075-4f19-ba4f-e574da34529b	43052	43052	1	73207d5e744f9c6cd82880502c6f6c2f	73207d5e744f9c6cd82880502c6f6c2f	0
229	1	506ab58b-3415-43c0-b2a0-fe13df5e919e	44436	44436	1	7d43c8b6cf373215cd9e03f4379677eb	7d43c8b6cf373215cd9e03f4379677eb	0
230	1	89d46c3f-213c-4e9d-bf96-b47852d260c7	44498	44498	1	caceeadce14cc31995c4da236092a66b	caceeadce14cc31995c4da236092a66b	0
231	1	f4a42da9-13c4-4b15-abd3-c664b8a653b7	44364	44364	1	39778a14a8363f66b2c464b5ff882b61	39778a14a8363f66b2c464b5ff882b61	0
232	1	fe55359b-b700-4ad1-95e1-b0fd89be6551	44388	44388	1	5c41da7047fa2c9b4c5b6e4c6d8e867d	5c41da7047fa2c9b4c5b6e4c6d8e867d	0
233	1	e9eac4e2-33de-4a43-90ad-154de9cd7587	44438	44438	1	a3bcf1f15a815282432fd6ca7c61028a	a3bcf1f15a815282432fd6ca7c61028a	0
234	1	eac9c261-d5ce-493f-a3cc-e5851c43ef09	44378	44378	1	b9c1f27e91df647acec58bd9da96fefa	b9c1f27e91df647acec58bd9da96fefa	0
235	1	b96261ad-5ed9-43b3-a813-0d69fe12b7ca	44574	44574	1	c12f68ae570856fe5f570e023698b4d7	c12f68ae570856fe5f570e023698b4d7	0
236	1	295a35fe-0db7-4860-9b3c-1c7d48a5f056	44470	44470	1	5a80c5d7711047c7a1ff5e3e9342c05e	5a80c5d7711047c7a1ff5e3e9342c05e	0
237	1	40668503-f244-407d-b5ab-0e292e10874b	44562	44562	1	9f84e8af4464129c76b8366f47d91a43	9f84e8af4464129c76b8366f47d91a43	0
238	1	fa63fd75-0070-4f02-8be5-1157d4ae5c32	44634	44634	1	e3aae728001fb72f363954bff2136629	e3aae728001fb72f363954bff2136629	0
239	1	8fa36d7d-00cd-420e-8fbd-beb1108d2898	43382	43382	1	20b6a6ef7f5b748fd38f52e3c1359b63	20b6a6ef7f5b748fd38f52e3c1359b63	0
240	1	58824d98-577c-4f90-a6f6-7a0e90b973d8	44728	44728	1	95af8da0679a3f3054b5bfc5a80c9f97	95af8da0679a3f3054b5bfc5a80c9f97	0
241	1	87f631fd-d115-40c0-8de7-b593ad42d176	44964	44964	1	8a43be8126ca37eef458047efad0944d	8a43be8126ca37eef458047efad0944d	0
242	1	698c12f9-448f-4e5a-94d3-735bba384275	44916	44916	1	148dbdffdb8cccd9740a9a24705cf1c9	148dbdffdb8cccd9740a9a24705cf1c9	0
243	1	3a36e983-4360-423c-b03b-1f2813f44e70	44902	44902	1	e2520c936e7faf681423dad0c85ba32b	e2520c936e7faf681423dad0c85ba32b	0
244	1	1223e993-7e4c-40d6-ab7a-d3f2d1bc4d44	45024	45024	1	ff356cb16b3a92ad3b0b70e4566a559c	ff356cb16b3a92ad3b0b70e4566a559c	0
245	1	b8637a2e-89ad-4b50-b4b5-9ddcc04087b7	44960	44960	1	2a0dac6aace9d3d72b898ee9a6085133	2a0dac6aace9d3d72b898ee9a6085133	0
246	1	b55b5e85-6c39-4ccb-bbbf-ad07d050dcc9	44776	44776	1	06a7df7a4f039e13c878635a89528448	06a7df7a4f039e13c878635a89528448	0
247	1	55f23b33-6a21-46d3-9000-0d116e8efa55	44822	44822	1	664c53fd851d85812544cd5edb5076e8	664c53fd851d85812544cd5edb5076e8	0
248	1	8ba7cd6d-15f7-4979-8f82-80d2d4fb002d	44866	44866	1	3d80292f44427d5710daccc29659e1dc	3d80292f44427d5710daccc29659e1dc	0
249	1	f6f31cb6-1dd4-4799-a400-24e7193bcd0f	44626	44626	1	07b41968c6da42aeac0afa531feee8a7	07b41968c6da42aeac0afa531feee8a7	0
250	1	d50cc393-d22f-442d-ae5a-6d3aeeff26d5	43674	43674	1	bc563cf6857291b3d28bb4404dc21e11	bc563cf6857291b3d28bb4404dc21e11	0
251	1	a222131c-8fed-4e29-975b-436808ab35d7	44720	44720	1	d455eae8ebcc1aea280045f6f42bad93	d455eae8ebcc1aea280045f6f42bad93	0
252	1	0113cd15-beb1-4a52-aa77-d341794f16d0	44658	44658	1	ca41bde7e62b30039defe14d784a9b2e	ca41bde7e62b30039defe14d784a9b2e	0
253	1	4a3a85e1-416f-46ad-ab8e-b3a405661a26	44570	44570	1	9792810bb375dfcb0975f8fb5163c76e	9792810bb375dfcb0975f8fb5163c76e	0
254	1	e0093e37-7e83-40b6-96f3-ab0263eae305	44396	44396	1	c0c1576ad0ed071b7509269e4f21f467	c0c1576ad0ed071b7509269e4f21f467	0
255	1	7fdf5d65-59ad-42c5-8355-eafa95850934	44216	44216	1	347437fb26feb01a0b6741de5a05551f	347437fb26feb01a0b6741de5a05551f	0
256	1	5af9fd02-6e39-457c-9b0c-1fdc3c16c130	44140	44140	1	8b342206917958bcf19be566fdb6c034	8b342206917958bcf19be566fdb6c034	0
257	1	b9715980-3ea3-4739-93f4-c525eb79e1f4	44156	44156	1	99561fc4d84e3d9c8777978b47ba0923	99561fc4d84e3d9c8777978b47ba0923	0
258	1	33881bf7-4487-4672-b363-2165f3d84499	44106	44106	1	3a89846b1476b1813acb8699cca85bb7	3a89846b1476b1813acb8699cca85bb7	0
259	1	0dd13935-feac-4d1f-b8bf-a75a766d53c7	43982	43982	1	7de4fc8829c49ec47bfebeda6488373e	7de4fc8829c49ec47bfebeda6488373e	0
260	1	fd105f79-a3ec-4a9b-8a45-f4be180c32a1	43986	43986	1	8c70366811b1a6b0f0364207e3aa72ef	8c70366811b1a6b0f0364207e3aa72ef	0
261	1	f79b611d-4609-49df-8e36-492e98fd7e8c	44130	44130	1	c552c0661226522ff155c6cff7853c1f	c552c0661226522ff155c6cff7853c1f	0
262	1	d06b5b4a-c176-4db0-b11e-2d2ad757a8ec	43754	43754	1	f5a3fb26034b1c1fa5aae39ce8ec3817	f5a3fb26034b1c1fa5aae39ce8ec3817	0
263	1	cff0fde5-d6c6-4aca-96a5-e0109e89ecab	43564	43564	1	d303c0b74d9016ebf998c28ebee28c04	d303c0b74d9016ebf998c28ebee28c04	0
264	1	7fae5888-36c2-4fab-a858-8071edf6abe8	43442	43442	1	8598ebb649cd0fad929cb7bd92ed8623	8598ebb649cd0fad929cb7bd92ed8623	0
265	1	9d2fb24f-bcb1-401c-bc7d-8dfb37f140ee	43378	43378	1	eaf72eae196f352839e818527cdda003	eaf72eae196f352839e818527cdda003	0
266	1	1e4de75c-4098-443f-a3e9-781b9c0d91e8	43306	43306	1	dbe67b846e44e0b80f15a463a0cea48e	dbe67b846e44e0b80f15a463a0cea48e	0
267	1	dbc4b348-73aa-4285-9df7-4832918af1d3	43342	43342	1	5c9bfec8339d5c21b67cafab20a05d95	5c9bfec8339d5c21b67cafab20a05d95	0
268	1	c833e46b-ea70-4927-922f-d446e373e5d1	43302	43302	1	fe7664cf5f02820369419ad915403a07	fe7664cf5f02820369419ad915403a07	0
269	1	e54301be-7f6e-4e42-83e8-7970802c4926	43322	43322	1	5f6b536eb7b2631f2d7da910abace98b	5f6b536eb7b2631f2d7da910abace98b	0
270	1	cbe929ca-68cb-446b-8ba3-60d666372043	43268	43268	1	9bb5d479d3ec0207b8b8a3aa1e411335	9bb5d479d3ec0207b8b8a3aa1e411335	0
271	1	1078c494-a2d1-489f-a04d-f0899084e1d2	43236	43236	1	deb392885a48665e7741338e06cd3959	deb392885a48665e7741338e06cd3959	0
272	1	d8dd01f8-569e-408b-99a0-8f197cc093a2	44344	44344	1	e0744c773214e1ca3f9292747c123387	e0744c773214e1ca3f9292747c123387	0
273	1	b72db9d3-e6d4-44be-bd50-33ced3dac248	43206	43206	1	183626be18f0a85f6e269becd60fb07e	183626be18f0a85f6e269becd60fb07e	0
274	1	04bc02ad-eea8-4ef0-8620-9e64e91c66cd	43028	43028	1	3abaf60a1a3c70c261274feb69fc20b1	3abaf60a1a3c70c261274feb69fc20b1	0
275	1	1e6a2b62-c742-419f-9e0f-1653c95cdc5c	43042	43042	1	00518b4d1fa7a84346ac3598b1489952	00518b4d1fa7a84346ac3598b1489952	0
276	1	56197c7b-487b-4294-884f-0d3d990f808a	42966	42966	1	516b89c87435d1355b6ad5135138b112	516b89c87435d1355b6ad5135138b112	0
277	1	7e38367a-1201-4e6a-8554-3298ebd0174d	42876	42876	1	49af6226bccb1e215362d2793c6aaa32	49af6226bccb1e215362d2793c6aaa32	0
278	1	203df1ad-c2ea-47af-b812-2c1aa899f669	42814	42814	1	4d6f0005e7427a55a6cb274bc449c4f9	4d6f0005e7427a55a6cb274bc449c4f9	0
279	1	f7ee8c58-3ffb-4ab8-bfa4-5be6e1cb5df7	42730	42730	1	0bd9709b687dfacae289a8a1b7e20fd4	0bd9709b687dfacae289a8a1b7e20fd4	0
280	1	e671a2f4-b62c-49b0-9c24-316459d277eb	42590	42590	1	1f71c9d1cca2d8a5b34ef886df8e5af7	1f71c9d1cca2d8a5b34ef886df8e5af7	0
281	1	eb5658d6-a0ec-4265-ad76-124b0e2dbf27	42420	42420	1	d14f719bdc1b2a2d50d8d7b44c19b2f8	d14f719bdc1b2a2d50d8d7b44c19b2f8	0
282	1	b9b66e00-8ee9-4fc6-821b-5b399067205f	42384	42384	1	40a6958a8c41bb655d7f932f406e7435	40a6958a8c41bb655d7f932f406e7435	0
283	1	a31a11f1-32ac-4f78-83af-93fe48593c04	44626	44626	1	e3be860e3752a758c9b1a91e24d8567c	e3be860e3752a758c9b1a91e24d8567c	0
284	1	6dd5f865-9a1c-434e-b227-6e84717ebaed	42372	42372	1	1036ea05e1bd75aa2967850b5f7272d1	1036ea05e1bd75aa2967850b5f7272d1	0
285	1	9ae66892-f305-41b3-be54-913c7e5f6e78	42262	42262	1	fdfc05f561d8fafc1b3af65211eabf6d	fdfc05f561d8fafc1b3af65211eabf6d	0
286	1	1802c2ea-b5f7-414b-8161-d01010cd0ea2	42056	42056	1	97413a034796a51f928b9bacb7260182	97413a034796a51f928b9bacb7260182	0
287	1	49e0e596-0032-48db-9b32-63f88463d5ce	42018	42018	1	012e3d15f03dd146980ecc115d3074d2	012e3d15f03dd146980ecc115d3074d2	0
288	1	a4033fe1-71ab-4f11-a637-a585037e7674	41796	41796	1	f8e786d1079230144815f9d2ec5a0279	f8e786d1079230144815f9d2ec5a0279	0
289	1	1b0e9b09-be9c-4562-ae4f-031d213d525d	41782	41782	1	65e4883cd32a54f175ec10d98f5e8358	65e4883cd32a54f175ec10d98f5e8358	0
290	1	26ca6f41-e094-4981-8564-9d561c01056c	41710	41710	1	6f3458fa129cca308afef34e58a51e81	6f3458fa129cca308afef34e58a51e81	0
291	1	f7fc7935-64fd-4b27-aaaf-269b3340e8cf	41632	41632	1	06bae94858b4fc82290696b93bc15132	06bae94858b4fc82290696b93bc15132	0
292	1	f19eec5a-d80a-43e6-a712-398a87bfd9d3	41454	41454	1	22703009595f2366e243a1032a0f8680	22703009595f2366e243a1032a0f8680	0
293	1	c80bc53d-173f-46df-9cb7-05daf8159a4a	41446	41446	1	c926cb82ba2e19680720860f95ebebd8	c926cb82ba2e19680720860f95ebebd8	0
294	1	8d98a389-2c35-4774-8930-c73059417baf	44836	44836	1	19f482d048c49cb1849eb72c1823f481	19f482d048c49cb1849eb72c1823f481	0
295	1	50629f77-8f53-4011-9ffd-d162175c172b	41590	41590	1	751391a0ac9fa4ab7a5815f9d6b4a093	751391a0ac9fa4ab7a5815f9d6b4a093	0
296	1	76f63581-ffcd-4d26-97d2-e22ab78a443e	41546	41546	1	b7a73b3d7bb0aec259b60c086c9bd338	b7a73b3d7bb0aec259b60c086c9bd338	0
297	1	a8619449-39ae-4637-8c9a-5cfa64e69368	41530	41530	1	8e6e75c7d2487f7741eccde87903125a	8e6e75c7d2487f7741eccde87903125a	0
298	1	5448340e-a522-4115-8f2d-f53556a0d386	41456	41456	1	9ca858564ead10d4485eda09a46bf72d	9ca858564ead10d4485eda09a46bf72d	0
299	1	16a4da90-2afb-49f6-bc11-07b6dfd6ec84	41510	41510	1	4c303fd0265f56ed4f0355d9a08fc184	4c303fd0265f56ed4f0355d9a08fc184	0
300	1	c57b7e25-4daa-46c9-90cb-e261567e686d	41508	41508	1	4b211ec3f46b7325ad714354dc3c32ef	4b211ec3f46b7325ad714354dc3c32ef	0
301	1	3122a4f3-4f6b-49bb-a8ff-35401948eba2	41488	41488	1	023ab1909b61827094fea0d3f1c0b89f	023ab1909b61827094fea0d3f1c0b89f	0
302	1	e5c5e4c6-f558-43ba-b3e3-7d8e7219da74	41374	41374	1	7daf01cbbd22f85c828ff8657a50c8f2	7daf01cbbd22f85c828ff8657a50c8f2	0
303	1	0308a179-e7e0-4597-b964-93e31f0c40c7	41388	41388	1	f90eaa44b05344d13e7279f4711ffb1f	f90eaa44b05344d13e7279f4711ffb1f	0
304	1	0998339e-ced8-4a00-af39-228d696289d8	41286	41286	1	1e7d01810b29bcfb9f1dbe54da956891	1e7d01810b29bcfb9f1dbe54da956891	0
305	1	fcca1ac2-6903-457b-8285-f833b20519de	45100	45100	1	05c90bfae2459d7ffac94ef0b315750c	05c90bfae2459d7ffac94ef0b315750c	0
306	1	5e0352c2-7724-4ec6-896f-447d52c42d16	41218	41218	1	c0bbb6a69d8b571c8052f472a0e1c0e4	c0bbb6a69d8b571c8052f472a0e1c0e4	0
307	1	b000fe56-a502-4db1-ae07-af5c76967a5c	41096	41096	1	1be2652ea0d5b9acc113df1e13e5599e	1be2652ea0d5b9acc113df1e13e5599e	0
308	1	bfd9ea2c-a6d5-4796-901f-651e2d15484d	40950	40950	1	f007519e8e2c6dfaff8cc7f69a83e333	f007519e8e2c6dfaff8cc7f69a83e333	0
309	1	2d153012-cfb0-4bd8-a09f-6978c1020ac9	40934	40934	1	5addf06b05f71def6f1d0ccc774fa497	5addf06b05f71def6f1d0ccc774fa497	0
310	1	1cfa29b2-ce24-41c7-a0fb-86c7e21bf848	40878	40878	1	a0cc6ae28d46b86a106dcd17e1490ec6	a0cc6ae28d46b86a106dcd17e1490ec6	0
311	1	5afc74aa-8b4b-47d0-9b1e-c271f7eaccc4	41020	41020	1	4336e43a334d370943fdcaa0eb694cf7	4336e43a334d370943fdcaa0eb694cf7	0
312	1	a1372273-0304-450c-9f40-2b76a17d6e21	40892	40892	1	14042595b76dac63bdd5a3e36fd36146	14042595b76dac63bdd5a3e36fd36146	0
313	1	2d1964cb-4a49-4efd-aae3-369e0baf7cf9	40692	40692	1	b5bb163d1d11bf4e94e76a59ad58a4b9	b5bb163d1d11bf4e94e76a59ad58a4b9	0
314	1	494dda8a-b833-438f-88ce-602243efea54	40576	40576	1	b27f15b47671fd78a78b14bcd8a26676	b27f15b47671fd78a78b14bcd8a26676	0
315	1	a552027d-5824-4ed5-ac1d-663a39b6c67c	40590	40590	1	b1a8d20aeb19fa251c4581e6948d0ebf	b1a8d20aeb19fa251c4581e6948d0ebf	0
316	1	5940cfad-3b41-4e8b-9f96-ac1a7c28bf1d	45262	45262	1	517ca714f00f55dfb63688c52472829c	517ca714f00f55dfb63688c52472829c	0
317	1	4a0c9370-94a9-4326-8b92-5cbc22c9795f	40528	40528	1	476ecce54a444e8c665260716cac14ca	476ecce54a444e8c665260716cac14ca	0
318	1	510c63d6-7bb9-4296-b271-bac552c80a0d	40340	40340	1	b72dea4e504b88fd8a2938feff864236	b72dea4e504b88fd8a2938feff864236	0
319	1	dc3c3223-04a6-4d02-b7a3-d9a702be9c38	40190	40190	1	86dafc8c6ab1ed150d693d01ebe7ac76	86dafc8c6ab1ed150d693d01ebe7ac76	0
320	1	bce641d6-17c0-419e-9b09-486eeab71438	40132	40132	1	1acb394c8eba0f907e8a28ac2a8c2113	1acb394c8eba0f907e8a28ac2a8c2113	0
321	1	704744cf-d950-4be6-a8bd-94c37d627cec	40052	40052	1	c4698216955920773e4a7e4f34af8520	c4698216955920773e4a7e4f34af8520	0
322	1	72db0209-0159-4a59-942f-4bc84b1540a3	39892	39892	1	d4ac8d8695ce313eeed7fa3622b1a4bb	d4ac8d8695ce313eeed7fa3622b1a4bb	0
323	1	74caf3bc-37f4-478c-b982-d53c7cf31d58	39864	39864	1	dfa7a8738bd9ee011f2716772283c086	dfa7a8738bd9ee011f2716772283c086	0
324	1	b32c7547-49c2-42d3-b3ae-6a0cff38b3a7	39786	39786	1	2d043bb008db8efbe50031e888473d61	2d043bb008db8efbe50031e888473d61	0
325	1	e51fa94a-fb58-44c5-a947-4c7a1b17cd4b	39928	39928	1	e03512ed07bad95caa8a448f38d336c2	e03512ed07bad95caa8a448f38d336c2	0
326	1	91b2855d-62bd-4d03-acfe-88da02109a0e	39802	39802	1	e6fe5bc4e0bf9c6b1561196ec1638be6	e6fe5bc4e0bf9c6b1561196ec1638be6	0
327	1	d7ca34eb-1cb2-432b-9208-c82cdf7feff5	45604	45604	1	c9091f09b4469c9d427d3fd6dfe57b2d	c9091f09b4469c9d427d3fd6dfe57b2d	0
328	1	b9330816-a30a-457e-886a-245c852a7893	39838	39838	1	d1465db20abe30a29b2181aa6f3a92e2	d1465db20abe30a29b2181aa6f3a92e2	0
329	1	d1a2ea52-9d33-47bc-9052-dfa1a7a11d77	39726	39726	1	360c7eb69043a73f92f5cbb445b8a2d9	360c7eb69043a73f92f5cbb445b8a2d9	0
330	1	0becaa02-16b0-42c5-9099-249e700af28e	39714	39714	1	812392380ec90a8aaa2b6d400d3317e2	812392380ec90a8aaa2b6d400d3317e2	0
331	1	892897f3-6878-4eaf-87da-365dcb3e404b	39524	39524	1	f88851d66831ba8f278ca85f7e01cfe0	f88851d66831ba8f278ca85f7e01cfe0	0
332	1	e33a869d-0ccf-4f80-98d8-628d54dde041	39532	39532	1	c3f3ad892248d9730fcbd9d0319ac6cc	c3f3ad892248d9730fcbd9d0319ac6cc	0
333	1	24e38a0b-22c6-4c9e-813a-d2cab629899b	39396	39396	1	f033685eb761b9cb18e54d0058ab8f41	f033685eb761b9cb18e54d0058ab8f41	0
334	1	1f7dc9c7-73f8-488b-9ce8-25fa487ddb29	39304	39304	1	d332d1c59fdbfbb6eeb01a06340da09b	d332d1c59fdbfbb6eeb01a06340da09b	0
335	1	130b2905-72b0-4065-986f-a8f6483b6795	39144	39144	1	9f6bcb51d7cab1aa5c6647b63e530cf8	9f6bcb51d7cab1aa5c6647b63e530cf8	0
336	1	92abc631-eb66-40ac-97b9-9a28e432fd6d	39080	39080	1	b92874ac094439e278818df5c92115b0	b92874ac094439e278818df5c92115b0	0
337	1	8c658644-99c7-4b0b-a2ad-60318d72a70b	38970	38970	1	d9fe6d8110f803cd0a5dae65e6f26dc8	d9fe6d8110f803cd0a5dae65e6f26dc8	0
338	1	92d99f3f-1862-45c8-825c-440234e9eb7a	21166	21166	1	364c39c55082b10cd60837265bf91ede	364c39c55082b10cd60837265bf91ede	0
339	1	af07146a-a537-44d6-b964-b93d71d1bc0a	45884	45884	1	5e7196e8890446af5d3f0b0d2a15b3fe	5e7196e8890446af5d3f0b0d2a15b3fe	0
340	1	c776a2a1-8077-4c30-b612-282b772e927f	39026	39026	1	5eafe191b5589fc677b2a31868df4616	5eafe191b5589fc677b2a31868df4616	0
341	1	f9fb14ea-e5f9-4029-b831-8d5dc0991082	38798	38798	1	27611ac624b5b9d214adefa64a5fb08f	27611ac624b5b9d214adefa64a5fb08f	0
342	1	0b715e87-4b04-48a3-ac47-23a9a4c8fda9	38806	38806	1	0bef7d256a50d242aad9958e7dc5dacb	0bef7d256a50d242aad9958e7dc5dacb	0
343	1	c530acb1-0ef1-4733-ad73-3802e86a630b	38734	38734	1	9fcf7659bc1dc28312bb63e1a47a557f	9fcf7659bc1dc28312bb63e1a47a557f	0
344	1	77d7d830-a4fa-40ab-b796-b8157a52aaa4	38602	38602	1	0d36449cd1cf8b145752c02a2d60be00	0d36449cd1cf8b145752c02a2d60be00	0
345	1	48d8354a-dea8-48ef-baba-44b83d3d9edf	38410	38410	1	e9c652befef27bad2da0a96008e850cd	e9c652befef27bad2da0a96008e850cd	0
346	1	2afd6429-5e73-47ec-abc6-4d1bd19a92b2	38258	38258	1	1c8f74da6984d40b8f4f3ad0392849db	1c8f74da6984d40b8f4f3ad0392849db	0
347	1	b2b26051-eb60-413b-8b7e-fca8ace85d6b	38174	38174	1	d98e198e6ca5047360dcac901c23f5c6	d98e198e6ca5047360dcac901c23f5c6	0
348	1	5a57bfad-a94a-4a34-adee-f6e2338c19b8	37820	37820	1	e330f5096a25c5586b1716ce360dfb4e	e330f5096a25c5586b1716ce360dfb4e	0
349	1	86f76bd3-ba5a-457e-b823-69f7b5468f60	37690	37690	1	55293d26d07ed289b1e3bdaeff9343bb	55293d26d07ed289b1e3bdaeff9343bb	0
350	1	ca6db771-836d-4452-a168-667f8a200833	46096	46096	1	91158e09fe7388853ea7d6c891ef0d57	91158e09fe7388853ea7d6c891ef0d57	0
351	1	2ef814f2-b57f-4fb6-951e-fe8cdced71a7	37588	37588	1	2be156007bd53f2a390c666fcb3611b2	2be156007bd53f2a390c666fcb3611b2	0
352	1	44d81a8d-d52b-4b7f-8df4-c4c77584de89	37528	37528	1	dbe9e8599016ac50ed4215bf82058302	dbe9e8599016ac50ed4215bf82058302	0
353	1	3f617095-a681-4904-8cbf-bcd5d7dd0ff9	37330	37330	1	4286d9103e7adf3b1afec1c5c2c9c259	4286d9103e7adf3b1afec1c5c2c9c259	0
354	1	079b04b4-9a96-4dfc-b786-cab51d4d95ba	37306	37306	1	e1d2f43d208a1db289f2f5e062134722	e1d2f43d208a1db289f2f5e062134722	0
355	1	8e7eb4cf-a5b9-40f8-9399-6bb107e1c681	37254	37254	1	b44c32ff3e68ea45bfb918ead85a0aae	b44c32ff3e68ea45bfb918ead85a0aae	0
356	1	483e4efb-a4d0-41d0-ae19-291fbd3c66df	37210	37210	1	f3156c6bdade06dffd13eb05c98a0711	f3156c6bdade06dffd13eb05c98a0711	0
357	1	c92450d5-aff3-44c4-8d47-a3b8e77317d3	37178	37178	1	c6be78c3c1c6fdd6c7f609e9a5303ac7	c6be78c3c1c6fdd6c7f609e9a5303ac7	0
358	1	e55ca32e-b87a-43cb-8018-bcdefc89bed7	37092	37092	1	ab102a1d7c910f830f66b1de52080022	ab102a1d7c910f830f66b1de52080022	0
359	1	1adb3606-7f7f-443f-b0f7-26440a612e24	37120	37120	1	8779e3251302dc4ed11a9609597a64a0	8779e3251302dc4ed11a9609597a64a0	0
360	1	043533aa-6370-4836-8fef-604e1d600f56	36998	36998	1	e5f7ee8cc2722dc8e54e7f944325e0ec	e5f7ee8cc2722dc8e54e7f944325e0ec	0
361	1	5cdb1dfd-c88d-470e-b5d5-e98cdb795705	46190	46190	1	d4f613332b35493aa736907c864fa263	d4f613332b35493aa736907c864fa263	0
362	1	66c59df1-09b6-45bc-8344-a49f2c877710	36998	36998	1	9da2b983e7d427b7ef38d294dbbf94d2	9da2b983e7d427b7ef38d294dbbf94d2	0
363	1	4b91f671-6a1b-40df-917d-2c5e417667e7	37026	37026	1	ed6b6cac74bd5256e4ff678bddd42d5d	ed6b6cac74bd5256e4ff678bddd42d5d	0
364	1	f21bf2b8-7cdf-49fe-8f4e-ff518471700e	36800	36800	1	dc8743720f7b60db5ecf64fbca402209	dc8743720f7b60db5ecf64fbca402209	0
365	1	39d5c059-9f1f-45cf-8995-e8eea160abac	36826	36826	1	89e857e8761c54a145e4af055f2a111a	89e857e8761c54a145e4af055f2a111a	0
366	1	92c12ea0-bbac-4643-90ef-596b0a5dabd2	36674	36674	1	68ce20de90d55611e0bca6f68951874d	68ce20de90d55611e0bca6f68951874d	0
367	1	c7c0efd0-0353-4580-9ce7-f7e0967e4e4f	36786	36786	1	4cbf68dcd83ec00bae93f42820e93af7	4cbf68dcd83ec00bae93f42820e93af7	0
368	1	c37b1717-94f8-4079-bc18-00925714e8f9	36600	36600	1	e37218bb10a7f1be457294fed2f3c6cb	e37218bb10a7f1be457294fed2f3c6cb	0
369	1	bbd74d71-9be3-48aa-9d91-c8a4e76dc852	36574	36574	1	18c0e9765158a36725704720e14c034f	18c0e9765158a36725704720e14c034f	0
370	1	32e8e50a-6194-408b-b9b6-07030c812ffd	36482	36482	1	7f6fa73e83f493f4f507cd64f48408a5	7f6fa73e83f493f4f507cd64f48408a5	0
371	1	80472d5c-4930-4371-8a1c-e91758915bda	36472	36472	1	4a83313bb5baae0854ec8bb1f89cf24c	4a83313bb5baae0854ec8bb1f89cf24c	0
372	1	c06ca2ec-bdf9-47fd-8561-8a21fde1504c	46284	46284	1	a6ec56abf0d52598585e62b384a7dab3	a6ec56abf0d52598585e62b384a7dab3	0
373	1	3cb297b2-d2c5-4df1-89dd-f11ae4efcff4	36338	36338	1	25f90a5ab9747897d8be19677e6cd48d	25f90a5ab9747897d8be19677e6cd48d	0
374	1	a9c9de02-11ce-489d-82c6-f9997fd0bd8b	36328	36328	1	f908b3a11e21c3d113480ab46cd38546	f908b3a11e21c3d113480ab46cd38546	0
375	1	918a17dd-f120-4045-9137-57ddfc28315b	36270	36270	1	005bc510aca46209d6afa7b2c4287787	005bc510aca46209d6afa7b2c4287787	0
376	1	9cce22af-260e-4b83-bceb-1d3bcc28249e	36082	36082	1	440318bb01419f446db9bafb5a61d31b	440318bb01419f446db9bafb5a61d31b	0
377	1	aa40e194-a66d-4705-a5ea-5032b2e793b9	36022	36022	1	d93c0338b2d4fea6fb92e7af0e91bb60	d93c0338b2d4fea6fb92e7af0e91bb60	0
378	1	5174cf1e-b874-4bbc-9ba0-34d875426422	35994	35994	1	a10cdb95973211dbecdfac86b13c50d6	a10cdb95973211dbecdfac86b13c50d6	0
379	1	37a81ed6-5c49-4bda-b515-5837aa6d2c0c	35944	35944	1	9f343a6ee6b9a24605b53891740517ed	9f343a6ee6b9a24605b53891740517ed	0
380	1	812b2e04-45ab-49ae-bbf7-e04fdd3c7309	35808	35808	1	01c61e8cdf84f8ce6fbf390ea1b43894	01c61e8cdf84f8ce6fbf390ea1b43894	0
381	1	c2fb756d-3161-481c-8507-6bf3df2ecf97	35900	35900	1	068680c79b7612a3ad69f586499f984d	068680c79b7612a3ad69f586499f984d	0
382	1	c93a8f27-7796-4462-b9f9-87eee8141b5f	36010	36010	1	f146b2c2d32848696879843e7d2ceff4	f146b2c2d32848696879843e7d2ceff4	0
383	1	98c8a120-b839-4df7-a068-d01a2d21b7c0	46516	46516	1	c4f3177e749e25d111c4c5debe9fcbcf	c4f3177e749e25d111c4c5debe9fcbcf	0
384	1	3fd8d10a-98d1-4861-a4ba-e1770185e106	36032	36032	1	d771074b976f788053c0e47123996394	d771074b976f788053c0e47123996394	0
385	1	122c6f8f-56f0-4bd9-82cc-83af8ea29bcf	35932	35932	1	a8db3cb1710b91b4394d6c5a355086ec	a8db3cb1710b91b4394d6c5a355086ec	0
386	1	1cfe3816-3519-4f50-9cb4-02cd34140b10	35938	35938	1	435110c40019a7a7f51c4e348097e176	435110c40019a7a7f51c4e348097e176	0
387	1	8ce3bc10-6757-46ed-a31d-69a954d0613d	35988	35988	1	8885ccaf8fdb427f0e6c5c61c5a432b7	8885ccaf8fdb427f0e6c5c61c5a432b7	0
388	1	c7c221f4-c82d-4139-be4c-db20d20fbfef	35988	35988	1	1fea4363b7b4a7599cdf9cd675a4ed87	1fea4363b7b4a7599cdf9cd675a4ed87	0
389	1	a46d3c42-5d62-4ee9-90d8-aa5f0d0d32e9	36004	36004	1	10de95055127a4d981112821e1c6a897	10de95055127a4d981112821e1c6a897	0
390	1	b8a06fe3-4f00-428e-b925-9e41eac6fc39	35932	35932	1	ea4073a734a07a74ad1c2d773dd915b1	ea4073a734a07a74ad1c2d773dd915b1	0
391	1	dcc24dbe-4b8a-4eca-b627-79d8fc2d433a	35832	35832	1	78db6985f7bcb8993fdbb8be8f727edf	78db6985f7bcb8993fdbb8be8f727edf	0
392	1	a5d49f13-af53-43d2-98d1-e5cf06d10f17	35824	35824	1	e1b5eaed201d56c97001845563a39ec7	e1b5eaed201d56c97001845563a39ec7	0
393	1	e34273fd-1bf5-40e5-a7aa-dec0e728f598	35868	35868	1	719e91b6ea3c9c7ef32c6e8dc478a71b	719e91b6ea3c9c7ef32c6e8dc478a71b	0
394	1	703d13e2-5427-4c74-a13b-1fc527a663a0	46508	46508	1	c6ad3f1ed0f7993edc0400d2d57aa891	c6ad3f1ed0f7993edc0400d2d57aa891	0
395	1	e688d9fd-890f-4bd7-ad83-651a8da334c5	35916	35916	1	183a0a1acd030c767117f62f1de5fa26	183a0a1acd030c767117f62f1de5fa26	0
396	1	cff8fba9-0b76-40de-8393-bd5ff99b516a	35808	35808	1	e0a00ecf0cf5bf7d3f1d8f32f4f5f65c	e0a00ecf0cf5bf7d3f1d8f32f4f5f65c	0
397	1	e81489c6-10c9-4476-82cb-9350c2e6ab5d	35862	35862	1	4a7737e4e892216ade0d9b289cbbee04	4a7737e4e892216ade0d9b289cbbee04	0
398	1	ad9f07f0-7179-4363-8855-05f3279cf13e	35778	35778	1	74b86c5b348b0aaa67357557a1295277	74b86c5b348b0aaa67357557a1295277	0
399	1	c6f3e455-02e8-4059-87eb-cb448f9a8cb0	35918	35918	1	5973b609d0f8c5a98dcddf336808b405	5973b609d0f8c5a98dcddf336808b405	0
400	1	de6852da-f847-4638-859d-ff33b9d1fb7f	35942	35942	1	8208254387009e10777a7466dae752f7	8208254387009e10777a7466dae752f7	0
401	1	66b2f414-b26c-40ed-a541-fadae5c2b82b	35828	35828	1	da36443cacb2cd1527c6f4f3238a49c3	da36443cacb2cd1527c6f4f3238a49c3	0
402	1	88c04e07-0656-4f2d-8556-3bb9f404bd64	35786	35786	1	4236e4d2ff65d751c99a648c4d70db6b	4236e4d2ff65d751c99a648c4d70db6b	0
403	1	b8222e8a-9e9b-4b1d-a027-a4f2171e1de9	35602	35602	1	08132f7ab82d8a64703bcba5d77279e9	08132f7ab82d8a64703bcba5d77279e9	0
404	1	e93e125d-c8f1-4654-a4d8-fbb05dc43259	35560	35560	1	4c05d13cdcdda7289eca44a8607bbe23	4c05d13cdcdda7289eca44a8607bbe23	0
405	1	8b3ac7d4-d746-4394-af52-4d1dfaba35a1	46488	46488	1	04877f4f362b63c191866511225cd33c	04877f4f362b63c191866511225cd33c	0
406	1	ca877375-8044-40d1-a9c7-54cfa910842a	35456	35456	1	dc8bdc5ee8308b5543cde454ea8c6fba	dc8bdc5ee8308b5543cde454ea8c6fba	0
407	1	bf3ace3c-cdbd-4ffc-8125-2d97d4f5fb7a	35352	35352	1	d7a7fd2161fbaa852c93d3c1c4164193	d7a7fd2161fbaa852c93d3c1c4164193	0
408	1	162a5d4a-b8fb-4825-9b5c-41f7a5259d24	35134	35134	1	577a8c05c5f517ef20ea816a3f50ffbd	577a8c05c5f517ef20ea816a3f50ffbd	0
409	1	961141d2-e08a-42c5-b605-1b82e5ba9d93	35090	35090	1	c91e03fb7a661de525ad901de59e9f27	c91e03fb7a661de525ad901de59e9f27	0
410	1	36af69d9-498e-4873-9984-957b9b449823	34960	34960	1	daf1ae112b67e6d28d8c4eca34bb40b2	daf1ae112b67e6d28d8c4eca34bb40b2	0
411	1	215db2c0-1708-4586-ba22-7a49f9d64c8d	34800	34800	1	bb6c8a4a4b886786fdc730c5abef08d2	bb6c8a4a4b886786fdc730c5abef08d2	0
412	1	5c4c567b-d9b9-4f6d-b3c1-5d885f5ec492	34588	34588	1	a58ca9c5cd3aedd5ad5f103de3b1668a	a58ca9c5cd3aedd5ad5f103de3b1668a	0
413	1	d6d0b460-74ba-4d6f-a3c9-87f7ca8af39d	34440	34440	1	bf2e0c565ae52940553bae484c92a5bb	bf2e0c565ae52940553bae484c92a5bb	0
414	1	98d55971-1063-4531-adf5-00ec2ccc0564	34398	34398	1	daabbe45e847ea77deb8306a8b1ecb29	daabbe45e847ea77deb8306a8b1ecb29	0
415	1	5f4f8b41-ffcb-494c-aa41-32828f4cc461	34312	34312	1	9567f808394b7bbaf8e6c0213c3be4d8	9567f808394b7bbaf8e6c0213c3be4d8	0
416	1	52f87765-aa60-4114-babb-1777312e4a65	46708	46708	1	0125a9d05a27e774741425f42abd50fe	0125a9d05a27e774741425f42abd50fe	0
417	1	3f334b24-bcb1-4044-aacf-0de74981ae1e	34212	34212	1	d9ecdfcad02d6ba7bd436a4680338147	d9ecdfcad02d6ba7bd436a4680338147	0
418	1	19216914-9eac-4bc8-a67f-98c4b170a356	33884	33884	1	205c3ae1a3a216a68eb7359a0ba98d00	205c3ae1a3a216a68eb7359a0ba98d00	0
419	1	19f0de22-a882-4589-829f-72aeb4850b81	33832	33832	1	2a725fed58ce330261ee94d8a7add072	2a725fed58ce330261ee94d8a7add072	0
420	1	5e3abf3e-7628-4cbf-850e-69a380fb112c	33624	33624	1	eeb2cea632cd8ec64b724444b4c00cdd	eeb2cea632cd8ec64b724444b4c00cdd	0
421	1	b35c466a-f68c-4d32-adcf-6f82bef9a39f	33478	33478	1	7a2013db6f3242df64ac5e41fc0d9fd0	7a2013db6f3242df64ac5e41fc0d9fd0	0
422	1	2a17f315-ee36-42b2-bc90-008b1cb7fd39	33326	33326	1	239df0464fa1168117d173d16a88af8f	239df0464fa1168117d173d16a88af8f	0
423	1	5bef20d0-b02d-49aa-891b-77e072140cf2	33058	33058	1	89b636fbcd5cbb5ce23e89d0bcc9c8c0	89b636fbcd5cbb5ce23e89d0bcc9c8c0	0
424	1	c33a278b-63cd-41db-988c-07906398ea90	32922	32922	1	e3c94844b541fd430587ede5e4de5754	e3c94844b541fd430587ede5e4de5754	0
425	1	8d675477-c455-4208-b293-43147dc20b75	32806	32806	1	116be51126569fc5c8b40c033f6d9161	116be51126569fc5c8b40c033f6d9161	0
426	1	4183885b-f648-4c7a-85c5-b907da4fe529	32680	32680	1	a31b17497fbd3903457db1efe97c96b9	a31b17497fbd3903457db1efe97c96b9	0
427	1	df4c67b3-09ae-4a0e-a3d9-29affb0a85a2	46762	46762	1	768f24ca8662695be4981331ce00ea78	768f24ca8662695be4981331ce00ea78	0
428	1	5dd010df-a513-45d9-b8d8-8628f3038a71	32308	32308	1	aab438235163b198521d92b6f553d9c2	aab438235163b198521d92b6f553d9c2	0
429	1	8a1f74be-b7c9-4742-b937-f36984376663	32122	32122	1	ed36f67c753be12265036c68bf102cc1	ed36f67c753be12265036c68bf102cc1	0
430	1	24f689e4-7366-42d8-be99-03f168247c2a	32104	32104	1	b806f334886de56d76e82f5165865725	b806f334886de56d76e82f5165865725	0
431	1	2e749b9a-7e23-4724-9368-7f1b3860f4c5	31900	31900	1	ca57601a594785c06f74df9c10771873	ca57601a594785c06f74df9c10771873	0
432	1	115070a7-7327-46ef-ad6b-9aeba610aa66	31678	31678	1	bbf0f2187ecfc14d88e935348e7beed7	bbf0f2187ecfc14d88e935348e7beed7	0
433	1	b0ddaa8b-9b28-45b1-973d-a55981585c27	31644	31644	1	ccb3ee24d71f56f5ee4b3bd2936d24a4	ccb3ee24d71f56f5ee4b3bd2936d24a4	0
434	1	fc0616ea-744b-4b5a-b1d2-39575e153e8b	31348	31348	1	bd9aa3ee3a6292f512f36079bb8981a7	bd9aa3ee3a6292f512f36079bb8981a7	0
435	1	311aad79-5264-470f-8090-b09373dcc580	31158	31158	1	41407c59c5d3a01db138edd3ee0f8a81	41407c59c5d3a01db138edd3ee0f8a81	0
436	1	9de13e0a-f986-4f3b-8a9c-7320a5b83932	30866	30866	1	98c165f6f62b999fbb0c30090f24a614	98c165f6f62b999fbb0c30090f24a614	0
437	1	a95db791-da7b-43fa-9227-1df3248bae3f	30578	30578	1	87e128f23963ca746f2062b1b138b97f	87e128f23963ca746f2062b1b138b97f	0
438	1	81d032d4-1f2f-4ce2-8e90-6e89f530d92b	46760	46760	1	de7e1323851c1fc3d019084814dcc465	de7e1323851c1fc3d019084814dcc465	0
439	1	b92a3de3-c8f0-414b-9d6e-2eed64d5e7a0	30382	30382	1	ea8253868b01c87657ae3e946cdceab6	ea8253868b01c87657ae3e946cdceab6	0
440	1	82079fe6-7844-48b8-9f71-e6bc96e48c9d	30114	30114	1	e3dab1128e3024d08081a9a32468eee3	e3dab1128e3024d08081a9a32468eee3	0
441	1	351dc15d-1fb8-47d2-99ac-95c571419b39	29782	29782	1	acb40ee16abcd29a4acbdd55d61b7e72	acb40ee16abcd29a4acbdd55d61b7e72	0
442	1	ca74fab2-12cc-46d0-a4e1-277c3246409d	29526	29526	1	1fef391948afa196dc20c1a3ffba8b5c	1fef391948afa196dc20c1a3ffba8b5c	0
443	1	9c8c2201-fa4d-4f9b-9e19-5b6b14edf9e8	29356	29356	1	4a211fdd0263cdd736971ce8152aaaae	4a211fdd0263cdd736971ce8152aaaae	0
444	1	26eefa7a-0e8d-4ffd-8cd5-7bfad5489a11	29138	29138	1	0d778f664674f0c087abe6f5c4ddc7c9	0d778f664674f0c087abe6f5c4ddc7c9	0
445	1	8ac660c0-347d-44ce-b511-96077049c4b8	28930	28930	1	ca5beed1fe5842263ca996cb61965ab5	ca5beed1fe5842263ca996cb61965ab5	0
446	1	b608d8e8-e8cd-4b39-8e61-5f3e4264fd46	28882	28882	1	940579b35da1b6eef88088a414f9c8aa	940579b35da1b6eef88088a414f9c8aa	0
447	1	88fbd031-c88d-44e8-b012-84b1f6222671	28868	28868	1	3375e44664f1d66908ba4efaf8f62bbf	3375e44664f1d66908ba4efaf8f62bbf	0
448	1	33e936b8-a172-4e21-a23e-8858ffa26bb5	28764	28764	1	a3d9358b53f8a5ccbcbfd5d35ce3b192	a3d9358b53f8a5ccbcbfd5d35ce3b192	0
449	1	0f70bdef-11ea-4d94-a453-ca7e7a40eb27	23292	23292	1	cd2ee5120c99415c08e12587bdd41ecc	cd2ee5120c99415c08e12587bdd41ecc	0
450	1	b4187dbe-da7d-4476-a8c7-78798198b980	46834	46834	1	211f171089e972f0b1cfa73232ebb367	211f171089e972f0b1cfa73232ebb367	0
451	1	2761ffbb-1384-45a9-8038-9eb2d30b98c6	28472	28472	1	d686ea730df47d76bee5ebaaf9cde486	d686ea730df47d76bee5ebaaf9cde486	0
452	1	e9ae172b-57be-43ad-b06d-fc55ffa61f3e	28506	28506	1	405e2b91f94456e6010786500c24f874	405e2b91f94456e6010786500c24f874	0
453	1	272ad35b-eb72-4eb8-8d56-d877ed84f69c	28410	28410	1	3438286b6f07a32f51fe67e3bcc67744	3438286b6f07a32f51fe67e3bcc67744	0
454	1	c8171c85-d4b0-4dd3-92c9-34784c985179	28060	28060	1	51cc23e7e077b9a56348942e40771b4e	51cc23e7e077b9a56348942e40771b4e	0
455	1	921ffd41-4250-45da-9ccf-ad8af56d3d70	27834	27834	1	4d8ff60dbe08895ae63fc00c391e9223	4d8ff60dbe08895ae63fc00c391e9223	0
456	1	db72a028-8f01-4c15-b682-8cc38d05fe3b	27690	27690	1	b4b09b7baecd13e30dc27b38b732ab9c	b4b09b7baecd13e30dc27b38b732ab9c	0
457	1	bc5490b8-3ccf-43bc-ab9b-79bf5533e92a	27554	27554	1	98b010b8e60c21177afb608a9b2ebe76	98b010b8e60c21177afb608a9b2ebe76	0
458	1	20a808dd-5e3c-441f-b66a-182b7a434864	27546	27546	1	031910044b3358d7f1e5c69a222a9d61	031910044b3358d7f1e5c69a222a9d61	0
459	1	a8fc9b6c-d04c-4904-9fd4-49a2a067516a	27232	27232	1	235a2b053cc1f3bf9bc0d2ec8bbc914b	235a2b053cc1f3bf9bc0d2ec8bbc914b	0
460	1	dbba38fb-f14d-45cc-94a9-35dae385515f	26574	26574	1	e10060b3d71d4d37263a5c21250b665c	e10060b3d71d4d37263a5c21250b665c	0
461	1	96a00140-56d4-4177-a711-7e47f5a606f7	46920	46920	1	e57930566825a2f7ff11806a5caca2b1	e57930566825a2f7ff11806a5caca2b1	0
462	1	ae0987b8-a76a-4f65-94d7-84141e21cc15	25940	25940	1	912790b5ede92a23a75e511b18834dbc	912790b5ede92a23a75e511b18834dbc	0
463	1	d62faa96-027f-4910-8679-d35699740925	25278	25278	1	114750ae3cf38de12c1017af7a808bea	114750ae3cf38de12c1017af7a808bea	0
464	1	1459fc94-0258-461e-8fec-a06c0ffb3b8e	24500	24500	1	560d505228bcae724aee0d72ff3da486	560d505228bcae724aee0d72ff3da486	0
465	1	3bbf184c-d333-49eb-ac0b-8d316748f63b	23704	23704	1	5bb6d3c8c17efad61ef8c408400a69c3	5bb6d3c8c17efad61ef8c408400a69c3	0
466	1	68992625-2ffc-4e0a-939d-218f91e14cad	22694	22694	1	10a876108cb09b8da0b681fd9290ebf3	10a876108cb09b8da0b681fd9290ebf3	0
467	1	6824210e-0d6a-47f8-a357-5ef77c77a67f	21582	21582	1	2b1877cd929d563ceb7ffb5b3bf357cb	2b1877cd929d563ceb7ffb5b3bf357cb	0
468	1	c502e092-6409-4f86-a923-743606044d91	20198	20198	1	b4f26668b102f9eca8419c26eb9c12cd	b4f26668b102f9eca8419c26eb9c12cd	0
469	1	07823ac3-3611-4711-aa71-01267fd21a12	46898	46898	1	f555c6524286ba659239c6e53caf520b	f555c6524286ba659239c6e53caf520b	0
470	1	db74393d-d5ac-45c2-ab52-bc5ea4b87970	46994	46994	1	0717fd8362ceff4c118c791285ef1993	0717fd8362ceff4c118c791285ef1993	0
471	1	5f68c0cd-3c07-4f69-865f-72f0f48c6405	47126	47126	1	5768a5aac0ec590f75cbb04c0c2177d3	5768a5aac0ec590f75cbb04c0c2177d3	0
472	1	0c0e76bf-8011-491b-91df-3c72f2c584f6	47238	47238	1	c8cd1c4bbac3459d07b7370597a3eb8a	c8cd1c4bbac3459d07b7370597a3eb8a	0
473	1	407560a2-e1b5-4263-bac5-3a1f9f0ccef9	47248	47248	1	2f7c19201fed2d349b60d89de60020eb	2f7c19201fed2d349b60d89de60020eb	0
474	1	44481c48-8e82-4717-82a0-c1b10ad79819	47378	47378	1	924b84e486fc21badc811a59ba226872	924b84e486fc21badc811a59ba226872	0
475	1	d9245745-0c2c-4303-80c7-db5f4f07c0a7	47292	47292	1	e9a6b0fddb38386eed7db193e7e5a6f2	e9a6b0fddb38386eed7db193e7e5a6f2	0
476	1	416180d2-afa9-42d6-b0cd-3e315768ea71	47436	47436	1	dae60720ce22eed9105731e9168de7bf	dae60720ce22eed9105731e9168de7bf	0
477	1	8a9c5677-1e89-4684-a197-02bed1f416fc	25478	25478	1	dfa0c0d7052637991e040289787b39e4	dfa0c0d7052637991e040289787b39e4	0
478	1	e467bf61-b7f5-40e6-a822-60fe744b7895	47620	47620	1	ea14bf3a57a682b5cc5aae7d19ecdc5d	ea14bf3a57a682b5cc5aae7d19ecdc5d	0
479	1	50e12026-2e48-4e0c-bc26-71f6fce063fa	47658	47658	1	5e6d40c6e12e5e6c7fdf59e0db30f081	5e6d40c6e12e5e6c7fdf59e0db30f081	0
480	1	51ebff35-c6c7-4d91-af6c-9ee9f33cd9e6	47972	47972	1	1132e40a8443dd8d64f92e2e8fb5849a	1132e40a8443dd8d64f92e2e8fb5849a	0
481	1	f5001ddc-050d-4698-9d66-05b45d53a3e1	47996	47996	1	c85e4a7620ac211d99e6ff862708160a	c85e4a7620ac211d99e6ff862708160a	0
482	1	5efae0ed-2620-4b45-9700-347efeb9e069	47964	47964	1	4a7f7bf1014cb6779d756e70c8cfe0e5	4a7f7bf1014cb6779d756e70c8cfe0e5	0
483	1	8b8d3ef1-da94-4031-88e3-967c986f7669	48168	48168	1	8c1720260ff7e3ed696e99cd7a8f72b4	8c1720260ff7e3ed696e99cd7a8f72b4	0
484	1	4350e257-8d5d-4ec7-a566-ea8519f5de62	48394	48394	1	2e2926df85c15066234546827e2f3809	2e2926df85c15066234546827e2f3809	0
485	1	2d11b9bf-6886-4911-ae5f-8d27357e4da0	48602	48602	1	1ada11f7c7ffae9595fa039d68275554	1ada11f7c7ffae9595fa039d68275554	0
486	1	ad6c51ea-c992-4ce4-8c91-8b4767d11bfb	48572	48572	1	b257e775ff22b5361e71e4c1dfc934c4	b257e775ff22b5361e71e4c1dfc934c4	0
487	1	55043f1d-d897-4766-bdba-da970cdc7fee	48628	48628	1	f5091fd6839fa743c40cbd3db3555b20	f5091fd6839fa743c40cbd3db3555b20	0
488	1	48834b17-5626-41b9-b5ef-af8bab41cb6c	27686	27686	1	ef3813460bf6a6334b7643ea7a78d801	ef3813460bf6a6334b7643ea7a78d801	0
489	1	4d9a8dc5-8800-41e6-b34b-1d0786c49a24	48806	48806	1	acd445956e4d57cb1d083476504f57c6	acd445956e4d57cb1d083476504f57c6	0
490	1	c0d34517-b022-48bf-95a9-c4af6f36dbbf	48948	48948	1	6ea83ed53d7a80954bbf7ce434dedeee	6ea83ed53d7a80954bbf7ce434dedeee	0
491	1	14064f15-7b44-4586-8182-2ed1124cbcf2	48858	48858	1	7a13b8aa305aff7e91f4045fbfd6bf0d	7a13b8aa305aff7e91f4045fbfd6bf0d	0
492	1	d1e9de59-40d6-44bb-94d0-9a7c010c7cf0	48674	48674	1	5a8d7171fef9f4177164facc73705bd3	5a8d7171fef9f4177164facc73705bd3	0
493	1	0082cd3c-a252-4d77-8beb-c6e5b4055d80	48510	48510	1	4c437e962d37521376a0c59623722b8b	4c437e962d37521376a0c59623722b8b	0
494	1	47068a29-6b9d-4c8e-9860-10bab7a2bc24	48546	48546	1	b45c7d0520407aaab4d9be869130305a	b45c7d0520407aaab4d9be869130305a	0
495	1	4a394461-cb32-4b71-89d8-596d732a100f	48390	48390	1	21facac8f30b10e17950ec80e895f474	21facac8f30b10e17950ec80e895f474	0
496	1	99e4fdc1-0e0d-42c6-996d-ca213d7192a8	48364	48364	1	397a06354a005775c6594cd3aba34f7f	397a06354a005775c6594cd3aba34f7f	0
497	1	d01b6396-30cc-44d3-bb3b-27270c070094	48276	48276	1	8a5700f2c304af74c8a733d6dc501abb	8a5700f2c304af74c8a733d6dc501abb	0
498	1	913ca7a0-342b-4511-a3aa-6c3c648ae9d3	48380	48380	1	4931aa6bd4df47353776792fc174ab5e	4931aa6bd4df47353776792fc174ab5e	0
499	1	a81d96c0-85f3-48a9-a33f-94f9d34e13eb	29850	29850	1	451e1002e89a03c346f1d1e0d0894362	451e1002e89a03c346f1d1e0d0894362	0
500	1	6aa27e57-7cd3-4c93-a613-07b62f9596cb	48458	48458	1	fe00c1074901cd3379dff2a5876664cc	fe00c1074901cd3379dff2a5876664cc	0
501	1	2b4cc24e-01c9-42d4-a677-39780d7cf9e8	48602	48602	1	09715da803d890e9128e4f0e9c9ddec8	09715da803d890e9128e4f0e9c9ddec8	0
502	1	3f7a8227-22e5-436d-87ea-19174110513a	48640	48640	1	689159d014b123cec5a36df8dd1ec2ef	689159d014b123cec5a36df8dd1ec2ef	0
503	1	90feb213-d58a-4642-a929-736045138538	48720	48720	1	25489364e6539f9a23338be820c12a72	25489364e6539f9a23338be820c12a72	0
504	1	4810cc35-8005-4c50-a0ec-43d0b49f8784	48844	48844	1	8637e29bb61833941173966b05231351	8637e29bb61833941173966b05231351	0
505	1	747a9129-5cb0-4bb9-b94f-58ad7eadaece	49038	49038	1	dcc3798bed09738e69b43963cf4fdf97	dcc3798bed09738e69b43963cf4fdf97	0
506	1	e0e03ccf-27ec-40f5-ba1d-cc3f475a090f	49180	49180	1	c8860359cd0596a39e358f2f2f1db34e	c8860359cd0596a39e358f2f2f1db34e	0
507	1	ae9b33e1-5a49-4821-911f-1fd3998c0e6c	49116	49116	1	71149323b78649216ca35b198110fd31	71149323b78649216ca35b198110fd31	0
508	1	a88587c8-025b-4cce-9c4b-b38c89702b0e	49168	49168	1	86eeb835e96156ddf953a5e22dd77777	86eeb835e96156ddf953a5e22dd77777	0
509	1	cc1f5e96-d8e6-4b7b-81ad-842f09cf76ec	49322	49322	1	9f8a1387bc367ae7bda7a131d9208707	9f8a1387bc367ae7bda7a131d9208707	0
510	1	af79262b-c371-47e9-8c82-8f145ac21e0f	31956	31956	1	e1b078b24ead20e48f41c038ff59dbb1	e1b078b24ead20e48f41c038ff59dbb1	0
511	1	670788ab-ae50-4f5a-88cc-9713567707ae	49166	49166	1	720da7cfdc5ab030869f705ed3f1e916	720da7cfdc5ab030869f705ed3f1e916	0
512	1	b77f3db8-72ba-4f6b-bcad-a3165cb72f57	49144	49144	1	714faac8281688f2e3184078354c5b58	714faac8281688f2e3184078354c5b58	0
513	1	89451d82-6a8e-4bb5-a32b-6274e8656efe	49112	49112	1	0f1fb770c8625b3b8662013682aa0824	0f1fb770c8625b3b8662013682aa0824	0
514	1	cd8353f1-a207-42df-9021-8a7d1e41bf54	48966	48966	1	6bcd9cf81092c6f2b9aa1b283a88f3a5	6bcd9cf81092c6f2b9aa1b283a88f3a5	0
515	1	d6884f51-3f25-41a3-8c7d-9ed071da3f09	48816	48816	1	ee61b87e2796cc2c1f45b3908ddc62b7	ee61b87e2796cc2c1f45b3908ddc62b7	0
516	1	67b04b83-953e-4b17-b191-4aadac183620	48792	48792	1	321cc3598c938ec3368c3c3267d4b55e	321cc3598c938ec3368c3c3267d4b55e	0
517	1	9f917ff4-5f93-411a-9529-f9ec974fc2ba	48764	48764	1	a3c4a848306307a4caebae97644a282a	a3c4a848306307a4caebae97644a282a	0
518	1	78bbda6b-8584-4bad-9662-43490d8dffc9	48682	48682	1	220d5d59765b658d0599477b959d9ecb	220d5d59765b658d0599477b959d9ecb	0
519	1	75468f25-dab9-4c69-9081-3e064f97fc2a	48772	48772	1	76541274e9ee947ebb3361005e6d04dd	76541274e9ee947ebb3361005e6d04dd	0
520	1	1ab3be7f-dc4e-4109-a55d-8ae50dd1851c	48610	48610	1	ad05d8b93fe7c5f8bda4bbfc9d3e571d	ad05d8b93fe7c5f8bda4bbfc9d3e571d	0
3	4301	246906a5-f6b2-474a-a86b-46449da4f853	74130	74130	1	33c54dc7268f77f5cee29b8189cc6a0f	33c54dc7268f77f5cee29b8189cc6a0f	0
523	1	6dc2ac17-89a8-4ef8-9992-2195fa7eb9db	202708	202708	1	6991c9c8883885c498a4abe292d77d2b	6991c9c8883885c498a4abe292d77d2b	0
524	1	47ecd577-5dc8-4bdf-b77e-2f1fc8811f45	191958	191958	1	5539d9f1477c0bb66feec4f69121126b	5539d9f1477c0bb66feec4f69121126b	0
526	1	41d877dd-de67-414a-ae9e-416c8a735c0a	185148	185148	1	6887b9787e9a5826f8e6be94b7cab565	6887b9787e9a5826f8e6be94b7cab565	0
528	1	d93b8ff2-762d-456a-a1b4-975adaabd672	126460	126460	1	b172767277a63a5eb7dc4b7f153a4556	b172767277a63a5eb7dc4b7f153a4556	0
529	1	7106004c-2605-40ed-925c-01b6b82a8360	115704	115704	1	52dbb065e558d0f4285d30ac4adbc782	52dbb065e558d0f4285d30ac4adbc782	0
530	1	badd936f-6f83-4181-be47-48c3b874a51b	116198	116198	1	a0e201c45c6eacef729b1d800d3529c4	a0e201c45c6eacef729b1d800d3529c4	0
532	1	c63ec10e-d524-4c88-a203-dbb3e838a397	255424	255424	1	5eec51d61e95d7e01c39cf107b66f7ce	5eec51d61e95d7e01c39cf107b66f7ce	0
533	1	c1c6b725-89ba-4c5f-9749-b0669a54415f	61538	61538	1	f6197bd3420d2a4678a4526fa78b5295	f6197bd3420d2a4678a4526fa78b5295	0
534	1	40eca3dc-27c2-4461-ac96-4c8a3c8cb5c7	64322	64322	1	3809392bbc46dd91b1e30da867393acd	3809392bbc46dd91b1e30da867393acd	0
535	1	3e66f6b7-2776-4817-b48f-c22eacba24a3	66720	66720	1	dce351fd75dabcb5e40a23e29dd1cae2	dce351fd75dabcb5e40a23e29dd1cae2	0
536	1	02bb7357-5dbf-49b2-9f4f-4eeaa8697d49	69168	69168	1	ba528523ba2aa85181304d168cbeea55	ba528523ba2aa85181304d168cbeea55	0
537	1	dcbcfc67-218e-41e5-b867-9a46823376bb	71606	71606	1	b0594c0e500ad138d89430e964a38f4f	b0594c0e500ad138d89430e964a38f4f	0
538	1	54e7bd0c-e809-402b-85d9-3f2feba92107	73536	73536	1	b6e4e7a5e85c850da5298c419cfcbdb7	b6e4e7a5e85c850da5298c419cfcbdb7	0
539	1	3469e8d1-bb56-4822-8f60-543f3a7fdf2c	177016	177016	1	a7c2df31243b8d95f234ff1c07c5ccc9	a7c2df31243b8d95f234ff1c07c5ccc9	0
540	1	3873d605-f4d1-4aef-8bc1-9ec062b8402c	75294	75294	1	38d843bcb164a60bdadcddb61abf8b8a	38d843bcb164a60bdadcddb61abf8b8a	0
541	1	2c87bf6f-9d8e-4067-a5d0-9e7df357f7b3	78002	78002	1	f0aabff68616799944e309ce8ed3b33b	f0aabff68616799944e309ce8ed3b33b	0
542	1	79292e84-82b1-445b-a74c-8930befb3bcc	79712	79712	1	9eadd560e293992777c4c9cd50e21727	9eadd560e293992777c4c9cd50e21727	0
543	1	9d3b50a7-f309-4f47-be21-0e2c950adba3	81484	81484	1	d9e6ba6dd7c97c4f99684ba9f6365804	d9e6ba6dd7c97c4f99684ba9f6365804	0
544	1	e76be3eb-075e-43fd-81e0-078fb6eceb48	85534	85534	1	91576099ae5ba5f307489b165d077a17	91576099ae5ba5f307489b165d077a17	0
545	1	37eae07e-596b-4cb0-92a9-9e39f58ec1d2	88914	88914	1	abf3a03c20df77942b9a713fd40f3550	abf3a03c20df77942b9a713fd40f3550	0
546	1	62cf481d-f9dd-4cac-ae2b-9a5017828506	90948	90948	1	540d46e38db44da346031a34ed30aa35	540d46e38db44da346031a34ed30aa35	0
547	1	9c151587-95ff-4cf4-b422-0b68de658a5d	94960	94960	1	3156452174b829b16741554feba095b6	3156452174b829b16741554feba095b6	0
548	1	ddf7659b-c944-4145-8010-b7a65e7a2913	100688	100688	1	888bd2cff7a3244b8da9c8066c4e008d	888bd2cff7a3244b8da9c8066c4e008d	0
549	1	350904f5-b54d-4fd5-b868-9918c0fd9c1b	107528	107528	1	db9d75eaf91e490526df4eb918f4484c	db9d75eaf91e490526df4eb918f4484c	0
550	1	9370d356-a3fe-44e8-a3b3-bb77d6d6925d	174924	174924	1	561433d0df04a385aa80935787afca4b	561433d0df04a385aa80935787afca4b	0
551	1	3807bb56-0472-43b7-b1bd-5075bffbc683	112058	112058	1	86b33f2006601fe5db4c47383423ef5b	86b33f2006601fe5db4c47383423ef5b	0
552	1	55107e94-a0a0-469a-ad83-8f68ccc286a4	115720	115720	1	7677a98f91b92125d4074362ca601ffd	7677a98f91b92125d4074362ca601ffd	0
553	1	d15072c9-806d-49fd-9bb5-313735b28462	118850	118850	1	18399a558f840a679637797dbb154592	18399a558f840a679637797dbb154592	0
554	1	62e06244-9d1b-4878-9d01-4bcbd1cf92bc	122950	122950	1	06a551b81ff29e89aabd913411af3ab5	06a551b81ff29e89aabd913411af3ab5	0
555	1	55632c1a-acf3-4438-bd39-168bd4f0cdac	125162	125162	1	bc5a9497515517a2fcbdb7c63d163e68	bc5a9497515517a2fcbdb7c63d163e68	0
556	1	d4611b66-2498-4219-9f2e-06b4815eb0ab	126844	126844	1	0f037f05cbb866da8f7c942a82623e60	0f037f05cbb866da8f7c942a82623e60	0
557	1	81d70ca2-5f9f-47ff-995b-0a1da8a9e0a9	128540	128540	1	0091162b781ef545509433cc03ee52ae	0091162b781ef545509433cc03ee52ae	0
558	1	3517fd38-fe99-40de-900a-ebe47454d392	130204	130204	1	b647938faf0ec3ddca49a320d6dd16c6	b647938faf0ec3ddca49a320d6dd16c6	0
559	1	2ee76269-44cd-4f04-82b0-1b50c9598bc9	132166	132166	1	b5b86cea11bb22862d2f8c0685915b8b	b5b86cea11bb22862d2f8c0685915b8b	0
560	1	4e669ecd-ef0d-41dd-bd27-22e8d5bc4b37	134852	134852	1	a4766782cbf02213841230a7a22c7620	a4766782cbf02213841230a7a22c7620	0
561	1	0d2193e8-d232-49e8-81d6-3a3850a448ea	169288	169288	1	350894959d3030e46af787ec1c424366	350894959d3030e46af787ec1c424366	0
562	1	c31a78da-581c-4297-a74b-762f2e76e3bd	137324	137324	1	eedb09aa431cdb9f74efa299b0b079eb	eedb09aa431cdb9f74efa299b0b079eb	0
563	1	c24b0c12-2939-4cee-91b2-91a0d13002a5	139276	139276	1	62091af5f3c7b60107bcb6a5d7ac72d3	62091af5f3c7b60107bcb6a5d7ac72d3	0
564	1	655b1c57-c23d-4208-b371-51d59537ece8	140660	140660	1	08aa86ae979e1c2e8152d337a75c89d3	08aa86ae979e1c2e8152d337a75c89d3	0
565	1	9e965f10-9134-4bc7-aeed-6ebd12b7b493	141078	141078	1	76d1b14678602005f545529c2c554c71	76d1b14678602005f545529c2c554c71	0
566	1	17b7cfee-f0a8-49b0-9401-6e573b0a4b16	141738	141738	1	4696b0fabf538089c396c46956b33950	4696b0fabf538089c396c46956b33950	0
567	1	8ee6a18e-4c1a-4663-a7a0-eadee4f28b9a	142824	142824	1	96f8cc37b9b65d1819d9b267603fbc87	96f8cc37b9b65d1819d9b267603fbc87	0
568	1	3537a797-08f5-4535-af2d-c11280a1215e	142004	142004	1	98ea761f93d6509885652c457c3a2408	98ea761f93d6509885652c457c3a2408	0
569	1	debedd57-92ae-4424-8cb9-0fdfeeb84e9d	142114	142114	1	da6c4b736999ea3c1a4a571b643ec22b	da6c4b736999ea3c1a4a571b643ec22b	0
570	1	65cfc2e6-3141-4c63-a91c-bcd24322e0c5	142208	142208	1	c0c1c73e119a2d8f50d4d076576e2955	c0c1c73e119a2d8f50d4d076576e2955	0
571	1	737b5251-63fd-46cc-861d-efdf638b6058	142482	142482	1	c184a1fc37b13965f48d6f3adf2e1226	c184a1fc37b13965f48d6f3adf2e1226	0
572	1	ae0bc06f-65cb-47e3-9418-2f048846b884	173414	173414	1	bd24882c07f917e54f27645ca402f9e6	bd24882c07f917e54f27645ca402f9e6	0
573	1	b0973ff7-c562-40a4-b182-080068074a3d	142600	142600	1	5969746e1401fb3b3d2556858e46c54d	5969746e1401fb3b3d2556858e46c54d	0
574	1	5adecf16-3493-4e7c-a766-ac6d236c3ebf	144314	144314	1	46a439624612ca3d0f841e29b1c13df3	46a439624612ca3d0f841e29b1c13df3	0
575	1	c3b9fcdd-b873-495a-971c-ab2ee14dce1c	145680	145680	1	b781a102b6cede2a28ac8ac0e3d54f34	b781a102b6cede2a28ac8ac0e3d54f34	0
576	1	398a8e65-86b9-4f83-805b-972a08adfee1	146402	146402	1	7ca7ee3caae5580b5d7506975e97790e	7ca7ee3caae5580b5d7506975e97790e	0
577	1	2b7a4484-c15d-448f-a3d0-d6f5fbd07c60	148576	148576	1	0e13c45ecabc89877ecfaea412837d6e	0e13c45ecabc89877ecfaea412837d6e	0
578	1	3d475894-f0f7-4d3a-bd7d-97f09edd004e	150386	150386	1	bbdd458c0afbfbc9c2805363fdd7aae5	bbdd458c0afbfbc9c2805363fdd7aae5	0
579	1	12490392-7a69-4be1-85c6-cd426d87b055	153718	153718	1	d6a8163362e0ed52da25fde4e87b657c	d6a8163362e0ed52da25fde4e87b657c	0
580	1	44a113de-7798-4c09-b0b7-8d0489fe3c8b	153804	153804	1	500f45c0252e9d139c740191d61d8605	500f45c0252e9d139c740191d61d8605	0
581	1	a73446e1-e6ef-4ee7-92a1-5b7b8fddf474	152528	152528	1	c16aec2618a2339eb45082aebd31262a	c16aec2618a2339eb45082aebd31262a	0
582	1	9a106807-7241-46d6-bb67-e923421ad8ba	151460	151460	1	4f8f05aa4c1151a98f5c42b318d440a9	4f8f05aa4c1151a98f5c42b318d440a9	0
583	1	bf19dbf9-aca5-4006-90b3-b33feeaa0d63	170040	170040	1	a427cf047361ec2dc8578c9685152d46	a427cf047361ec2dc8578c9685152d46	0
584	1	e3cb3301-4cc7-491e-9654-962a1474a100	150848	150848	1	940e5495b09a9bafbcd06149c5c8a25d	940e5495b09a9bafbcd06149c5c8a25d	0
585	1	dbf8642e-ed24-4f72-9712-e49e83cbb0f0	150568	150568	1	dcb64cfe8a14e77f1a146c01035611d3	dcb64cfe8a14e77f1a146c01035611d3	0
586	1	2b75f599-361e-4c8f-b289-f07d26e535de	151612	151612	1	b543abfc738ae43310002fed9a6d878d	b543abfc738ae43310002fed9a6d878d	0
587	1	ba751dbd-9774-47c4-a32a-451f4007d479	152564	152564	1	2db4e97f47d7d0aa8521243bf583b36c	2db4e97f47d7d0aa8521243bf583b36c	0
588	1	62d1ad8c-a122-4bfe-82b1-b8e27a9ad121	151812	151812	1	6333aad0f39eb6be25e925bb1f742b2c	6333aad0f39eb6be25e925bb1f742b2c	0
589	1	b3b2f455-89c9-4755-834b-788535ce4efa	151450	151450	1	e8acf29dbeeb291f0597aba7976dd8dd	e8acf29dbeeb291f0597aba7976dd8dd	0
590	1	2f3cab8e-022e-4e65-a849-09143eb20045	150478	150478	1	fc1e325673023948bf63d09a08723c96	fc1e325673023948bf63d09a08723c96	0
591	1	183839b7-67dc-45fc-a978-5ac52824ef88	150160	150160	1	682763696e5ce3b5bfd638254db0baf0	682763696e5ce3b5bfd638254db0baf0	0
592	1	8d99c092-1d8a-4536-9775-d990b698902a	150040	150040	1	69a3e722a9a8e7e50966ddd8ff951663	69a3e722a9a8e7e50966ddd8ff951663	0
593	1	db9cb309-e46d-452a-97bf-0af23140aadb	150574	150574	1	901f3b205cb785b50bbb89be3e81a569	901f3b205cb785b50bbb89be3e81a569	0
594	1	4544dbd7-0d04-42dd-8790-daf021f724ec	172978	172978	1	fc5a65bf67f499ba8adac6f9eb815bf8	fc5a65bf67f499ba8adac6f9eb815bf8	0
595	1	5b0febe7-f367-46aa-8998-14de2ee598b7	151542	151542	1	2f39dcc5b4e1a52f39c549507e23dbbd	2f39dcc5b4e1a52f39c549507e23dbbd	0
596	1	0d39d2f4-5730-4d76-b53e-90913a7daccc	151552	151552	1	b7140d379b1e6325df777f38bdc715f0	b7140d379b1e6325df777f38bdc715f0	0
597	1	e0b99e69-a4f8-4b9a-ba2a-f051dc7ce484	151406	151406	1	e6b4c21f11091f3c4fdfdede5fa20630	e6b4c21f11091f3c4fdfdede5fa20630	0
598	1	69bf0867-c3c1-42f5-9000-72f83c66de26	151048	151048	1	7df33da5a89869f5b63294d74b8f7cc9	7df33da5a89869f5b63294d74b8f7cc9	0
599	1	9e358f7b-848f-483f-99fb-9116acd55579	151252	151252	1	26dc9a1daf23d2bd5ec098e1d775387f	26dc9a1daf23d2bd5ec098e1d775387f	0
600	1	209221de-461f-4a9a-9d1b-92fa12879883	151200	151200	1	35fc4f79c5fa4edbddfc508d35d17cbd	35fc4f79c5fa4edbddfc508d35d17cbd	0
601	1	a31473d8-2425-4403-9386-137d6bf905b5	152760	152760	1	728d3d6a986a631a5b15f433fc674028	728d3d6a986a631a5b15f433fc674028	0
602	1	ca0e87a1-273f-47cc-a73d-da3b1eaa0325	153130	153130	1	4ad27e1a5ca1acaea67f900e731773e9	4ad27e1a5ca1acaea67f900e731773e9	0
603	1	0a45a777-35e3-4a6b-864e-229037e0662d	152858	152858	1	1f13321451b9946caed63243b46ab5af	1f13321451b9946caed63243b46ab5af	0
604	1	6e556857-9ac7-41e0-a490-117be503c232	153320	153320	1	717f51cb424a4bcd6d24bfd5e5d8fdf4	717f51cb424a4bcd6d24bfd5e5d8fdf4	0
605	1	1cd20668-d7cf-4a0b-8c47-df1e28fd3633	169198	169198	1	9c9c71427d45b5253846d7280a86abdd	9c9c71427d45b5253846d7280a86abdd	0
606	1	fbb27990-c6f3-4d87-9306-f17d4fd07081	153978	153978	1	e433e20015fd34676c583c306016a4d5	e433e20015fd34676c583c306016a4d5	0
607	1	dd39c45b-b1e9-486f-a5a2-b15059c7960d	156108	156108	1	b1276d14c675ed667df0fb3c692d87fe	b1276d14c675ed667df0fb3c692d87fe	0
608	1	b3d6781b-69fd-4ffb-b442-fc362c16e9d6	156442	156442	1	966daf1437a90269764ea4565c4fed43	966daf1437a90269764ea4565c4fed43	0
609	1	591df548-4608-4592-a637-e1fe07f1bbe5	156236	156236	1	e188c263fd8683d4c1c0b52b22c62856	e188c263fd8683d4c1c0b52b22c62856	0
610	1	e290599f-ee6c-48d8-926c-58beaf92e27e	155438	155438	1	d007de7e040e6c1cbb24a2e10e86d766	d007de7e040e6c1cbb24a2e10e86d766	0
611	1	b37b1765-62b8-4669-ab25-722c5e957549	152940	152940	1	9b4cba250e9f226b5efdba206468c06c	9b4cba250e9f226b5efdba206468c06c	0
612	1	e6fae7dd-0c9a-4e2c-9fe9-1a362b9c86c5	150090	150090	1	cf47bed595a55a1b6a7c4e1ef0765af8	cf47bed595a55a1b6a7c4e1ef0765af8	0
613	1	8a6ace01-77e7-4c28-b51b-70d75a4fded8	148302	148302	1	30b4768ece5e451a676d7c3f79338c8b	30b4768ece5e451a676d7c3f79338c8b	0
614	1	44fd00d3-1602-4e1e-a3ca-2caf2c6a9b61	147610	147610	1	e0b506751a3af50bb75b1a244036fd12	e0b506751a3af50bb75b1a244036fd12	0
615	1	68795922-cb3a-45c1-b0cf-1ddc355f16a7	147298	147298	1	8b385bbe9a92ef027b199de17c961b69	8b385bbe9a92ef027b199de17c961b69	0
616	1	1fc56b15-bd85-4790-8f99-44b8850751a3	171476	171476	1	3d373d3bad8f38d9a0ba6f93de56ee54	3d373d3bad8f38d9a0ba6f93de56ee54	0
617	1	f5c70a6e-1ecf-4fce-ab73-6d5720557dee	147076	147076	1	d21d325613b0df66963c9e4963132b60	d21d325613b0df66963c9e4963132b60	0
618	1	a7c374b2-b7a5-4f44-9561-2d4ddd38b795	146584	146584	1	dca89fc231b707cbec07f07e6ce92c0c	dca89fc231b707cbec07f07e6ce92c0c	0
619	1	b1c963f9-5211-44c0-b3ce-5d2b59114402	146738	146738	1	47b998b98a7959124fc74ff6c20a8baa	47b998b98a7959124fc74ff6c20a8baa	0
620	1	f10978e3-0baf-4bae-866a-1a3d33701d33	148830	148830	1	643b00e60d14007c9c8b4d8ddfa386c5	643b00e60d14007c9c8b4d8ddfa386c5	0
621	1	337867f5-50d6-4645-ae7f-1fbedca92d62	152100	152100	1	44fe0a9eba090d15e305a70bd00fa2dd	44fe0a9eba090d15e305a70bd00fa2dd	0
622	1	ad2b0a65-0229-4af6-afa0-4d9be37b0500	151354	151354	1	c6223e1e2db9f7b3a0cda5585e3a0065	c6223e1e2db9f7b3a0cda5585e3a0065	0
623	1	f4963650-6612-48e0-a604-3a817413f417	150130	150130	1	63bb7c59fb2f2f898a7580c7bbf22da0	63bb7c59fb2f2f898a7580c7bbf22da0	0
624	1	1470ed5e-ce6e-4249-a278-78d9534f438b	150336	150336	1	0d5475f07d7c179a6ffdfbe73738427a	0d5475f07d7c179a6ffdfbe73738427a	0
625	1	ea4ac92e-7ef4-4993-bead-e92693a87c57	150112	150112	1	e6e8e30e4a8de8b825dcb27776e202d2	e6e8e30e4a8de8b825dcb27776e202d2	0
626	1	9465e051-44e8-4654-8ed0-c5edeccf2526	149942	149942	1	fda07181a98a30292acf34d262cf0239	fda07181a98a30292acf34d262cf0239	0
627	1	4fc6a1f3-22c7-4530-9c95-324a56d2e86c	169044	169044	1	6198378ccf93829a7f7ccd90b4b6e9cb	6198378ccf93829a7f7ccd90b4b6e9cb	0
628	1	db46cf8d-6177-46e9-9050-1591825a3687	149106	149106	1	af031063f16b3c23c20aceffb6fb6feb	af031063f16b3c23c20aceffb6fb6feb	0
629	1	39d7fbca-9f13-456f-bd1f-dfdf818de517	148782	148782	1	269eb6a8bc1d1e87fc1078ed0227fb9f	269eb6a8bc1d1e87fc1078ed0227fb9f	0
630	1	087694ce-ae42-46a1-a387-416e619da6a5	148350	148350	1	2f96e0260a83bf921292c8cd9ca44520	2f96e0260a83bf921292c8cd9ca44520	0
631	1	5c9df7ff-0d40-4d01-b532-91dba7438a96	147458	147458	1	7d0a3e364eee3ca7b8c1ec6ccdb9c330	7d0a3e364eee3ca7b8c1ec6ccdb9c330	0
632	1	6766062c-41e7-42d4-b8fc-93ffb883a6ea	147384	147384	1	5669bd01610030ca5dbb6a32d3db89ea	5669bd01610030ca5dbb6a32d3db89ea	0
633	1	0c2a55a6-5a58-4ff5-966a-16a4b71886d3	146574	146574	1	e61386d8d93aa8a8031768b30bc5144e	e61386d8d93aa8a8031768b30bc5144e	0
634	1	26f09971-6b5e-4a1c-9fa5-df5ae3a44fce	146336	146336	1	10540332866ffdd094d19561e8fef50c	10540332866ffdd094d19561e8fef50c	0
635	1	6a0969f2-8867-42f3-865a-0ca8c3dd6959	145228	145228	1	9e57659407768b94fb542ebd619f9775	9e57659407768b94fb542ebd619f9775	0
636	1	9363197d-65a0-4acd-bc1c-af9a717dcf66	144268	144268	1	116ee9a3dc3daa998f5f6efca5de35b9	116ee9a3dc3daa998f5f6efca5de35b9	0
637	1	88fd9fb3-9189-4333-bd3d-c86dd5c08795	143132	143132	1	4a299db49b09d51cf263f1500a27b855	4a299db49b09d51cf263f1500a27b855	0
638	1	ef13610b-b0ee-4f59-8447-3a9f4d8d66d9	177194	177194	1	fd32f41e1d86f653244a2f66ef3ca7af	fd32f41e1d86f653244a2f66ef3ca7af	0
639	1	0f2602d5-45c3-42d5-820a-f547bc10552f	170006	170006	1	f1dd18d86d48297f5f283df3c9497eb1	f1dd18d86d48297f5f283df3c9497eb1	0
640	1	7e2f8c22-9614-4623-a424-0604d6054933	141516	141516	1	5d57097f5d3bbf93be6101293ee9b2d4	5d57097f5d3bbf93be6101293ee9b2d4	0
641	1	94cc3faa-5bbf-4e52-8e97-3e6825140ba7	140322	140322	1	e344a7d7e463135771202fa7780e1127	e344a7d7e463135771202fa7780e1127	0
642	1	40b488e4-4b7f-43a2-b6c5-14fc7ad094ff	138804	138804	1	06424e5b8316ac13cc02c3aa1c6f962a	06424e5b8316ac13cc02c3aa1c6f962a	0
643	1	cb74567f-1c0e-4b69-a1a2-dcb3b1c7a363	137402	137402	1	513fe91533fcb1291606a3e965559c10	513fe91533fcb1291606a3e965559c10	0
644	1	13c333b5-c0f9-4210-8fcc-c0e38bf0524e	135428	135428	1	e974679945b1382d0274fb8702e0a4ba	e974679945b1382d0274fb8702e0a4ba	0
645	1	9a52609a-8b5a-449c-ad07-6bc5178ff6c7	133570	133570	1	a02c272ce461f0b8b2d20292ec6911b7	a02c272ce461f0b8b2d20292ec6911b7	0
646	1	8859d397-d9ce-41fd-befc-70ad3b9c6c2d	130792	130792	1	dccb5b05e2c022be1dd99a0a5683df15	dccb5b05e2c022be1dd99a0a5683df15	0
647	1	5644036c-c67a-41c8-8697-db1808fbd802	126870	126870	1	853e598a9976f45ba70ca1d240c90077	853e598a9976f45ba70ca1d240c90077	0
648	1	acb5010a-ff64-496c-ab3b-2e0d90bdf9bf	123918	123918	1	721e36316d9cc9b6a705b545a0d00632	721e36316d9cc9b6a705b545a0d00632	0
649	1	926e3f64-e065-41cd-a810-84f3b2ba674b	119398	119398	1	4361aa8d37d75ada98abee9e2a9fafff	4361aa8d37d75ada98abee9e2a9fafff	0
650	1	626790b5-c01d-42c0-afac-cda7b71d562d	168974	168974	1	ef859b5faed95f7368fa155e6e212bab	ef859b5faed95f7368fa155e6e212bab	0
651	1	5f13fd59-6c92-4393-b20f-13b595f6f4cd	112028	112028	1	03dad270dde0e4df56724628483c4442	03dad270dde0e4df56724628483c4442	0
652	1	ca8615cf-5ca0-486e-8125-42b0f629541d	108318	108318	1	5f3b1f382349be2c4dcb02d01e0cb9fc	5f3b1f382349be2c4dcb02d01e0cb9fc	0
653	1	e58646d8-ddd7-479d-ba96-71bf6a7854a9	106384	106384	1	3edc0ad85d08a3dc22f24341920fb1e4	3edc0ad85d08a3dc22f24341920fb1e4	0
654	1	340b7418-4775-4044-8d3c-1caf17c14173	104794	104794	1	af672dc4dc76c3d672a33453bce862d0	af672dc4dc76c3d672a33453bce862d0	0
656	1	7813ce31-1e7d-4a78-90b3-19594f0b61d4	226012	226012	1	6b7010b1a4daf5520e1abb20f4840524	6b7010b1a4daf5520e1abb20f4840524	0
657	1	df8161e2-1bb3-47e3-9be9-975731f30591	104394	104394	1	81995f5240bba300a4333a31204c1c6d	81995f5240bba300a4333a31204c1c6d	0
658	1	9d468ae1-dae2-4c04-80aa-04488a2cef7d	107862	107862	1	ff70a0da3fcd6bb00de1c28879502866	ff70a0da3fcd6bb00de1c28879502866	0
659	1	746e135a-d421-4536-a195-8b325acf9d75	110914	110914	1	842c626a9fba366de7d886749900bbba	842c626a9fba366de7d886749900bbba	0
660	1	ec4f1333-7be9-490b-9999-92953b5091c7	113220	113220	1	2b0e125a4335157a55ce20aacd80a1f3	2b0e125a4335157a55ce20aacd80a1f3	0
661	1	3cc3da23-46b3-4143-a01a-f51fdba013e2	115198	115198	1	0c6953ec7acff32eeefae63030b5ea6e	0c6953ec7acff32eeefae63030b5ea6e	0
662	1	a7601683-5a21-4141-b2ec-6f4dc9263165	169362	169362	1	aac0a05da66324708c6aae73b1fbd338	aac0a05da66324708c6aae73b1fbd338	0
663	1	4c853697-e02a-4210-a905-dfc2d48f3be1	120540	120540	1	2d3511333cdb6c9cdbc748b2952dbb30	2d3511333cdb6c9cdbc748b2952dbb30	0
664	1	54aac417-d82a-4fc0-8198-1ec4f041f9b6	124748	124748	1	80fe741dd0c913c834170daa285406bb	80fe741dd0c913c834170daa285406bb	0
665	1	7c1a1156-246b-4419-98cc-13b81d19db83	127230	127230	1	6a2197af1815a490fdf3815eb22fcadc	6a2197af1815a490fdf3815eb22fcadc	0
666	1	7feaaca8-9907-447f-9f13-5a357c259bf8	131016	131016	1	5c581924e1962f6f704f056c8c08704e	5c581924e1962f6f704f056c8c08704e	0
667	1	75a0a367-138b-4583-94e3-3ce118f65963	134930	134930	1	88c98d5c0c272fc2eefe557a26124d8a	88c98d5c0c272fc2eefe557a26124d8a	0
668	1	3af63c60-ff59-4476-9786-50e89787e3b4	136828	136828	1	ff08bd8b2fec7a2866243c83054a3e68	ff08bd8b2fec7a2866243c83054a3e68	0
669	1	dcb958a6-e7ba-4adf-b2e8-26ed0db28097	138562	138562	1	0013b9169c33f8cdd9338f6d5851eb25	0013b9169c33f8cdd9338f6d5851eb25	0
670	1	2276a470-2a9b-431c-b9b2-ea05e3d13d42	140630	140630	1	0300773d0312441d37c645acdeb416f3	0300773d0312441d37c645acdeb416f3	0
671	1	9ac008b0-172d-4a80-82e6-838fb7a6d88a	142108	142108	1	f179a9b190a9dad142bcd40bc4ccb60e	f179a9b190a9dad142bcd40bc4ccb60e	0
672	1	f8ac022b-7898-43d9-ad3d-a44aef540dad	142682	142682	1	a6ddce0cad5aac735dfb97376b5a28b5	a6ddce0cad5aac735dfb97376b5a28b5	0
673	1	9d81c72b-9de7-47f3-bdc1-417d3d74ccf2	168932	168932	1	ec549bb833dd68cc1dee53869ffb3873	ec549bb833dd68cc1dee53869ffb3873	0
674	1	6306722e-0a8e-4ce5-9deb-86ece623378b	143444	143444	1	c69e8399d7aa4b268a130fe2db5c34a0	c69e8399d7aa4b268a130fe2db5c34a0	0
675	1	0574a10d-aa65-4b85-b4ac-3cd4129c76ab	144316	144316	1	cbac1411de216090f919617903068f12	cbac1411de216090f919617903068f12	0
676	1	8b59dbba-e329-421a-b410-2322edeb44c2	145086	145086	1	bb67488f4da12bcd64ecaa621c2756df	bb67488f4da12bcd64ecaa621c2756df	0
677	1	4649bd7b-6ec3-4c2f-89f3-1f3324c37cf6	146296	146296	1	2b015a2987bdd1c7b384d92f83aa68cb	2b015a2987bdd1c7b384d92f83aa68cb	0
678	1	0ee354d4-f031-4066-b98f-1c37656c03b4	147106	147106	1	e03573a3a047f8289784020a1b3d613d	e03573a3a047f8289784020a1b3d613d	0
679	1	1a4d673c-1dc2-4b80-878e-0ff1209ecade	147668	147668	1	2c82e615b52366c602c8d70c7a858c3c	2c82e615b52366c602c8d70c7a858c3c	0
680	1	c1b9e035-382d-4579-999a-40ab8f2f1ded	148532	148532	1	6213bea4fefe3de3411f8cb26ed96c89	6213bea4fefe3de3411f8cb26ed96c89	0
681	1	4d3816f9-6e1f-49ae-9c26-b12816a1fdf0	148288	148288	1	896da30590435600362377ef89ffc08d	896da30590435600362377ef89ffc08d	0
682	1	d8df89f3-3674-4603-acd8-41d9c0355d7a	147796	147796	1	62c89e54d6a1634a0b65b542050c3c32	62c89e54d6a1634a0b65b542050c3c32	0
683	1	2047f53b-4dc8-47d3-8020-603aa115cd2e	147574	147574	1	8f62701bac75991c92dd3cf0a6da39a1	8f62701bac75991c92dd3cf0a6da39a1	0
684	1	002a4f57-339e-4185-81ce-c7de3a21cf78	169348	169348	1	e68fc3fdfae913bf422b969cc7cb3a23	e68fc3fdfae913bf422b969cc7cb3a23	0
685	1	e45e56d1-ead6-4ee8-ba00-bbe2b8d23df1	147680	147680	1	08bc37cef9b62ad90207ae8ec00b5d05	08bc37cef9b62ad90207ae8ec00b5d05	0
686	1	5a56a711-c1fd-4ae6-b827-1b9c18834dfd	147434	147434	1	cd51c4462811d4434abc8dc0780f2426	cd51c4462811d4434abc8dc0780f2426	0
687	1	0265ee5b-daa5-4ea6-90a3-8a549603c3dd	147910	147910	1	a66f0dd42224ae3c963710d9c952d188	a66f0dd42224ae3c963710d9c952d188	0
688	1	92242754-9bb9-4e3f-8885-510002f982a1	148314	148314	1	0d553549442bdc0ea34ee64f47697fed	0d553549442bdc0ea34ee64f47697fed	0
689	1	3c3c2bc4-aec2-4084-a7a3-3103d0ebeda8	148636	148636	1	613856cd0de1269fe92e83e0dd5ae339	613856cd0de1269fe92e83e0dd5ae339	0
690	1	42075e97-86c7-44ed-bdeb-e29bfd3fd6a4	148548	148548	1	65898de8c1095d6ec2d9f2df0992c307	65898de8c1095d6ec2d9f2df0992c307	0
691	1	ec8af7c1-71f5-47d2-9a7c-53918f314296	149326	149326	1	99d4a9b86cac989d9bc90a45beac71b7	99d4a9b86cac989d9bc90a45beac71b7	0
692	1	d57d1db9-1de9-4c0f-931e-1c45dcb0b362	150190	150190	1	e4cbedac0e2a50e3b26be70f14a487ce	e4cbedac0e2a50e3b26be70f14a487ce	0
693	1	5e56d650-7d08-40af-8158-618d80cbc962	150678	150678	1	38d6f647777e737733c7d520d6214ff0	38d6f647777e737733c7d520d6214ff0	0
694	1	c1eb80a5-fd2c-418c-acde-51b8e80de924	150912	150912	1	b63c981e14118d937e98e20c43c310b1	b63c981e14118d937e98e20c43c310b1	0
695	1	b4d31a2d-68bf-41dd-9fce-938d69487f11	171624	171624	1	4352f9f18a7b3660db728210c24e2a62	4352f9f18a7b3660db728210c24e2a62	0
696	1	f5cb1324-0242-43e1-9fa6-573689f039b6	151878	151878	1	3e4d72c431a281401ffafd193cbbdced	3e4d72c431a281401ffafd193cbbdced	0
697	1	2867f01c-f2ed-45dc-a893-e0994b0e7036	154026	154026	1	f2b5ab1fe5dc9df23cfa902577586b84	f2b5ab1fe5dc9df23cfa902577586b84	0
698	1	ccb2eecf-c680-4a5a-a9c5-5f015130b6ea	155572	155572	1	0d8f29abf15a1391c35acb259fce8052	0d8f29abf15a1391c35acb259fce8052	0
699	1	38de0334-ddaf-4d2a-bc10-7f0ced37e3f5	156414	156414	1	9d368c59495324ff50347b551f9dc110	9d368c59495324ff50347b551f9dc110	0
700	1	7de9a71a-dfb0-4b00-a0b8-d16ddafce3a4	156254	156254	1	8415d66e63c9e234a464ed4029414eb1	8415d66e63c9e234a464ed4029414eb1	0
701	1	174e0501-7310-48e3-9d69-034a6cb9602b	155936	155936	1	c5b61fe888c3e39939a26b2ac9c36b6e	c5b61fe888c3e39939a26b2ac9c36b6e	0
702	1	fb70ef4a-bd9f-408e-b778-fcd5e7e987b5	155686	155686	1	bd89da3db2f70894db2f8bab4986eb6f	bd89da3db2f70894db2f8bab4986eb6f	0
703	1	b8080642-3e67-4580-aaf2-a30d9fbeed23	155810	155810	1	17a3e4ffdf7cd2c18f6a17f03f93f395	17a3e4ffdf7cd2c18f6a17f03f93f395	0
704	1	79c5d630-17bc-4179-9385-d09ba20865d7	157822	157822	1	acee2d78d4baa0b85efa8a3b1410e4eb	acee2d78d4baa0b85efa8a3b1410e4eb	0
705	1	31fca96f-bd2b-4d04-84b4-7bcd0614c2bb	158666	158666	1	0c9d42113b34ab615398e782a9f74337	0c9d42113b34ab615398e782a9f74337	0
706	1	f6b561ec-9195-4009-b722-97591bd2f13a	173244	173244	1	7b0230b94347b7b1b88ad8569ac3935e	7b0230b94347b7b1b88ad8569ac3935e	0
707	1	96e9fde5-0406-4b9d-bc36-83c6babb0630	156154	156154	1	897241fa14291f070d764a19a60f8f6c	897241fa14291f070d764a19a60f8f6c	0
708	1	a7a7a33d-9e30-4bbb-935f-abcd90a6cb66	156480	156480	1	6ae23ae366b40424d420ada937bb03d3	6ae23ae366b40424d420ada937bb03d3	0
709	1	c8355194-30a4-4a2a-9dce-91958e2bf9a9	156094	156094	1	84b79c7d361ec84c0b48be7675260164	84b79c7d361ec84c0b48be7675260164	0
710	1	dce3f645-2c95-4003-a12a-d7d1b1be9c80	155818	155818	1	9bccc34bac21fa087486e42a484167b8	9bccc34bac21fa087486e42a484167b8	0
711	1	1cd948bb-df0c-4c6f-bdc9-4be28b0d8777	156434	156434	1	62be29855f0addc2b941cb0309c196e2	62be29855f0addc2b941cb0309c196e2	0
712	1	2e27d063-5a30-452b-b3b7-53cd4ac96c0a	156310	156310	1	cfb5949d2fb37d134c21bb5b4222a2b6	cfb5949d2fb37d134c21bb5b4222a2b6	0
713	1	13b73189-66c5-444a-a834-d741cb7412a4	155498	155498	1	3c5c30a9fb231626abf44862eeda2e15	3c5c30a9fb231626abf44862eeda2e15	0
714	1	784ba96b-a956-477b-a904-30b5c773a97c	154096	154096	1	928ecc8d17f826d8b16efd0542777e1e	928ecc8d17f826d8b16efd0542777e1e	0
715	1	62d72dbd-1aa2-41cc-82ce-e3205c46bee9	152542	152542	1	e05fc3f50d27677f363221d5b6eec2c5	e05fc3f50d27677f363221d5b6eec2c5	0
716	1	cebe645b-833a-4980-a7bf-dfab30d16f58	151530	151530	1	83aae6e7056196023b5bbae68875b808	83aae6e7056196023b5bbae68875b808	0
717	1	08e22d13-81b3-4ea2-acb4-a0c82ba8e309	174368	174368	1	cd8e4bba2f5397be60f7b44536256205	cd8e4bba2f5397be60f7b44536256205	0
718	1	1239a34a-6cce-4ac7-a81d-0ec26a9bedbc	150680	150680	1	c03d0f8b51fdea114b09a54e0e4c79a2	c03d0f8b51fdea114b09a54e0e4c79a2	0
719	1	b0e4b9a7-f772-40c4-b92b-b365a492c11c	149718	149718	1	43503a4e76525deb64e76f6a05a7012b	43503a4e76525deb64e76f6a05a7012b	0
720	1	18a158db-365c-480e-a9eb-f32ada2003d7	148954	148954	1	2b1e880e66cb7b9113a5c174ce83c601	2b1e880e66cb7b9113a5c174ce83c601	0
721	1	a690cb35-40f1-4fab-93ed-781cb1fea388	148598	148598	1	8beb9b937f96a407956fe4cceb13bea7	8beb9b937f96a407956fe4cceb13bea7	0
722	1	e8f821b1-88f0-472c-9c12-a641fd89a654	147536	147536	1	ce25fd150f66a4bef9c9bf2ded19201c	ce25fd150f66a4bef9c9bf2ded19201c	0
723	1	72ceed80-f8ac-4a4f-910e-59a0460bad8a	146944	146944	1	5d2d8e984ce16e7055dde9af93e0ce7a	5d2d8e984ce16e7055dde9af93e0ce7a	0
724	1	68e246d7-8874-4fb6-85d0-db3711b81796	147166	147166	1	86f72f2f9044ac6e736553f46cb14498	86f72f2f9044ac6e736553f46cb14498	0
725	1	0358b129-0ecf-4a23-8845-5877d5eef9da	147060	147060	1	dd145901a61219341030bb22c705be38	dd145901a61219341030bb22c705be38	0
726	1	fce9e11b-f5eb-4d8f-8837-b46c50b36bec	146898	146898	1	dcd15679e321b254398efc3a81b444d5	dcd15679e321b254398efc3a81b444d5	0
727	1	13b73b5b-3490-46de-b6f7-9aa5f9d92e34	147386	147386	1	87cff586af07b20d5b0d1a8378e8b5a0	87cff586af07b20d5b0d1a8378e8b5a0	0
728	1	9248b83d-1955-4e1b-8cfc-300ea248b1f1	172116	172116	1	1365f115d82a75779e6f58eda910567a	1365f115d82a75779e6f58eda910567a	0
729	1	7ca31ba0-f302-4193-ba07-6a476ea7ffc9	146992	146992	1	c3a60e86f48a0a0cdb6f874fc79387cc	c3a60e86f48a0a0cdb6f874fc79387cc	0
730	1	b1ef7f6a-5089-4980-b621-90a59bab714f	147618	147618	1	5322b3af173cfecde181a92595b65844	5322b3af173cfecde181a92595b65844	0
731	1	d1b3d945-be83-4aa1-9cec-2583ffaf439e	147486	147486	1	6fe2572160156d36b0c67ca0aea0cae9	6fe2572160156d36b0c67ca0aea0cae9	0
732	1	1303b6d5-27a1-40b5-8953-14a79eb96aa7	147324	147324	1	179b4c5dde871d9031fdffe7da8dce89	179b4c5dde871d9031fdffe7da8dce89	0
733	1	539d9703-1940-4359-8be8-e57181d4482b	146536	146536	1	d95b700d09b2d79efb05290a841f094a	d95b700d09b2d79efb05290a841f094a	0
734	1	f302f423-1fb9-46c9-a424-99942d6a1a90	145494	145494	1	ac0ff4fccdea321fff9d9d2e625382f0	ac0ff4fccdea321fff9d9d2e625382f0	0
735	1	3e631227-52d0-44a1-b965-fe911fcbfb47	143728	143728	1	783790071185da03ecd2d875e08173cd	783790071185da03ecd2d875e08173cd	0
736	1	15f9798b-22ba-42a4-b257-f84e7a158190	142840	142840	1	168c9ac6e05b2474f68938227c49b1a6	168c9ac6e05b2474f68938227c49b1a6	0
737	1	a0fadfa2-1624-434a-b79b-d16c84dfaa1b	140940	140940	1	9cf01429adc99e1ce1f3e63c8f57ebad	9cf01429adc99e1ce1f3e63c8f57ebad	0
738	1	b0c2cb4b-5db2-4c5b-99af-9f5b0ee1627c	139526	139526	1	af6c848f5f4c119ff8cd6e5cb7cdaf88	af6c848f5f4c119ff8cd6e5cb7cdaf88	0
739	1	dff4f8d5-90fc-4e0c-b241-ee6f1f714d7c	172410	172410	1	0d07e14cc74ef6145540e2c2f18b4ec9	0d07e14cc74ef6145540e2c2f18b4ec9	0
740	1	eb741e1b-38a1-41ea-925f-7a7403728e3a	138050	138050	1	026b843e4e54358303bf9c82f1153af8	026b843e4e54358303bf9c82f1153af8	0
741	1	b158cce1-2aee-4485-990d-6577b184db61	135900	135900	1	a94700e0955f2c94e94521ec8a37c90e	a94700e0955f2c94e94521ec8a37c90e	0
742	1	a00da1f1-545c-4176-b940-8e492eba5d3c	133174	133174	1	ece0d34cf9c3f3ce218356401a745591	ece0d34cf9c3f3ce218356401a745591	0
743	1	d6af3dc5-4ebc-4d08-ad03-5b8c2e5d88e8	129492	129492	1	81a404390b16b47ee5693d0909c35826	81a404390b16b47ee5693d0909c35826	0
744	1	65916543-0267-4894-a49b-7fe5fc24f80f	125750	125750	1	f87a62dd52621535f45b15d79c583d1b	f87a62dd52621535f45b15d79c583d1b	0
745	1	dc2a673d-0000-4a9c-9b8e-b1fc2bcd5cb5	121632	121632	1	82c0dee89787b28fd1d4a1b231a5cb2f	82c0dee89787b28fd1d4a1b231a5cb2f	0
746	1	094820d6-08c2-4e18-a0e5-2ba6eb13041a	119066	119066	1	c9018fb5aab01d9ad60cdf8a02ca0619	c9018fb5aab01d9ad60cdf8a02ca0619	0
747	1	dc551a12-5922-4c86-96c4-fcc9363c22fc	116378	116378	1	d68e5f41f3c9e0c69dcd965b17eb60d8	d68e5f41f3c9e0c69dcd965b17eb60d8	0
748	1	cc4cb94c-d883-472c-94c2-e717c78bde3b	113888	113888	1	e32a06053532286a715f03846f4c10ff	e32a06053532286a715f03846f4c10ff	0
749	1	89133841-20cf-4fb3-a7c6-2a1cf6101258	110616	110616	1	7168359fa262a9e124380e546fd5eb3c	7168359fa262a9e124380e546fd5eb3c	0
750	1	f9d79f72-fecd-4af2-8d25-9f5f362c06cd	175268	175268	1	ee2022f39e96fa62fe869dd9407861fe	ee2022f39e96fa62fe869dd9407861fe	0
751	1	0a5ff96f-c3c9-406b-b978-969fa13b8a84	166916	166916	1	82118f8c73189ace43a65edec4593965	82118f8c73189ace43a65edec4593965	0
752	1	e3fe1883-7389-4ac3-8946-a945b22639af	107958	107958	1	1ad979ee5657811161001185989fbf3d	1ad979ee5657811161001185989fbf3d	0
753	1	dc6d5356-f602-478f-827b-2da6ded6ee98	103476	103476	1	2f9af964bb32767dc5b67dc3309378b6	2f9af964bb32767dc5b67dc3309378b6	0
754	1	2244098c-5232-4e0a-9d52-9074b2551de6	101508	101508	1	cd5b07a65b4971891eba74c06fc76ee8	cd5b07a65b4971891eba74c06fc76ee8	0
755	1	7a8167db-c93e-43df-8598-b8774062dcbe	159482	159482	1	8f523ae239e35cb7140ae0fbe1a9da3f	8f523ae239e35cb7140ae0fbe1a9da3f	0
756	1	ecf42c87-1c2b-47c2-a5c5-b93bcc468392	147594	147594	1	7016060dcff64563a7d65ac1f855dcbe	7016060dcff64563a7d65ac1f855dcbe	0
757	1	c804d8dd-abe9-4432-a1be-01306e073c6e	131580	131580	1	43fa835a2eb26f5d8b7ab99d0c1538cd	43fa835a2eb26f5d8b7ab99d0c1538cd	0
758	1	350204f6-1d10-4e80-a695-a1f9a552a339	111748	111748	1	b2c67a60930303ec410a8983d1adf07e	b2c67a60930303ec410a8983d1adf07e	0
759	1	2d306e73-0526-4828-a7da-38ff5080dca4	105616	105616	1	502d88509bde9036fcd252a9629a48b7	502d88509bde9036fcd252a9629a48b7	0
760	1	bd6edf4d-97cf-4e14-9039-7dcdcdb74bd8	182160	182160	1	7206edd3cdf757f81ef788eeb1302bcb	7206edd3cdf757f81ef788eeb1302bcb	0
761	1	7ba41d49-f1da-4bb5-aa88-5a1d09cd8039	182944	182944	1	63f4a7d3391965072ffc319414242699	63f4a7d3391965072ffc319414242699	0
762	1	5e6b3bcc-a1c8-4f1d-921c-c198ff72169a	179978	179978	1	df4654516d1a09c2ba3a40045f6b6bc2	df4654516d1a09c2ba3a40045f6b6bc2	0
763	1	4b6d6ac2-7c75-4863-a360-20cfba262884	178962	178962	1	3d38ac258d0d8761c05993e1f78e314f	3d38ac258d0d8761c05993e1f78e314f	0
764	1	c467a51f-04b8-4741-b3b8-99116be66957	180810	180810	1	c7e3bbf4ec317846ca2cf9eef7e7a0d0	c7e3bbf4ec317846ca2cf9eef7e7a0d0	0
765	1	1249f847-3a0b-410f-9bef-3377b9ab112c	183818	183818	1	26e34a1d35615d52936ec41f22f6f211	26e34a1d35615d52936ec41f22f6f211	0
766	1	9ece1f6b-43b9-4984-be33-fd20c503825b	188006	188006	1	ee067d4589a9f687e1ff6ee01b39f32e	ee067d4589a9f687e1ff6ee01b39f32e	0
767	1	ed7da4b6-3088-44d3-a27a-718da3a9b3da	188464	188464	1	0c884805ae285f7f5ccb951a579bb376	0c884805ae285f7f5ccb951a579bb376	0
768	1	8b48f6c1-8dc1-4752-a8a7-5e7490e00a3e	191336	191336	1	58d2634f4f13939c4ddf3bfb932a4549	58d2634f4f13939c4ddf3bfb932a4549	0
769	1	545b7ded-f482-411c-8ff6-096b2e1c0834	195530	195530	1	7d3df962701f8059ab1f760d8a11543f	7d3df962701f8059ab1f760d8a11543f	0
770	1	41f98c70-a6cb-4b06-9f14-874e01a3eb82	198262	198262	1	e6897479a3b40dc239de88ee611461da	e6897479a3b40dc239de88ee611461da	0
771	1	7ed4b89f-6211-473c-a45c-84cf2f7ca78f	198522	198522	1	72d0e3ed668e663969f9530af50811c1	72d0e3ed668e663969f9530af50811c1	0
772	1	d4108270-444e-426f-b02b-52078b923ea0	200824	200824	1	cbede4645902bb809a4ec9bc301d07bd	cbede4645902bb809a4ec9bc301d07bd	0
773	1	209efc51-9885-467e-8a7d-53f6b0155f6e	200300	200300	1	73f1295ebc101e5e15960aa20f405f00	73f1295ebc101e5e15960aa20f405f00	0
774	1	ff52d842-03a1-4186-a74e-ae74d29af2d9	195878	195878	1	699494b3ff4f1d95b568f534be35ecf7	699494b3ff4f1d95b568f534be35ecf7	0
775	1	3500da34-2e56-4174-b12d-c4bf215ba9f7	184314	184314	1	4ff005438a9fddfb10e866465a254ef9	4ff005438a9fddfb10e866465a254ef9	0
776	1	fc4f1ad8-a7c1-40a8-a39b-777d342264bb	192846	192846	1	1fae5d5e27eec54c60b07534cc000c2b	1fae5d5e27eec54c60b07534cc000c2b	0
777	1	9bce96ff-ce36-4a9c-a5e0-97203ec9be85	193442	193442	1	7761718d9feae8b13cfc9c9f71ae9319	7761718d9feae8b13cfc9c9f71ae9319	0
778	1	da318af5-8457-44bd-a0d2-2c439d6d2945	192544	192544	1	0d62d89746b9ff2a5ab0f5182c317b10	0d62d89746b9ff2a5ab0f5182c317b10	0
779	1	d5c6310d-16d6-4340-b049-4711c11c87dc	187382	187382	1	b365aeac522429d2023f89eca62102a6	b365aeac522429d2023f89eca62102a6	0
780	1	a78fc508-2fae-4977-8509-0712e0991584	183560	183560	1	bbe3cd0f586921fadc773c6a8d3ca384	bbe3cd0f586921fadc773c6a8d3ca384	0
781	1	3515147e-2e6e-46ea-ae8b-aad447ec7a77	184432	184432	1	b03f4964ff5f185a551e8e0529410fb0	b03f4964ff5f185a551e8e0529410fb0	0
782	1	8a6113a5-2923-4674-8870-ca0e200d2669	183202	183202	1	95edde9f154edcc7b59f5486ffc07aa0	95edde9f154edcc7b59f5486ffc07aa0	0
783	1	7ab78de6-c0c7-4f68-9906-527687bfad83	177504	177504	1	7e45f16dac15d5bbcd97847e0609d392	7e45f16dac15d5bbcd97847e0609d392	0
784	1	01820239-1f36-4df1-8485-b0d7f508b90f	177210	177210	1	3b2e3964e3df12a5c3d6bf872293ea70	3b2e3964e3df12a5c3d6bf872293ea70	0
785	1	517b8d5f-4107-459b-b71c-92532c7d66b2	181534	181534	1	3cd6d3680d9b6beb233f9ff4b48a90ed	3cd6d3680d9b6beb233f9ff4b48a90ed	0
786	1	92e4e5d7-5846-4ab9-b779-bbc6198b88f3	190436	190436	1	c4800bc5c8e2ebc20dfaf4d1564239c0	c4800bc5c8e2ebc20dfaf4d1564239c0	0
787	1	a8bce391-55b8-400c-9d74-1d82e1a72eae	182398	182398	1	11ed8d11625dee2478f93da4c908d44d	11ed8d11625dee2478f93da4c908d44d	0
788	1	fc5d3668-71ad-4a73-a5ee-92a2d17326d7	179088	179088	1	43d5dc80925cb939420fd896c21c4f6e	43d5dc80925cb939420fd896c21c4f6e	0
789	1	110e1b7d-95c7-4657-91bf-13b17a0915d2	177456	177456	1	0b6a11b26417ff3414f2cbd2c94f711d	0b6a11b26417ff3414f2cbd2c94f711d	0
790	1	1ccbda38-582d-4e91-9899-429988664808	181254	181254	1	fe5ffc9d372aff37a1762e040db44cf2	fe5ffc9d372aff37a1762e040db44cf2	0
791	1	30a65bbe-0aa4-4212-884a-771d532518e2	181626	181626	1	00365f0f641177371091f0fef7fdd19b	00365f0f641177371091f0fef7fdd19b	0
792	1	26c391d0-f694-40f1-b978-da21b12a76b5	177148	177148	1	2e16e749ac57250ab91725717bdd9168	2e16e749ac57250ab91725717bdd9168	0
793	1	14521b9b-d6fe-45af-b70d-706a2277e526	177550	177550	1	778743c91a91767c3c2443d8ed51cf52	778743c91a91767c3c2443d8ed51cf52	0
794	1	5b3f4419-0ffc-437b-b41d-216de6048c7b	181210	181210	1	09ef2810d7ee8d74884b4a6c3419edeb	09ef2810d7ee8d74884b4a6c3419edeb	0
795	1	9d33a484-6077-486d-b417-f205915a458f	180880	180880	1	104ba050b5235dd3ec76cff3992b1b18	104ba050b5235dd3ec76cff3992b1b18	0
796	1	7b49881a-860a-4fe0-9eb8-0b54b3215350	177276	177276	1	213a11d5d22e5877a1467df2752ba870	213a11d5d22e5877a1467df2752ba870	0
797	1	0b2352f4-c406-4ace-abad-0b0d4f9488d7	192314	192314	1	843193ef1b1497a977f5908d47797d5f	843193ef1b1497a977f5908d47797d5f	0
798	1	b865b7a8-e713-4e11-a838-7367c326d676	177722	177722	1	e4fcd60340dc1085e73b785e7b66c902	e4fcd60340dc1085e73b785e7b66c902	0
799	1	cee529d4-a8df-4252-bd3a-dfa3c867a78a	180522	180522	1	628e296837c00c2c134ea750b69b432b	628e296837c00c2c134ea750b69b432b	0
800	1	3ffff4b5-d8d8-4edb-bb0d-79d5dd7bce45	178902	178902	1	7df67d9ffd51d1d4a41c6a9b4ab7ebf1	7df67d9ffd51d1d4a41c6a9b4ab7ebf1	0
801	1	5291e2e8-ecec-4f07-9894-fd0256bb466e	175396	175396	1	0d020263b38b076b8a8c7a75abacf4f8	0d020263b38b076b8a8c7a75abacf4f8	0
802	1	3c6da5d3-8adb-40bb-a6d7-29c46c3aeec1	177252	177252	1	f0dd001427d5cee4ee37e7f819d9e1b3	f0dd001427d5cee4ee37e7f819d9e1b3	0
803	1	dd4cdda1-1ce4-4f6e-9f7a-fd45b3c123e9	179528	179528	1	3f8aa86346d47506bc1e894c3718c1ae	3f8aa86346d47506bc1e894c3718c1ae	0
804	1	207eb8b1-8e89-43ab-95b2-3ba5a58d6b1e	177270	177270	1	a2cb8fe767afd4b364c17ef907b61364	a2cb8fe767afd4b364c17ef907b61364	0
805	1	b01a5fbe-ba39-44a5-8178-3c96d28d2c33	174590	174590	1	e1ad56127a53d8dbeef092bac639072c	e1ad56127a53d8dbeef092bac639072c	0
806	1	50a981ac-4719-478f-830a-8c7fa4bb7d40	176700	176700	1	95d45ba8288efd18f3d8da6766f4dc90	95d45ba8288efd18f3d8da6766f4dc90	0
807	1	7aee9f9a-c0a4-4389-841f-0e190f6a5369	179716	179716	1	b3cbbe4e3bcaa8865e7516f58e729bf1	b3cbbe4e3bcaa8865e7516f58e729bf1	0
808	1	d0b920ed-21cd-4455-b450-fa19f0803da1	194308	194308	1	c400ea896d6c7917dc5db27f67c0e3e1	c400ea896d6c7917dc5db27f67c0e3e1	0
809	1	7175abcc-09bc-4b30-9895-83070e6c4e5e	177008	177008	1	e0ff14ec8afef999afab51c4d20b9b3c	e0ff14ec8afef999afab51c4d20b9b3c	0
810	1	f82267ab-0cf4-4047-8feb-ca0ae3107fd4	175418	175418	1	1db9b1277901c5213550461906cdedff	1db9b1277901c5213550461906cdedff	0
811	1	91a21962-1e04-4340-b5f1-373f7ac13bfc	178088	178088	1	2ba69d70465dacc94e501c9f9a39a62f	2ba69d70465dacc94e501c9f9a39a62f	0
812	1	78bacaac-2312-4034-a816-fcb5c5f2bebb	180030	180030	1	54fa2ba89f593f2e4f96f4e4f4ea8bd9	54fa2ba89f593f2e4f96f4e4f4ea8bd9	0
813	1	38603996-b497-45a7-8a9e-b11db709fe86	177912	177912	1	cc4127980c91995c7b0de0f6f5830155	cc4127980c91995c7b0de0f6f5830155	0
814	1	ee996ef4-65a9-47be-a8d7-73fe692f6f98	176306	176306	1	33da29a9d53f9867cd519fc8e6033645	33da29a9d53f9867cd519fc8e6033645	0
815	1	4e53bb7f-ac1a-433f-a1e5-e3f3fb68e5aa	178414	178414	1	8cfa9fe33d1531f8591716c182010d1d	8cfa9fe33d1531f8591716c182010d1d	0
816	1	d2e4d686-2469-4eb3-aafa-8ac2473d011b	178536	178536	1	629828aac5e9f235a4dcb0297d320cad	629828aac5e9f235a4dcb0297d320cad	0
817	1	d8dcc4da-f328-41a1-8dce-7250d9db9f1b	175316	175316	1	358eb88a03b344b3960cb1c9a377c7fe	358eb88a03b344b3960cb1c9a377c7fe	0
818	1	0af79259-388f-4555-8eb4-42aa205cb348	173882	173882	1	c85b0eceefddbfd89c294103be27649d	c85b0eceefddbfd89c294103be27649d	0
819	1	f22ac8cd-9822-45e4-8ca4-7d9c68cc27c7	186552	186552	1	57093e14fbd4f24152f3de37f3bfd0c3	57093e14fbd4f24152f3de37f3bfd0c3	0
820	1	54db9741-5cb0-428c-801a-3ade0223aa1d	175612	175612	1	9344ce8530d39129cfdab6337dee2dac	9344ce8530d39129cfdab6337dee2dac	0
821	1	d9d01963-9640-429b-850e-64ce7889fc00	175044	175044	1	944a6c48c26c068b7f9fd94b71a4a131	944a6c48c26c068b7f9fd94b71a4a131	0
822	1	0eb7bbb7-5980-43b3-a5f7-90ed6ec6e5a5	170036	170036	1	63ecb58daa17921cb4501bbbd9c59679	63ecb58daa17921cb4501bbbd9c59679	0
823	1	6077d3d2-9f4d-42ba-aa7e-1da67c1a28d7	166222	166222	1	503664887fa841e82650e3fbea894ae0	503664887fa841e82650e3fbea894ae0	0
824	1	d9eee7f8-8036-48fe-b994-d304f6e9e871	165624	165624	1	ed1ceb18d158c0b1af9fd9a861514b83	ed1ceb18d158c0b1af9fd9a861514b83	0
825	1	347ba6d4-f8ce-4280-916a-86523c9353f4	160794	160794	1	e4bc53a3be3726bcd13d5036543fdffb	e4bc53a3be3726bcd13d5036543fdffb	0
826	1	ded2ec46-8cc4-4c66-9af3-7f72623fb430	150042	150042	1	728426310d4e376cc66b6167fab9bdb0	728426310d4e376cc66b6167fab9bdb0	0
827	1	02f53a09-cc69-4198-91ec-ea42288480be	143158	143158	1	a662138c322ad9bba7532e18a42a3476	a662138c322ad9bba7532e18a42a3476	0
828	1	37597a35-a80b-4163-8b5c-2d8a3a23bbbe	140120	140120	1	1687a8f1f136935afb458e8bc4dd9a3e	1687a8f1f136935afb458e8bc4dd9a3e	0
829	1	fcf1828d-2cd1-4de0-a881-dc51bd630db2	134010	134010	1	7d002e251f8a74d8f917230e1c728139	7d002e251f8a74d8f917230e1c728139	0
522	4301	ef21b522-4ea1-4e64-98c2-6aea4f21fdde	1880	1880	1	76a6a0f7ed382ed71c1e648bcf5f153d	76a6a0f7ed382ed71c1e648bcf5f153d	1
531	4301	3a805dfe-56d2-4db6-96ed-1deef69483e4	15963	15963	1	a4a90616e121d2052afafa79cf5b6229	a4a90616e121d2052afafa79cf5b6229	1
655	4301	dea5edab-0aff-4fe9-b27d-0bbeaa6c6d11	12925	12925	1	0c72c7642d9b2d7013089a7d131bdcef	0c72c7642d9b2d7013089a7d131bdcef	1
525	4301	78ccabaa-05a9-4bf9-a185-2330c96901b3	7410	7410	1	818cce7f5ca10fc1678287c1aefe3482	818cce7f5ca10fc1678287c1aefe3482	1
527	4301	ff24179a-e9aa-452d-b118-5bc0d63d422b	12830	12830	1	4de9f2eb4a2d9411a0beebcff55675b0	4de9f2eb4a2d9411a0beebcff55675b0	1
\.


--
-- Data for Name: changes; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.changes (seq, changetype, internalid, resourcetype, date) FROM stdin;
1	2	4	3	20250211T152516
2	4	3	2	20250211T152516
3	5	2	1	20250211T152516
4	3	1	0	20250211T152516
5	2	5	3	20250211T152516
6	2	6	3	20250211T152516
7	2	7	3	20250211T152516
8	2	8	3	20250211T152516
9	2	9	3	20250211T152516
10	2	10	3	20250211T152516
11	2	11	3	20250211T152516
12	2	12	3	20250211T152516
13	2	13	3	20250211T152516
14	2	14	3	20250211T152516
15	2	15	3	20250211T152516
16	2	16	3	20250211T152516
17	2	17	3	20250211T152516
18	2	18	3	20250211T152516
19	2	19	3	20250211T152516
20	2	20	3	20250211T152516
21	2	21	3	20250211T152516
22	2	22	3	20250211T152516
23	2	23	3	20250211T152516
24	2	24	3	20250211T152516
25	2	25	3	20250211T152516
26	2	26	3	20250211T152516
27	2	27	3	20250211T152516
28	2	28	3	20250211T152516
29	2	29	3	20250211T152516
30	2	30	3	20250211T152516
31	2	31	3	20250211T152516
32	2	32	3	20250211T152516
33	2	33	3	20250211T152516
34	2	34	3	20250211T152516
35	2	35	3	20250211T152516
36	2	36	3	20250211T152516
37	2	37	3	20250211T152516
38	2	38	3	20250211T152516
39	2	39	3	20250211T152516
40	2	40	3	20250211T152516
41	2	41	3	20250211T152516
42	2	42	3	20250211T152516
43	2	43	3	20250211T152516
44	2	44	3	20250211T152516
45	2	45	3	20250211T152516
46	2	46	3	20250211T152516
47	2	47	3	20250211T152516
48	2	48	3	20250211T152516
49	2	49	3	20250211T152516
50	2	50	3	20250211T152516
51	2	51	3	20250211T152516
52	2	52	3	20250211T152516
53	2	53	3	20250211T152516
54	2	54	3	20250211T152516
55	2	55	3	20250211T152516
56	2	56	3	20250211T152516
57	2	57	3	20250211T152516
58	2	58	3	20250211T152516
59	2	59	3	20250211T152516
60	2	60	3	20250211T152516
61	2	61	3	20250211T152516
62	2	62	3	20250211T152516
63	2	63	3	20250211T152516
64	2	64	3	20250211T152516
65	2	65	3	20250211T152516
66	2	66	3	20250211T152516
67	2	67	3	20250211T152516
68	2	68	3	20250211T152516
69	2	69	3	20250211T152516
70	2	70	3	20250211T152516
71	2	71	3	20250211T152516
72	2	72	3	20250211T152516
73	2	73	3	20250211T152516
74	2	74	3	20250211T152516
75	2	75	3	20250211T152516
76	2	76	3	20250211T152516
77	2	77	3	20250211T152516
78	2	78	3	20250211T152516
79	2	79	3	20250211T152516
80	2	80	3	20250211T152516
81	2	81	3	20250211T152516
82	2	82	3	20250211T152516
83	2	83	3	20250211T152516
84	2	84	3	20250211T152516
85	2	85	3	20250211T152516
86	2	86	3	20250211T152516
87	2	87	3	20250211T152516
88	2	88	3	20250211T152516
89	2	89	3	20250211T152516
90	2	90	3	20250211T152516
91	2	91	3	20250211T152516
92	2	92	3	20250211T152516
93	2	93	3	20250211T152516
94	2	94	3	20250211T152516
95	2	95	3	20250211T152516
96	2	96	3	20250211T152516
97	2	97	3	20250211T152516
98	2	98	3	20250211T152516
99	2	99	3	20250211T152516
100	2	100	3	20250211T152516
101	2	101	3	20250211T152516
102	2	102	3	20250211T152516
103	2	103	3	20250211T152516
104	2	104	3	20250211T152516
105	2	105	3	20250211T152516
106	2	106	3	20250211T152516
107	2	107	3	20250211T152516
108	2	108	3	20250211T152516
109	2	109	3	20250211T152516
110	2	110	3	20250211T152516
111	2	111	3	20250211T152516
112	2	112	3	20250211T152516
113	2	113	3	20250211T152516
114	2	114	3	20250211T152516
115	2	115	3	20250211T152516
116	2	116	3	20250211T152516
117	2	117	3	20250211T152516
118	2	118	3	20250211T152516
119	2	119	3	20250211T152516
120	2	120	3	20250211T152516
121	2	121	3	20250211T152516
122	2	122	3	20250211T152516
123	2	123	3	20250211T152516
124	2	124	3	20250211T152516
125	2	125	3	20250211T152516
126	2	126	3	20250211T152516
127	2	127	3	20250211T152516
128	2	128	3	20250211T152516
129	2	129	3	20250211T152516
130	2	130	3	20250211T152516
131	2	131	3	20250211T152516
132	2	132	3	20250211T152516
133	2	133	3	20250211T152516
134	2	134	3	20250211T152516
135	2	135	3	20250211T152516
136	2	136	3	20250211T152516
137	2	137	3	20250211T152516
138	2	138	3	20250211T152516
139	2	139	3	20250211T152516
140	2	140	3	20250211T152516
141	2	141	3	20250211T152516
142	2	142	3	20250211T152516
143	2	143	3	20250211T152516
144	2	144	3	20250211T152516
145	2	145	3	20250211T152516
146	2	146	3	20250211T152516
147	2	147	3	20250211T152516
148	2	148	3	20250211T152516
149	2	149	3	20250211T152516
150	2	150	3	20250211T152516
151	2	151	3	20250211T152516
152	2	152	3	20250211T152516
153	2	153	3	20250211T152516
154	2	154	3	20250211T152516
155	2	155	3	20250211T152516
156	2	156	3	20250211T152516
157	2	157	3	20250211T152516
158	2	158	3	20250211T152516
159	2	159	3	20250211T152516
160	2	160	3	20250211T152516
161	2	161	3	20250211T152516
162	2	162	3	20250211T152516
163	2	163	3	20250211T152516
164	2	164	3	20250211T152516
165	2	165	3	20250211T152516
166	2	166	3	20250211T152516
167	2	167	3	20250211T152516
168	2	168	3	20250211T152516
169	2	169	3	20250211T152516
170	2	170	3	20250211T152517
171	2	171	3	20250211T152517
172	2	172	3	20250211T152517
173	2	173	3	20250211T152517
174	2	174	3	20250211T152517
175	2	175	3	20250211T152517
176	2	176	3	20250211T152517
177	2	177	3	20250211T152517
178	2	178	3	20250211T152517
179	2	179	3	20250211T152517
180	2	180	3	20250211T152517
181	2	181	3	20250211T152517
182	2	182	3	20250211T152517
183	2	183	3	20250211T152517
184	2	184	3	20250211T152517
185	2	185	3	20250211T152517
186	2	186	3	20250211T152517
187	2	187	3	20250211T152517
188	2	188	3	20250211T152517
189	2	189	3	20250211T152517
190	2	190	3	20250211T152517
191	2	191	3	20250211T152517
192	2	192	3	20250211T152517
193	2	193	3	20250211T152517
194	2	194	3	20250211T152517
195	2	195	3	20250211T152517
196	2	196	3	20250211T152517
197	2	197	3	20250211T152517
198	2	198	3	20250211T152517
199	2	199	3	20250211T152517
200	2	200	3	20250211T152517
201	2	201	3	20250211T152517
202	2	202	3	20250211T152517
203	2	203	3	20250211T152517
204	2	204	3	20250211T152517
205	2	205	3	20250211T152517
206	2	206	3	20250211T152517
207	2	207	3	20250211T152517
208	2	208	3	20250211T152517
209	2	209	3	20250211T152517
210	2	210	3	20250211T152517
211	2	211	3	20250211T152517
212	2	212	3	20250211T152517
213	2	213	3	20250211T152517
214	2	214	3	20250211T152517
215	2	215	3	20250211T152517
216	2	216	3	20250211T152517
217	2	217	3	20250211T152517
218	2	218	3	20250211T152517
219	2	219	3	20250211T152517
220	2	220	3	20250211T152517
221	2	221	3	20250211T152517
222	2	222	3	20250211T152517
223	2	223	3	20250211T152517
224	2	224	3	20250211T152517
225	2	225	3	20250211T152517
226	2	226	3	20250211T152517
227	2	227	3	20250211T152517
228	2	228	3	20250211T152517
229	2	229	3	20250211T152517
230	2	230	3	20250211T152517
231	2	231	3	20250211T152517
232	2	232	3	20250211T152517
233	2	233	3	20250211T152517
234	2	234	3	20250211T152517
235	2	235	3	20250211T152517
236	2	236	3	20250211T152517
237	2	237	3	20250211T152517
238	2	238	3	20250211T152517
239	2	239	3	20250211T152517
240	2	240	3	20250211T152517
241	2	241	3	20250211T152517
242	2	242	3	20250211T152517
243	2	243	3	20250211T152517
244	2	244	3	20250211T152517
245	2	245	3	20250211T152517
246	2	246	3	20250211T152517
247	2	247	3	20250211T152517
248	2	248	3	20250211T152517
249	2	249	3	20250211T152517
250	2	250	3	20250211T152517
251	2	251	3	20250211T152517
252	2	252	3	20250211T152517
253	2	253	3	20250211T152517
254	2	254	3	20250211T152517
255	2	255	3	20250211T152517
256	2	256	3	20250211T152517
257	2	257	3	20250211T152517
258	2	258	3	20250211T152517
259	2	259	3	20250211T152517
260	2	260	3	20250211T152517
261	2	261	3	20250211T152517
262	2	262	3	20250211T152517
263	2	263	3	20250211T152517
264	2	264	3	20250211T152517
265	2	265	3	20250211T152517
266	2	266	3	20250211T152517
267	2	267	3	20250211T152517
268	2	268	3	20250211T152517
269	2	269	3	20250211T152517
270	2	270	3	20250211T152517
271	2	271	3	20250211T152517
272	2	272	3	20250211T152517
273	2	273	3	20250211T152517
274	2	274	3	20250211T152517
275	2	275	3	20250211T152517
276	2	276	3	20250211T152517
277	2	277	3	20250211T152517
278	2	278	3	20250211T152517
279	2	279	3	20250211T152517
280	2	280	3	20250211T152517
281	2	281	3	20250211T152517
282	2	282	3	20250211T152517
283	2	283	3	20250211T152517
284	2	284	3	20250211T152517
285	2	285	3	20250211T152517
286	2	286	3	20250211T152517
287	2	287	3	20250211T152517
288	2	288	3	20250211T152517
289	2	289	3	20250211T152517
290	2	290	3	20250211T152517
291	2	291	3	20250211T152517
292	2	292	3	20250211T152517
293	2	293	3	20250211T152517
294	2	294	3	20250211T152517
295	2	295	3	20250211T152517
296	2	296	3	20250211T152517
297	2	297	3	20250211T152517
298	2	298	3	20250211T152517
299	2	299	3	20250211T152517
300	2	300	3	20250211T152517
301	2	301	3	20250211T152517
302	2	302	3	20250211T152517
303	2	303	3	20250211T152517
304	2	304	3	20250211T152517
305	2	305	3	20250211T152517
306	2	306	3	20250211T152517
307	2	307	3	20250211T152517
308	2	308	3	20250211T152517
309	2	309	3	20250211T152517
310	2	310	3	20250211T152517
311	2	311	3	20250211T152517
312	2	312	3	20250211T152517
313	2	313	3	20250211T152517
314	2	314	3	20250211T152517
315	2	315	3	20250211T152517
316	2	316	3	20250211T152517
317	2	317	3	20250211T152517
318	2	318	3	20250211T152517
319	2	319	3	20250211T152517
320	2	320	3	20250211T152517
321	2	321	3	20250211T152517
322	2	322	3	20250211T152517
323	2	323	3	20250211T152517
324	2	324	3	20250211T152517
325	2	325	3	20250211T152517
326	2	326	3	20250211T152517
327	2	327	3	20250211T152517
328	2	328	3	20250211T152517
329	2	329	3	20250211T152517
330	2	330	3	20250211T152517
331	2	331	3	20250211T152517
332	2	332	3	20250211T152517
333	2	333	3	20250211T152517
334	2	334	3	20250211T152517
335	2	335	3	20250211T152517
336	2	336	3	20250211T152517
337	2	337	3	20250211T152517
338	2	338	3	20250211T152517
339	2	339	3	20250211T152517
340	2	340	3	20250211T152517
341	2	341	3	20250211T152517
342	2	342	3	20250211T152517
343	2	343	3	20250211T152517
344	2	344	3	20250211T152517
345	2	345	3	20250211T152517
346	2	346	3	20250211T152517
347	2	347	3	20250211T152517
348	2	348	3	20250211T152517
349	2	349	3	20250211T152517
350	2	350	3	20250211T152517
351	2	351	3	20250211T152517
352	2	352	3	20250211T152517
353	2	353	3	20250211T152517
354	2	354	3	20250211T152517
355	2	355	3	20250211T152517
356	2	356	3	20250211T152517
357	2	357	3	20250211T152517
358	2	358	3	20250211T152517
359	2	359	3	20250211T152517
360	2	360	3	20250211T152517
361	2	361	3	20250211T152517
362	2	362	3	20250211T152517
363	2	363	3	20250211T152517
364	2	364	3	20250211T152517
365	2	365	3	20250211T152517
366	2	366	3	20250211T152517
367	2	367	3	20250211T152517
368	2	368	3	20250211T152517
369	2	369	3	20250211T152517
370	2	370	3	20250211T152517
371	2	371	3	20250211T152517
372	2	372	3	20250211T152517
373	2	373	3	20250211T152517
374	2	374	3	20250211T152518
375	2	375	3	20250211T152518
376	2	376	3	20250211T152518
377	2	377	3	20250211T152518
378	2	378	3	20250211T152518
379	2	379	3	20250211T152518
380	2	380	3	20250211T152518
381	2	381	3	20250211T152518
382	2	382	3	20250211T152518
383	2	383	3	20250211T152518
384	2	384	3	20250211T152518
385	2	385	3	20250211T152518
386	2	386	3	20250211T152518
387	2	387	3	20250211T152518
388	2	388	3	20250211T152518
389	2	389	3	20250211T152518
390	2	390	3	20250211T152518
391	2	391	3	20250211T152518
392	2	392	3	20250211T152518
393	2	393	3	20250211T152518
394	2	394	3	20250211T152518
395	2	395	3	20250211T152518
396	2	396	3	20250211T152518
397	2	397	3	20250211T152518
398	2	398	3	20250211T152518
399	2	399	3	20250211T152518
400	2	400	3	20250211T152518
401	2	401	3	20250211T152518
402	2	402	3	20250211T152518
403	2	403	3	20250211T152518
404	2	404	3	20250211T152518
405	2	405	3	20250211T152518
406	2	406	3	20250211T152518
407	2	407	3	20250211T152518
408	2	408	3	20250211T152518
409	2	409	3	20250211T152518
410	2	410	3	20250211T152518
411	2	411	3	20250211T152518
412	2	412	3	20250211T152518
413	2	413	3	20250211T152518
414	2	414	3	20250211T152518
415	2	415	3	20250211T152518
416	2	416	3	20250211T152518
417	2	417	3	20250211T152518
418	2	418	3	20250211T152518
419	2	419	3	20250211T152518
420	2	420	3	20250211T152518
421	2	421	3	20250211T152518
422	2	422	3	20250211T152518
423	2	423	3	20250211T152518
424	2	424	3	20250211T152518
425	2	425	3	20250211T152518
426	2	426	3	20250211T152518
427	2	427	3	20250211T152518
428	2	428	3	20250211T152518
429	2	429	3	20250211T152518
430	2	430	3	20250211T152518
431	2	431	3	20250211T152518
432	2	432	3	20250211T152518
433	2	433	3	20250211T152518
434	2	434	3	20250211T152518
435	2	435	3	20250211T152518
436	2	436	3	20250211T152518
437	2	437	3	20250211T152518
438	2	438	3	20250211T152518
439	2	439	3	20250211T152518
440	2	440	3	20250211T152518
441	2	441	3	20250211T152518
442	2	442	3	20250211T152518
443	2	443	3	20250211T152518
444	2	444	3	20250211T152518
445	2	445	3	20250211T152518
446	2	446	3	20250211T152518
447	2	447	3	20250211T152518
448	2	448	3	20250211T152518
449	2	449	3	20250211T152518
450	2	450	3	20250211T152518
451	2	451	3	20250211T152518
452	2	452	3	20250211T152518
453	2	453	3	20250211T152518
454	2	454	3	20250211T152518
455	2	455	3	20250211T152518
456	2	456	3	20250211T152518
457	2	457	3	20250211T152518
458	2	458	3	20250211T152518
459	2	459	3	20250211T152518
460	2	460	3	20250211T152518
461	2	461	3	20250211T152518
462	2	462	3	20250211T152518
463	2	463	3	20250211T152518
464	2	464	3	20250211T152518
465	2	465	3	20250211T152518
466	2	466	3	20250211T152518
467	2	467	3	20250211T152518
468	2	468	3	20250211T152518
469	2	469	3	20250211T152518
470	2	470	3	20250211T152518
471	2	471	3	20250211T152518
472	2	472	3	20250211T152518
473	2	473	3	20250211T152518
474	2	474	3	20250211T152518
475	2	475	3	20250211T152518
476	2	476	3	20250211T152518
477	2	477	3	20250211T152518
478	2	478	3	20250211T152518
479	2	479	3	20250211T152518
480	2	480	3	20250211T152518
481	2	481	3	20250211T152518
482	2	482	3	20250211T152518
483	2	483	3	20250211T152518
484	2	484	3	20250211T152518
485	2	485	3	20250211T152518
486	2	486	3	20250211T152518
487	2	487	3	20250211T152518
488	2	488	3	20250211T152518
489	2	489	3	20250211T152518
490	2	490	3	20250211T152518
491	2	491	3	20250211T152518
492	2	492	3	20250211T152518
493	2	493	3	20250211T152518
494	2	494	3	20250211T152518
495	2	495	3	20250211T152518
496	2	496	3	20250211T152518
497	2	497	3	20250211T152518
498	2	498	3	20250211T152518
499	2	499	3	20250211T152518
500	2	500	3	20250211T152518
501	2	501	3	20250211T152518
502	2	502	3	20250211T152518
503	2	503	3	20250211T152518
504	2	504	3	20250211T152518
505	2	505	3	20250211T152518
506	2	506	3	20250211T152518
507	2	507	3	20250211T152518
508	2	508	3	20250211T152518
509	2	509	3	20250211T152518
510	2	510	3	20250211T152518
511	2	511	3	20250211T152518
512	2	512	3	20250211T152518
513	2	513	3	20250211T152518
514	2	514	3	20250211T152518
515	2	515	3	20250211T152518
516	2	516	3	20250211T152518
517	2	517	3	20250211T152518
518	2	518	3	20250211T152518
519	2	519	3	20250211T152518
520	2	520	3	20250211T152518
521	14	3	2	20250211T152619
522	13	2	1	20250211T152619
523	12	1	0	20250211T152619
524	15	3	2	20250211T152619
525	2	523	3	20250211T154521
526	4	522	2	20250211T154521
527	5	521	1	20250211T154521
528	2	524	3	20250211T154521
529	2	526	3	20250211T154521
530	4	525	2	20250211T154521
531	2	528	3	20250211T154521
532	4	527	2	20250211T154521
533	2	529	3	20250211T154521
534	2	530	3	20250211T154521
535	2	532	3	20250211T154521
536	4	531	2	20250211T154521
537	2	533	3	20250211T154521
538	2	534	3	20250211T154521
539	2	535	3	20250211T154521
540	2	536	3	20250211T154521
541	2	537	3	20250211T154521
542	2	538	3	20250211T154521
543	2	539	3	20250211T154521
544	2	540	3	20250211T154521
545	2	541	3	20250211T154521
546	2	542	3	20250211T154521
547	2	543	3	20250211T154521
548	2	544	3	20250211T154521
549	2	545	3	20250211T154521
550	2	546	3	20250211T154521
551	2	547	3	20250211T154521
552	2	548	3	20250211T154521
553	2	549	3	20250211T154521
554	2	550	3	20250211T154521
555	2	551	3	20250211T154521
556	2	552	3	20250211T154521
557	2	553	3	20250211T154521
558	2	554	3	20250211T154521
559	2	555	3	20250211T154521
560	2	556	3	20250211T154521
561	2	557	3	20250211T154521
562	2	558	3	20250211T154521
563	2	559	3	20250211T154521
564	2	560	3	20250211T154521
565	2	561	3	20250211T154521
566	2	562	3	20250211T154521
567	2	563	3	20250211T154521
568	2	564	3	20250211T154521
569	2	565	3	20250211T154521
570	2	566	3	20250211T154521
571	2	567	3	20250211T154521
572	2	568	3	20250211T154521
573	2	569	3	20250211T154521
574	2	570	3	20250211T154521
575	2	571	3	20250211T154521
576	2	572	3	20250211T154521
577	2	573	3	20250211T154521
578	2	574	3	20250211T154521
579	2	575	3	20250211T154521
580	2	576	3	20250211T154521
581	2	577	3	20250211T154521
582	2	578	3	20250211T154521
583	2	579	3	20250211T154521
584	2	580	3	20250211T154521
585	2	581	3	20250211T154521
586	2	582	3	20250211T154521
587	2	583	3	20250211T154521
588	2	584	3	20250211T154521
589	2	585	3	20250211T154521
590	2	586	3	20250211T154521
591	2	587	3	20250211T154521
592	2	588	3	20250211T154521
593	2	589	3	20250211T154521
594	2	590	3	20250211T154521
595	2	591	3	20250211T154521
596	2	592	3	20250211T154521
597	2	593	3	20250211T154521
598	2	594	3	20250211T154521
599	2	595	3	20250211T154521
600	2	596	3	20250211T154521
601	2	597	3	20250211T154521
602	2	598	3	20250211T154521
603	2	599	3	20250211T154521
604	2	600	3	20250211T154521
605	2	601	3	20250211T154521
606	2	602	3	20250211T154521
607	2	603	3	20250211T154521
608	2	604	3	20250211T154521
609	2	605	3	20250211T154521
610	2	606	3	20250211T154521
611	2	607	3	20250211T154521
612	2	608	3	20250211T154521
613	2	609	3	20250211T154521
614	2	610	3	20250211T154521
615	2	611	3	20250211T154521
616	2	612	3	20250211T154521
617	2	613	3	20250211T154521
618	2	614	3	20250211T154521
619	2	615	3	20250211T154521
620	2	616	3	20250211T154521
621	2	617	3	20250211T154521
622	2	618	3	20250211T154521
623	2	619	3	20250211T154521
624	2	620	3	20250211T154521
625	2	621	3	20250211T154521
626	2	622	3	20250211T154521
627	2	623	3	20250211T154521
628	2	624	3	20250211T154521
629	2	625	3	20250211T154521
630	2	626	3	20250211T154521
631	2	627	3	20250211T154521
632	2	628	3	20250211T154521
633	2	629	3	20250211T154521
634	2	630	3	20250211T154521
635	2	631	3	20250211T154521
636	2	632	3	20250211T154521
637	2	633	3	20250211T154521
638	2	634	3	20250211T154521
639	2	635	3	20250211T154521
640	2	636	3	20250211T154521
641	2	637	3	20250211T154521
642	2	638	3	20250211T154521
643	2	639	3	20250211T154521
644	2	640	3	20250211T154521
645	2	641	3	20250211T154521
646	2	642	3	20250211T154521
647	2	643	3	20250211T154521
648	2	644	3	20250211T154521
649	2	645	3	20250211T154521
650	2	646	3	20250211T154521
651	2	647	3	20250211T154521
652	2	648	3	20250211T154521
653	2	649	3	20250211T154521
654	2	650	3	20250211T154521
655	2	651	3	20250211T154521
656	2	652	3	20250211T154521
657	2	653	3	20250211T154521
658	2	654	3	20250211T154521
659	2	656	3	20250211T154521
660	4	655	2	20250211T154521
661	2	657	3	20250211T154521
662	2	658	3	20250211T154521
663	2	659	3	20250211T154521
664	2	660	3	20250211T154521
665	2	661	3	20250211T154522
666	2	662	3	20250211T154522
667	2	663	3	20250211T154522
668	2	664	3	20250211T154522
669	2	665	3	20250211T154522
670	2	666	3	20250211T154522
671	2	667	3	20250211T154522
672	2	668	3	20250211T154522
673	2	669	3	20250211T154522
674	2	670	3	20250211T154522
675	2	671	3	20250211T154522
676	2	672	3	20250211T154522
677	2	673	3	20250211T154522
678	2	674	3	20250211T154522
679	2	675	3	20250211T154522
680	2	676	3	20250211T154522
681	2	677	3	20250211T154522
682	2	678	3	20250211T154522
683	2	679	3	20250211T154522
684	2	680	3	20250211T154522
685	2	681	3	20250211T154522
686	2	682	3	20250211T154522
687	2	683	3	20250211T154522
688	2	684	3	20250211T154522
689	2	685	3	20250211T154522
690	2	686	3	20250211T154522
691	2	687	3	20250211T154522
692	2	688	3	20250211T154522
693	2	689	3	20250211T154522
694	2	690	3	20250211T154522
695	2	691	3	20250211T154522
696	2	692	3	20250211T154522
697	2	693	3	20250211T154522
698	2	694	3	20250211T154522
699	2	695	3	20250211T154522
700	2	696	3	20250211T154522
701	2	697	3	20250211T154522
702	2	698	3	20250211T154522
703	2	699	3	20250211T154522
704	2	700	3	20250211T154522
705	2	701	3	20250211T154522
706	2	702	3	20250211T154522
707	2	703	3	20250211T154522
708	2	704	3	20250211T154522
709	2	705	3	20250211T154522
710	2	706	3	20250211T154522
711	2	707	3	20250211T154522
712	2	708	3	20250211T154522
713	2	709	3	20250211T154522
714	2	710	3	20250211T154522
715	2	711	3	20250211T154522
716	2	712	3	20250211T154522
717	2	713	3	20250211T154522
718	2	714	3	20250211T154522
719	2	715	3	20250211T154522
720	2	716	3	20250211T154522
721	2	717	3	20250211T154522
722	2	718	3	20250211T154522
723	2	719	3	20250211T154522
724	2	720	3	20250211T154522
725	2	721	3	20250211T154522
726	2	722	3	20250211T154522
727	2	723	3	20250211T154522
728	2	724	3	20250211T154522
729	2	725	3	20250211T154522
730	2	726	3	20250211T154522
731	2	727	3	20250211T154522
732	2	728	3	20250211T154522
733	2	729	3	20250211T154522
734	2	730	3	20250211T154522
735	2	731	3	20250211T154522
736	2	732	3	20250211T154522
737	2	733	3	20250211T154522
738	2	734	3	20250211T154522
739	2	735	3	20250211T154522
740	2	736	3	20250211T154522
741	2	737	3	20250211T154522
742	2	738	3	20250211T154522
743	2	739	3	20250211T154522
744	2	740	3	20250211T154522
745	2	741	3	20250211T154522
746	2	742	3	20250211T154522
747	2	743	3	20250211T154522
748	2	744	3	20250211T154522
749	2	745	3	20250211T154522
750	2	746	3	20250211T154522
751	2	747	3	20250211T154522
752	2	748	3	20250211T154522
753	2	749	3	20250211T154522
754	2	750	3	20250211T154522
755	2	751	3	20250211T154522
756	2	752	3	20250211T154522
757	2	753	3	20250211T154522
758	2	754	3	20250211T154522
759	2	755	3	20250211T154522
760	2	756	3	20250211T154522
761	2	757	3	20250211T154522
762	2	758	3	20250211T154522
763	2	759	3	20250211T154522
764	2	760	3	20250211T154522
765	2	761	3	20250211T154522
766	2	762	3	20250211T154522
767	2	763	3	20250211T154522
768	2	764	3	20250211T154522
769	2	765	3	20250211T154522
770	2	766	3	20250211T154522
771	2	767	3	20250211T154522
772	2	768	3	20250211T154522
773	2	769	3	20250211T154522
774	2	770	3	20250211T154522
775	2	771	3	20250211T154522
776	2	772	3	20250211T154522
777	2	773	3	20250211T154522
778	2	774	3	20250211T154522
779	2	775	3	20250211T154522
780	2	776	3	20250211T154522
781	2	777	3	20250211T154522
782	2	778	3	20250211T154522
783	2	779	3	20250211T154522
784	2	780	3	20250211T154522
785	2	781	3	20250211T154522
786	2	782	3	20250211T154522
787	2	783	3	20250211T154522
788	2	784	3	20250211T154522
789	2	785	3	20250211T154522
790	2	786	3	20250211T154522
791	2	787	3	20250211T154522
792	2	788	3	20250211T154522
793	2	789	3	20250211T154522
794	2	790	3	20250211T154522
795	2	791	3	20250211T154522
796	2	792	3	20250211T154522
797	2	793	3	20250211T154522
798	2	794	3	20250211T154522
799	2	795	3	20250211T154522
800	2	796	3	20250211T154522
801	2	797	3	20250211T154522
802	2	798	3	20250211T154522
803	2	799	3	20250211T154522
804	2	800	3	20250211T154522
805	2	801	3	20250211T154522
806	2	802	3	20250211T154522
807	2	803	3	20250211T154522
808	2	804	3	20250211T154522
809	2	805	3	20250211T154522
810	2	806	3	20250211T154522
811	2	807	3	20250211T154522
812	2	808	3	20250211T154522
813	2	809	3	20250211T154522
814	2	810	3	20250211T154522
815	2	811	3	20250211T154522
816	2	812	3	20250211T154522
817	2	813	3	20250211T154522
818	2	814	3	20250211T154522
819	2	815	3	20250211T154522
820	2	816	3	20250211T154522
821	2	817	3	20250211T154522
822	2	818	3	20250211T154522
823	2	819	3	20250211T154522
824	2	820	3	20250211T154522
825	2	821	3	20250211T154522
826	2	822	3	20250211T154522
827	2	823	3	20250211T154522
828	2	824	3	20250211T154522
829	2	825	3	20250211T154522
830	2	826	3	20250211T154522
831	2	827	3	20250211T154522
832	2	828	3	20250211T154522
833	2	829	3	20250211T154522
834	15	522	2	20250211T154530
835	15	525	2	20250211T154530
836	15	527	2	20250211T154531
837	15	531	2	20250211T154531
838	15	655	2	20250211T154531
839	14	522	2	20250211T154622
840	14	531	2	20250211T154622
841	15	522	2	20250211T154622
842	15	531	2	20250211T154622
843	14	655	2	20250211T154623
844	14	525	2	20250211T154623
845	14	527	2	20250211T154623
846	13	521	1	20250211T154623
847	12	1	0	20250211T154623
848	15	655	2	20250211T154623
849	15	525	2	20250211T154623
850	15	527	2	20250211T154623
\.


--
-- Data for Name: deletedfiles; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.deletedfiles (uuid, filetype, compressedsize, uncompressedsize, compressiontype, uncompressedhash, compressedhash) FROM stdin;
d934e242-63d3-4b10-ad3d-7b2e479fab79	4301	12883	12883	1	cf47ebc1e54977af387b2ce0e5191e4c	cf47ebc1e54977af387b2ce0e5191e4c
\.


--
-- Data for Name: deletedresources; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.deletedresources (resourcetype, publicid) FROM stdin;
\.


--
-- Data for Name: dicomidentifiers; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.dicomidentifiers (id, taggroup, tagelement, value) FROM stdin;
4	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.3.0
3	32	14	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.5.0
2	16	32	NOID
2	16	16	NAME^NONE
2	16	48	
2	32	13	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.4.0
2	8	80	
2	8	32	20000101
1	16	32	NOID
1	16	16	NAME^NONE
1	16	48	
5	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.8.0
6	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.26.0
7	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.206.0
8	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.208.0
9	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.210.0
10	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.212.0
11	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.214.0
12	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.216.0
13	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.218.0
14	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.220.0
15	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.222.0
16	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.224.0
17	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.28.0
18	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.226.0
19	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.228.0
20	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.230.0
21	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.232.0
22	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.234.0
23	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.236.0
24	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.238.0
25	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.240.0
26	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.242.0
27	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.244.0
28	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.30.0
29	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.246.0
30	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.248.0
31	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.250.0
32	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.252.0
33	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.254.0
34	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.256.0
35	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.258.0
36	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.260.0
37	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.262.0
38	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.264.0
39	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.32.0
40	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.266.0
41	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.268.0
42	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.270.0
43	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.272.0
44	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.274.0
45	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.276.0
46	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.278.0
47	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.280.0
48	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.282.0
49	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.284.0
50	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.34.0
51	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.286.0
52	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.288.0
53	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.290.0
54	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.292.0
55	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.294.0
56	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.296.0
57	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.298.0
58	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.300.0
59	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.302.0
60	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.304.0
61	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.36.0
62	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.306.0
63	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.308.0
64	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.310.0
65	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.312.0
66	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.314.0
67	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.316.0
68	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.318.0
69	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.320.0
70	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.322.0
71	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.324.0
72	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.38.0
73	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.326.0
74	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.328.0
75	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.330.0
76	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.332.0
77	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.334.0
78	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.336.0
79	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.338.0
80	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.340.0
81	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.342.0
82	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.344.0
83	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.40.0
84	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.346.0
85	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.348.0
86	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.350.0
87	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.352.0
88	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.354.0
89	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.356.0
90	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.358.0
91	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.360.0
92	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.362.0
93	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.364.0
94	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.42.0
95	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.366.0
96	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.368.0
97	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.370.0
98	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.372.0
99	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.374.0
100	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.376.0
101	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.378.0
102	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.380.0
103	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.382.0
104	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.384.0
105	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.44.0
106	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.386.0
107	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.388.0
108	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.390.0
109	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.392.0
110	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.394.0
111	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.396.0
112	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.398.0
113	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.400.0
114	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.402.0
115	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.404.0
116	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.10.0
117	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.46.0
118	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.406.0
119	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.408.0
120	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.410.0
121	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.412.0
122	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.414.0
123	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.416.0
124	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.418.0
125	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.420.0
126	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.422.0
127	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.424.0
128	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.48.0
129	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.426.0
130	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.428.0
131	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.430.0
132	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.432.0
133	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.434.0
134	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.436.0
135	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.438.0
136	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.440.0
137	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.442.0
138	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.444.0
139	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.50.0
140	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.446.0
141	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.448.0
142	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.450.0
143	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.452.0
144	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.454.0
145	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.456.0
146	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.458.0
147	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.460.0
521	16	16	NAME^NONE
148	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.462.0
149	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.464.0
150	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.52.0
151	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.466.0
152	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.468.0
153	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.470.0
154	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.472.0
155	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.474.0
156	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.476.0
157	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.478.0
158	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.480.0
159	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.482.0
160	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.484.0
161	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.54.0
162	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.486.0
163	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.488.0
164	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.490.0
165	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.492.0
166	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.494.0
167	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.496.0
168	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.498.0
169	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.500.0
170	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.502.0
171	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.504.0
172	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.56.0
173	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.506.0
174	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.508.0
175	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.510.0
176	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.512.0
177	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.514.0
178	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.516.0
179	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.518.0
180	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.520.0
181	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.522.0
182	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.524.0
183	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.58.0
184	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.526.0
185	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.528.0
186	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.530.0
187	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.532.0
188	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.534.0
189	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.536.0
190	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.538.0
191	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.540.0
192	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.542.0
193	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.544.0
194	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.60.0
195	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.546.0
196	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.548.0
197	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.550.0
198	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.552.0
199	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.554.0
200	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.556.0
201	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.558.0
202	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.560.0
203	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.562.0
204	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.564.0
205	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.62.0
206	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.566.0
207	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.568.0
208	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.570.0
209	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.572.0
210	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.574.0
211	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.576.0
212	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.578.0
213	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.580.0
214	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.582.0
215	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.584.0
216	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.64.0
217	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.586.0
218	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.588.0
219	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.590.0
220	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.592.0
221	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.594.0
222	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.596.0
521	16	48	
223	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.598.0
224	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.600.0
225	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.602.0
226	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.604.0
227	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.12.0
228	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.66.0
229	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.606.0
230	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.608.0
231	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.610.0
232	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.612.0
233	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.614.0
234	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.616.0
235	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.618.0
236	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.620.0
237	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.622.0
238	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.624.0
239	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.68.0
240	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.626.0
241	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.628.0
242	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.630.0
243	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.632.0
244	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.634.0
245	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.636.0
246	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.638.0
247	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.640.0
248	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.642.0
249	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.644.0
250	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.70.0
251	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.646.0
252	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.648.0
253	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.650.0
254	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.652.0
255	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.654.0
256	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.656.0
257	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.658.0
258	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.660.0
259	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.662.0
260	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.664.0
261	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.72.0
262	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.666.0
263	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.668.0
264	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.670.0
265	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.672.0
266	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.674.0
267	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.676.0
268	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.678.0
269	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.680.0
270	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.682.0
271	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.684.0
272	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.74.0
273	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.686.0
274	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.688.0
275	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.690.0
276	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.692.0
277	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.694.0
278	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.696.0
279	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.698.0
280	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.700.0
281	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.702.0
282	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.704.0
283	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.76.0
284	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.706.0
285	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.708.0
286	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.710.0
287	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.712.0
288	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.714.0
289	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.716.0
290	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.718.0
291	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.720.0
292	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.722.0
293	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.724.0
294	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.78.0
295	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.726.0
296	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.728.0
297	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.730.0
298	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.732.0
299	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.734.0
300	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.736.0
301	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.738.0
302	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.740.0
303	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.742.0
304	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.744.0
305	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.80.0
306	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.746.0
307	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.748.0
308	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.750.0
309	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.752.0
310	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.754.0
311	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.756.0
312	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.758.0
313	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.760.0
314	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.762.0
315	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.764.0
316	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.82.0
317	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.766.0
318	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.768.0
319	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.770.0
320	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.772.0
321	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.774.0
322	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.776.0
323	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.778.0
324	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.780.0
325	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.782.0
326	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.784.0
327	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.84.0
328	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.786.0
329	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.788.0
330	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.790.0
331	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.792.0
332	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.794.0
333	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.796.0
334	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.798.0
335	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.800.0
336	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.802.0
337	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.804.0
338	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.14.0
339	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.86.0
340	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.806.0
341	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.808.0
342	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.810.0
343	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.812.0
344	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.814.0
345	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.816.0
346	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.818.0
347	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.820.0
348	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.822.0
349	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.824.0
350	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.88.0
351	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.826.0
352	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.828.0
353	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.830.0
354	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.832.0
355	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.834.0
356	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.836.0
357	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.838.0
358	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.840.0
359	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.842.0
360	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.844.0
361	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.90.0
362	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.846.0
363	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.848.0
364	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.850.0
365	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.852.0
366	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.854.0
367	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.856.0
368	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.858.0
369	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.860.0
370	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.862.0
371	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.864.0
372	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.92.0
373	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.866.0
374	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.868.0
375	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.870.0
376	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.872.0
377	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.874.0
378	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.876.0
379	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.878.0
380	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.880.0
381	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.882.0
382	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.884.0
383	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.94.0
384	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.886.0
385	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.888.0
386	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.890.0
387	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.892.0
388	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.894.0
389	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.896.0
390	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.898.0
391	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.900.0
392	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.902.0
393	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.904.0
394	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.96.0
395	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.906.0
396	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.908.0
397	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.910.0
398	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.912.0
399	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.914.0
400	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.916.0
401	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.918.0
402	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.920.0
403	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.922.0
404	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.924.0
405	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.98.0
406	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.926.0
407	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.928.0
408	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.930.0
409	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.932.0
410	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.934.0
411	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.936.0
412	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.938.0
413	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.940.0
414	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.942.0
415	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.944.0
416	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.100.0
417	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.946.0
418	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.948.0
419	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.950.0
420	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.952.0
421	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.954.0
422	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.956.0
423	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.958.0
424	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.960.0
425	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.962.0
426	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.964.0
427	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.102.0
428	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.966.0
429	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.968.0
430	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.970.0
431	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.972.0
432	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.974.0
433	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.976.0
434	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.978.0
435	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.980.0
436	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.982.0
437	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.984.0
438	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.104.0
439	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.986.0
440	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.988.0
441	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.990.0
442	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.992.0
443	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.994.0
444	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.996.0
445	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.998.0
446	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1000.0
447	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1002.0
448	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1004.0
449	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.16.0
450	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.106.0
451	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1006.0
452	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1008.0
453	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1010.0
454	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1012.0
455	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1014.0
456	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1016.0
457	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1018.0
458	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1020.0
459	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1022.0
460	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1024.0
461	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.108.0
462	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1026.0
463	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1028.0
464	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1030.0
465	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1032.0
466	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1034.0
467	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1036.0
468	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1038.0
469	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.110.0
470	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.112.0
471	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.114.0
472	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.116.0
473	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.118.0
474	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.120.0
475	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.122.0
476	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.124.0
477	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.18.0
478	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.126.0
479	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.128.0
480	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.130.0
481	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.132.0
482	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.134.0
483	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.136.0
484	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.138.0
485	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.140.0
486	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.142.0
487	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.144.0
488	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.20.0
489	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.146.0
490	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.148.0
491	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.150.0
492	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.152.0
493	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.154.0
494	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.156.0
495	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.158.0
496	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.160.0
497	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.162.0
498	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.164.0
499	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.22.0
500	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.166.0
501	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.168.0
502	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.170.0
503	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.172.0
504	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.174.0
505	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.176.0
506	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.178.0
507	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.180.0
508	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.182.0
509	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.184.0
510	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.24.0
511	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.186.0
512	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.188.0
513	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.190.0
514	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.192.0
515	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.194.0
516	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.196.0
517	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.198.0
518	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.200.0
519	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.202.0
520	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.204.0
523	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2590.0
522	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2593.0
521	16	32	NOID
521	32	13	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2592.0
521	8	80	
521	8	32	20100806
524	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2595.0
526	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2607.0
525	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2599.0
528	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2698.0
527	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2634.0
529	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2699.0
530	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2700.0
532	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2701.0
531	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2702.0
533	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2703.0
534	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2704.0
535	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2705.0
536	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2706.0
537	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2707.0
538	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2708.0
539	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2608.0
540	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2709.0
541	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2710.0
542	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2711.0
543	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2712.0
544	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2713.0
545	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2714.0
546	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2715.0
547	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2716.0
548	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2717.0
549	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2718.0
550	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2609.0
551	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2719.0
552	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2720.0
553	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2721.0
554	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2722.0
555	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2723.0
556	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2724.0
557	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2725.0
558	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2726.0
559	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2727.0
560	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2728.0
561	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2610.0
562	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2729.0
563	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2730.0
564	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2731.0
565	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2732.0
566	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2733.0
567	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2734.0
568	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2735.0
569	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2736.0
570	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2737.0
571	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2738.0
572	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2611.0
573	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2739.0
574	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2740.0
575	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2741.0
576	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2742.0
577	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2743.0
578	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2744.0
579	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2745.0
580	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2746.0
581	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2747.0
582	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2748.0
583	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2612.0
584	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2749.0
585	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2750.0
586	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2751.0
587	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2752.0
588	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2753.0
589	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2754.0
590	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2755.0
591	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2756.0
592	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2757.0
593	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2758.0
594	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2613.0
595	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2759.0
596	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2760.0
597	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2761.0
598	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2762.0
599	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2763.0
600	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2764.0
601	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2765.0
602	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2766.0
603	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2767.0
604	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2768.0
605	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2614.0
606	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2769.0
607	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2770.0
608	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2771.0
609	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2772.0
610	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2773.0
611	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2774.0
612	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2775.0
613	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2776.0
614	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2777.0
615	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2778.0
616	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2615.0
617	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2779.0
618	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2780.0
619	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2781.0
620	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2782.0
621	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2783.0
622	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2784.0
623	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2785.0
624	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2786.0
625	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2787.0
626	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2788.0
627	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2616.0
628	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2789.0
629	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2790.0
630	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2791.0
631	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2792.0
632	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2793.0
633	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2794.0
634	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2795.0
635	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2796.0
636	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2797.0
637	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2798.0
638	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2597.0
639	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2617.0
640	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2799.0
641	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2800.0
642	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2801.0
643	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2802.0
644	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2803.0
645	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2804.0
646	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2805.0
647	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2806.0
648	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2807.0
649	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2808.0
650	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2618.0
651	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2809.0
652	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2810.0
653	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2811.0
654	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2812.0
656	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2813.0
655	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2814.0
657	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2815.0
658	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2816.0
659	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2817.0
660	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2818.0
661	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2819.0
662	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2619.0
663	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2820.0
664	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2821.0
665	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2822.0
666	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2823.0
667	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2824.0
668	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2825.0
669	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2826.0
670	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2827.0
671	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2828.0
672	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2829.0
673	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2620.0
674	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2830.0
675	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2831.0
676	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2832.0
677	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2833.0
678	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2834.0
679	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2835.0
680	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2836.0
681	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2837.0
682	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2838.0
683	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2839.0
684	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2621.0
685	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2840.0
686	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2841.0
687	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2842.0
688	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2843.0
689	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2844.0
690	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2845.0
691	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2846.0
692	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2847.0
693	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2848.0
694	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2849.0
695	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2622.0
696	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2850.0
697	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2851.0
698	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2852.0
699	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2853.0
700	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2854.0
701	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2855.0
702	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2856.0
703	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2857.0
704	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2858.0
705	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2859.0
706	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2623.0
707	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2860.0
708	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2861.0
709	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2862.0
710	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2863.0
711	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2864.0
712	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2865.0
713	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2866.0
714	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2867.0
715	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2868.0
716	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2869.0
717	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2624.0
718	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2870.0
719	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2871.0
720	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2872.0
721	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2873.0
722	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2874.0
723	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2875.0
724	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2876.0
725	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2877.0
726	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2878.0
727	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2879.0
728	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2625.0
729	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2880.0
730	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2881.0
731	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2882.0
732	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2883.0
733	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2884.0
734	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2885.0
735	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2886.0
736	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2887.0
737	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2888.0
738	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2889.0
739	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2626.0
740	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2890.0
741	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2891.0
742	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2892.0
743	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2893.0
744	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2894.0
745	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2895.0
746	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2896.0
747	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2897.0
748	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2898.0
749	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2899.0
750	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2600.0
751	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2627.0
752	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2900.0
753	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2901.0
754	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2902.0
755	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2628.0
756	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2629.0
757	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2630.0
758	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2631.0
759	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2632.0
760	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2633.0
761	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2635.0
762	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2636.0
763	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2637.0
764	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2601.0
765	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2638.0
766	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2639.0
767	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2640.0
768	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2641.0
769	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2642.0
770	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2643.0
771	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2644.0
772	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2645.0
773	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2646.0
774	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2647.0
775	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2602.0
776	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2648.0
777	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2649.0
778	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2650.0
779	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2651.0
780	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2652.0
781	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2653.0
782	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2654.0
783	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2655.0
784	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2656.0
785	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2657.0
786	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2603.0
787	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2658.0
788	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2659.0
789	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2660.0
790	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2661.0
791	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2662.0
792	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2663.0
793	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2664.0
794	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2665.0
795	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2666.0
796	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2667.0
797	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2604.0
798	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2668.0
799	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2669.0
800	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2670.0
801	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2671.0
802	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2672.0
803	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2673.0
804	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2674.0
805	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2675.0
806	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2676.0
807	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2677.0
808	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2605.0
809	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2678.0
810	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2679.0
811	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2680.0
812	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2681.0
813	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2682.0
814	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2683.0
815	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2684.0
816	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2685.0
817	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2686.0
818	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2687.0
819	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2606.0
820	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2688.0
821	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2689.0
822	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2690.0
823	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2691.0
824	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2692.0
825	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2693.0
826	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2694.0
827	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2695.0
828	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2696.0
829	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2697.0
\.


--
-- Data for Name: exportedresources; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.exportedresources (seq, resourcetype, publicid, remotemodality, patientid, studyinstanceuid, seriesinstanceuid, sopinstanceuid, date) FROM stdin;
\.


--
-- Data for Name: globalintegers; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.globalintegers (key, value) FROM stdin;
2	1
3	2
0	67334438
1	67334438
6	850
4	6
5	820
\.


--
-- Data for Name: globalproperties; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.globalproperties (property, value) FROM stdin;
1	6
4	1
10	1
11	2
6	1
12	1
13	1
\.


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.labels (id, label) FROM stdin;
\.


--
-- Data for Name: maindicomtags; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.maindicomtags (id, taggroup, tagelement, value) FROM stdin;
4	8	18	20000101
4	8	19	000000.000
4	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.3.0
4	32	18	
4	32	19	1
4	32	50	0.000000\\0.000000\\-0.125000
4	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
4	40	8	1
3	8	33	20000101
3	8	49	000000.000
3	8	96	CT
3	8	112	Imaging Sciences International
3	32	14	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.5.0
3	32	17	1
3	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
2	16	16	NAME^NONE
2	16	32	NOID
2	16	48	
2	16	64	
2	8	32	20000101
2	8	48	000000.000
2	8	80	
2	8	144	
2	32	13	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.4.0
2	32	16	
1	16	16	NAME^NONE
1	16	32	NOID
1	16	48	
1	16	64	
5	8	18	20000101
5	8	19	000000.000
5	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.8.0
5	32	18	
5	32	19	2
5	32	50	0.000000\\0.000000\\-0.375000
5	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
5	40	8	1
6	8	18	20000101
6	8	19	000000.000
6	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.26.0
6	32	18	
6	32	19	11
6	32	50	0.000000\\0.000000\\-2.625000
6	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
6	40	8	1
7	8	18	20000101
7	8	19	000000.000
7	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.206.0
7	32	18	
7	32	19	101
7	32	50	0.000000\\0.000000\\-25.125000
7	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
7	40	8	1
8	8	18	20000101
8	8	19	000000.000
8	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.208.0
8	32	18	
8	32	19	102
8	32	50	0.000000\\0.000000\\-25.375000
8	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
8	40	8	1
9	8	18	20000101
9	8	19	000000.000
9	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.210.0
9	32	18	
9	32	19	103
9	32	50	0.000000\\0.000000\\-25.625000
9	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
9	40	8	1
10	8	18	20000101
10	8	19	000000.000
10	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.212.0
10	32	18	
10	32	19	104
10	32	50	0.000000\\0.000000\\-25.875000
10	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
10	40	8	1
11	8	18	20000101
11	8	19	000000.000
11	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.214.0
11	32	18	
11	32	19	105
11	32	50	0.000000\\0.000000\\-26.125000
11	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
11	40	8	1
12	8	18	20000101
12	8	19	000000.000
12	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.216.0
12	32	18	
12	32	19	106
12	32	50	0.000000\\0.000000\\-26.375000
12	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
12	40	8	1
13	8	18	20000101
13	8	19	000000.000
13	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.218.0
13	32	18	
13	32	19	107
13	32	50	0.000000\\0.000000\\-26.625000
13	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
13	40	8	1
14	8	18	20000101
14	8	19	000000.000
14	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.220.0
14	32	18	
14	32	19	108
14	32	50	0.000000\\0.000000\\-26.875000
14	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
14	40	8	1
15	8	18	20000101
15	8	19	000000.000
15	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.222.0
15	32	18	
15	32	19	109
15	32	50	0.000000\\0.000000\\-27.125000
15	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
15	40	8	1
16	8	18	20000101
16	8	19	000000.000
16	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.224.0
16	32	18	
16	32	19	110
16	32	50	0.000000\\0.000000\\-27.375000
16	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
16	40	8	1
17	8	18	20000101
17	8	19	000000.000
17	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.28.0
17	32	18	
17	32	19	12
17	32	50	0.000000\\0.000000\\-2.875000
17	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
17	40	8	1
18	8	18	20000101
18	8	19	000000.000
18	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.226.0
18	32	18	
18	32	19	111
18	32	50	0.000000\\0.000000\\-27.625000
18	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
18	40	8	1
19	8	18	20000101
19	8	19	000000.000
19	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.228.0
19	32	18	
19	32	19	112
19	32	50	0.000000\\0.000000\\-27.875000
19	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
19	40	8	1
20	8	18	20000101
20	8	19	000000.000
20	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.230.0
20	32	18	
20	32	19	113
20	32	50	0.000000\\0.000000\\-28.125000
20	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
20	40	8	1
21	8	18	20000101
21	8	19	000000.000
21	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.232.0
21	32	18	
21	32	19	114
21	32	50	0.000000\\0.000000\\-28.375000
21	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
21	40	8	1
22	8	18	20000101
22	8	19	000000.000
22	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.234.0
22	32	18	
22	32	19	115
22	32	50	0.000000\\0.000000\\-28.625000
22	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
22	40	8	1
23	8	18	20000101
23	8	19	000000.000
23	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.236.0
23	32	18	
23	32	19	116
23	32	50	0.000000\\0.000000\\-28.875000
23	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
23	40	8	1
24	8	18	20000101
24	8	19	000000.000
24	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.238.0
24	32	18	
24	32	19	117
24	32	50	0.000000\\0.000000\\-29.125000
24	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
24	40	8	1
25	8	18	20000101
25	8	19	000000.000
25	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.240.0
25	32	18	
25	32	19	118
25	32	50	0.000000\\0.000000\\-29.375000
25	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
25	40	8	1
26	8	18	20000101
26	8	19	000000.000
26	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.242.0
26	32	18	
26	32	19	119
26	32	50	0.000000\\0.000000\\-29.625000
26	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
26	40	8	1
27	8	18	20000101
27	8	19	000000.000
27	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.244.0
27	32	18	
27	32	19	120
27	32	50	0.000000\\0.000000\\-29.875000
27	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
27	40	8	1
28	8	18	20000101
28	8	19	000000.000
28	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.30.0
28	32	18	
28	32	19	13
28	32	50	0.000000\\0.000000\\-3.125000
28	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
28	40	8	1
29	8	18	20000101
29	8	19	000000.000
29	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.246.0
29	32	18	
29	32	19	121
29	32	50	0.000000\\0.000000\\-30.125000
29	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
29	40	8	1
30	8	18	20000101
30	8	19	000000.000
30	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.248.0
30	32	18	
30	32	19	122
30	32	50	0.000000\\0.000000\\-30.375000
30	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
30	40	8	1
31	8	18	20000101
31	8	19	000000.000
31	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.250.0
31	32	18	
31	32	19	123
31	32	50	0.000000\\0.000000\\-30.625000
31	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
31	40	8	1
32	8	18	20000101
32	8	19	000000.000
32	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.252.0
32	32	18	
32	32	19	124
32	32	50	0.000000\\0.000000\\-30.875000
32	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
32	40	8	1
33	8	18	20000101
33	8	19	000000.000
33	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.254.0
33	32	18	
33	32	19	125
33	32	50	0.000000\\0.000000\\-31.125000
33	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
33	40	8	1
34	8	18	20000101
34	8	19	000000.000
34	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.256.0
34	32	18	
34	32	19	126
34	32	50	0.000000\\0.000000\\-31.375000
34	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
34	40	8	1
35	8	18	20000101
35	8	19	000000.000
35	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.258.0
35	32	18	
35	32	19	127
35	32	50	0.000000\\0.000000\\-31.625000
35	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
35	40	8	1
36	8	18	20000101
36	8	19	000000.000
36	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.260.0
36	32	18	
36	32	19	128
36	32	50	0.000000\\0.000000\\-31.875000
36	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
36	40	8	1
37	8	18	20000101
37	8	19	000000.000
37	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.262.0
37	32	18	
37	32	19	129
37	32	50	0.000000\\0.000000\\-32.125000
37	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
37	40	8	1
38	8	18	20000101
38	8	19	000000.000
38	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.264.0
38	32	18	
38	32	19	130
38	32	50	0.000000\\0.000000\\-32.375000
38	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
38	40	8	1
39	8	18	20000101
39	8	19	000000.000
39	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.32.0
39	32	18	
39	32	19	14
39	32	50	0.000000\\0.000000\\-3.375000
39	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
39	40	8	1
40	8	18	20000101
40	8	19	000000.000
40	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.266.0
40	32	18	
40	32	19	131
40	32	50	0.000000\\0.000000\\-32.625000
40	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
40	40	8	1
41	8	18	20000101
41	8	19	000000.000
41	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.268.0
41	32	18	
41	32	19	132
41	32	50	0.000000\\0.000000\\-32.875000
41	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
41	40	8	1
42	8	18	20000101
42	8	19	000000.000
42	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.270.0
42	32	18	
42	32	19	133
42	32	50	0.000000\\0.000000\\-33.125000
42	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
42	40	8	1
43	8	18	20000101
43	8	19	000000.000
43	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.272.0
43	32	18	
43	32	19	134
43	32	50	0.000000\\0.000000\\-33.375000
43	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
43	40	8	1
44	8	18	20000101
44	8	19	000000.000
44	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.274.0
44	32	18	
44	32	19	135
44	32	50	0.000000\\0.000000\\-33.625000
44	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
44	40	8	1
45	8	18	20000101
45	8	19	000000.000
45	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.276.0
45	32	18	
45	32	19	136
45	32	50	0.000000\\0.000000\\-33.875000
45	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
45	40	8	1
46	8	18	20000101
46	8	19	000000.000
46	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.278.0
46	32	18	
46	32	19	137
46	32	50	0.000000\\0.000000\\-34.125000
46	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
46	40	8	1
47	8	18	20000101
47	8	19	000000.000
47	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.280.0
47	32	18	
47	32	19	138
47	32	50	0.000000\\0.000000\\-34.375000
47	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
47	40	8	1
48	8	18	20000101
48	8	19	000000.000
48	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.282.0
48	32	18	
48	32	19	139
48	32	50	0.000000\\0.000000\\-34.625000
48	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
48	40	8	1
49	8	18	20000101
49	8	19	000000.000
49	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.284.0
49	32	18	
49	32	19	140
49	32	50	0.000000\\0.000000\\-34.875000
49	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
49	40	8	1
50	8	18	20000101
50	8	19	000000.000
50	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.34.0
50	32	18	
50	32	19	15
50	32	50	0.000000\\0.000000\\-3.625000
50	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
50	40	8	1
51	8	18	20000101
51	8	19	000000.000
51	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.286.0
51	32	18	
51	32	19	141
51	32	50	0.000000\\0.000000\\-35.125000
51	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
51	40	8	1
52	8	18	20000101
52	8	19	000000.000
52	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.288.0
52	32	18	
52	32	19	142
52	32	50	0.000000\\0.000000\\-35.375000
52	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
52	40	8	1
53	8	18	20000101
53	8	19	000000.000
53	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.290.0
53	32	18	
53	32	19	143
53	32	50	0.000000\\0.000000\\-35.625000
53	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
53	40	8	1
54	8	18	20000101
54	8	19	000000.000
54	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.292.0
54	32	18	
54	32	19	144
54	32	50	0.000000\\0.000000\\-35.875000
54	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
54	40	8	1
55	8	18	20000101
55	8	19	000000.000
55	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.294.0
55	32	18	
55	32	19	145
55	32	50	0.000000\\0.000000\\-36.125000
55	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
55	40	8	1
56	8	18	20000101
56	8	19	000000.000
56	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.296.0
56	32	18	
56	32	19	146
56	32	50	0.000000\\0.000000\\-36.375000
56	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
56	40	8	1
57	8	18	20000101
57	8	19	000000.000
57	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.298.0
57	32	18	
57	32	19	147
57	32	50	0.000000\\0.000000\\-36.625000
57	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
57	40	8	1
58	8	18	20000101
58	8	19	000000.000
58	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.300.0
58	32	18	
58	32	19	148
58	32	50	0.000000\\0.000000\\-36.875000
58	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
58	40	8	1
59	8	18	20000101
59	8	19	000000.000
59	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.302.0
59	32	18	
59	32	19	149
59	32	50	0.000000\\0.000000\\-37.125000
59	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
59	40	8	1
60	8	18	20000101
60	8	19	000000.000
60	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.304.0
60	32	18	
60	32	19	150
60	32	50	0.000000\\0.000000\\-37.375000
60	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
60	40	8	1
61	8	18	20000101
61	8	19	000000.000
61	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.36.0
61	32	18	
61	32	19	16
61	32	50	0.000000\\0.000000\\-3.875000
61	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
61	40	8	1
62	8	18	20000101
62	8	19	000000.000
62	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.306.0
62	32	18	
62	32	19	151
62	32	50	0.000000\\0.000000\\-37.625000
62	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
62	40	8	1
63	8	18	20000101
63	8	19	000000.000
63	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.308.0
63	32	18	
63	32	19	152
63	32	50	0.000000\\0.000000\\-37.875000
63	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
63	40	8	1
64	8	18	20000101
64	8	19	000000.000
64	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.310.0
64	32	18	
64	32	19	153
64	32	50	0.000000\\0.000000\\-38.125000
64	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
64	40	8	1
65	8	18	20000101
65	8	19	000000.000
65	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.312.0
65	32	18	
65	32	19	154
65	32	50	0.000000\\0.000000\\-38.375000
65	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
65	40	8	1
66	8	18	20000101
66	8	19	000000.000
66	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.314.0
66	32	18	
66	32	19	155
66	32	50	0.000000\\0.000000\\-38.625000
66	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
66	40	8	1
67	8	18	20000101
67	8	19	000000.000
67	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.316.0
67	32	18	
67	32	19	156
67	32	50	0.000000\\0.000000\\-38.875000
67	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
67	40	8	1
68	8	18	20000101
68	8	19	000000.000
68	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.318.0
68	32	18	
68	32	19	157
68	32	50	0.000000\\0.000000\\-39.125000
68	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
68	40	8	1
69	8	18	20000101
69	8	19	000000.000
69	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.320.0
69	32	18	
69	32	19	158
69	32	50	0.000000\\0.000000\\-39.375000
69	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
69	40	8	1
70	8	18	20000101
70	8	19	000000.000
70	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.322.0
70	32	18	
70	32	19	159
70	32	50	0.000000\\0.000000\\-39.625000
70	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
70	40	8	1
71	8	18	20000101
71	8	19	000000.000
71	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.324.0
71	32	18	
71	32	19	160
71	32	50	0.000000\\0.000000\\-39.875000
71	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
71	40	8	1
72	8	18	20000101
72	8	19	000000.000
72	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.38.0
72	32	18	
72	32	19	17
72	32	50	0.000000\\0.000000\\-4.125000
72	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
72	40	8	1
73	8	18	20000101
73	8	19	000000.000
73	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.326.0
73	32	18	
73	32	19	161
73	32	50	0.000000\\0.000000\\-40.125000
73	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
73	40	8	1
74	8	18	20000101
74	8	19	000000.000
74	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.328.0
74	32	18	
74	32	19	162
74	32	50	0.000000\\0.000000\\-40.375000
74	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
74	40	8	1
75	8	18	20000101
75	8	19	000000.000
75	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.330.0
75	32	18	
75	32	19	163
75	32	50	0.000000\\0.000000\\-40.625000
75	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
75	40	8	1
76	8	18	20000101
76	8	19	000000.000
76	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.332.0
76	32	18	
76	32	19	164
76	32	50	0.000000\\0.000000\\-40.875000
76	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
76	40	8	1
77	8	18	20000101
77	8	19	000000.000
77	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.334.0
77	32	18	
77	32	19	165
77	32	50	0.000000\\0.000000\\-41.125000
77	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
77	40	8	1
78	8	18	20000101
78	8	19	000000.000
78	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.336.0
78	32	18	
78	32	19	166
78	32	50	0.000000\\0.000000\\-41.375000
78	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
78	40	8	1
79	8	18	20000101
79	8	19	000000.000
79	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.338.0
79	32	18	
79	32	19	167
79	32	50	0.000000\\0.000000\\-41.625000
79	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
79	40	8	1
80	8	18	20000101
80	8	19	000000.000
80	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.340.0
80	32	18	
80	32	19	168
80	32	50	0.000000\\0.000000\\-41.875000
80	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
80	40	8	1
81	8	18	20000101
81	8	19	000000.000
81	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.342.0
81	32	18	
81	32	19	169
81	32	50	0.000000\\0.000000\\-42.125000
81	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
81	40	8	1
82	8	18	20000101
82	8	19	000000.000
82	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.344.0
82	32	18	
82	32	19	170
82	32	50	0.000000\\0.000000\\-42.375000
82	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
82	40	8	1
83	8	18	20000101
83	8	19	000000.000
83	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.40.0
83	32	18	
83	32	19	18
83	32	50	0.000000\\0.000000\\-4.375000
83	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
83	40	8	1
84	8	18	20000101
84	8	19	000000.000
84	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.346.0
84	32	18	
84	32	19	171
84	32	50	0.000000\\0.000000\\-42.625000
84	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
84	40	8	1
85	8	18	20000101
85	8	19	000000.000
85	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.348.0
85	32	18	
85	32	19	172
85	32	50	0.000000\\0.000000\\-42.875000
85	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
85	40	8	1
86	8	18	20000101
86	8	19	000000.000
86	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.350.0
86	32	18	
86	32	19	173
86	32	50	0.000000\\0.000000\\-43.125000
86	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
86	40	8	1
87	8	18	20000101
87	8	19	000000.000
87	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.352.0
87	32	18	
87	32	19	174
87	32	50	0.000000\\0.000000\\-43.375000
87	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
87	40	8	1
88	8	18	20000101
88	8	19	000000.000
88	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.354.0
88	32	18	
88	32	19	175
88	32	50	0.000000\\0.000000\\-43.625000
88	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
88	40	8	1
89	8	18	20000101
89	8	19	000000.000
89	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.356.0
89	32	18	
89	32	19	176
89	32	50	0.000000\\0.000000\\-43.875000
89	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
89	40	8	1
90	8	18	20000101
90	8	19	000000.000
90	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.358.0
90	32	18	
90	32	19	177
90	32	50	0.000000\\0.000000\\-44.125000
90	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
90	40	8	1
91	8	18	20000101
91	8	19	000000.000
91	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.360.0
91	32	18	
91	32	19	178
91	32	50	0.000000\\0.000000\\-44.375000
91	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
91	40	8	1
92	8	18	20000101
92	8	19	000000.000
92	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.362.0
92	32	18	
92	32	19	179
92	32	50	0.000000\\0.000000\\-44.625000
92	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
92	40	8	1
93	8	18	20000101
93	8	19	000000.000
93	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.364.0
93	32	18	
93	32	19	180
93	32	50	0.000000\\0.000000\\-44.875000
93	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
93	40	8	1
94	8	18	20000101
94	8	19	000000.000
94	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.42.0
94	32	18	
94	32	19	19
94	32	50	0.000000\\0.000000\\-4.625000
94	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
94	40	8	1
95	8	18	20000101
95	8	19	000000.000
95	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.366.0
95	32	18	
95	32	19	181
95	32	50	0.000000\\0.000000\\-45.125000
95	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
95	40	8	1
96	8	18	20000101
96	8	19	000000.000
96	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.368.0
96	32	18	
96	32	19	182
96	32	50	0.000000\\0.000000\\-45.375000
96	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
96	40	8	1
97	8	18	20000101
97	8	19	000000.000
97	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.370.0
97	32	18	
97	32	19	183
97	32	50	0.000000\\0.000000\\-45.625000
97	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
97	40	8	1
98	8	18	20000101
98	8	19	000000.000
98	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.372.0
98	32	18	
98	32	19	184
98	32	50	0.000000\\0.000000\\-45.875000
98	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
98	40	8	1
99	8	18	20000101
99	8	19	000000.000
99	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.374.0
99	32	18	
99	32	19	185
99	32	50	0.000000\\0.000000\\-46.125000
99	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
99	40	8	1
100	8	18	20000101
100	8	19	000000.000
100	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.376.0
100	32	18	
100	32	19	186
100	32	50	0.000000\\0.000000\\-46.375000
100	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
100	40	8	1
101	8	18	20000101
101	8	19	000000.000
101	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.378.0
101	32	18	
101	32	19	187
101	32	50	0.000000\\0.000000\\-46.625000
101	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
101	40	8	1
102	8	18	20000101
102	8	19	000000.000
102	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.380.0
102	32	18	
102	32	19	188
102	32	50	0.000000\\0.000000\\-46.875000
102	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
102	40	8	1
103	8	18	20000101
103	8	19	000000.000
103	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.382.0
103	32	18	
103	32	19	189
103	32	50	0.000000\\0.000000\\-47.125000
103	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
103	40	8	1
104	8	18	20000101
104	8	19	000000.000
104	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.384.0
104	32	18	
104	32	19	190
104	32	50	0.000000\\0.000000\\-47.375000
104	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
104	40	8	1
105	8	18	20000101
105	8	19	000000.000
105	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.44.0
105	32	18	
105	32	19	20
105	32	50	0.000000\\0.000000\\-4.875000
105	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
105	40	8	1
106	8	18	20000101
106	8	19	000000.000
106	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.386.0
106	32	18	
106	32	19	191
106	32	50	0.000000\\0.000000\\-47.625000
106	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
106	40	8	1
107	8	18	20000101
107	8	19	000000.000
107	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.388.0
107	32	18	
107	32	19	192
107	32	50	0.000000\\0.000000\\-47.875000
107	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
107	40	8	1
108	8	18	20000101
108	8	19	000000.000
108	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.390.0
108	32	18	
108	32	19	193
108	32	50	0.000000\\0.000000\\-48.125000
108	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
108	40	8	1
109	8	18	20000101
109	8	19	000000.000
109	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.392.0
109	32	18	
109	32	19	194
109	32	50	0.000000\\0.000000\\-48.375000
109	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
109	40	8	1
110	8	18	20000101
110	8	19	000000.000
110	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.394.0
110	32	18	
110	32	19	195
110	32	50	0.000000\\0.000000\\-48.625000
110	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
110	40	8	1
111	8	18	20000101
111	8	19	000000.000
111	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.396.0
111	32	18	
111	32	19	196
111	32	50	0.000000\\0.000000\\-48.875000
111	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
111	40	8	1
112	8	18	20000101
112	8	19	000000.000
112	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.398.0
112	32	18	
112	32	19	197
112	32	50	0.000000\\0.000000\\-49.125000
112	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
112	40	8	1
113	8	18	20000101
113	8	19	000000.000
113	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.400.0
113	32	18	
113	32	19	198
113	32	50	0.000000\\0.000000\\-49.375000
113	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
113	40	8	1
114	8	18	20000101
114	8	19	000000.000
114	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.402.0
114	32	18	
114	32	19	199
114	32	50	0.000000\\0.000000\\-49.625000
114	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
114	40	8	1
115	8	18	20000101
115	8	19	000000.000
115	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.404.0
115	32	18	
115	32	19	200
115	32	50	0.000000\\0.000000\\-49.875000
115	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
115	40	8	1
116	8	18	20000101
116	8	19	000000.000
116	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.10.0
116	32	18	
116	32	19	3
116	32	50	0.000000\\0.000000\\-0.625000
116	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
116	40	8	1
117	8	18	20000101
117	8	19	000000.000
117	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.46.0
117	32	18	
117	32	19	21
117	32	50	0.000000\\0.000000\\-5.125000
117	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
117	40	8	1
118	8	18	20000101
118	8	19	000000.000
118	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.406.0
118	32	18	
118	32	19	201
118	32	50	0.000000\\0.000000\\-50.125000
118	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
118	40	8	1
119	8	18	20000101
119	8	19	000000.000
119	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.408.0
119	32	18	
119	32	19	202
119	32	50	0.000000\\0.000000\\-50.375000
119	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
119	40	8	1
120	8	18	20000101
120	8	19	000000.000
120	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.410.0
120	32	18	
120	32	19	203
120	32	50	0.000000\\0.000000\\-50.625000
120	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
120	40	8	1
121	8	18	20000101
121	8	19	000000.000
121	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.412.0
121	32	18	
121	32	19	204
121	32	50	0.000000\\0.000000\\-50.875000
121	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
121	40	8	1
122	8	18	20000101
122	8	19	000000.000
122	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.414.0
122	32	18	
122	32	19	205
122	32	50	0.000000\\0.000000\\-51.125000
122	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
122	40	8	1
123	8	18	20000101
123	8	19	000000.000
123	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.416.0
123	32	18	
123	32	19	206
123	32	50	0.000000\\0.000000\\-51.375000
123	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
123	40	8	1
124	8	18	20000101
124	8	19	000000.000
124	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.418.0
124	32	18	
124	32	19	207
124	32	50	0.000000\\0.000000\\-51.625000
124	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
124	40	8	1
125	8	18	20000101
125	8	19	000000.000
125	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.420.0
125	32	18	
125	32	19	208
125	32	50	0.000000\\0.000000\\-51.875000
125	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
125	40	8	1
126	8	18	20000101
126	8	19	000000.000
126	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.422.0
126	32	18	
126	32	19	209
126	32	50	0.000000\\0.000000\\-52.125000
126	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
126	40	8	1
127	8	18	20000101
127	8	19	000000.000
127	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.424.0
127	32	18	
127	32	19	210
127	32	50	0.000000\\0.000000\\-52.375000
127	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
127	40	8	1
128	8	18	20000101
128	8	19	000000.000
128	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.48.0
128	32	18	
128	32	19	22
128	32	50	0.000000\\0.000000\\-5.375000
128	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
128	40	8	1
129	8	18	20000101
129	8	19	000000.000
129	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.426.0
129	32	18	
129	32	19	211
129	32	50	0.000000\\0.000000\\-52.625000
129	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
129	40	8	1
130	8	18	20000101
130	8	19	000000.000
130	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.428.0
130	32	18	
130	32	19	212
130	32	50	0.000000\\0.000000\\-52.875000
130	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
130	40	8	1
131	8	18	20000101
131	8	19	000000.000
131	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.430.0
131	32	18	
131	32	19	213
131	32	50	0.000000\\0.000000\\-53.125000
131	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
131	40	8	1
132	8	18	20000101
132	8	19	000000.000
132	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.432.0
132	32	18	
132	32	19	214
132	32	50	0.000000\\0.000000\\-53.375000
132	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
132	40	8	1
133	8	18	20000101
133	8	19	000000.000
133	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.434.0
133	32	18	
133	32	19	215
133	32	50	0.000000\\0.000000\\-53.625000
133	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
133	40	8	1
134	8	18	20000101
134	8	19	000000.000
134	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.436.0
134	32	18	
134	32	19	216
134	32	50	0.000000\\0.000000\\-53.875000
134	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
134	40	8	1
135	8	18	20000101
135	8	19	000000.000
135	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.438.0
135	32	18	
135	32	19	217
135	32	50	0.000000\\0.000000\\-54.125000
135	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
135	40	8	1
136	8	18	20000101
136	8	19	000000.000
136	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.440.0
136	32	18	
136	32	19	218
136	32	50	0.000000\\0.000000\\-54.375000
136	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
136	40	8	1
137	8	18	20000101
137	8	19	000000.000
137	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.442.0
137	32	18	
137	32	19	219
137	32	50	0.000000\\0.000000\\-54.625000
137	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
137	40	8	1
138	8	18	20000101
138	8	19	000000.000
138	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.444.0
138	32	18	
138	32	19	220
138	32	50	0.000000\\0.000000\\-54.875000
138	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
138	40	8	1
139	8	18	20000101
139	8	19	000000.000
139	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.50.0
139	32	18	
139	32	19	23
139	32	50	0.000000\\0.000000\\-5.625000
139	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
139	40	8	1
140	8	18	20000101
140	8	19	000000.000
140	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.446.0
140	32	18	
140	32	19	221
140	32	50	0.000000\\0.000000\\-55.125000
140	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
140	40	8	1
141	8	18	20000101
141	8	19	000000.000
141	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.448.0
141	32	18	
141	32	19	222
141	32	50	0.000000\\0.000000\\-55.375000
141	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
141	40	8	1
142	8	18	20000101
142	8	19	000000.000
142	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.450.0
142	32	18	
142	32	19	223
142	32	50	0.000000\\0.000000\\-55.625000
142	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
142	40	8	1
143	8	18	20000101
143	8	19	000000.000
143	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.452.0
143	32	18	
143	32	19	224
143	32	50	0.000000\\0.000000\\-55.875000
143	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
143	40	8	1
144	8	18	20000101
144	8	19	000000.000
144	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.454.0
144	32	18	
144	32	19	225
144	32	50	0.000000\\0.000000\\-56.125000
144	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
144	40	8	1
145	8	18	20000101
145	8	19	000000.000
145	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.456.0
145	32	18	
145	32	19	226
145	32	50	0.000000\\0.000000\\-56.375000
145	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
145	40	8	1
146	8	18	20000101
146	8	19	000000.000
146	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.458.0
146	32	18	
146	32	19	227
146	32	50	0.000000\\0.000000\\-56.625000
146	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
146	40	8	1
147	8	18	20000101
147	8	19	000000.000
147	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.460.0
147	32	18	
147	32	19	228
147	32	50	0.000000\\0.000000\\-56.875000
147	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
147	40	8	1
148	8	18	20000101
148	8	19	000000.000
148	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.462.0
148	32	18	
148	32	19	229
148	32	50	0.000000\\0.000000\\-57.125000
148	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
148	40	8	1
149	8	18	20000101
149	8	19	000000.000
149	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.464.0
149	32	18	
149	32	19	230
149	32	50	0.000000\\0.000000\\-57.375000
149	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
149	40	8	1
150	8	18	20000101
150	8	19	000000.000
150	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.52.0
150	32	18	
150	32	19	24
150	32	50	0.000000\\0.000000\\-5.875000
150	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
150	40	8	1
151	8	18	20000101
151	8	19	000000.000
151	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.466.0
151	32	18	
151	32	19	231
151	32	50	0.000000\\0.000000\\-57.625000
151	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
151	40	8	1
152	8	18	20000101
152	8	19	000000.000
152	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.468.0
152	32	18	
152	32	19	232
152	32	50	0.000000\\0.000000\\-57.875000
152	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
152	40	8	1
153	8	18	20000101
153	8	19	000000.000
153	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.470.0
153	32	18	
153	32	19	233
153	32	50	0.000000\\0.000000\\-58.125000
153	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
153	40	8	1
154	8	18	20000101
154	8	19	000000.000
154	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.472.0
154	32	18	
154	32	19	234
154	32	50	0.000000\\0.000000\\-58.375000
154	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
154	40	8	1
155	8	18	20000101
155	8	19	000000.000
155	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.474.0
155	32	18	
155	32	19	235
155	32	50	0.000000\\0.000000\\-58.625000
155	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
155	40	8	1
156	8	18	20000101
156	8	19	000000.000
156	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.476.0
156	32	18	
156	32	19	236
156	32	50	0.000000\\0.000000\\-58.875000
156	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
156	40	8	1
157	8	18	20000101
157	8	19	000000.000
157	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.478.0
157	32	18	
157	32	19	237
157	32	50	0.000000\\0.000000\\-59.125000
157	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
157	40	8	1
158	8	18	20000101
158	8	19	000000.000
158	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.480.0
158	32	18	
158	32	19	238
158	32	50	0.000000\\0.000000\\-59.375000
158	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
158	40	8	1
159	8	18	20000101
159	8	19	000000.000
159	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.482.0
159	32	18	
159	32	19	239
159	32	50	0.000000\\0.000000\\-59.625000
159	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
159	40	8	1
160	8	18	20000101
160	8	19	000000.000
160	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.484.0
160	32	18	
160	32	19	240
160	32	50	0.000000\\0.000000\\-59.875000
160	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
160	40	8	1
161	8	18	20000101
161	8	19	000000.000
161	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.54.0
161	32	18	
161	32	19	25
161	32	50	0.000000\\0.000000\\-6.125000
161	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
161	40	8	1
162	8	18	20000101
162	8	19	000000.000
162	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.486.0
162	32	18	
162	32	19	241
162	32	50	0.000000\\0.000000\\-60.125000
162	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
162	40	8	1
163	8	18	20000101
163	8	19	000000.000
163	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.488.0
163	32	18	
163	32	19	242
163	32	50	0.000000\\0.000000\\-60.375000
163	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
163	40	8	1
164	8	18	20000101
164	8	19	000000.000
164	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.490.0
164	32	18	
164	32	19	243
164	32	50	0.000000\\0.000000\\-60.625000
164	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
164	40	8	1
165	8	18	20000101
165	8	19	000000.000
165	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.492.0
165	32	18	
165	32	19	244
165	32	50	0.000000\\0.000000\\-60.875000
165	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
165	40	8	1
166	8	18	20000101
166	8	19	000000.000
166	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.494.0
166	32	18	
166	32	19	245
166	32	50	0.000000\\0.000000\\-61.125000
166	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
166	40	8	1
167	8	18	20000101
167	8	19	000000.000
167	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.496.0
167	32	18	
167	32	19	246
167	32	50	0.000000\\0.000000\\-61.375000
167	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
167	40	8	1
168	8	18	20000101
168	8	19	000000.000
168	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.498.0
168	32	18	
168	32	19	247
168	32	50	0.000000\\0.000000\\-61.625000
168	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
168	40	8	1
169	8	18	20000101
169	8	19	000000.000
169	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.500.0
169	32	18	
169	32	19	248
169	32	50	0.000000\\0.000000\\-61.875000
169	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
169	40	8	1
170	8	18	20000101
170	8	19	000000.000
170	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.502.0
170	32	18	
170	32	19	249
170	32	50	0.000000\\0.000000\\-62.125000
170	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
170	40	8	1
171	8	18	20000101
171	8	19	000000.000
171	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.504.0
171	32	18	
171	32	19	250
171	32	50	0.000000\\0.000000\\-62.375000
171	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
171	40	8	1
172	8	18	20000101
172	8	19	000000.000
172	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.56.0
172	32	18	
172	32	19	26
172	32	50	0.000000\\0.000000\\-6.375000
172	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
172	40	8	1
173	8	18	20000101
173	8	19	000000.000
173	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.506.0
173	32	18	
173	32	19	251
173	32	50	0.000000\\0.000000\\-62.625000
173	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
173	40	8	1
174	8	18	20000101
174	8	19	000000.000
174	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.508.0
174	32	18	
174	32	19	252
174	32	50	0.000000\\0.000000\\-62.875000
174	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
174	40	8	1
175	8	18	20000101
175	8	19	000000.000
175	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.510.0
175	32	18	
175	32	19	253
175	32	50	0.000000\\0.000000\\-63.125000
175	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
175	40	8	1
176	8	18	20000101
176	8	19	000000.000
176	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.512.0
176	32	18	
176	32	19	254
176	32	50	0.000000\\0.000000\\-63.375000
176	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
176	40	8	1
177	8	18	20000101
177	8	19	000000.000
177	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.514.0
177	32	18	
177	32	19	255
177	32	50	0.000000\\0.000000\\-63.625000
177	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
177	40	8	1
178	8	18	20000101
178	8	19	000000.000
178	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.516.0
178	32	18	
178	32	19	256
178	32	50	0.000000\\0.000000\\-63.875000
178	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
178	40	8	1
179	8	18	20000101
179	8	19	000000.000
179	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.518.0
179	32	18	
179	32	19	257
179	32	50	0.000000\\0.000000\\-64.125000
179	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
179	40	8	1
180	8	18	20000101
180	8	19	000000.000
180	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.520.0
180	32	18	
180	32	19	258
180	32	50	0.000000\\0.000000\\-64.375000
180	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
180	40	8	1
181	8	18	20000101
181	8	19	000000.000
181	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.522.0
181	32	18	
181	32	19	259
181	32	50	0.000000\\0.000000\\-64.625000
181	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
181	40	8	1
182	8	18	20000101
182	8	19	000000.000
182	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.524.0
182	32	18	
182	32	19	260
182	32	50	0.000000\\0.000000\\-64.875000
182	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
182	40	8	1
183	8	18	20000101
183	8	19	000000.000
183	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.58.0
183	32	18	
183	32	19	27
183	32	50	0.000000\\0.000000\\-6.625000
183	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
183	40	8	1
184	8	18	20000101
184	8	19	000000.000
184	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.526.0
184	32	18	
184	32	19	261
184	32	50	0.000000\\0.000000\\-65.125000
184	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
184	40	8	1
185	8	18	20000101
185	8	19	000000.000
185	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.528.0
185	32	18	
185	32	19	262
185	32	50	0.000000\\0.000000\\-65.375000
185	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
185	40	8	1
186	8	18	20000101
186	8	19	000000.000
186	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.530.0
186	32	18	
186	32	19	263
186	32	50	0.000000\\0.000000\\-65.625000
186	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
186	40	8	1
187	8	18	20000101
187	8	19	000000.000
187	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.532.0
187	32	18	
187	32	19	264
187	32	50	0.000000\\0.000000\\-65.875000
187	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
187	40	8	1
188	8	18	20000101
188	8	19	000000.000
188	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.534.0
188	32	18	
188	32	19	265
188	32	50	0.000000\\0.000000\\-66.125000
188	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
188	40	8	1
189	8	18	20000101
189	8	19	000000.000
189	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.536.0
189	32	18	
189	32	19	266
189	32	50	0.000000\\0.000000\\-66.375000
189	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
189	40	8	1
190	8	18	20000101
190	8	19	000000.000
190	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.538.0
190	32	18	
190	32	19	267
190	32	50	0.000000\\0.000000\\-66.625000
190	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
190	40	8	1
191	8	18	20000101
191	8	19	000000.000
191	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.540.0
191	32	18	
191	32	19	268
191	32	50	0.000000\\0.000000\\-66.875000
191	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
191	40	8	1
192	8	18	20000101
192	8	19	000000.000
192	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.542.0
192	32	18	
192	32	19	269
192	32	50	0.000000\\0.000000\\-67.125000
192	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
192	40	8	1
193	8	18	20000101
193	8	19	000000.000
193	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.544.0
193	32	18	
193	32	19	270
193	32	50	0.000000\\0.000000\\-67.375000
193	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
193	40	8	1
194	8	18	20000101
194	8	19	000000.000
194	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.60.0
194	32	18	
194	32	19	28
194	32	50	0.000000\\0.000000\\-6.875000
194	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
194	40	8	1
195	8	18	20000101
195	8	19	000000.000
195	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.546.0
195	32	18	
195	32	19	271
195	32	50	0.000000\\0.000000\\-67.625000
195	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
195	40	8	1
196	8	18	20000101
196	8	19	000000.000
196	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.548.0
196	32	18	
196	32	19	272
196	32	50	0.000000\\0.000000\\-67.875000
196	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
196	40	8	1
197	8	18	20000101
197	8	19	000000.000
197	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.550.0
197	32	18	
197	32	19	273
197	32	50	0.000000\\0.000000\\-68.125000
197	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
197	40	8	1
198	8	18	20000101
198	8	19	000000.000
198	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.552.0
198	32	18	
198	32	19	274
198	32	50	0.000000\\0.000000\\-68.375000
198	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
198	40	8	1
199	8	18	20000101
199	8	19	000000.000
199	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.554.0
199	32	18	
199	32	19	275
199	32	50	0.000000\\0.000000\\-68.625000
199	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
199	40	8	1
200	8	18	20000101
200	8	19	000000.000
200	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.556.0
200	32	18	
200	32	19	276
200	32	50	0.000000\\0.000000\\-68.875000
200	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
200	40	8	1
201	8	18	20000101
201	8	19	000000.000
201	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.558.0
201	32	18	
201	32	19	277
201	32	50	0.000000\\0.000000\\-69.125000
201	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
201	40	8	1
202	8	18	20000101
202	8	19	000000.000
202	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.560.0
202	32	18	
202	32	19	278
202	32	50	0.000000\\0.000000\\-69.375000
202	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
202	40	8	1
203	8	18	20000101
203	8	19	000000.000
203	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.562.0
203	32	18	
203	32	19	279
203	32	50	0.000000\\0.000000\\-69.625000
203	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
203	40	8	1
204	8	18	20000101
204	8	19	000000.000
204	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.564.0
204	32	18	
204	32	19	280
204	32	50	0.000000\\0.000000\\-69.875000
204	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
204	40	8	1
205	8	18	20000101
205	8	19	000000.000
205	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.62.0
205	32	18	
205	32	19	29
205	32	50	0.000000\\0.000000\\-7.125000
205	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
205	40	8	1
206	8	18	20000101
206	8	19	000000.000
206	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.566.0
206	32	18	
206	32	19	281
206	32	50	0.000000\\0.000000\\-70.125000
206	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
206	40	8	1
207	8	18	20000101
207	8	19	000000.000
207	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.568.0
207	32	18	
207	32	19	282
207	32	50	0.000000\\0.000000\\-70.375000
207	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
207	40	8	1
208	8	18	20000101
208	8	19	000000.000
208	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.570.0
208	32	18	
208	32	19	283
208	32	50	0.000000\\0.000000\\-70.625000
208	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
208	40	8	1
209	8	18	20000101
209	8	19	000000.000
209	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.572.0
209	32	18	
209	32	19	284
209	32	50	0.000000\\0.000000\\-70.875000
209	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
209	40	8	1
210	8	18	20000101
210	8	19	000000.000
210	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.574.0
210	32	18	
210	32	19	285
210	32	50	0.000000\\0.000000\\-71.125000
210	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
210	40	8	1
211	8	18	20000101
211	8	19	000000.000
211	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.576.0
211	32	18	
211	32	19	286
211	32	50	0.000000\\0.000000\\-71.375000
211	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
211	40	8	1
212	8	18	20000101
212	8	19	000000.000
212	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.578.0
212	32	18	
212	32	19	287
212	32	50	0.000000\\0.000000\\-71.625000
212	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
212	40	8	1
213	8	18	20000101
213	8	19	000000.000
213	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.580.0
213	32	18	
213	32	19	288
213	32	50	0.000000\\0.000000\\-71.875000
213	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
213	40	8	1
214	8	18	20000101
214	8	19	000000.000
214	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.582.0
214	32	18	
214	32	19	289
214	32	50	0.000000\\0.000000\\-72.125000
214	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
214	40	8	1
215	8	18	20000101
215	8	19	000000.000
215	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.584.0
215	32	18	
215	32	19	290
215	32	50	0.000000\\0.000000\\-72.375000
215	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
215	40	8	1
216	8	18	20000101
216	8	19	000000.000
216	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.64.0
216	32	18	
216	32	19	30
216	32	50	0.000000\\0.000000\\-7.375000
216	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
216	40	8	1
217	8	18	20000101
217	8	19	000000.000
217	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.586.0
217	32	18	
217	32	19	291
217	32	50	0.000000\\0.000000\\-72.625000
217	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
217	40	8	1
218	8	18	20000101
218	8	19	000000.000
218	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.588.0
218	32	18	
218	32	19	292
218	32	50	0.000000\\0.000000\\-72.875000
218	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
218	40	8	1
219	8	18	20000101
219	8	19	000000.000
219	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.590.0
219	32	18	
219	32	19	293
219	32	50	0.000000\\0.000000\\-73.125000
219	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
219	40	8	1
220	8	18	20000101
220	8	19	000000.000
220	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.592.0
220	32	18	
220	32	19	294
220	32	50	0.000000\\0.000000\\-73.375000
220	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
220	40	8	1
221	8	18	20000101
221	8	19	000000.000
221	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.594.0
221	32	18	
221	32	19	295
221	32	50	0.000000\\0.000000\\-73.625000
221	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
221	40	8	1
222	8	18	20000101
222	8	19	000000.000
222	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.596.0
222	32	18	
222	32	19	296
222	32	50	0.000000\\0.000000\\-73.875000
222	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
222	40	8	1
223	8	18	20000101
223	8	19	000000.000
223	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.598.0
223	32	18	
223	32	19	297
223	32	50	0.000000\\0.000000\\-74.125000
223	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
223	40	8	1
224	8	18	20000101
224	8	19	000000.000
224	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.600.0
224	32	18	
224	32	19	298
224	32	50	0.000000\\0.000000\\-74.375000
224	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
224	40	8	1
225	8	18	20000101
225	8	19	000000.000
225	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.602.0
225	32	18	
225	32	19	299
225	32	50	0.000000\\0.000000\\-74.625000
225	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
225	40	8	1
226	8	18	20000101
226	8	19	000000.000
226	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.604.0
226	32	18	
226	32	19	300
226	32	50	0.000000\\0.000000\\-74.875000
226	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
226	40	8	1
227	8	18	20000101
227	8	19	000000.000
227	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.12.0
227	32	18	
227	32	19	4
227	32	50	0.000000\\0.000000\\-0.875000
227	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
227	40	8	1
228	8	18	20000101
228	8	19	000000.000
228	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.66.0
228	32	18	
228	32	19	31
228	32	50	0.000000\\0.000000\\-7.625000
228	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
228	40	8	1
229	8	18	20000101
229	8	19	000000.000
229	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.606.0
229	32	18	
229	32	19	301
229	32	50	0.000000\\0.000000\\-75.125000
229	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
229	40	8	1
230	8	18	20000101
230	8	19	000000.000
230	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.608.0
230	32	18	
230	32	19	302
230	32	50	0.000000\\0.000000\\-75.375000
230	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
230	40	8	1
231	8	18	20000101
231	8	19	000000.000
231	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.610.0
231	32	18	
231	32	19	303
231	32	50	0.000000\\0.000000\\-75.625000
231	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
231	40	8	1
232	8	18	20000101
232	8	19	000000.000
232	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.612.0
232	32	18	
232	32	19	304
232	32	50	0.000000\\0.000000\\-75.875000
232	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
232	40	8	1
233	8	18	20000101
233	8	19	000000.000
233	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.614.0
233	32	18	
233	32	19	305
233	32	50	0.000000\\0.000000\\-76.125000
233	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
233	40	8	1
234	8	18	20000101
234	8	19	000000.000
234	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.616.0
234	32	18	
234	32	19	306
234	32	50	0.000000\\0.000000\\-76.375000
234	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
234	40	8	1
235	8	18	20000101
235	8	19	000000.000
235	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.618.0
235	32	18	
235	32	19	307
235	32	50	0.000000\\0.000000\\-76.625000
235	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
235	40	8	1
236	8	18	20000101
236	8	19	000000.000
236	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.620.0
236	32	18	
236	32	19	308
236	32	50	0.000000\\0.000000\\-76.875000
236	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
236	40	8	1
237	8	18	20000101
237	8	19	000000.000
237	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.622.0
237	32	18	
237	32	19	309
237	32	50	0.000000\\0.000000\\-77.125000
237	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
237	40	8	1
238	8	18	20000101
238	8	19	000000.000
238	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.624.0
238	32	18	
238	32	19	310
238	32	50	0.000000\\0.000000\\-77.375000
238	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
238	40	8	1
239	8	18	20000101
239	8	19	000000.000
239	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.68.0
239	32	18	
239	32	19	32
239	32	50	0.000000\\0.000000\\-7.875000
239	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
239	40	8	1
240	8	18	20000101
240	8	19	000000.000
240	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.626.0
240	32	18	
240	32	19	311
240	32	50	0.000000\\0.000000\\-77.625000
240	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
240	40	8	1
241	8	18	20000101
241	8	19	000000.000
241	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.628.0
241	32	18	
241	32	19	312
241	32	50	0.000000\\0.000000\\-77.875000
241	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
241	40	8	1
242	8	18	20000101
242	8	19	000000.000
242	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.630.0
242	32	18	
242	32	19	313
242	32	50	0.000000\\0.000000\\-78.125000
242	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
242	40	8	1
243	8	18	20000101
243	8	19	000000.000
243	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.632.0
243	32	18	
243	32	19	314
243	32	50	0.000000\\0.000000\\-78.375000
243	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
243	40	8	1
244	8	18	20000101
244	8	19	000000.000
244	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.634.0
244	32	18	
244	32	19	315
244	32	50	0.000000\\0.000000\\-78.625000
244	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
244	40	8	1
245	8	18	20000101
245	8	19	000000.000
245	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.636.0
245	32	18	
245	32	19	316
245	32	50	0.000000\\0.000000\\-78.875000
245	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
245	40	8	1
246	8	18	20000101
246	8	19	000000.000
246	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.638.0
246	32	18	
246	32	19	317
246	32	50	0.000000\\0.000000\\-79.125000
246	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
246	40	8	1
247	8	18	20000101
247	8	19	000000.000
247	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.640.0
247	32	18	
247	32	19	318
247	32	50	0.000000\\0.000000\\-79.375000
247	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
247	40	8	1
248	8	18	20000101
248	8	19	000000.000
248	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.642.0
248	32	18	
248	32	19	319
248	32	50	0.000000\\0.000000\\-79.625000
248	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
248	40	8	1
249	8	18	20000101
249	8	19	000000.000
249	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.644.0
249	32	18	
249	32	19	320
249	32	50	0.000000\\0.000000\\-79.875000
249	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
249	40	8	1
250	8	18	20000101
250	8	19	000000.000
250	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.70.0
250	32	18	
250	32	19	33
250	32	50	0.000000\\0.000000\\-8.125000
250	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
250	40	8	1
251	8	18	20000101
251	8	19	000000.000
251	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.646.0
251	32	18	
251	32	19	321
251	32	50	0.000000\\0.000000\\-80.125000
251	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
251	40	8	1
252	8	18	20000101
252	8	19	000000.000
252	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.648.0
252	32	18	
252	32	19	322
252	32	50	0.000000\\0.000000\\-80.375000
252	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
252	40	8	1
253	8	18	20000101
253	8	19	000000.000
253	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.650.0
253	32	18	
253	32	19	323
253	32	50	0.000000\\0.000000\\-80.625000
253	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
253	40	8	1
254	8	18	20000101
254	8	19	000000.000
254	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.652.0
254	32	18	
254	32	19	324
254	32	50	0.000000\\0.000000\\-80.875000
254	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
254	40	8	1
255	8	18	20000101
255	8	19	000000.000
255	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.654.0
255	32	18	
255	32	19	325
255	32	50	0.000000\\0.000000\\-81.125000
255	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
255	40	8	1
256	8	18	20000101
256	8	19	000000.000
256	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.656.0
256	32	18	
256	32	19	326
256	32	50	0.000000\\0.000000\\-81.375000
256	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
256	40	8	1
257	8	18	20000101
257	8	19	000000.000
257	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.658.0
257	32	18	
257	32	19	327
257	32	50	0.000000\\0.000000\\-81.625000
257	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
257	40	8	1
258	8	18	20000101
258	8	19	000000.000
258	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.660.0
258	32	18	
258	32	19	328
258	32	50	0.000000\\0.000000\\-81.875000
258	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
258	40	8	1
259	8	18	20000101
259	8	19	000000.000
259	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.662.0
259	32	18	
259	32	19	329
259	32	50	0.000000\\0.000000\\-82.125000
259	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
259	40	8	1
260	8	18	20000101
260	8	19	000000.000
260	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.664.0
260	32	18	
260	32	19	330
260	32	50	0.000000\\0.000000\\-82.375000
260	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
260	40	8	1
261	8	18	20000101
261	8	19	000000.000
261	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.72.0
261	32	18	
261	32	19	34
261	32	50	0.000000\\0.000000\\-8.375000
261	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
261	40	8	1
262	8	18	20000101
262	8	19	000000.000
262	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.666.0
262	32	18	
262	32	19	331
262	32	50	0.000000\\0.000000\\-82.625000
262	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
262	40	8	1
263	8	18	20000101
263	8	19	000000.000
263	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.668.0
263	32	18	
263	32	19	332
263	32	50	0.000000\\0.000000\\-82.875000
263	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
263	40	8	1
264	8	18	20000101
264	8	19	000000.000
264	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.670.0
264	32	18	
264	32	19	333
264	32	50	0.000000\\0.000000\\-83.125000
264	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
264	40	8	1
265	8	18	20000101
265	8	19	000000.000
265	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.672.0
265	32	18	
265	32	19	334
265	32	50	0.000000\\0.000000\\-83.375000
265	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
265	40	8	1
266	8	18	20000101
266	8	19	000000.000
266	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.674.0
266	32	18	
266	32	19	335
266	32	50	0.000000\\0.000000\\-83.625000
266	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
266	40	8	1
267	8	18	20000101
267	8	19	000000.000
267	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.676.0
267	32	18	
267	32	19	336
267	32	50	0.000000\\0.000000\\-83.875000
267	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
267	40	8	1
268	8	18	20000101
268	8	19	000000.000
268	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.678.0
268	32	18	
268	32	19	337
268	32	50	0.000000\\0.000000\\-84.125000
268	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
268	40	8	1
269	8	18	20000101
269	8	19	000000.000
269	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.680.0
269	32	18	
269	32	19	338
269	32	50	0.000000\\0.000000\\-84.375000
269	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
269	40	8	1
270	8	18	20000101
270	8	19	000000.000
270	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.682.0
270	32	18	
270	32	19	339
270	32	50	0.000000\\0.000000\\-84.625000
270	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
270	40	8	1
271	8	18	20000101
271	8	19	000000.000
271	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.684.0
271	32	18	
271	32	19	340
271	32	50	0.000000\\0.000000\\-84.875000
271	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
271	40	8	1
272	8	18	20000101
272	8	19	000000.000
272	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.74.0
272	32	18	
272	32	19	35
272	32	50	0.000000\\0.000000\\-8.625000
272	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
272	40	8	1
273	8	18	20000101
273	8	19	000000.000
273	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.686.0
273	32	18	
273	32	19	341
273	32	50	0.000000\\0.000000\\-85.125000
273	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
273	40	8	1
274	8	18	20000101
274	8	19	000000.000
274	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.688.0
274	32	18	
274	32	19	342
274	32	50	0.000000\\0.000000\\-85.375000
274	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
274	40	8	1
275	8	18	20000101
275	8	19	000000.000
275	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.690.0
275	32	18	
275	32	19	343
275	32	50	0.000000\\0.000000\\-85.625000
275	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
275	40	8	1
276	8	18	20000101
276	8	19	000000.000
276	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.692.0
276	32	18	
276	32	19	344
276	32	50	0.000000\\0.000000\\-85.875000
276	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
276	40	8	1
277	8	18	20000101
277	8	19	000000.000
277	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.694.0
277	32	18	
277	32	19	345
277	32	50	0.000000\\0.000000\\-86.125000
277	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
277	40	8	1
278	8	18	20000101
278	8	19	000000.000
278	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.696.0
278	32	18	
278	32	19	346
278	32	50	0.000000\\0.000000\\-86.375000
278	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
278	40	8	1
279	8	18	20000101
279	8	19	000000.000
279	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.698.0
279	32	18	
279	32	19	347
279	32	50	0.000000\\0.000000\\-86.625000
279	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
279	40	8	1
280	8	18	20000101
280	8	19	000000.000
280	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.700.0
280	32	18	
280	32	19	348
280	32	50	0.000000\\0.000000\\-86.875000
280	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
280	40	8	1
281	8	18	20000101
281	8	19	000000.000
281	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.702.0
281	32	18	
281	32	19	349
281	32	50	0.000000\\0.000000\\-87.125000
281	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
281	40	8	1
282	8	18	20000101
282	8	19	000000.000
282	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.704.0
282	32	18	
282	32	19	350
282	32	50	0.000000\\0.000000\\-87.375000
282	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
282	40	8	1
283	8	18	20000101
283	8	19	000000.000
283	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.76.0
283	32	18	
283	32	19	36
283	32	50	0.000000\\0.000000\\-8.875000
283	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
283	40	8	1
284	8	18	20000101
284	8	19	000000.000
284	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.706.0
284	32	18	
284	32	19	351
284	32	50	0.000000\\0.000000\\-87.625000
284	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
284	40	8	1
285	8	18	20000101
285	8	19	000000.000
285	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.708.0
285	32	18	
285	32	19	352
285	32	50	0.000000\\0.000000\\-87.875000
285	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
285	40	8	1
286	8	18	20000101
286	8	19	000000.000
286	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.710.0
286	32	18	
286	32	19	353
286	32	50	0.000000\\0.000000\\-88.125000
286	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
286	40	8	1
287	8	18	20000101
287	8	19	000000.000
287	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.712.0
287	32	18	
287	32	19	354
287	32	50	0.000000\\0.000000\\-88.375000
287	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
287	40	8	1
288	8	18	20000101
288	8	19	000000.000
288	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.714.0
288	32	18	
288	32	19	355
288	32	50	0.000000\\0.000000\\-88.625000
288	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
288	40	8	1
289	8	18	20000101
289	8	19	000000.000
289	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.716.0
289	32	18	
289	32	19	356
289	32	50	0.000000\\0.000000\\-88.875000
289	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
289	40	8	1
290	8	18	20000101
290	8	19	000000.000
290	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.718.0
290	32	18	
290	32	19	357
290	32	50	0.000000\\0.000000\\-89.125000
290	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
290	40	8	1
291	8	18	20000101
291	8	19	000000.000
291	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.720.0
291	32	18	
291	32	19	358
291	32	50	0.000000\\0.000000\\-89.375000
291	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
291	40	8	1
292	8	18	20000101
292	8	19	000000.000
292	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.722.0
292	32	18	
292	32	19	359
292	32	50	0.000000\\0.000000\\-89.625000
292	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
292	40	8	1
293	8	18	20000101
293	8	19	000000.000
293	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.724.0
293	32	18	
293	32	19	360
293	32	50	0.000000\\0.000000\\-89.875000
293	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
293	40	8	1
294	8	18	20000101
294	8	19	000000.000
294	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.78.0
294	32	18	
294	32	19	37
294	32	50	0.000000\\0.000000\\-9.125000
294	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
294	40	8	1
295	8	18	20000101
295	8	19	000000.000
295	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.726.0
295	32	18	
295	32	19	361
295	32	50	0.000000\\0.000000\\-90.125000
295	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
295	40	8	1
296	8	18	20000101
296	8	19	000000.000
296	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.728.0
296	32	18	
296	32	19	362
296	32	50	0.000000\\0.000000\\-90.375000
296	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
296	40	8	1
297	8	18	20000101
297	8	19	000000.000
297	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.730.0
297	32	18	
297	32	19	363
297	32	50	0.000000\\0.000000\\-90.625000
297	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
297	40	8	1
298	8	18	20000101
298	8	19	000000.000
298	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.732.0
298	32	18	
298	32	19	364
298	32	50	0.000000\\0.000000\\-90.875000
298	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
298	40	8	1
299	8	18	20000101
299	8	19	000000.000
299	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.734.0
299	32	18	
299	32	19	365
299	32	50	0.000000\\0.000000\\-91.125000
299	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
299	40	8	1
300	8	18	20000101
300	8	19	000000.000
300	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.736.0
300	32	18	
300	32	19	366
300	32	50	0.000000\\0.000000\\-91.375000
300	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
300	40	8	1
301	8	18	20000101
301	8	19	000000.000
301	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.738.0
301	32	18	
301	32	19	367
301	32	50	0.000000\\0.000000\\-91.625000
301	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
301	40	8	1
302	8	18	20000101
302	8	19	000000.000
302	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.740.0
302	32	18	
302	32	19	368
302	32	50	0.000000\\0.000000\\-91.875000
302	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
302	40	8	1
303	8	18	20000101
303	8	19	000000.000
303	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.742.0
303	32	18	
303	32	19	369
303	32	50	0.000000\\0.000000\\-92.125000
303	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
303	40	8	1
304	8	18	20000101
304	8	19	000000.000
304	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.744.0
304	32	18	
304	32	19	370
304	32	50	0.000000\\0.000000\\-92.375000
304	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
304	40	8	1
305	8	18	20000101
305	8	19	000000.000
305	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.80.0
305	32	18	
305	32	19	38
305	32	50	0.000000\\0.000000\\-9.375000
305	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
305	40	8	1
306	8	18	20000101
306	8	19	000000.000
306	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.746.0
306	32	18	
306	32	19	371
306	32	50	0.000000\\0.000000\\-92.625000
306	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
306	40	8	1
307	8	18	20000101
307	8	19	000000.000
307	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.748.0
307	32	18	
307	32	19	372
307	32	50	0.000000\\0.000000\\-92.875000
307	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
307	40	8	1
308	8	18	20000101
308	8	19	000000.000
308	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.750.0
308	32	18	
308	32	19	373
308	32	50	0.000000\\0.000000\\-93.125000
308	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
308	40	8	1
309	8	18	20000101
309	8	19	000000.000
309	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.752.0
309	32	18	
309	32	19	374
309	32	50	0.000000\\0.000000\\-93.375000
309	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
309	40	8	1
310	8	18	20000101
310	8	19	000000.000
310	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.754.0
310	32	18	
310	32	19	375
310	32	50	0.000000\\0.000000\\-93.625000
310	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
310	40	8	1
311	8	18	20000101
311	8	19	000000.000
311	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.756.0
311	32	18	
311	32	19	376
311	32	50	0.000000\\0.000000\\-93.875000
311	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
311	40	8	1
312	8	18	20000101
312	8	19	000000.000
312	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.758.0
312	32	18	
312	32	19	377
312	32	50	0.000000\\0.000000\\-94.125000
312	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
312	40	8	1
313	8	18	20000101
313	8	19	000000.000
313	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.760.0
313	32	18	
313	32	19	378
313	32	50	0.000000\\0.000000\\-94.375000
313	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
313	40	8	1
314	8	18	20000101
314	8	19	000000.000
314	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.762.0
314	32	18	
314	32	19	379
314	32	50	0.000000\\0.000000\\-94.625000
314	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
314	40	8	1
315	8	18	20000101
315	8	19	000000.000
315	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.764.0
315	32	18	
315	32	19	380
315	32	50	0.000000\\0.000000\\-94.875000
315	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
315	40	8	1
316	8	18	20000101
316	8	19	000000.000
316	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.82.0
316	32	18	
316	32	19	39
316	32	50	0.000000\\0.000000\\-9.625000
316	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
316	40	8	1
317	8	18	20000101
317	8	19	000000.000
317	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.766.0
317	32	18	
317	32	19	381
317	32	50	0.000000\\0.000000\\-95.125000
317	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
317	40	8	1
318	8	18	20000101
318	8	19	000000.000
318	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.768.0
318	32	18	
318	32	19	382
318	32	50	0.000000\\0.000000\\-95.375000
318	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
318	40	8	1
319	8	18	20000101
319	8	19	000000.000
319	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.770.0
319	32	18	
319	32	19	383
319	32	50	0.000000\\0.000000\\-95.625000
319	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
319	40	8	1
320	8	18	20000101
320	8	19	000000.000
320	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.772.0
320	32	18	
320	32	19	384
320	32	50	0.000000\\0.000000\\-95.875000
320	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
320	40	8	1
321	8	18	20000101
321	8	19	000000.000
321	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.774.0
321	32	18	
321	32	19	385
321	32	50	0.000000\\0.000000\\-96.125000
321	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
321	40	8	1
322	8	18	20000101
322	8	19	000000.000
322	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.776.0
322	32	18	
322	32	19	386
322	32	50	0.000000\\0.000000\\-96.375000
322	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
322	40	8	1
323	8	18	20000101
323	8	19	000000.000
323	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.778.0
323	32	18	
323	32	19	387
323	32	50	0.000000\\0.000000\\-96.625000
323	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
323	40	8	1
324	8	18	20000101
324	8	19	000000.000
324	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.780.0
324	32	18	
324	32	19	388
324	32	50	0.000000\\0.000000\\-96.875000
324	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
324	40	8	1
325	8	18	20000101
325	8	19	000000.000
325	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.782.0
325	32	18	
325	32	19	389
325	32	50	0.000000\\0.000000\\-97.125000
325	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
325	40	8	1
326	8	18	20000101
326	8	19	000000.000
326	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.784.0
326	32	18	
326	32	19	390
326	32	50	0.000000\\0.000000\\-97.375000
326	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
326	40	8	1
327	8	18	20000101
327	8	19	000000.000
327	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.84.0
327	32	18	
327	32	19	40
327	32	50	0.000000\\0.000000\\-9.875000
327	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
327	40	8	1
328	8	18	20000101
328	8	19	000000.000
328	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.786.0
328	32	18	
328	32	19	391
328	32	50	0.000000\\0.000000\\-97.625000
328	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
328	40	8	1
329	8	18	20000101
329	8	19	000000.000
329	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.788.0
329	32	18	
329	32	19	392
329	32	50	0.000000\\0.000000\\-97.875000
329	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
329	40	8	1
330	8	18	20000101
330	8	19	000000.000
330	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.790.0
330	32	18	
330	32	19	393
330	32	50	0.000000\\0.000000\\-98.125000
330	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
330	40	8	1
331	8	18	20000101
331	8	19	000000.000
331	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.792.0
331	32	18	
331	32	19	394
331	32	50	0.000000\\0.000000\\-98.375000
331	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
331	40	8	1
332	8	18	20000101
332	8	19	000000.000
332	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.794.0
332	32	18	
332	32	19	395
332	32	50	0.000000\\0.000000\\-98.625000
332	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
332	40	8	1
333	8	18	20000101
333	8	19	000000.000
333	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.796.0
333	32	18	
333	32	19	396
333	32	50	0.000000\\0.000000\\-98.875000
333	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
333	40	8	1
334	8	18	20000101
334	8	19	000000.000
334	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.798.0
334	32	18	
334	32	19	397
334	32	50	0.000000\\0.000000\\-99.125000
334	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
334	40	8	1
335	8	18	20000101
335	8	19	000000.000
335	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.800.0
335	32	18	
335	32	19	398
335	32	50	0.000000\\0.000000\\-99.375000
335	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
335	40	8	1
336	8	18	20000101
336	8	19	000000.000
336	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.802.0
336	32	18	
336	32	19	399
336	32	50	0.000000\\0.000000\\-99.625000
336	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
336	40	8	1
337	8	18	20000101
337	8	19	000000.000
337	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.804.0
337	32	18	
337	32	19	400
337	32	50	0.000000\\0.000000\\-99.875000
337	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
337	40	8	1
338	8	18	20000101
338	8	19	000000.000
338	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.14.0
338	32	18	
338	32	19	5
338	32	50	0.000000\\0.000000\\-1.125000
338	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
338	40	8	1
339	8	18	20000101
339	8	19	000000.000
339	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.86.0
339	32	18	
339	32	19	41
339	32	50	0.000000\\0.000000\\-10.125000
339	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
339	40	8	1
340	8	18	20000101
340	8	19	000000.000
340	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.806.0
340	32	18	
340	32	19	401
340	32	50	0.000000\\0.000000\\-100.125000
340	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
340	40	8	1
341	8	18	20000101
341	8	19	000000.000
341	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.808.0
341	32	18	
341	32	19	402
341	32	50	0.000000\\0.000000\\-100.375000
341	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
341	40	8	1
342	8	18	20000101
342	8	19	000000.000
342	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.810.0
342	32	18	
342	32	19	403
342	32	50	0.000000\\0.000000\\-100.625000
342	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
342	40	8	1
343	8	18	20000101
343	8	19	000000.000
343	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.812.0
343	32	18	
343	32	19	404
343	32	50	0.000000\\0.000000\\-100.875000
343	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
343	40	8	1
344	8	18	20000101
344	8	19	000000.000
344	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.814.0
344	32	18	
344	32	19	405
344	32	50	0.000000\\0.000000\\-101.125000
344	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
344	40	8	1
345	8	18	20000101
345	8	19	000000.000
345	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.816.0
345	32	18	
345	32	19	406
345	32	50	0.000000\\0.000000\\-101.375000
345	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
345	40	8	1
346	8	18	20000101
346	8	19	000000.000
346	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.818.0
346	32	18	
346	32	19	407
346	32	50	0.000000\\0.000000\\-101.625000
346	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
346	40	8	1
347	8	18	20000101
347	8	19	000000.000
347	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.820.0
347	32	18	
347	32	19	408
347	32	50	0.000000\\0.000000\\-101.875000
347	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
347	40	8	1
348	8	18	20000101
348	8	19	000000.000
348	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.822.0
348	32	18	
348	32	19	409
348	32	50	0.000000\\0.000000\\-102.125000
348	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
348	40	8	1
349	8	18	20000101
349	8	19	000000.000
349	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.824.0
349	32	18	
349	32	19	410
349	32	50	0.000000\\0.000000\\-102.375000
349	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
349	40	8	1
350	8	18	20000101
350	8	19	000000.000
350	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.88.0
350	32	18	
350	32	19	42
350	32	50	0.000000\\0.000000\\-10.375000
350	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
350	40	8	1
351	8	18	20000101
351	8	19	000000.000
351	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.826.0
351	32	18	
351	32	19	411
351	32	50	0.000000\\0.000000\\-102.625000
351	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
351	40	8	1
352	8	18	20000101
352	8	19	000000.000
352	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.828.0
352	32	18	
352	32	19	412
352	32	50	0.000000\\0.000000\\-102.875000
352	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
352	40	8	1
353	8	18	20000101
353	8	19	000000.000
353	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.830.0
353	32	18	
353	32	19	413
353	32	50	0.000000\\0.000000\\-103.125000
353	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
353	40	8	1
354	8	18	20000101
354	8	19	000000.000
354	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.832.0
354	32	18	
354	32	19	414
354	32	50	0.000000\\0.000000\\-103.375000
354	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
354	40	8	1
355	8	18	20000101
355	8	19	000000.000
355	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.834.0
355	32	18	
355	32	19	415
355	32	50	0.000000\\0.000000\\-103.625000
355	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
355	40	8	1
356	8	18	20000101
356	8	19	000000.000
356	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.836.0
356	32	18	
356	32	19	416
356	32	50	0.000000\\0.000000\\-103.875000
356	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
356	40	8	1
357	8	18	20000101
357	8	19	000000.000
357	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.838.0
357	32	18	
357	32	19	417
357	32	50	0.000000\\0.000000\\-104.125000
357	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
357	40	8	1
358	8	18	20000101
358	8	19	000000.000
358	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.840.0
358	32	18	
358	32	19	418
358	32	50	0.000000\\0.000000\\-104.375000
358	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
358	40	8	1
359	8	18	20000101
359	8	19	000000.000
359	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.842.0
359	32	18	
359	32	19	419
359	32	50	0.000000\\0.000000\\-104.625000
359	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
359	40	8	1
360	8	18	20000101
360	8	19	000000.000
360	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.844.0
360	32	18	
360	32	19	420
360	32	50	0.000000\\0.000000\\-104.875000
360	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
360	40	8	1
361	8	18	20000101
361	8	19	000000.000
361	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.90.0
361	32	18	
361	32	19	43
361	32	50	0.000000\\0.000000\\-10.625000
361	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
361	40	8	1
362	8	18	20000101
362	8	19	000000.000
362	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.846.0
362	32	18	
362	32	19	421
362	32	50	0.000000\\0.000000\\-105.125000
362	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
362	40	8	1
363	8	18	20000101
363	8	19	000000.000
363	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.848.0
363	32	18	
363	32	19	422
363	32	50	0.000000\\0.000000\\-105.375000
363	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
363	40	8	1
364	8	18	20000101
364	8	19	000000.000
364	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.850.0
364	32	18	
364	32	19	423
364	32	50	0.000000\\0.000000\\-105.625000
364	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
364	40	8	1
365	8	18	20000101
365	8	19	000000.000
365	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.852.0
365	32	18	
365	32	19	424
365	32	50	0.000000\\0.000000\\-105.875000
365	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
365	40	8	1
366	8	18	20000101
366	8	19	000000.000
366	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.854.0
366	32	18	
366	32	19	425
366	32	50	0.000000\\0.000000\\-106.125000
366	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
366	40	8	1
367	8	18	20000101
367	8	19	000000.000
367	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.856.0
367	32	18	
367	32	19	426
367	32	50	0.000000\\0.000000\\-106.375000
367	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
367	40	8	1
368	8	18	20000101
368	8	19	000000.000
368	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.858.0
368	32	18	
368	32	19	427
368	32	50	0.000000\\0.000000\\-106.625000
368	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
368	40	8	1
369	8	18	20000101
369	8	19	000000.000
369	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.860.0
369	32	18	
369	32	19	428
369	32	50	0.000000\\0.000000\\-106.875000
369	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
369	40	8	1
370	8	18	20000101
370	8	19	000000.000
370	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.862.0
370	32	18	
370	32	19	429
370	32	50	0.000000\\0.000000\\-107.125000
370	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
370	40	8	1
371	8	18	20000101
371	8	19	000000.000
371	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.864.0
371	32	18	
371	32	19	430
371	32	50	0.000000\\0.000000\\-107.375000
371	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
371	40	8	1
372	8	18	20000101
372	8	19	000000.000
372	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.92.0
372	32	18	
372	32	19	44
372	32	50	0.000000\\0.000000\\-10.875000
372	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
372	40	8	1
373	8	18	20000101
373	8	19	000000.000
373	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.866.0
373	32	18	
373	32	19	431
373	32	50	0.000000\\0.000000\\-107.625000
373	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
373	40	8	1
374	8	18	20000101
374	8	19	000000.000
374	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.868.0
374	32	18	
374	32	19	432
374	32	50	0.000000\\0.000000\\-107.875000
374	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
374	40	8	1
375	8	18	20000101
375	8	19	000000.000
375	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.870.0
375	32	18	
375	32	19	433
375	32	50	0.000000\\0.000000\\-108.125000
375	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
375	40	8	1
376	8	18	20000101
376	8	19	000000.000
376	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.872.0
376	32	18	
376	32	19	434
376	32	50	0.000000\\0.000000\\-108.375000
376	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
376	40	8	1
377	8	18	20000101
377	8	19	000000.000
377	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.874.0
377	32	18	
377	32	19	435
377	32	50	0.000000\\0.000000\\-108.625000
377	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
377	40	8	1
378	8	18	20000101
378	8	19	000000.000
378	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.876.0
378	32	18	
378	32	19	436
378	32	50	0.000000\\0.000000\\-108.875000
378	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
378	40	8	1
379	8	18	20000101
379	8	19	000000.000
379	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.878.0
379	32	18	
379	32	19	437
379	32	50	0.000000\\0.000000\\-109.125000
379	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
379	40	8	1
380	8	18	20000101
380	8	19	000000.000
380	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.880.0
380	32	18	
380	32	19	438
380	32	50	0.000000\\0.000000\\-109.375000
380	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
380	40	8	1
381	8	18	20000101
381	8	19	000000.000
381	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.882.0
381	32	18	
381	32	19	439
381	32	50	0.000000\\0.000000\\-109.625000
381	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
381	40	8	1
382	8	18	20000101
382	8	19	000000.000
382	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.884.0
382	32	18	
382	32	19	440
382	32	50	0.000000\\0.000000\\-109.875000
382	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
382	40	8	1
383	8	18	20000101
383	8	19	000000.000
383	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.94.0
383	32	18	
383	32	19	45
383	32	50	0.000000\\0.000000\\-11.125000
383	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
383	40	8	1
384	8	18	20000101
384	8	19	000000.000
384	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.886.0
384	32	18	
384	32	19	441
384	32	50	0.000000\\0.000000\\-110.125000
384	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
384	40	8	1
385	8	18	20000101
385	8	19	000000.000
385	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.888.0
385	32	18	
385	32	19	442
385	32	50	0.000000\\0.000000\\-110.375000
385	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
385	40	8	1
386	8	18	20000101
386	8	19	000000.000
386	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.890.0
386	32	18	
386	32	19	443
386	32	50	0.000000\\0.000000\\-110.625000
386	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
386	40	8	1
387	8	18	20000101
387	8	19	000000.000
387	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.892.0
387	32	18	
387	32	19	444
387	32	50	0.000000\\0.000000\\-110.875000
387	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
387	40	8	1
388	8	18	20000101
388	8	19	000000.000
388	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.894.0
388	32	18	
388	32	19	445
388	32	50	0.000000\\0.000000\\-111.125000
388	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
388	40	8	1
389	8	18	20000101
389	8	19	000000.000
389	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.896.0
389	32	18	
389	32	19	446
389	32	50	0.000000\\0.000000\\-111.375000
389	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
389	40	8	1
390	8	18	20000101
390	8	19	000000.000
390	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.898.0
390	32	18	
390	32	19	447
390	32	50	0.000000\\0.000000\\-111.625000
390	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
390	40	8	1
391	8	18	20000101
391	8	19	000000.000
391	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.900.0
391	32	18	
391	32	19	448
391	32	50	0.000000\\0.000000\\-111.875000
391	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
391	40	8	1
392	8	18	20000101
392	8	19	000000.000
392	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.902.0
392	32	18	
392	32	19	449
392	32	50	0.000000\\0.000000\\-112.125000
392	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
392	40	8	1
393	8	18	20000101
393	8	19	000000.000
393	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.904.0
393	32	18	
393	32	19	450
393	32	50	0.000000\\0.000000\\-112.375000
393	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
393	40	8	1
394	8	18	20000101
394	8	19	000000.000
394	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.96.0
394	32	18	
394	32	19	46
394	32	50	0.000000\\0.000000\\-11.375000
394	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
394	40	8	1
395	8	18	20000101
395	8	19	000000.000
395	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.906.0
395	32	18	
395	32	19	451
395	32	50	0.000000\\0.000000\\-112.625000
395	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
395	40	8	1
396	8	18	20000101
396	8	19	000000.000
396	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.908.0
396	32	18	
396	32	19	452
396	32	50	0.000000\\0.000000\\-112.875000
396	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
396	40	8	1
397	8	18	20000101
397	8	19	000000.000
397	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.910.0
397	32	18	
397	32	19	453
397	32	50	0.000000\\0.000000\\-113.125000
397	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
397	40	8	1
398	8	18	20000101
398	8	19	000000.000
398	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.912.0
398	32	18	
398	32	19	454
398	32	50	0.000000\\0.000000\\-113.375000
398	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
398	40	8	1
399	8	18	20000101
399	8	19	000000.000
399	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.914.0
399	32	18	
399	32	19	455
399	32	50	0.000000\\0.000000\\-113.625000
399	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
399	40	8	1
400	8	18	20000101
400	8	19	000000.000
400	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.916.0
400	32	18	
400	32	19	456
400	32	50	0.000000\\0.000000\\-113.875000
400	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
400	40	8	1
401	8	18	20000101
401	8	19	000000.000
401	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.918.0
401	32	18	
401	32	19	457
401	32	50	0.000000\\0.000000\\-114.125000
401	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
401	40	8	1
402	8	18	20000101
402	8	19	000000.000
402	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.920.0
402	32	18	
402	32	19	458
402	32	50	0.000000\\0.000000\\-114.375000
402	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
402	40	8	1
403	8	18	20000101
403	8	19	000000.000
403	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.922.0
403	32	18	
403	32	19	459
403	32	50	0.000000\\0.000000\\-114.625000
403	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
403	40	8	1
404	8	18	20000101
404	8	19	000000.000
404	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.924.0
404	32	18	
404	32	19	460
404	32	50	0.000000\\0.000000\\-114.875000
404	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
404	40	8	1
405	8	18	20000101
405	8	19	000000.000
405	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.98.0
405	32	18	
405	32	19	47
405	32	50	0.000000\\0.000000\\-11.625000
405	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
405	40	8	1
406	8	18	20000101
406	8	19	000000.000
406	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.926.0
406	32	18	
406	32	19	461
406	32	50	0.000000\\0.000000\\-115.125000
406	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
406	40	8	1
407	8	18	20000101
407	8	19	000000.000
407	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.928.0
407	32	18	
407	32	19	462
407	32	50	0.000000\\0.000000\\-115.375000
407	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
407	40	8	1
408	8	18	20000101
408	8	19	000000.000
408	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.930.0
408	32	18	
408	32	19	463
408	32	50	0.000000\\0.000000\\-115.625000
408	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
408	40	8	1
409	8	18	20000101
409	8	19	000000.000
409	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.932.0
409	32	18	
409	32	19	464
409	32	50	0.000000\\0.000000\\-115.875000
409	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
409	40	8	1
410	8	18	20000101
410	8	19	000000.000
410	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.934.0
410	32	18	
410	32	19	465
410	32	50	0.000000\\0.000000\\-116.125000
410	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
410	40	8	1
411	8	18	20000101
411	8	19	000000.000
411	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.936.0
411	32	18	
411	32	19	466
411	32	50	0.000000\\0.000000\\-116.375000
411	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
411	40	8	1
412	8	18	20000101
412	8	19	000000.000
412	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.938.0
412	32	18	
412	32	19	467
412	32	50	0.000000\\0.000000\\-116.625000
412	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
412	40	8	1
413	8	18	20000101
413	8	19	000000.000
413	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.940.0
413	32	18	
413	32	19	468
413	32	50	0.000000\\0.000000\\-116.875000
413	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
413	40	8	1
414	8	18	20000101
414	8	19	000000.000
414	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.942.0
414	32	18	
414	32	19	469
414	32	50	0.000000\\0.000000\\-117.125000
414	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
414	40	8	1
415	8	18	20000101
415	8	19	000000.000
415	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.944.0
415	32	18	
415	32	19	470
415	32	50	0.000000\\0.000000\\-117.375000
415	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
415	40	8	1
416	8	18	20000101
416	8	19	000000.000
416	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.100.0
416	32	18	
416	32	19	48
416	32	50	0.000000\\0.000000\\-11.875000
416	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
416	40	8	1
417	8	18	20000101
417	8	19	000000.000
417	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.946.0
417	32	18	
417	32	19	471
417	32	50	0.000000\\0.000000\\-117.625000
417	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
417	40	8	1
418	8	18	20000101
418	8	19	000000.000
418	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.948.0
418	32	18	
418	32	19	472
418	32	50	0.000000\\0.000000\\-117.875000
418	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
418	40	8	1
419	8	18	20000101
419	8	19	000000.000
419	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.950.0
419	32	18	
419	32	19	473
419	32	50	0.000000\\0.000000\\-118.125000
419	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
419	40	8	1
420	8	18	20000101
420	8	19	000000.000
420	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.952.0
420	32	18	
420	32	19	474
420	32	50	0.000000\\0.000000\\-118.375000
420	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
420	40	8	1
421	8	18	20000101
421	8	19	000000.000
421	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.954.0
421	32	18	
421	32	19	475
421	32	50	0.000000\\0.000000\\-118.625000
421	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
421	40	8	1
422	8	18	20000101
422	8	19	000000.000
422	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.956.0
422	32	18	
422	32	19	476
422	32	50	0.000000\\0.000000\\-118.875000
422	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
422	40	8	1
423	8	18	20000101
423	8	19	000000.000
423	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.958.0
423	32	18	
423	32	19	477
423	32	50	0.000000\\0.000000\\-119.125000
423	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
423	40	8	1
424	8	18	20000101
424	8	19	000000.000
424	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.960.0
424	32	18	
424	32	19	478
424	32	50	0.000000\\0.000000\\-119.375000
424	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
424	40	8	1
425	8	18	20000101
425	8	19	000000.000
425	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.962.0
425	32	18	
425	32	19	479
425	32	50	0.000000\\0.000000\\-119.625000
425	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
425	40	8	1
426	8	18	20000101
426	8	19	000000.000
426	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.964.0
426	32	18	
426	32	19	480
426	32	50	0.000000\\0.000000\\-119.875000
426	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
426	40	8	1
427	8	18	20000101
427	8	19	000000.000
427	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.102.0
427	32	18	
427	32	19	49
427	32	50	0.000000\\0.000000\\-12.125000
427	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
427	40	8	1
428	8	18	20000101
428	8	19	000000.000
428	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.966.0
428	32	18	
428	32	19	481
428	32	50	0.000000\\0.000000\\-120.125000
428	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
428	40	8	1
429	8	18	20000101
429	8	19	000000.000
429	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.968.0
429	32	18	
429	32	19	482
429	32	50	0.000000\\0.000000\\-120.375000
429	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
429	40	8	1
430	8	18	20000101
430	8	19	000000.000
430	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.970.0
430	32	18	
430	32	19	483
430	32	50	0.000000\\0.000000\\-120.625000
430	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
430	40	8	1
431	8	18	20000101
431	8	19	000000.000
431	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.972.0
431	32	18	
431	32	19	484
431	32	50	0.000000\\0.000000\\-120.875000
431	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
431	40	8	1
432	8	18	20000101
432	8	19	000000.000
432	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.974.0
432	32	18	
432	32	19	485
432	32	50	0.000000\\0.000000\\-121.125000
432	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
432	40	8	1
433	8	18	20000101
433	8	19	000000.000
433	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.976.0
433	32	18	
433	32	19	486
433	32	50	0.000000\\0.000000\\-121.375000
433	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
433	40	8	1
434	8	18	20000101
434	8	19	000000.000
434	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.978.0
434	32	18	
434	32	19	487
434	32	50	0.000000\\0.000000\\-121.625000
434	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
434	40	8	1
435	8	18	20000101
435	8	19	000000.000
435	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.980.0
435	32	18	
435	32	19	488
435	32	50	0.000000\\0.000000\\-121.875000
435	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
435	40	8	1
436	8	18	20000101
436	8	19	000000.000
436	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.982.0
436	32	18	
436	32	19	489
436	32	50	0.000000\\0.000000\\-122.125000
436	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
436	40	8	1
437	8	18	20000101
437	8	19	000000.000
437	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.984.0
437	32	18	
437	32	19	490
437	32	50	0.000000\\0.000000\\-122.375000
437	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
437	40	8	1
438	8	18	20000101
438	8	19	000000.000
438	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.104.0
438	32	18	
438	32	19	50
438	32	50	0.000000\\0.000000\\-12.375000
438	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
438	40	8	1
439	8	18	20000101
439	8	19	000000.000
439	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.986.0
439	32	18	
439	32	19	491
439	32	50	0.000000\\0.000000\\-122.625000
439	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
439	40	8	1
440	8	18	20000101
440	8	19	000000.000
440	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.988.0
440	32	18	
440	32	19	492
440	32	50	0.000000\\0.000000\\-122.875000
440	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
440	40	8	1
441	8	18	20000101
441	8	19	000000.000
441	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.990.0
441	32	18	
441	32	19	493
441	32	50	0.000000\\0.000000\\-123.125000
441	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
441	40	8	1
442	8	18	20000101
442	8	19	000000.000
442	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.992.0
442	32	18	
442	32	19	494
442	32	50	0.000000\\0.000000\\-123.375000
442	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
442	40	8	1
443	8	18	20000101
443	8	19	000000.000
443	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.994.0
443	32	18	
443	32	19	495
443	32	50	0.000000\\0.000000\\-123.625000
443	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
443	40	8	1
444	8	18	20000101
444	8	19	000000.000
444	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.996.0
444	32	18	
444	32	19	496
444	32	50	0.000000\\0.000000\\-123.875000
444	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
444	40	8	1
445	8	18	20000101
445	8	19	000000.000
445	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.998.0
445	32	18	
445	32	19	497
445	32	50	0.000000\\0.000000\\-124.125000
445	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
445	40	8	1
446	8	18	20000101
446	8	19	000000.000
446	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1000.0
446	32	18	
446	32	19	498
446	32	50	0.000000\\0.000000\\-124.375000
446	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
446	40	8	1
447	8	18	20000101
447	8	19	000000.000
447	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1002.0
447	32	18	
447	32	19	499
447	32	50	0.000000\\0.000000\\-124.625000
447	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
447	40	8	1
448	8	18	20000101
448	8	19	000000.000
448	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1004.0
448	32	18	
448	32	19	500
448	32	50	0.000000\\0.000000\\-124.875000
448	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
448	40	8	1
449	8	18	20000101
449	8	19	000000.000
449	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.16.0
449	32	18	
449	32	19	6
449	32	50	0.000000\\0.000000\\-1.375000
449	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
449	40	8	1
450	8	18	20000101
450	8	19	000000.000
450	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.106.0
450	32	18	
450	32	19	51
450	32	50	0.000000\\0.000000\\-12.625000
450	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
450	40	8	1
451	8	18	20000101
451	8	19	000000.000
451	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1006.0
451	32	18	
451	32	19	501
451	32	50	0.000000\\0.000000\\-125.125000
451	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
451	40	8	1
452	8	18	20000101
452	8	19	000000.000
452	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1008.0
452	32	18	
452	32	19	502
452	32	50	0.000000\\0.000000\\-125.375000
452	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
452	40	8	1
453	8	18	20000101
453	8	19	000000.000
453	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1010.0
453	32	18	
453	32	19	503
453	32	50	0.000000\\0.000000\\-125.625000
453	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
453	40	8	1
454	8	18	20000101
454	8	19	000000.000
454	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1012.0
454	32	18	
454	32	19	504
454	32	50	0.000000\\0.000000\\-125.875000
454	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
454	40	8	1
455	8	18	20000101
455	8	19	000000.000
455	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1014.0
455	32	18	
455	32	19	505
455	32	50	0.000000\\0.000000\\-126.125000
455	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
455	40	8	1
456	8	18	20000101
456	8	19	000000.000
456	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1016.0
456	32	18	
456	32	19	506
456	32	50	0.000000\\0.000000\\-126.375000
456	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
456	40	8	1
457	8	18	20000101
457	8	19	000000.000
457	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1018.0
457	32	18	
457	32	19	507
457	32	50	0.000000\\0.000000\\-126.625000
457	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
457	40	8	1
458	8	18	20000101
458	8	19	000000.000
458	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1020.0
458	32	18	
458	32	19	508
458	32	50	0.000000\\0.000000\\-126.875000
458	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
458	40	8	1
459	8	18	20000101
459	8	19	000000.000
459	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1022.0
459	32	18	
459	32	19	509
459	32	50	0.000000\\0.000000\\-127.125000
459	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
459	40	8	1
460	8	18	20000101
460	8	19	000000.000
460	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1024.0
460	32	18	
460	32	19	510
460	32	50	0.000000\\0.000000\\-127.375000
460	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
460	40	8	1
461	8	18	20000101
461	8	19	000000.000
461	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.108.0
461	32	18	
461	32	19	52
461	32	50	0.000000\\0.000000\\-12.875000
461	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
461	40	8	1
462	8	18	20000101
462	8	19	000000.000
462	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1026.0
462	32	18	
462	32	19	511
462	32	50	0.000000\\0.000000\\-127.625000
462	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
462	40	8	1
463	8	18	20000101
463	8	19	000000.000
463	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1028.0
463	32	18	
463	32	19	512
463	32	50	0.000000\\0.000000\\-127.875000
463	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
463	40	8	1
464	8	18	20000101
464	8	19	000000.000
464	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1030.0
464	32	18	
464	32	19	513
464	32	50	0.000000\\0.000000\\-128.125000
464	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
464	40	8	1
465	8	18	20000101
465	8	19	000000.000
465	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1032.0
465	32	18	
465	32	19	514
465	32	50	0.000000\\0.000000\\-128.375000
465	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
465	40	8	1
466	8	18	20000101
466	8	19	000000.000
466	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1034.0
466	32	18	
466	32	19	515
466	32	50	0.000000\\0.000000\\-128.625000
466	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
466	40	8	1
467	8	18	20000101
467	8	19	000000.000
467	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1036.0
467	32	18	
467	32	19	516
467	32	50	0.000000\\0.000000\\-128.875000
467	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
467	40	8	1
468	8	18	20000101
468	8	19	000000.000
468	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.1038.0
468	32	18	
468	32	19	517
468	32	50	0.000000\\0.000000\\-129.125000
468	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
468	40	8	1
469	8	18	20000101
469	8	19	000000.000
469	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.110.0
469	32	18	
469	32	19	53
469	32	50	0.000000\\0.000000\\-13.125000
469	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
469	40	8	1
470	8	18	20000101
470	8	19	000000.000
470	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.112.0
470	32	18	
470	32	19	54
470	32	50	0.000000\\0.000000\\-13.375000
470	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
470	40	8	1
471	8	18	20000101
471	8	19	000000.000
471	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.114.0
471	32	18	
471	32	19	55
471	32	50	0.000000\\0.000000\\-13.625000
471	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
471	40	8	1
472	8	18	20000101
472	8	19	000000.000
472	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.116.0
472	32	18	
472	32	19	56
472	32	50	0.000000\\0.000000\\-13.875000
472	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
472	40	8	1
473	8	18	20000101
473	8	19	000000.000
473	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.118.0
473	32	18	
473	32	19	57
473	32	50	0.000000\\0.000000\\-14.125000
473	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
473	40	8	1
474	8	18	20000101
474	8	19	000000.000
474	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.120.0
474	32	18	
474	32	19	58
474	32	50	0.000000\\0.000000\\-14.375000
474	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
474	40	8	1
475	8	18	20000101
475	8	19	000000.000
475	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.122.0
475	32	18	
475	32	19	59
475	32	50	0.000000\\0.000000\\-14.625000
475	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
475	40	8	1
476	8	18	20000101
476	8	19	000000.000
476	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.124.0
476	32	18	
476	32	19	60
476	32	50	0.000000\\0.000000\\-14.875000
476	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
476	40	8	1
477	8	18	20000101
477	8	19	000000.000
477	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.18.0
477	32	18	
477	32	19	7
477	32	50	0.000000\\0.000000\\-1.625000
477	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
477	40	8	1
478	8	18	20000101
478	8	19	000000.000
478	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.126.0
478	32	18	
478	32	19	61
478	32	50	0.000000\\0.000000\\-15.125000
478	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
478	40	8	1
479	8	18	20000101
479	8	19	000000.000
479	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.128.0
479	32	18	
479	32	19	62
479	32	50	0.000000\\0.000000\\-15.375000
479	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
479	40	8	1
480	8	18	20000101
480	8	19	000000.000
480	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.130.0
480	32	18	
480	32	19	63
480	32	50	0.000000\\0.000000\\-15.625000
480	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
480	40	8	1
481	8	18	20000101
481	8	19	000000.000
481	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.132.0
481	32	18	
481	32	19	64
481	32	50	0.000000\\0.000000\\-15.875000
481	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
481	40	8	1
482	8	18	20000101
482	8	19	000000.000
482	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.134.0
482	32	18	
482	32	19	65
482	32	50	0.000000\\0.000000\\-16.125000
482	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
482	40	8	1
483	8	18	20000101
483	8	19	000000.000
483	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.136.0
483	32	18	
483	32	19	66
483	32	50	0.000000\\0.000000\\-16.375000
483	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
483	40	8	1
484	8	18	20000101
484	8	19	000000.000
484	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.138.0
484	32	18	
484	32	19	67
484	32	50	0.000000\\0.000000\\-16.625000
484	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
484	40	8	1
485	8	18	20000101
485	8	19	000000.000
485	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.140.0
485	32	18	
485	32	19	68
485	32	50	0.000000\\0.000000\\-16.875000
485	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
485	40	8	1
486	8	18	20000101
486	8	19	000000.000
486	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.142.0
486	32	18	
486	32	19	69
486	32	50	0.000000\\0.000000\\-17.125000
486	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
486	40	8	1
487	8	18	20000101
487	8	19	000000.000
487	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.144.0
487	32	18	
487	32	19	70
487	32	50	0.000000\\0.000000\\-17.375000
487	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
487	40	8	1
488	8	18	20000101
488	8	19	000000.000
488	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.20.0
488	32	18	
488	32	19	8
488	32	50	0.000000\\0.000000\\-1.875000
488	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
488	40	8	1
489	8	18	20000101
489	8	19	000000.000
489	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.146.0
489	32	18	
489	32	19	71
489	32	50	0.000000\\0.000000\\-17.625000
489	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
489	40	8	1
490	8	18	20000101
490	8	19	000000.000
490	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.148.0
490	32	18	
490	32	19	72
490	32	50	0.000000\\0.000000\\-17.875000
490	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
490	40	8	1
491	8	18	20000101
491	8	19	000000.000
491	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.150.0
491	32	18	
491	32	19	73
491	32	50	0.000000\\0.000000\\-18.125000
491	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
491	40	8	1
492	8	18	20000101
492	8	19	000000.000
492	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.152.0
492	32	18	
492	32	19	74
492	32	50	0.000000\\0.000000\\-18.375000
492	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
492	40	8	1
493	8	18	20000101
493	8	19	000000.000
493	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.154.0
493	32	18	
493	32	19	75
493	32	50	0.000000\\0.000000\\-18.625000
493	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
493	40	8	1
494	8	18	20000101
494	8	19	000000.000
494	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.156.0
494	32	18	
494	32	19	76
494	32	50	0.000000\\0.000000\\-18.875000
494	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
494	40	8	1
495	8	18	20000101
495	8	19	000000.000
495	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.158.0
495	32	18	
495	32	19	77
495	32	50	0.000000\\0.000000\\-19.125000
495	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
495	40	8	1
496	8	18	20000101
496	8	19	000000.000
496	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.160.0
496	32	18	
496	32	19	78
496	32	50	0.000000\\0.000000\\-19.375000
496	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
496	40	8	1
497	8	18	20000101
497	8	19	000000.000
497	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.162.0
497	32	18	
497	32	19	79
497	32	50	0.000000\\0.000000\\-19.625000
497	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
497	40	8	1
498	8	18	20000101
498	8	19	000000.000
498	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.164.0
498	32	18	
498	32	19	80
498	32	50	0.000000\\0.000000\\-19.875000
498	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
498	40	8	1
499	8	18	20000101
499	8	19	000000.000
499	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.22.0
499	32	18	
499	32	19	9
499	32	50	0.000000\\0.000000\\-2.125000
499	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
499	40	8	1
500	8	18	20000101
500	8	19	000000.000
500	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.166.0
500	32	18	
500	32	19	81
500	32	50	0.000000\\0.000000\\-20.125000
500	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
500	40	8	1
501	8	18	20000101
501	8	19	000000.000
501	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.168.0
501	32	18	
501	32	19	82
501	32	50	0.000000\\0.000000\\-20.375000
501	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
501	40	8	1
502	8	18	20000101
502	8	19	000000.000
502	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.170.0
502	32	18	
502	32	19	83
502	32	50	0.000000\\0.000000\\-20.625000
502	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
502	40	8	1
503	8	18	20000101
503	8	19	000000.000
503	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.172.0
503	32	18	
503	32	19	84
503	32	50	0.000000\\0.000000\\-20.875000
503	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
503	40	8	1
504	8	18	20000101
504	8	19	000000.000
504	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.174.0
504	32	18	
504	32	19	85
504	32	50	0.000000\\0.000000\\-21.125000
504	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
504	40	8	1
505	8	18	20000101
505	8	19	000000.000
505	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.176.0
505	32	18	
505	32	19	86
505	32	50	0.000000\\0.000000\\-21.375000
505	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
505	40	8	1
506	8	18	20000101
506	8	19	000000.000
506	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.178.0
506	32	18	
506	32	19	87
506	32	50	0.000000\\0.000000\\-21.625000
506	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
506	40	8	1
507	8	18	20000101
507	8	19	000000.000
507	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.180.0
507	32	18	
507	32	19	88
507	32	50	0.000000\\0.000000\\-21.875000
507	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
507	40	8	1
508	8	18	20000101
508	8	19	000000.000
508	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.182.0
508	32	18	
508	32	19	89
508	32	50	0.000000\\0.000000\\-22.125000
508	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
508	40	8	1
509	8	18	20000101
509	8	19	000000.000
509	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.184.0
509	32	18	
509	32	19	90
509	32	50	0.000000\\0.000000\\-22.375000
509	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
509	40	8	1
510	8	18	20000101
510	8	19	000000.000
510	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.24.0
510	32	18	
510	32	19	10
510	32	50	0.000000\\0.000000\\-2.375000
510	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
510	40	8	1
511	8	18	20000101
511	8	19	000000.000
511	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.186.0
511	32	18	
511	32	19	91
511	32	50	0.000000\\0.000000\\-22.625000
511	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
511	40	8	1
512	8	18	20000101
512	8	19	000000.000
512	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.188.0
512	32	18	
512	32	19	92
512	32	50	0.000000\\0.000000\\-22.875000
512	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
512	40	8	1
513	8	18	20000101
513	8	19	000000.000
513	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.190.0
513	32	18	
513	32	19	93
513	32	50	0.000000\\0.000000\\-23.125000
513	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
513	40	8	1
514	8	18	20000101
514	8	19	000000.000
514	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.192.0
514	32	18	
514	32	19	94
514	32	50	0.000000\\0.000000\\-23.375000
514	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
514	40	8	1
515	8	18	20000101
515	8	19	000000.000
515	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.194.0
515	32	18	
515	32	19	95
515	32	50	0.000000\\0.000000\\-23.625000
515	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
515	40	8	1
516	8	18	20000101
516	8	19	000000.000
516	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.196.0
516	32	18	
516	32	19	96
516	32	50	0.000000\\0.000000\\-23.875000
516	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
516	40	8	1
517	8	18	20000101
517	8	19	000000.000
517	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.198.0
517	32	18	
517	32	19	97
517	32	50	0.000000\\0.000000\\-24.125000
517	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
517	40	8	1
518	8	18	20000101
518	8	19	000000.000
518	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.200.0
518	32	18	
518	32	19	98
518	32	50	0.000000\\0.000000\\-24.375000
518	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
518	40	8	1
519	8	18	20000101
519	8	19	000000.000
519	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.202.0
519	32	18	
519	32	19	99
519	32	50	0.000000\\0.000000\\-24.625000
519	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
519	40	8	1
520	8	18	20000101
520	8	19	000000.000
520	8	24	1.3.6.1.4.1.5962.99.1.5128099.2103784727.1533308485539.204.0
520	32	18	
520	32	19	100
520	32	50	0.000000\\0.000000\\-24.875000
520	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
520	40	8	1
523	8	18	20100806
523	8	19	010452.000
523	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2590.0
523	32	18	1
523	32	19	1
523	32	50	-265.000\\0.000\\150.000
523	32	55	1.000000\\-0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
522	8	33	20100806
522	8	49	010434.000
522	8	96	CT
522	8	112	GE MEDICAL SYSTEMS
522	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2593.0
522	32	17	1
522	32	55	1.000000\\-0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
522	64	580	20100806
522	64	581	010434.000
521	16	16	NAME^NONE
521	16	32	NOID
521	16	48	
521	16	64	
521	8	32	20100806
521	8	48	010434.000
521	8	80	
521	8	144	
521	32	13	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2592.0
521	32	16	
524	8	18	20100806
524	8	19	010508.000
524	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2595.0
524	32	18	2
524	32	19	2
524	32	50	0.000\\265.000\\150.000
524	32	55	0.000000\\-1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
526	8	18	20100806
526	8	19	010537.000
526	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2607.0
526	32	18	1
526	32	19	9
526	32	50	-122.200\\-107.100\\20.750
526	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
525	8	33	20100806
525	8	49	010521.000
525	8	96	CT
525	8	112	GE MEDICAL SYSTEMS
525	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2599.0
525	32	17	2
525	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
525	64	580	20100806
525	64	581	010434.000
528	8	18	20100806
528	8	19	010558.000
528	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2698.0
528	32	18	1
528	32	19	65
528	32	50	-122.200\\-107.100\\140.750
528	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
527	8	33	20100806
527	8	49	010521.000
527	8	96	CT
527	8	112	GE MEDICAL SYSTEMS
527	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2634.0
527	32	17	3
527	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
527	64	580	20100806
527	64	581	010434.000
529	8	18	20100806
529	8	19	010558.000
529	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2699.0
529	32	18	1
529	32	19	66
529	32	50	-122.200\\-107.100\\143.250
529	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
530	8	18	20100806
530	8	19	010558.000
530	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2700.0
530	32	18	1
530	32	19	67
530	32	50	-122.200\\-107.100\\145.750
530	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
532	8	18	20100806
532	8	19	010634.000
532	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2701.0
532	32	18	1
532	32	19	1
532	32	50	-122.199\\-107.099\\59.809
532	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
531	8	33	20100806
531	8	49	010634.000
531	8	96	CT
531	8	112	GE MEDICAL SYSTEMS
531	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2702.0
531	32	17	601
531	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
533	8	18	20100806
533	8	19	010635.000
533	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2703.0
533	32	18	1
533	32	19	2
533	32	50	-126.838\\-98.18\\184.809
533	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
534	8	18	20100806
534	8	19	010635.000
534	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2704.0
534	32	18	1
534	32	19	3
534	32	50	-126.838\\-96.18\\184.809
534	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
535	8	18	20100806
535	8	19	010635.000
535	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2705.0
535	32	18	1
535	32	19	4
535	32	50	-126.838\\-94.18\\184.809
535	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
536	8	18	20100806
536	8	19	010636.000
536	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2706.0
536	32	18	1
536	32	19	5
536	32	50	-126.838\\-92.18\\184.809
536	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
537	8	18	20100806
537	8	19	010636.000
537	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2707.0
537	32	18	1
537	32	19	6
537	32	50	-126.838\\-90.18\\184.809
537	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
538	8	18	20100806
538	8	19	010636.000
538	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2708.0
538	32	18	1
538	32	19	7
538	32	50	-126.838\\-88.18\\184.809
538	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
539	8	18	20100806
539	8	19	010538.000
539	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2608.0
539	32	18	1
539	32	19	10
539	32	50	-122.200\\-107.100\\25.750
539	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
540	8	18	20100806
540	8	19	010637.000
540	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2709.0
540	32	18	1
540	32	19	8
540	32	50	-126.838\\-86.18\\184.809
540	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
541	8	18	20100806
541	8	19	010637.000
541	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2710.0
541	32	18	1
541	32	19	9
541	32	50	-126.838\\-84.18\\184.809
541	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
542	8	18	20100806
542	8	19	010637.000
542	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2711.0
542	32	18	1
542	32	19	10
542	32	50	-126.838\\-82.18\\184.809
542	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
543	8	18	20100806
543	8	19	010638.000
543	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2712.0
543	32	18	1
543	32	19	11
543	32	50	-126.838\\-80.18\\184.809
543	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
544	8	18	20100806
544	8	19	010638.000
544	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2713.0
544	32	18	1
544	32	19	12
544	32	50	-126.838\\-78.18\\184.809
544	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
545	8	18	20100806
545	8	19	010638.000
545	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2714.0
545	32	18	1
545	32	19	13
545	32	50	-126.838\\-76.18\\184.809
545	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
546	8	18	20100806
546	8	19	010639.000
546	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2715.0
546	32	18	1
546	32	19	14
546	32	50	-126.838\\-74.18\\184.809
546	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
547	8	18	20100806
547	8	19	010639.000
547	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2716.0
547	32	18	1
547	32	19	15
547	32	50	-126.838\\-72.18\\184.809
547	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
548	8	18	20100806
548	8	19	010639.000
548	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2717.0
548	32	18	1
548	32	19	16
548	32	50	-126.838\\-70.18\\184.809
548	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
549	8	18	20100806
549	8	19	010640.000
549	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2718.0
549	32	18	1
549	32	19	17
549	32	50	-126.838\\-68.18\\184.809
549	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
550	8	18	20100806
550	8	19	010538.000
550	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2609.0
550	32	18	1
550	32	19	11
550	32	50	-122.200\\-107.100\\30.750
550	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
551	8	18	20100806
551	8	19	010640.000
551	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2719.0
551	32	18	1
551	32	19	18
551	32	50	-126.838\\-66.18\\184.809
551	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
552	8	18	20100806
552	8	19	010640.000
552	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2720.0
552	32	18	1
552	32	19	19
552	32	50	-126.838\\-64.18\\184.809
552	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
553	8	18	20100806
553	8	19	010641.000
553	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2721.0
553	32	18	1
553	32	19	20
553	32	50	-126.838\\-62.18\\184.809
553	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
554	8	18	20100806
554	8	19	010641.000
554	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2722.0
554	32	18	1
554	32	19	21
554	32	50	-126.838\\-60.18\\184.809
554	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
555	8	18	20100806
555	8	19	010642.000
555	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2723.0
555	32	18	1
555	32	19	22
555	32	50	-126.838\\-58.18\\184.809
555	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
556	8	18	20100806
556	8	19	010642.000
556	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2724.0
556	32	18	1
556	32	19	23
556	32	50	-126.838\\-56.18\\184.809
556	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
557	8	18	20100806
557	8	19	010642.000
557	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2725.0
557	32	18	1
557	32	19	24
557	32	50	-126.838\\-54.18\\184.809
557	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
558	8	18	20100806
558	8	19	010643.000
558	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2726.0
558	32	18	1
558	32	19	25
558	32	50	-126.838\\-52.18\\184.809
558	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
559	8	18	20100806
559	8	19	010643.000
559	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2727.0
559	32	18	1
559	32	19	26
559	32	50	-126.838\\-50.18\\184.809
559	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
560	8	18	20100806
560	8	19	010643.000
560	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2728.0
560	32	18	1
560	32	19	27
560	32	50	-126.838\\-48.18\\184.809
560	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
561	8	18	20100806
561	8	19	010538.000
561	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2610.0
561	32	18	1
561	32	19	12
561	32	50	-122.200\\-107.100\\35.750
561	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
562	8	18	20100806
562	8	19	010644.000
562	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2729.0
562	32	18	1
562	32	19	28
562	32	50	-126.838\\-46.18\\184.809
562	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
563	8	18	20100806
563	8	19	010644.000
563	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2730.0
563	32	18	1
563	32	19	29
563	32	50	-126.838\\-44.18\\184.809
563	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
564	8	18	20100806
564	8	19	010644.000
564	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2731.0
564	32	18	1
564	32	19	30
564	32	50	-126.838\\-42.18\\184.809
564	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
565	8	18	20100806
565	8	19	010645.000
565	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2732.0
565	32	18	1
565	32	19	31
565	32	50	-126.838\\-40.18\\184.809
565	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
566	8	18	20100806
566	8	19	010645.000
566	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2733.0
566	32	18	1
566	32	19	32
566	32	50	-126.838\\-38.18\\184.809
566	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
567	8	18	20100806
567	8	19	010645.000
567	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2734.0
567	32	18	1
567	32	19	33
567	32	50	-126.838\\-36.18\\184.809
567	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
568	8	18	20100806
568	8	19	010646.000
568	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2735.0
568	32	18	1
568	32	19	34
568	32	50	-126.838\\-34.18\\184.809
568	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
569	8	18	20100806
569	8	19	010646.000
569	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2736.0
569	32	18	1
569	32	19	35
569	32	50	-126.838\\-32.18\\184.809
569	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
570	8	18	20100806
570	8	19	010646.000
570	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2737.0
570	32	18	1
570	32	19	36
570	32	50	-126.838\\-30.18\\184.809
570	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
571	8	18	20100806
571	8	19	010647.000
571	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2738.0
571	32	18	1
571	32	19	37
571	32	50	-126.838\\-28.18\\184.809
571	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
572	8	18	20100806
572	8	19	010538.000
572	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2611.0
572	32	18	1
572	32	19	13
572	32	50	-122.200\\-107.100\\40.750
572	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
573	8	18	20100806
573	8	19	010647.000
573	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2739.0
573	32	18	1
573	32	19	38
573	32	50	-126.838\\-26.18\\184.809
573	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
574	8	18	20100806
574	8	19	010647.000
574	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2740.0
574	32	18	1
574	32	19	39
574	32	50	-126.838\\-24.18\\184.809
574	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
575	8	18	20100806
575	8	19	010648.000
575	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2741.0
575	32	18	1
575	32	19	40
575	32	50	-126.838\\-22.18\\184.809
575	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
576	8	18	20100806
576	8	19	010648.000
576	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2742.0
576	32	18	1
576	32	19	41
576	32	50	-126.838\\-20.18\\184.809
576	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
577	8	18	20100806
577	8	19	010648.000
577	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2743.0
577	32	18	1
577	32	19	42
577	32	50	-126.838\\-18.18\\184.809
577	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
578	8	18	20100806
578	8	19	010649.000
578	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2744.0
578	32	18	1
578	32	19	43
578	32	50	-126.838\\-16.18\\184.809
578	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
579	8	18	20100806
579	8	19	010649.000
579	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2745.0
579	32	18	1
579	32	19	44
579	32	50	-126.838\\-14.18\\184.809
579	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
580	8	18	20100806
580	8	19	010650.000
580	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2746.0
580	32	18	1
580	32	19	45
580	32	50	-126.838\\-12.18\\184.809
580	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
581	8	18	20100806
581	8	19	010650.000
581	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2747.0
581	32	18	1
581	32	19	46
581	32	50	-126.838\\-10.18\\184.809
581	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
582	8	18	20100806
582	8	19	010650.000
582	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2748.0
582	32	18	1
582	32	19	47
582	32	50	-126.838\\-8.18\\184.809
582	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
583	8	18	20100806
583	8	19	010539.000
583	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2612.0
583	32	18	1
583	32	19	14
583	32	50	-122.200\\-107.100\\45.750
583	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
584	8	18	20100806
584	8	19	010651.000
584	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2749.0
584	32	18	1
584	32	19	48
584	32	50	-126.838\\-6.18\\184.809
584	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
585	8	18	20100806
585	8	19	010651.000
585	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2750.0
585	32	18	1
585	32	19	49
585	32	50	-126.838\\-4.18\\184.809
585	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
586	8	18	20100806
586	8	19	010651.000
586	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2751.0
586	32	18	1
586	32	19	50
586	32	50	-126.838\\-2.18\\184.809
586	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
587	8	18	20100806
587	8	19	010652.000
587	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2752.0
587	32	18	1
587	32	19	51
587	32	50	-126.838\\-0.18\\184.809
587	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
588	8	18	20100806
588	8	19	010652.000
588	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2753.0
588	32	18	1
588	32	19	52
588	32	50	-126.838\\1.819\\184.809
588	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
589	8	18	20100806
589	8	19	010652.000
589	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2754.0
589	32	18	1
589	32	19	53
589	32	50	-126.838\\3.819\\184.809
589	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
590	8	18	20100806
590	8	19	010653.000
590	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2755.0
590	32	18	1
590	32	19	54
590	32	50	-126.838\\5.819\\184.809
590	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
591	8	18	20100806
591	8	19	010653.000
591	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2756.0
591	32	18	1
591	32	19	55
591	32	50	-126.838\\7.819\\184.809
591	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
592	8	18	20100806
592	8	19	010653.000
592	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2757.0
592	32	18	1
592	32	19	56
592	32	50	-126.838\\9.819\\184.809
592	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
593	8	18	20100806
593	8	19	010654.000
593	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2758.0
593	32	18	1
593	32	19	57
593	32	50	-126.838\\11.819\\184.809
593	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
594	8	18	20100806
594	8	19	010539.000
594	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2613.0
594	32	18	1
594	32	19	15
594	32	50	-122.200\\-107.100\\50.750
594	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
595	8	18	20100806
595	8	19	010654.000
595	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2759.0
595	32	18	1
595	32	19	58
595	32	50	-126.838\\13.819\\184.809
595	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
596	8	18	20100806
596	8	19	010654.000
596	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2760.0
596	32	18	1
596	32	19	59
596	32	50	-126.838\\15.819\\184.809
596	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
597	8	18	20100806
597	8	19	010655.000
597	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2761.0
597	32	18	1
597	32	19	60
597	32	50	-126.838\\17.819\\184.809
597	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
598	8	18	20100806
598	8	19	010655.000
598	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2762.0
598	32	18	1
598	32	19	61
598	32	50	-126.838\\19.819\\184.809
598	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
599	8	18	20100806
599	8	19	010655.000
599	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2763.0
599	32	18	1
599	32	19	62
599	32	50	-126.838\\21.819\\184.809
599	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
600	8	18	20100806
600	8	19	010656.000
600	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2764.0
600	32	18	1
600	32	19	63
600	32	50	-126.838\\23.819\\184.809
600	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
601	8	18	20100806
601	8	19	010656.000
601	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2765.0
601	32	18	1
601	32	19	64
601	32	50	-126.838\\25.819\\184.809
601	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
602	8	18	20100806
602	8	19	010656.000
602	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2766.0
602	32	18	1
602	32	19	65
602	32	50	-126.838\\27.819\\184.809
602	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
603	8	18	20100806
603	8	19	010657.000
603	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2767.0
603	32	18	1
603	32	19	66
603	32	50	-126.838\\29.819\\184.809
603	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
604	8	18	20100806
604	8	19	010657.000
604	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2768.0
604	32	18	1
604	32	19	67
604	32	50	-126.838\\31.819\\184.809
604	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
605	8	18	20100806
605	8	19	010539.000
605	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2614.0
605	32	18	1
605	32	19	16
605	32	50	-122.200\\-107.100\\55.750
605	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
606	8	18	20100806
606	8	19	010658.000
606	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2769.0
606	32	18	1
606	32	19	68
606	32	50	-126.838\\33.819\\184.809
606	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
607	8	18	20100806
607	8	19	010658.000
607	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2770.0
607	32	18	1
607	32	19	69
607	32	50	-126.838\\35.819\\184.809
607	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
608	8	18	20100806
608	8	19	010658.000
608	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2771.0
608	32	18	1
608	32	19	70
608	32	50	-126.838\\37.819\\184.809
608	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
609	8	18	20100806
609	8	19	010659.000
609	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2772.0
609	32	18	1
609	32	19	71
609	32	50	-126.838\\39.819\\184.809
609	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
610	8	18	20100806
610	8	19	010659.000
610	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2773.0
610	32	18	1
610	32	19	72
610	32	50	-126.838\\41.819\\184.809
610	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
611	8	18	20100806
611	8	19	010659.000
611	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2774.0
611	32	18	1
611	32	19	73
611	32	50	-126.838\\43.819\\184.809
611	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
612	8	18	20100806
612	8	19	010700.000
612	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2775.0
612	32	18	1
612	32	19	74
612	32	50	-126.838\\45.819\\184.809
612	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
613	8	18	20100806
613	8	19	010700.000
613	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2776.0
613	32	18	1
613	32	19	75
613	32	50	-126.838\\47.819\\184.809
613	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
614	8	18	20100806
614	8	19	010700.000
614	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2777.0
614	32	18	1
614	32	19	76
614	32	50	-126.838\\49.819\\184.809
614	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
615	8	18	20100806
615	8	19	010701.000
615	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2778.0
615	32	18	1
615	32	19	77
615	32	50	-126.838\\51.819\\184.809
615	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
616	8	18	20100806
616	8	19	010540.000
616	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2615.0
616	32	18	1
616	32	19	17
616	32	50	-122.200\\-107.100\\60.750
616	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
617	8	18	20100806
617	8	19	010701.000
617	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2779.0
617	32	18	1
617	32	19	78
617	32	50	-126.838\\53.819\\184.809
617	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
618	8	18	20100806
618	8	19	010701.000
618	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2780.0
618	32	18	1
618	32	19	79
618	32	50	-126.838\\55.819\\184.809
618	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
619	8	18	20100806
619	8	19	010702.000
619	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2781.0
619	32	18	1
619	32	19	80
619	32	50	-126.838\\57.819\\184.809
619	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
620	8	18	20100806
620	8	19	010702.000
620	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2782.0
620	32	18	1
620	32	19	81
620	32	50	-126.838\\59.819\\184.809
620	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
621	8	18	20100806
621	8	19	010702.000
621	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2783.0
621	32	18	1
621	32	19	82
621	32	50	-126.838\\61.819\\184.809
621	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
622	8	18	20100806
622	8	19	010703.000
622	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2784.0
622	32	18	1
622	32	19	83
622	32	50	-126.838\\63.819\\184.809
622	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
623	8	18	20100806
623	8	19	010703.000
623	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2785.0
623	32	18	1
623	32	19	84
623	32	50	-126.838\\65.819\\184.809
623	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
624	8	18	20100806
624	8	19	010703.000
624	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2786.0
624	32	18	1
624	32	19	85
624	32	50	-126.838\\67.819\\184.809
624	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
625	8	18	20100806
625	8	19	010704.000
625	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2787.0
625	32	18	1
625	32	19	86
625	32	50	-126.838\\69.819\\184.809
625	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
626	8	18	20100806
626	8	19	010704.000
626	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2788.0
626	32	18	1
626	32	19	87
626	32	50	-126.838\\71.819\\184.809
626	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
627	8	18	20100806
627	8	19	010540.000
627	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2616.0
627	32	18	1
627	32	19	18
627	32	50	-122.200\\-107.100\\65.750
627	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
628	8	18	20100806
628	8	19	010705.000
628	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2789.0
628	32	18	1
628	32	19	88
628	32	50	-126.838\\73.819\\184.809
628	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
629	8	18	20100806
629	8	19	010705.000
629	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2790.0
629	32	18	1
629	32	19	89
629	32	50	-126.838\\75.819\\184.809
629	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
630	8	18	20100806
630	8	19	010705.000
630	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2791.0
630	32	18	1
630	32	19	90
630	32	50	-126.838\\77.819\\184.809
630	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
631	8	18	20100806
631	8	19	010706.000
631	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2792.0
631	32	18	1
631	32	19	91
631	32	50	-126.838\\79.819\\184.809
631	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
632	8	18	20100806
632	8	19	010706.000
632	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2793.0
632	32	18	1
632	32	19	92
632	32	50	-126.838\\81.819\\184.809
632	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
633	8	18	20100806
633	8	19	010706.000
633	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2794.0
633	32	18	1
633	32	19	93
633	32	50	-126.838\\83.819\\184.809
633	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
634	8	18	20100806
634	8	19	010707.000
634	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2795.0
634	32	18	1
634	32	19	94
634	32	50	-126.838\\85.819\\184.809
634	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
635	8	18	20100806
635	8	19	010707.000
635	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2796.0
635	32	18	1
635	32	19	95
635	32	50	-126.838\\87.819\\184.809
635	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
636	8	18	20100806
636	8	19	010707.000
636	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2797.0
636	32	18	1
636	32	19	96
636	32	50	-126.838\\89.819\\184.809
636	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
637	8	18	20100806
637	8	19	010708.000
637	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2798.0
637	32	18	1
637	32	19	97
637	32	50	-126.838\\91.819\\184.809
637	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
638	8	18	20100806
638	8	19	010535.000
638	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2597.0
638	32	18	1
638	32	19	1
638	32	50	-122.200\\-107.100\\-19.250
638	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
639	8	18	20100806
639	8	19	010540.000
639	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2617.0
639	32	18	1
639	32	19	19
639	32	50	-122.200\\-107.100\\70.750
639	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
640	8	18	20100806
640	8	19	010708.000
640	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2799.0
640	32	18	1
640	32	19	98
640	32	50	-126.838\\93.819\\184.809
640	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
641	8	18	20100806
641	8	19	010708.000
641	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2800.0
641	32	18	1
641	32	19	99
641	32	50	-126.838\\95.819\\184.809
641	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
642	8	18	20100806
642	8	19	010709.000
642	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2801.0
642	32	18	1
642	32	19	100
642	32	50	-126.838\\97.819\\184.809
642	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
643	8	18	20100806
643	8	19	010709.000
643	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2802.0
643	32	18	1
643	32	19	101
643	32	50	-126.838\\99.819\\184.809
643	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
644	8	18	20100806
644	8	19	010709.000
644	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2803.0
644	32	18	1
644	32	19	102
644	32	50	-126.838\\101.819\\184.809
644	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
645	8	18	20100806
645	8	19	010710.000
645	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2804.0
645	32	18	1
645	32	19	103
645	32	50	-126.838\\103.819\\184.809
645	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
646	8	18	20100806
646	8	19	010710.000
646	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2805.0
646	32	18	1
646	32	19	104
646	32	50	-126.838\\105.819\\184.809
646	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
647	8	18	20100806
647	8	19	010710.000
647	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2806.0
647	32	18	1
647	32	19	105
647	32	50	-126.838\\107.819\\184.809
647	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
648	8	18	20100806
648	8	19	010711.000
648	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2807.0
648	32	18	1
648	32	19	106
648	32	50	-126.838\\109.819\\184.809
648	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
649	8	18	20100806
649	8	19	010711.000
649	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2808.0
649	32	18	1
649	32	19	107
649	32	50	-126.838\\111.819\\184.809
649	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
650	8	18	20100806
650	8	19	010540.000
650	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2618.0
650	32	18	1
650	32	19	20
650	32	50	-122.200\\-107.100\\75.750
778	32	18	1
650	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
651	8	18	20100806
651	8	19	010711.000
651	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2809.0
651	32	18	1
651	32	19	108
651	32	50	-126.838\\113.819\\184.809
651	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
652	8	18	20100806
652	8	19	010712.000
652	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2810.0
652	32	18	1
652	32	19	109
652	32	50	-126.838\\115.819\\184.809
652	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
653	8	18	20100806
653	8	19	010712.000
653	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2811.0
653	32	18	1
653	32	19	110
653	32	50	-126.838\\117.819\\184.809
653	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
654	8	18	20100806
654	8	19	010713.000
654	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2812.0
654	32	18	1
654	32	19	111
654	32	50	-126.838\\119.819\\184.809
654	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
656	8	18	20100806
656	8	19	010713.000
656	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2813.0
656	32	18	1
656	32	19	1
656	32	50	-122.199\\10.819\\188.559
656	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
655	8	33	20100806
655	8	49	010713.000
655	8	96	CT
655	8	112	GE MEDICAL SYSTEMS
655	32	14	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2814.0
655	32	17	602
655	32	55	1.000000\\0.000000\\0.000000\\0.000000\\0.000000\\-1.000000
657	8	18	20100806
657	8	19	010713.000
657	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2815.0
657	32	18	1
657	32	19	2
657	32	50	85.161\\-114.18\\184.809
657	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
658	8	18	20100806
658	8	19	010713.000
658	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2816.0
658	32	18	1
658	32	19	3
658	32	50	83.161\\-114.18\\184.809
658	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
659	8	18	20100806
659	8	19	010714.000
659	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2817.0
659	32	18	1
659	32	19	4
659	32	50	81.161\\-114.18\\184.809
659	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
660	8	18	20100806
660	8	19	010714.000
660	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2818.0
660	32	18	1
660	32	19	5
660	32	50	79.161\\-114.18\\184.809
660	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
661	8	18	20100806
661	8	19	010714.000
661	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2819.0
661	32	18	1
661	32	19	6
661	32	50	77.161\\-114.18\\184.809
661	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
662	8	18	20100806
662	8	19	010541.000
662	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2619.0
662	32	18	1
662	32	19	21
662	32	50	-122.200\\-107.100\\80.750
662	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
663	8	18	20100806
663	8	19	010715.000
663	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2820.0
663	32	18	1
663	32	19	7
663	32	50	75.161\\-114.18\\184.809
663	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
664	8	18	20100806
664	8	19	010715.000
664	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2821.0
664	32	18	1
664	32	19	8
664	32	50	73.161\\-114.18\\184.809
664	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
665	8	18	20100806
665	8	19	010715.000
665	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2822.0
665	32	18	1
665	32	19	9
665	32	50	71.161\\-114.18\\184.809
665	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
666	8	18	20100806
666	8	19	010716.000
666	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2823.0
666	32	18	1
666	32	19	10
666	32	50	69.161\\-114.18\\184.809
666	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
667	8	18	20100806
667	8	19	010716.000
667	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2824.0
667	32	18	1
667	32	19	11
667	32	50	67.161\\-114.18\\184.809
667	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
668	8	18	20100806
668	8	19	010716.000
668	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2825.0
668	32	18	1
668	32	19	12
668	32	50	65.161\\-114.18\\184.809
668	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
669	8	18	20100806
669	8	19	010717.000
669	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2826.0
669	32	18	1
669	32	19	13
669	32	50	63.161\\-114.18\\184.809
669	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
670	8	18	20100806
670	8	19	010717.000
670	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2827.0
670	32	18	1
670	32	19	14
670	32	50	61.161\\-114.18\\184.809
670	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
671	8	18	20100806
671	8	19	010718.000
671	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2828.0
671	32	18	1
671	32	19	15
671	32	50	59.161\\-114.18\\184.809
671	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
672	8	18	20100806
672	8	19	010718.000
672	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2829.0
672	32	18	1
672	32	19	16
672	32	50	57.161\\-114.18\\184.809
672	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
673	8	18	20100806
673	8	19	010541.000
673	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2620.0
673	32	18	1
673	32	19	22
673	32	50	-122.200\\-107.100\\85.750
673	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
674	8	18	20100806
674	8	19	010718.000
674	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2830.0
674	32	18	1
674	32	19	17
674	32	50	55.161\\-114.18\\184.809
674	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
675	8	18	20100806
675	8	19	010719.000
675	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2831.0
675	32	18	1
675	32	19	18
675	32	50	53.161\\-114.18\\184.809
675	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
676	8	18	20100806
676	8	19	010719.000
676	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2832.0
676	32	18	1
676	32	19	19
676	32	50	51.161\\-114.18\\184.809
676	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
677	8	18	20100806
677	8	19	010719.000
677	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2833.0
677	32	18	1
677	32	19	20
677	32	50	49.161\\-114.18\\184.809
677	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
678	8	18	20100806
678	8	19	010720.000
678	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2834.0
678	32	18	1
678	32	19	21
678	32	50	47.161\\-114.18\\184.809
678	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
679	8	18	20100806
679	8	19	010720.000
679	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2835.0
679	32	18	1
679	32	19	22
679	32	50	45.161\\-114.18\\184.809
679	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
680	8	18	20100806
680	8	19	010720.000
680	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2836.0
680	32	18	1
680	32	19	23
680	32	50	43.161\\-114.18\\184.809
680	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
681	8	18	20100806
681	8	19	010721.000
681	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2837.0
681	32	18	1
681	32	19	24
681	32	50	41.161\\-114.18\\184.809
681	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
682	8	18	20100806
682	8	19	010721.000
682	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2838.0
682	32	18	1
682	32	19	25
682	32	50	39.161\\-114.18\\184.809
682	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
683	8	18	20100806
683	8	19	010721.000
683	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2839.0
683	32	18	1
683	32	19	26
683	32	50	37.161\\-114.18\\184.809
683	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
684	8	18	20100806
684	8	19	010541.000
684	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2621.0
684	32	18	1
684	32	19	23
684	32	50	-122.200\\-107.100\\90.750
684	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
685	8	18	20100806
685	8	19	010722.000
685	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2840.0
685	32	18	1
685	32	19	27
685	32	50	35.161\\-114.18\\184.809
685	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
686	8	18	20100806
686	8	19	010722.000
686	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2841.0
686	32	18	1
686	32	19	28
686	32	50	33.161\\-114.18\\184.809
686	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
687	8	18	20100806
687	8	19	010722.000
687	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2842.0
687	32	18	1
687	32	19	29
687	32	50	31.161\\-114.18\\184.809
687	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
688	8	18	20100806
688	8	19	010723.000
688	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2843.0
688	32	18	1
688	32	19	30
688	32	50	29.161\\-114.18\\184.809
688	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
689	8	18	20100806
689	8	19	010723.000
689	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2844.0
689	32	18	1
689	32	19	31
689	32	50	27.161\\-114.18\\184.809
689	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
690	8	18	20100806
690	8	19	010723.000
690	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2845.0
690	32	18	1
690	32	19	32
690	32	50	25.161\\-114.18\\184.809
690	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
691	8	18	20100806
691	8	19	010724.000
691	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2846.0
691	32	18	1
691	32	19	33
691	32	50	23.161\\-114.18\\184.809
691	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
692	8	18	20100806
692	8	19	010724.000
692	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2847.0
692	32	18	1
692	32	19	34
692	32	50	21.161\\-114.18\\184.809
692	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
693	8	18	20100806
693	8	19	010724.000
693	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2848.0
693	32	18	1
693	32	19	35
693	32	50	19.161\\-114.18\\184.809
693	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
694	8	18	20100806
694	8	19	010725.000
694	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2849.0
694	32	18	1
694	32	19	36
694	32	50	17.161\\-114.18\\184.809
694	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
695	8	18	20100806
695	8	19	010541.000
695	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2622.0
695	32	18	1
695	32	19	24
695	32	50	-122.200\\-107.100\\95.750
695	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
696	8	18	20100806
696	8	19	010725.000
696	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2850.0
696	32	18	1
696	32	19	37
696	32	50	15.161\\-114.18\\184.809
696	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
697	8	18	20100806
697	8	19	010726.000
697	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2851.0
697	32	18	1
697	32	19	38
697	32	50	13.161\\-114.18\\184.809
697	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
698	8	18	20100806
698	8	19	010726.000
698	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2852.0
698	32	18	1
698	32	19	39
698	32	50	11.161\\-114.18\\184.809
698	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
699	8	18	20100806
699	8	19	010726.000
699	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2853.0
699	32	18	1
699	32	19	40
699	32	50	9.161\\-114.18\\184.809
699	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
700	8	18	20100806
700	8	19	010727.000
700	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2854.0
700	32	18	1
700	32	19	41
700	32	50	7.161\\-114.18\\184.809
700	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
701	8	18	20100806
701	8	19	010727.000
701	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2855.0
701	32	18	1
701	32	19	42
701	32	50	5.161\\-114.18\\184.809
701	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
702	8	18	20100806
702	8	19	010727.000
702	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2856.0
702	32	18	1
702	32	19	43
702	32	50	3.161\\-114.18\\184.809
702	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
703	8	18	20100806
703	8	19	010728.000
703	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2857.0
703	32	18	1
703	32	19	44
703	32	50	1.161\\-114.18\\184.809
703	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
704	8	18	20100806
704	8	19	010728.000
704	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2858.0
704	32	18	1
704	32	19	45
704	32	50	-0.838\\-114.18\\184.809
704	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
705	8	18	20100806
705	8	19	010728.000
705	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2859.0
705	32	18	1
705	32	19	46
705	32	50	-2.838\\-114.18\\184.809
705	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
706	8	18	20100806
706	8	19	010542.000
706	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2623.0
706	32	18	1
706	32	19	25
706	32	50	-122.200\\-107.100\\100.750
706	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
707	8	18	20100806
707	8	19	010729.000
707	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2860.0
707	32	18	1
707	32	19	47
707	32	50	-4.838\\-114.18\\184.809
707	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
708	8	18	20100806
708	8	19	010729.000
708	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2861.0
708	32	18	1
708	32	19	48
708	32	50	-6.838\\-114.18\\184.809
708	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
709	8	18	20100806
709	8	19	010729.000
709	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2862.0
709	32	18	1
709	32	19	49
709	32	50	-8.838\\-114.18\\184.809
709	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
710	8	18	20100806
710	8	19	010730.000
710	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2863.0
710	32	18	1
710	32	19	50
710	32	50	-10.838\\-114.18\\184.809
710	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
711	8	18	20100806
711	8	19	010730.000
711	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2864.0
711	32	18	1
711	32	19	51
711	32	50	-12.838\\-114.18\\184.809
711	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
712	8	18	20100806
712	8	19	010730.000
712	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2865.0
712	32	18	1
712	32	19	52
712	32	50	-14.838\\-114.18\\184.809
712	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
713	8	18	20100806
713	8	19	010731.000
713	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2866.0
713	32	18	1
713	32	19	53
713	32	50	-16.838\\-114.18\\184.809
713	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
714	8	18	20100806
714	8	19	010731.000
714	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2867.0
714	32	18	1
714	32	19	54
714	32	50	-18.838\\-114.18\\184.809
714	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
715	8	18	20100806
715	8	19	010731.000
715	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2868.0
715	32	18	1
715	32	19	55
715	32	50	-20.838\\-114.18\\184.809
715	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
716	8	18	20100806
716	8	19	010732.000
716	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2869.0
716	32	18	1
716	32	19	56
716	32	50	-22.838\\-114.18\\184.809
716	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
717	8	18	20100806
717	8	19	010542.000
717	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2624.0
717	32	18	1
717	32	19	26
717	32	50	-122.200\\-107.100\\105.750
717	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
718	8	18	20100806
718	8	19	010732.000
718	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2870.0
718	32	18	1
718	32	19	57
718	32	50	-24.838\\-114.18\\184.809
718	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
719	8	18	20100806
719	8	19	010733.000
719	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2871.0
719	32	18	1
719	32	19	58
719	32	50	-26.838\\-114.18\\184.809
719	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
720	8	18	20100806
720	8	19	010733.000
720	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2872.0
720	32	18	1
720	32	19	59
720	32	50	-28.838\\-114.18\\184.809
720	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
721	8	18	20100806
721	8	19	010733.000
721	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2873.0
721	32	18	1
721	32	19	60
721	32	50	-30.838\\-114.18\\184.809
721	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
722	8	18	20100806
722	8	19	010734.000
722	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2874.0
722	32	18	1
722	32	19	61
722	32	50	-32.838\\-114.18\\184.809
722	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
723	8	18	20100806
723	8	19	010734.000
723	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2875.0
723	32	18	1
723	32	19	62
723	32	50	-34.838\\-114.18\\184.809
723	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
724	8	18	20100806
724	8	19	010734.000
724	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2876.0
724	32	18	1
724	32	19	63
724	32	50	-36.838\\-114.18\\184.809
724	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
725	8	18	20100806
725	8	19	010735.000
725	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2877.0
725	32	18	1
725	32	19	64
725	32	50	-38.838\\-114.18\\184.809
725	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
726	8	18	20100806
726	8	19	010735.000
726	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2878.0
726	32	18	1
726	32	19	65
726	32	50	-40.838\\-114.18\\184.809
726	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
727	8	18	20100806
727	8	19	010735.000
727	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2879.0
727	32	18	1
727	32	19	66
727	32	50	-42.838\\-114.18\\184.809
727	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
728	8	18	20100806
728	8	19	010542.000
728	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2625.0
728	32	18	1
728	32	19	27
728	32	50	-122.200\\-107.100\\110.750
728	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
729	8	18	20100806
729	8	19	010736.000
729	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2880.0
729	32	18	1
729	32	19	67
729	32	50	-44.838\\-114.18\\184.809
729	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
730	8	18	20100806
730	8	19	010736.000
730	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2881.0
730	32	18	1
730	32	19	68
730	32	50	-46.838\\-114.18\\184.809
730	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
731	8	18	20100806
731	8	19	010736.000
731	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2882.0
731	32	18	1
731	32	19	69
731	32	50	-48.838\\-114.18\\184.809
731	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
732	8	18	20100806
732	8	19	010737.000
732	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2883.0
732	32	18	1
732	32	19	70
732	32	50	-50.838\\-114.18\\184.809
732	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
733	8	18	20100806
733	8	19	010737.000
733	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2884.0
733	32	18	1
733	32	19	71
733	32	50	-52.838\\-114.18\\184.809
733	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
734	8	18	20100806
734	8	19	010737.000
734	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2885.0
734	32	18	1
734	32	19	72
734	32	50	-54.838\\-114.18\\184.809
734	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
735	8	18	20100806
735	8	19	010738.000
735	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2886.0
735	32	18	1
735	32	19	73
735	32	50	-56.838\\-114.18\\184.809
735	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
736	8	18	20100806
736	8	19	010738.000
736	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2887.0
736	32	18	1
736	32	19	74
736	32	50	-58.838\\-114.18\\184.809
736	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
737	8	18	20100806
737	8	19	010738.000
737	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2888.0
737	32	18	1
737	32	19	75
737	32	50	-60.838\\-114.18\\184.809
737	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
738	8	18	20100806
738	8	19	010739.000
738	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2889.0
738	32	18	1
738	32	19	76
738	32	50	-62.838\\-114.18\\184.809
738	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
739	8	18	20100806
739	8	19	010542.000
739	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2626.0
739	32	18	1
739	32	19	28
739	32	50	-122.200\\-107.100\\115.750
739	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
740	8	18	20100806
740	8	19	010739.000
740	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2890.0
740	32	18	1
740	32	19	77
740	32	50	-64.838\\-114.18\\184.809
740	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
741	8	18	20100806
741	8	19	010739.000
741	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2891.0
741	32	18	1
741	32	19	78
741	32	50	-66.838\\-114.18\\184.809
741	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
742	8	18	20100806
742	8	19	010740.000
742	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2892.0
742	32	18	1
742	32	19	79
742	32	50	-68.838\\-114.18\\184.809
742	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
743	8	18	20100806
743	8	19	010740.000
743	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2893.0
743	32	18	1
743	32	19	80
743	32	50	-70.838\\-114.18\\184.809
743	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
744	8	18	20100806
744	8	19	010741.000
744	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2894.0
744	32	18	1
744	32	19	81
744	32	50	-72.838\\-114.18\\184.809
744	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
745	8	18	20100806
745	8	19	010741.000
745	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2895.0
745	32	18	1
745	32	19	82
745	32	50	-74.838\\-114.18\\184.809
745	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
746	8	18	20100806
746	8	19	010741.000
746	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2896.0
746	32	18	1
746	32	19	83
746	32	50	-76.838\\-114.18\\184.809
746	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
747	8	18	20100806
747	8	19	010742.000
747	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2897.0
747	32	18	1
747	32	19	84
747	32	50	-78.838\\-114.18\\184.809
747	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
748	8	18	20100806
748	8	19	010742.000
748	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2898.0
748	32	18	1
748	32	19	85
748	32	50	-80.838\\-114.18\\184.809
748	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
749	8	18	20100806
749	8	19	010742.000
749	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2899.0
749	32	18	1
749	32	19	86
749	32	50	-82.838\\-114.18\\184.809
749	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
750	8	18	20100806
750	8	19	010536.000
750	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2600.0
750	32	18	1
750	32	19	2
750	32	50	-122.200\\-107.100\\-14.250
750	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
751	8	18	20100806
751	8	19	010542.000
751	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2627.0
751	32	18	1
751	32	19	29
751	32	50	-122.200\\-107.100\\120.750
751	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
752	8	18	20100806
752	8	19	010743.000
752	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2900.0
752	32	18	1
752	32	19	87
752	32	50	-84.838\\-114.18\\184.809
752	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
753	8	18	20100806
753	8	19	010743.000
753	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2901.0
753	32	18	1
753	32	19	88
753	32	50	-86.838\\-114.18\\184.809
753	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
754	8	18	20100806
754	8	19	010743.000
754	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2902.0
754	32	18	1
754	32	19	89
754	32	50	-88.838\\-114.18\\184.809
754	32	55	0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000
755	8	18	20100806
755	8	19	010542.000
755	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2628.0
755	32	18	1
755	32	19	30
755	32	50	-122.200\\-107.100\\125.750
755	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
756	8	18	20100806
756	8	19	010542.000
756	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2629.0
756	32	18	1
756	32	19	31
756	32	50	-122.200\\-107.100\\130.750
756	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
757	8	18	20100806
757	8	19	010542.000
757	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2630.0
757	32	18	1
757	32	19	32
757	32	50	-122.200\\-107.100\\135.750
757	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
758	8	18	20100806
758	8	19	010542.000
758	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2631.0
758	32	18	1
758	32	19	33
758	32	50	-122.200\\-107.100\\140.750
758	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
759	8	18	20100806
759	8	19	010542.000
759	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2632.0
759	32	18	1
759	32	19	34
759	32	50	-122.200\\-107.100\\145.750
759	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
760	8	18	20100806
760	8	19	010549.000
760	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2633.0
760	32	18	1
760	32	19	1
760	32	50	-122.200\\-107.100\\-19.250
760	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
761	8	18	20100806
761	8	19	010549.000
761	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2635.0
761	32	18	1
761	32	19	2
761	32	50	-122.200\\-107.100\\-16.750
761	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
762	8	18	20100806
762	8	19	010549.000
762	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2636.0
762	32	18	1
762	32	19	3
762	32	50	-122.200\\-107.100\\-14.250
762	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
763	8	18	20100806
763	8	19	010549.000
763	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2637.0
763	32	18	1
763	32	19	4
763	32	50	-122.200\\-107.100\\-11.750
763	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
764	8	18	20100806
764	8	19	010536.000
764	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2601.0
764	32	18	1
764	32	19	3
764	32	50	-122.200\\-107.100\\-9.250
764	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
765	8	18	20100806
765	8	19	010550.000
765	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2638.0
765	32	18	1
765	32	19	5
765	32	50	-122.200\\-107.100\\-9.250
765	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
766	8	18	20100806
766	8	19	010550.000
766	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2639.0
766	32	18	1
766	32	19	6
766	32	50	-122.200\\-107.100\\-6.750
766	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
767	8	18	20100806
767	8	19	010550.000
767	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2640.0
767	32	18	1
767	32	19	7
767	32	50	-122.200\\-107.100\\-4.250
767	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
768	8	18	20100806
768	8	19	010550.000
768	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2641.0
768	32	18	1
768	32	19	8
768	32	50	-122.200\\-107.100\\-1.750
768	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
769	8	18	20100806
769	8	19	010550.000
769	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2642.0
769	32	18	1
769	32	19	9
769	32	50	-122.200\\-107.100\\0.750
769	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
770	8	18	20100806
770	8	19	010550.000
770	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2643.0
770	32	18	1
770	32	19	10
770	32	50	-122.200\\-107.100\\3.250
770	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
771	8	18	20100806
771	8	19	010550.000
771	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2644.0
771	32	18	1
771	32	19	11
771	32	50	-122.200\\-107.100\\5.750
771	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
772	8	18	20100806
772	8	19	010551.000
772	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2645.0
772	32	18	1
772	32	19	12
772	32	50	-122.200\\-107.100\\8.250
772	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
773	8	18	20100806
773	8	19	010551.000
773	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2646.0
773	32	18	1
773	32	19	13
773	32	50	-122.200\\-107.100\\10.750
773	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
774	8	18	20100806
774	8	19	010551.000
774	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2647.0
774	32	18	1
774	32	19	14
774	32	50	-122.200\\-107.100\\13.250
774	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
775	8	18	20100806
775	8	19	010536.000
775	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2602.0
775	32	18	1
775	32	19	4
775	32	50	-122.200\\-107.100\\-4.250
775	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
776	8	18	20100806
776	8	19	010551.000
776	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2648.0
776	32	18	1
776	32	19	15
776	32	50	-122.200\\-107.100\\15.750
776	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
777	8	18	20100806
777	8	19	010551.000
777	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2649.0
777	32	18	1
777	32	19	16
777	32	50	-122.200\\-107.100\\18.250
777	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
778	8	18	20100806
778	8	19	010551.000
778	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2650.0
778	32	19	17
778	32	50	-122.200\\-107.100\\20.750
778	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
779	8	18	20100806
779	8	19	010552.000
779	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2651.0
779	32	18	1
779	32	19	18
779	32	50	-122.200\\-107.100\\23.250
779	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
780	8	18	20100806
780	8	19	010552.000
780	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2652.0
780	32	18	1
780	32	19	19
780	32	50	-122.200\\-107.100\\25.750
780	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
781	8	18	20100806
781	8	19	010552.000
781	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2653.0
781	32	18	1
781	32	19	20
781	32	50	-122.200\\-107.100\\28.250
781	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
782	8	18	20100806
782	8	19	010552.000
782	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2654.0
782	32	18	1
782	32	19	21
782	32	50	-122.200\\-107.100\\30.750
782	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
783	8	18	20100806
783	8	19	010552.000
783	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2655.0
783	32	18	1
783	32	19	22
783	32	50	-122.200\\-107.100\\33.250
783	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
784	8	18	20100806
784	8	19	010552.000
784	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2656.0
784	32	18	1
784	32	19	23
784	32	50	-122.200\\-107.100\\35.750
784	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
785	8	18	20100806
785	8	19	010552.000
785	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2657.0
785	32	18	1
785	32	19	24
785	32	50	-122.200\\-107.100\\38.250
785	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
786	8	18	20100806
786	8	19	010536.000
786	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2603.0
786	32	18	1
786	32	19	5
786	32	50	-122.200\\-107.100\\0.750
786	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
787	8	18	20100806
787	8	19	010553.000
787	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2658.0
787	32	18	1
787	32	19	25
787	32	50	-122.200\\-107.100\\40.750
787	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
788	8	18	20100806
788	8	19	010553.000
788	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2659.0
788	32	18	1
788	32	19	26
788	32	50	-122.200\\-107.100\\43.250
788	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
789	8	18	20100806
789	8	19	010553.000
789	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2660.0
789	32	18	1
789	32	19	27
789	32	50	-122.200\\-107.100\\45.750
789	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
790	8	18	20100806
790	8	19	010553.000
790	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2661.0
790	32	18	1
790	32	19	28
790	32	50	-122.200\\-107.100\\48.250
790	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
791	8	18	20100806
791	8	19	010553.000
791	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2662.0
791	32	18	1
791	32	19	29
791	32	50	-122.200\\-107.100\\50.750
791	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
792	8	18	20100806
792	8	19	010553.000
792	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2663.0
792	32	18	1
792	32	19	30
792	32	50	-122.200\\-107.100\\53.250
792	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
793	8	18	20100806
793	8	19	010554.000
793	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2664.0
793	32	18	1
793	32	19	31
793	32	50	-122.200\\-107.100\\55.750
793	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
794	8	18	20100806
794	8	19	010554.000
810	8	18	20100806
794	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2665.0
794	32	18	1
794	32	19	32
794	32	50	-122.200\\-107.100\\58.250
794	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
795	8	18	20100806
795	8	19	010554.000
795	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2666.0
795	32	18	1
795	32	19	33
795	32	50	-122.200\\-107.100\\60.750
795	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
796	8	18	20100806
796	8	19	010554.000
796	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2667.0
796	32	18	1
796	32	19	34
796	32	50	-122.200\\-107.100\\63.250
796	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
797	8	18	20100806
797	8	19	010536.000
797	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2604.0
797	32	18	1
797	32	19	6
797	32	50	-122.200\\-107.100\\5.750
797	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
798	8	18	20100806
798	8	19	010554.000
798	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2668.0
798	32	18	1
798	32	19	35
798	32	50	-122.200\\-107.100\\65.750
798	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
799	8	18	20100806
799	8	19	010554.000
799	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2669.0
799	32	18	1
799	32	19	36
799	32	50	-122.200\\-107.100\\68.250
799	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
800	8	18	20100806
800	8	19	010554.000
800	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2670.0
800	32	18	1
800	32	19	37
800	32	50	-122.200\\-107.100\\70.750
800	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
801	8	18	20100806
801	8	19	010554.000
801	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2671.0
801	32	18	1
801	32	19	38
801	32	50	-122.200\\-107.100\\73.250
801	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
802	8	18	20100806
802	8	19	010555.000
802	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2672.0
802	32	18	1
802	32	19	39
802	32	50	-122.200\\-107.100\\75.750
802	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
803	8	18	20100806
803	8	19	010555.000
803	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2673.0
803	32	18	1
803	32	19	40
803	32	50	-122.200\\-107.100\\78.250
803	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
804	8	18	20100806
804	8	19	010555.000
804	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2674.0
804	32	18	1
804	32	19	41
804	32	50	-122.200\\-107.100\\80.750
804	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
805	8	18	20100806
805	8	19	010555.000
805	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2675.0
805	32	18	1
805	32	19	42
805	32	50	-122.200\\-107.100\\83.250
805	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
806	8	18	20100806
806	8	19	010555.000
806	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2676.0
806	32	18	1
806	32	19	43
806	32	50	-122.200\\-107.100\\85.750
806	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
807	8	18	20100806
807	8	19	010555.000
807	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2677.0
807	32	18	1
807	32	19	44
807	32	50	-122.200\\-107.100\\88.250
807	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
808	8	18	20100806
808	8	19	010537.000
808	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2605.0
808	32	18	1
808	32	19	7
808	32	50	-122.200\\-107.100\\10.750
808	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
809	8	18	20100806
809	8	19	010556.000
809	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2678.0
809	32	18	1
809	32	19	45
809	32	50	-122.200\\-107.100\\90.750
809	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
810	8	19	010556.000
810	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2679.0
810	32	18	1
810	32	19	46
810	32	50	-122.200\\-107.100\\93.250
810	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
811	8	18	20100806
811	8	19	010556.000
811	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2680.0
811	32	18	1
811	32	19	47
811	32	50	-122.200\\-107.100\\95.750
811	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
812	8	18	20100806
812	8	19	010556.000
812	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2681.0
812	32	18	1
812	32	19	48
812	32	50	-122.200\\-107.100\\98.250
812	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
813	8	18	20100806
813	8	19	010556.000
813	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2682.0
813	32	18	1
813	32	19	49
813	32	50	-122.200\\-107.100\\100.750
813	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
814	8	18	20100806
814	8	19	010556.000
814	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2683.0
814	32	18	1
814	32	19	50
814	32	50	-122.200\\-107.100\\103.250
814	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
815	8	18	20100806
815	8	19	010556.000
815	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2684.0
815	32	18	1
815	32	19	51
815	32	50	-122.200\\-107.100\\105.750
815	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
816	8	18	20100806
816	8	19	010557.000
816	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2685.0
816	32	18	1
816	32	19	52
816	32	50	-122.200\\-107.100\\108.250
816	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
817	8	18	20100806
817	8	19	010557.000
817	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2686.0
817	32	18	1
817	32	19	53
817	32	50	-122.200\\-107.100\\110.750
817	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
818	8	18	20100806
818	8	19	010557.000
818	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2687.0
818	32	18	1
818	32	19	54
818	32	50	-122.200\\-107.100\\113.250
818	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
819	8	18	20100806
819	8	19	010537.000
819	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2606.0
819	32	18	1
819	32	19	8
819	32	50	-122.200\\-107.100\\15.750
819	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
820	8	18	20100806
820	8	19	010557.000
820	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2688.0
820	32	18	1
820	32	19	55
820	32	50	-122.200\\-107.100\\115.750
820	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
821	8	18	20100806
821	8	19	010557.000
821	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2689.0
821	32	18	1
821	32	19	56
821	32	50	-122.200\\-107.100\\118.250
821	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
822	8	18	20100806
822	8	19	010557.000
822	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2690.0
822	32	18	1
822	32	19	57
822	32	50	-122.200\\-107.100\\120.750
822	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
823	8	18	20100806
823	8	19	010557.000
823	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2691.0
823	32	18	1
823	32	19	58
823	32	50	-122.200\\-107.100\\123.250
823	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
824	8	18	20100806
824	8	19	010558.000
824	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2692.0
824	32	18	1
824	32	19	59
824	32	50	-122.200\\-107.100\\125.750
824	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
825	8	18	20100806
825	8	19	010558.000
825	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2693.0
825	32	18	1
825	32	19	60
825	32	50	-122.200\\-107.100\\128.250
825	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
826	8	18	20100806
826	8	19	010558.000
826	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2694.0
826	32	18	1
826	32	19	61
826	32	50	-122.200\\-107.100\\130.750
826	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
827	8	18	20100806
827	8	19	010558.000
827	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2695.0
827	32	18	1
827	32	19	62
827	32	50	-122.200\\-107.100\\133.250
827	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
828	8	18	20100806
828	8	19	010558.000
828	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2696.0
828	32	18	1
828	32	19	63
828	32	50	-122.200\\-107.100\\135.750
828	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
829	8	18	20100806
829	8	19	010558.000
829	8	24	1.3.6.1.4.1.5962.99.1.1761388472.1291962045.1616669124536.2697.0
829	32	18	1
829	32	19	64
829	32	50	-122.200\\-107.100\\138.250
829	32	55	1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.metadata (id, type, value, revision) FROM stdin;
4	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
3	15	0008,0021;0008,0031;0008,0060;0008,0070;0008,0201;0008,1010;0008,103e;0008,1070;0018,0010;0018,0015;0018,0024;0018,1030;0018,1090;0018,1400;0020,000e;0020,0011;0020,0037;0020,0105;0020,1002;0040,0244;0040,0245;0040,0254;0040,0275;0054,0081;0054,0101;0054,1000	0
2	15	0008,0020;0008,0030;0008,0050;0008,0080;0008,0090;0008,0201;0008,1030;0020,000d;0020,0010;0032,1032;0032,1060	0
1	15	0010,0010;0010,0020;0010,0030;0010,0040;0010,1000	0
523	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
542	2	20250211T154521	0
542	3		0
3	3		0
4	2	20250211T152516	0
4	3		0
4	8	RestApi	0
4	11	172.22.0.1	0
4	13	orthanc	0
4	9	1.2.840.10008.1.2.4.51	0
4	14	2764	0
4	10	1.2.840.10008.5.1.4.1.1.2	0
4	1	1	0
5	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
542	8	RestApi	0
5	2	20250211T152516	0
5	3		0
5	8	RestApi	0
5	11	172.22.0.1	0
5	13	orthanc	0
5	9	1.2.840.10008.1.2.4.51	0
5	14	2764	0
5	10	1.2.840.10008.5.1.4.1.1.2	0
5	1	2	0
6	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
6	2	20250211T152516	0
6	3		0
6	8	RestApi	0
6	11	172.22.0.1	0
6	13	orthanc	0
6	9	1.2.840.10008.1.2.4.51	0
6	14	2770	0
6	10	1.2.840.10008.5.1.4.1.1.2	0
6	1	11	0
7	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
7	2	20250211T152516	0
7	3		0
7	8	RestApi	0
7	11	172.22.0.1	0
7	13	orthanc	0
7	9	1.2.840.10008.1.2.4.51	0
7	14	2772	0
7	10	1.2.840.10008.5.1.4.1.1.2	0
7	1	101	0
8	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
8	2	20250211T152516	0
8	3		0
8	8	RestApi	0
8	11	172.22.0.1	0
8	13	orthanc	0
8	9	1.2.840.10008.1.2.4.51	0
8	14	2772	0
8	10	1.2.840.10008.5.1.4.1.1.2	0
8	1	102	0
9	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
9	2	20250211T152516	0
9	3		0
9	8	RestApi	0
9	11	172.22.0.1	0
9	13	orthanc	0
9	9	1.2.840.10008.1.2.4.51	0
9	14	2772	0
9	10	1.2.840.10008.5.1.4.1.1.2	0
9	1	103	0
10	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
10	2	20250211T152516	0
10	3		0
10	8	RestApi	0
10	11	172.22.0.1	0
10	13	orthanc	0
10	9	1.2.840.10008.1.2.4.51	0
10	14	2772	0
10	10	1.2.840.10008.5.1.4.1.1.2	0
10	1	104	0
11	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
11	2	20250211T152516	0
11	3		0
11	8	RestApi	0
11	11	172.22.0.1	0
11	13	orthanc	0
11	9	1.2.840.10008.1.2.4.51	0
11	14	2772	0
11	10	1.2.840.10008.5.1.4.1.1.2	0
11	1	105	0
12	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
12	2	20250211T152516	0
12	3		0
12	8	RestApi	0
12	11	172.22.0.1	0
12	13	orthanc	0
12	9	1.2.840.10008.1.2.4.51	0
12	14	2772	0
12	10	1.2.840.10008.5.1.4.1.1.2	0
12	1	106	0
13	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
13	2	20250211T152516	0
13	3		0
13	8	RestApi	0
13	11	172.22.0.1	0
13	13	orthanc	0
13	9	1.2.840.10008.1.2.4.51	0
13	14	2772	0
13	10	1.2.840.10008.5.1.4.1.1.2	0
13	1	107	0
14	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
14	2	20250211T152516	0
14	3		0
14	8	RestApi	0
14	11	172.22.0.1	0
14	13	orthanc	0
14	9	1.2.840.10008.1.2.4.51	0
14	14	2772	0
14	10	1.2.840.10008.5.1.4.1.1.2	0
14	1	108	0
15	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
522	15	0008,0021;0008,0031;0008,0060;0008,0070;0008,0201;0008,1010;0008,103e;0008,1070;0018,0010;0018,0015;0018,0024;0018,1030;0018,1090;0018,1400;0020,000e;0020,0011;0020,0037;0020,0105;0020,1002;0040,0244;0040,0245;0040,0254;0040,0275;0054,0081;0054,0101;0054,1000	0
542	11	172.22.0.1	0
15	2	20250211T152516	0
15	3		0
15	8	RestApi	0
15	11	172.22.0.1	0
15	13	orthanc	0
15	9	1.2.840.10008.1.2.4.51	0
15	14	2772	0
15	10	1.2.840.10008.5.1.4.1.1.2	0
15	1	109	0
16	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
16	2	20250211T152516	0
16	3		0
16	8	RestApi	0
16	11	172.22.0.1	0
16	13	orthanc	0
16	9	1.2.840.10008.1.2.4.51	0
16	14	2772	0
16	10	1.2.840.10008.5.1.4.1.1.2	0
16	1	110	0
17	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
17	2	20250211T152516	0
17	3		0
17	8	RestApi	0
17	11	172.22.0.1	0
17	13	orthanc	0
17	9	1.2.840.10008.1.2.4.51	0
17	14	2770	0
17	10	1.2.840.10008.5.1.4.1.1.2	0
17	1	12	0
18	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
18	2	20250211T152516	0
18	3		0
18	8	RestApi	0
18	11	172.22.0.1	0
18	13	orthanc	0
18	9	1.2.840.10008.1.2.4.51	0
18	14	2772	0
18	10	1.2.840.10008.5.1.4.1.1.2	0
18	1	111	0
19	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
19	2	20250211T152516	0
19	3		0
19	8	RestApi	0
19	11	172.22.0.1	0
19	13	orthanc	0
19	9	1.2.840.10008.1.2.4.51	0
19	14	2772	0
19	10	1.2.840.10008.5.1.4.1.1.2	0
19	1	112	0
20	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
20	2	20250211T152516	0
20	3		0
20	8	RestApi	0
20	11	172.22.0.1	0
20	13	orthanc	0
20	9	1.2.840.10008.1.2.4.51	0
20	14	2772	0
20	10	1.2.840.10008.5.1.4.1.1.2	0
20	1	113	0
21	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
21	2	20250211T152516	0
21	3		0
21	8	RestApi	0
21	11	172.22.0.1	0
21	13	orthanc	0
21	9	1.2.840.10008.1.2.4.51	0
21	14	2772	0
21	10	1.2.840.10008.5.1.4.1.1.2	0
21	1	114	0
22	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
22	2	20250211T152516	0
22	3		0
22	8	RestApi	0
22	11	172.22.0.1	0
22	13	orthanc	0
22	9	1.2.840.10008.1.2.4.51	0
22	14	2772	0
22	10	1.2.840.10008.5.1.4.1.1.2	0
22	1	115	0
23	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
23	2	20250211T152516	0
23	3		0
23	8	RestApi	0
23	11	172.22.0.1	0
23	13	orthanc	0
23	9	1.2.840.10008.1.2.4.51	0
23	14	2772	0
23	10	1.2.840.10008.5.1.4.1.1.2	0
23	1	116	0
24	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
24	2	20250211T152516	0
24	3		0
24	8	RestApi	0
24	11	172.22.0.1	0
24	13	orthanc	0
24	9	1.2.840.10008.1.2.4.51	0
24	14	2772	0
24	10	1.2.840.10008.5.1.4.1.1.2	0
24	1	117	0
25	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
25	2	20250211T152516	0
25	3		0
25	8	RestApi	0
25	11	172.22.0.1	0
25	13	orthanc	0
25	9	1.2.840.10008.1.2.4.51	0
25	14	2772	0
25	10	1.2.840.10008.5.1.4.1.1.2	0
25	1	118	0
26	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
521	15	0008,0020;0008,0030;0008,0050;0008,0080;0008,0090;0008,0201;0008,1030;0020,000d;0020,0010;0032,1032;0032,1060	0
26	2	20250211T152516	0
26	3		0
26	8	RestApi	0
26	11	172.22.0.1	0
26	13	orthanc	0
26	9	1.2.840.10008.1.2.4.51	0
26	14	2772	0
26	10	1.2.840.10008.5.1.4.1.1.2	0
26	1	119	0
27	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
27	2	20250211T152516	0
27	3		0
27	8	RestApi	0
27	11	172.22.0.1	0
27	13	orthanc	0
27	9	1.2.840.10008.1.2.4.51	0
27	14	2772	0
27	10	1.2.840.10008.5.1.4.1.1.2	0
27	1	120	0
28	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
28	2	20250211T152516	0
28	3		0
28	8	RestApi	0
28	11	172.22.0.1	0
28	13	orthanc	0
28	9	1.2.840.10008.1.2.4.51	0
28	14	2772	0
28	10	1.2.840.10008.5.1.4.1.1.2	0
28	1	13	0
29	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
29	2	20250211T152516	0
29	3		0
29	8	RestApi	0
29	11	172.22.0.1	0
29	13	orthanc	0
29	9	1.2.840.10008.1.2.4.51	0
29	14	2772	0
29	10	1.2.840.10008.5.1.4.1.1.2	0
29	1	121	0
30	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
30	2	20250211T152516	0
30	3		0
30	8	RestApi	0
30	11	172.22.0.1	0
30	13	orthanc	0
30	9	1.2.840.10008.1.2.4.51	0
30	14	2772	0
30	10	1.2.840.10008.5.1.4.1.1.2	0
30	1	122	0
31	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
31	2	20250211T152516	0
31	3		0
31	8	RestApi	0
31	11	172.22.0.1	0
31	13	orthanc	0
31	9	1.2.840.10008.1.2.4.51	0
31	14	2772	0
31	10	1.2.840.10008.5.1.4.1.1.2	0
31	1	123	0
32	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
32	2	20250211T152516	0
32	3		0
32	8	RestApi	0
32	11	172.22.0.1	0
32	13	orthanc	0
32	9	1.2.840.10008.1.2.4.51	0
32	14	2772	0
32	10	1.2.840.10008.5.1.4.1.1.2	0
32	1	124	0
33	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
33	2	20250211T152516	0
33	3		0
33	8	RestApi	0
33	11	172.22.0.1	0
33	13	orthanc	0
33	9	1.2.840.10008.1.2.4.51	0
33	14	2772	0
33	10	1.2.840.10008.5.1.4.1.1.2	0
33	1	125	0
34	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
34	2	20250211T152516	0
34	3		0
34	8	RestApi	0
34	11	172.22.0.1	0
34	13	orthanc	0
34	9	1.2.840.10008.1.2.4.51	0
34	14	2772	0
34	10	1.2.840.10008.5.1.4.1.1.2	0
34	1	126	0
35	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
35	2	20250211T152516	0
35	3		0
35	8	RestApi	0
35	11	172.22.0.1	0
35	13	orthanc	0
35	9	1.2.840.10008.1.2.4.51	0
35	14	2770	0
35	10	1.2.840.10008.5.1.4.1.1.2	0
35	1	127	0
36	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
36	2	20250211T152516	0
36	3		0
36	8	RestApi	0
36	11	172.22.0.1	0
36	13	orthanc	0
36	9	1.2.840.10008.1.2.4.51	0
36	14	2772	0
36	10	1.2.840.10008.5.1.4.1.1.2	0
36	1	128	0
37	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
522	3		0
523	2	20250211T154521	0
523	3		0
37	2	20250211T152516	0
37	3		0
37	8	RestApi	0
37	11	172.22.0.1	0
37	13	orthanc	0
37	9	1.2.840.10008.1.2.4.51	0
37	14	2772	0
37	10	1.2.840.10008.5.1.4.1.1.2	0
37	1	129	0
38	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
523	8	RestApi	0
523	11	172.22.0.1	0
523	13	orthanc	0
38	2	20250211T152516	0
38	3		0
38	8	RestApi	0
38	11	172.22.0.1	0
38	13	orthanc	0
38	9	1.2.840.10008.1.2.4.51	0
38	14	2772	0
38	10	1.2.840.10008.5.1.4.1.1.2	0
38	1	130	0
39	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
39	2	20250211T152516	0
39	3		0
39	8	RestApi	0
39	11	172.22.0.1	0
39	13	orthanc	0
39	9	1.2.840.10008.1.2.4.51	0
39	14	2770	0
39	10	1.2.840.10008.5.1.4.1.1.2	0
39	1	14	0
40	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
40	2	20250211T152516	0
40	3		0
40	8	RestApi	0
40	11	172.22.0.1	0
40	13	orthanc	0
40	9	1.2.840.10008.1.2.4.51	0
40	14	2772	0
40	10	1.2.840.10008.5.1.4.1.1.2	0
40	1	131	0
41	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
41	2	20250211T152516	0
41	3		0
41	8	RestApi	0
41	11	172.22.0.1	0
41	13	orthanc	0
41	9	1.2.840.10008.1.2.4.51	0
41	14	2774	0
41	10	1.2.840.10008.5.1.4.1.1.2	0
41	1	132	0
42	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
42	2	20250211T152516	0
42	3		0
42	8	RestApi	0
42	11	172.22.0.1	0
42	13	orthanc	0
42	9	1.2.840.10008.1.2.4.51	0
42	14	2774	0
42	10	1.2.840.10008.5.1.4.1.1.2	0
42	1	133	0
43	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
43	2	20250211T152516	0
43	3		0
43	8	RestApi	0
43	11	172.22.0.1	0
43	13	orthanc	0
43	9	1.2.840.10008.1.2.4.51	0
43	14	2772	0
43	10	1.2.840.10008.5.1.4.1.1.2	0
43	1	134	0
44	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
44	2	20250211T152516	0
44	3		0
44	8	RestApi	0
44	11	172.22.0.1	0
44	13	orthanc	0
44	9	1.2.840.10008.1.2.4.51	0
44	14	2772	0
44	10	1.2.840.10008.5.1.4.1.1.2	0
44	1	135	0
45	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
45	2	20250211T152516	0
45	3		0
45	8	RestApi	0
45	11	172.22.0.1	0
45	13	orthanc	0
45	9	1.2.840.10008.1.2.4.51	0
45	14	2772	0
45	10	1.2.840.10008.5.1.4.1.1.2	0
45	1	136	0
46	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
46	2	20250211T152516	0
46	3		0
46	8	RestApi	0
46	11	172.22.0.1	0
46	13	orthanc	0
46	9	1.2.840.10008.1.2.4.51	0
46	14	2772	0
46	10	1.2.840.10008.5.1.4.1.1.2	0
46	1	137	0
47	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
47	2	20250211T152516	0
47	3		0
47	8	RestApi	0
47	11	172.22.0.1	0
47	13	orthanc	0
47	9	1.2.840.10008.1.2.4.51	0
47	14	2772	0
47	10	1.2.840.10008.5.1.4.1.1.2	0
47	1	138	0
48	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
48	2	20250211T152516	0
48	3		0
48	8	RestApi	0
48	11	172.22.0.1	0
48	13	orthanc	0
48	9	1.2.840.10008.1.2.4.51	0
48	14	2772	0
48	10	1.2.840.10008.5.1.4.1.1.2	0
48	1	139	0
49	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
523	9	1.2.840.10008.1.2.4.70	0
523	14	2982	0
523	10	1.2.840.10008.5.1.4.1.1.2	0
49	2	20250211T152516	0
49	3		0
49	8	RestApi	0
49	11	172.22.0.1	0
49	13	orthanc	0
49	9	1.2.840.10008.1.2.4.51	0
49	14	2774	0
49	10	1.2.840.10008.5.1.4.1.1.2	0
49	1	140	0
50	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
523	1	1	0
524	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
50	2	20250211T152516	0
50	3		0
50	8	RestApi	0
50	11	172.22.0.1	0
50	13	orthanc	0
50	9	1.2.840.10008.1.2.4.51	0
50	14	2770	0
50	10	1.2.840.10008.5.1.4.1.1.2	0
50	1	15	0
51	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
51	2	20250211T152516	0
51	3		0
51	8	RestApi	0
51	11	172.22.0.1	0
51	13	orthanc	0
51	9	1.2.840.10008.1.2.4.51	0
51	14	2774	0
51	10	1.2.840.10008.5.1.4.1.1.2	0
51	1	141	0
52	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
52	2	20250211T152516	0
52	3		0
52	8	RestApi	0
52	11	172.22.0.1	0
52	13	orthanc	0
52	9	1.2.840.10008.1.2.4.51	0
52	14	2774	0
52	10	1.2.840.10008.5.1.4.1.1.2	0
52	1	142	0
53	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
53	2	20250211T152516	0
53	3		0
53	8	RestApi	0
53	11	172.22.0.1	0
53	13	orthanc	0
53	9	1.2.840.10008.1.2.4.51	0
53	14	2772	0
53	10	1.2.840.10008.5.1.4.1.1.2	0
53	1	143	0
54	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
54	2	20250211T152516	0
54	3		0
54	8	RestApi	0
54	11	172.22.0.1	0
54	13	orthanc	0
54	9	1.2.840.10008.1.2.4.51	0
54	14	2774	0
54	10	1.2.840.10008.5.1.4.1.1.2	0
54	1	144	0
55	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
55	2	20250211T152516	0
55	3		0
55	8	RestApi	0
55	11	172.22.0.1	0
55	13	orthanc	0
55	9	1.2.840.10008.1.2.4.51	0
55	14	2772	0
55	10	1.2.840.10008.5.1.4.1.1.2	0
55	1	145	0
56	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
56	2	20250211T152516	0
56	3		0
56	8	RestApi	0
56	11	172.22.0.1	0
56	13	orthanc	0
56	9	1.2.840.10008.1.2.4.51	0
56	14	2774	0
56	10	1.2.840.10008.5.1.4.1.1.2	0
56	1	146	0
57	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
57	2	20250211T152516	0
57	3		0
57	8	RestApi	0
57	11	172.22.0.1	0
57	13	orthanc	0
57	9	1.2.840.10008.1.2.4.51	0
57	14	2774	0
57	10	1.2.840.10008.5.1.4.1.1.2	0
57	1	147	0
58	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
58	2	20250211T152516	0
58	3		0
58	8	RestApi	0
58	11	172.22.0.1	0
58	13	orthanc	0
58	9	1.2.840.10008.1.2.4.51	0
58	14	2774	0
58	10	1.2.840.10008.5.1.4.1.1.2	0
58	1	148	0
59	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
59	2	20250211T152516	0
59	3		0
59	8	RestApi	0
59	11	172.22.0.1	0
59	13	orthanc	0
59	9	1.2.840.10008.1.2.4.51	0
59	14	2774	0
59	10	1.2.840.10008.5.1.4.1.1.2	0
59	1	149	0
60	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
522	7	20250211T154521	0
60	2	20250211T152516	0
60	3		0
60	8	RestApi	0
60	11	172.22.0.1	0
60	13	orthanc	0
60	9	1.2.840.10008.1.2.4.51	0
60	14	2774	0
60	10	1.2.840.10008.5.1.4.1.1.2	0
60	1	150	0
61	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
524	2	20250211T154521	0
524	3		0
524	8	RestApi	0
61	2	20250211T152516	0
61	3		0
61	8	RestApi	0
61	11	172.22.0.1	0
61	13	orthanc	0
61	9	1.2.840.10008.1.2.4.51	0
61	14	2770	0
61	10	1.2.840.10008.5.1.4.1.1.2	0
61	1	16	0
62	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
62	2	20250211T152516	0
62	3		0
62	8	RestApi	0
62	11	172.22.0.1	0
62	13	orthanc	0
62	9	1.2.840.10008.1.2.4.51	0
62	14	2774	0
62	10	1.2.840.10008.5.1.4.1.1.2	0
62	1	151	0
63	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
63	2	20250211T152516	0
63	3		0
63	8	RestApi	0
63	11	172.22.0.1	0
63	13	orthanc	0
63	9	1.2.840.10008.1.2.4.51	0
63	14	2774	0
63	10	1.2.840.10008.5.1.4.1.1.2	0
63	1	152	0
64	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
64	2	20250211T152516	0
64	3		0
64	8	RestApi	0
64	11	172.22.0.1	0
64	13	orthanc	0
64	9	1.2.840.10008.1.2.4.51	0
64	14	2772	0
64	10	1.2.840.10008.5.1.4.1.1.2	0
64	1	153	0
65	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
65	2	20250211T152516	0
65	3		0
65	8	RestApi	0
65	11	172.22.0.1	0
65	13	orthanc	0
65	9	1.2.840.10008.1.2.4.51	0
65	14	2774	0
65	10	1.2.840.10008.5.1.4.1.1.2	0
65	1	154	0
66	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
66	2	20250211T152516	0
66	3		0
66	8	RestApi	0
66	11	172.22.0.1	0
66	13	orthanc	0
66	9	1.2.840.10008.1.2.4.51	0
66	14	2774	0
66	10	1.2.840.10008.5.1.4.1.1.2	0
66	1	155	0
67	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
67	2	20250211T152516	0
67	3		0
67	8	RestApi	0
67	11	172.22.0.1	0
67	13	orthanc	0
67	9	1.2.840.10008.1.2.4.51	0
67	14	2772	0
67	10	1.2.840.10008.5.1.4.1.1.2	0
67	1	156	0
68	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
68	2	20250211T152516	0
68	3		0
68	8	RestApi	0
68	11	172.22.0.1	0
68	13	orthanc	0
68	9	1.2.840.10008.1.2.4.51	0
68	14	2772	0
68	10	1.2.840.10008.5.1.4.1.1.2	0
68	1	157	0
69	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
69	2	20250211T152516	0
69	3		0
69	8	RestApi	0
69	11	172.22.0.1	0
69	13	orthanc	0
69	9	1.2.840.10008.1.2.4.51	0
69	14	2772	0
69	10	1.2.840.10008.5.1.4.1.1.2	0
69	1	158	0
70	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
70	2	20250211T152516	0
70	3		0
70	8	RestApi	0
70	11	172.22.0.1	0
70	13	orthanc	0
70	9	1.2.840.10008.1.2.4.51	0
70	14	2772	0
70	10	1.2.840.10008.5.1.4.1.1.2	0
70	1	159	0
71	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
524	11	172.22.0.1	0
524	13	orthanc	0
524	9	1.2.840.10008.1.2.4.70	0
71	2	20250211T152516	0
71	3		0
71	8	RestApi	0
71	11	172.22.0.1	0
71	13	orthanc	0
71	9	1.2.840.10008.1.2.4.51	0
71	14	2772	0
71	10	1.2.840.10008.5.1.4.1.1.2	0
71	1	160	0
72	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
524	14	2982	0
72	2	20250211T152516	0
72	3		0
72	8	RestApi	0
72	11	172.22.0.1	0
72	13	orthanc	0
72	9	1.2.840.10008.1.2.4.51	0
72	14	2770	0
72	10	1.2.840.10008.5.1.4.1.1.2	0
72	1	17	0
73	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
73	2	20250211T152516	0
73	3		0
73	8	RestApi	0
73	11	172.22.0.1	0
73	13	orthanc	0
73	9	1.2.840.10008.1.2.4.51	0
73	14	2772	0
73	10	1.2.840.10008.5.1.4.1.1.2	0
73	1	161	0
74	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
74	2	20250211T152516	0
74	3		0
74	8	RestApi	0
74	11	172.22.0.1	0
74	13	orthanc	0
74	9	1.2.840.10008.1.2.4.51	0
74	14	2772	0
74	10	1.2.840.10008.5.1.4.1.1.2	0
74	1	162	0
75	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
75	2	20250211T152516	0
75	3		0
75	8	RestApi	0
75	11	172.22.0.1	0
75	13	orthanc	0
75	9	1.2.840.10008.1.2.4.51	0
75	14	2772	0
75	10	1.2.840.10008.5.1.4.1.1.2	0
75	1	163	0
76	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
76	2	20250211T152516	0
76	3		0
76	8	RestApi	0
76	11	172.22.0.1	0
76	13	orthanc	0
76	9	1.2.840.10008.1.2.4.51	0
76	14	2772	0
76	10	1.2.840.10008.5.1.4.1.1.2	0
76	1	164	0
77	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
77	2	20250211T152516	0
77	3		0
77	8	RestApi	0
77	11	172.22.0.1	0
77	13	orthanc	0
77	9	1.2.840.10008.1.2.4.51	0
77	14	2772	0
77	10	1.2.840.10008.5.1.4.1.1.2	0
77	1	165	0
78	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
78	2	20250211T152516	0
78	3		0
78	8	RestApi	0
78	11	172.22.0.1	0
78	13	orthanc	0
78	9	1.2.840.10008.1.2.4.51	0
78	14	2772	0
78	10	1.2.840.10008.5.1.4.1.1.2	0
78	1	166	0
79	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
79	2	20250211T152516	0
79	3		0
79	8	RestApi	0
79	11	172.22.0.1	0
79	13	orthanc	0
79	9	1.2.840.10008.1.2.4.51	0
79	14	2772	0
79	10	1.2.840.10008.5.1.4.1.1.2	0
79	1	167	0
80	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
80	2	20250211T152516	0
80	3		0
80	8	RestApi	0
80	11	172.22.0.1	0
80	13	orthanc	0
80	9	1.2.840.10008.1.2.4.51	0
80	14	2772	0
80	10	1.2.840.10008.5.1.4.1.1.2	0
80	1	168	0
81	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
81	2	20250211T152516	0
81	3		0
81	8	RestApi	0
81	11	172.22.0.1	0
81	13	orthanc	0
81	9	1.2.840.10008.1.2.4.51	0
81	14	2772	0
81	10	1.2.840.10008.5.1.4.1.1.2	0
81	1	169	0
82	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
524	10	1.2.840.10008.5.1.4.1.1.2	0
524	1	2	0
526	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
82	2	20250211T152516	0
82	3		0
82	8	RestApi	0
82	11	172.22.0.1	0
82	13	orthanc	0
82	9	1.2.840.10008.1.2.4.51	0
82	14	2772	0
82	10	1.2.840.10008.5.1.4.1.1.2	0
82	1	170	0
83	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
542	13	orthanc	0
83	2	20250211T152516	0
83	3		0
83	8	RestApi	0
83	11	172.22.0.1	0
83	13	orthanc	0
83	9	1.2.840.10008.1.2.4.51	0
83	14	2770	0
83	10	1.2.840.10008.5.1.4.1.1.2	0
83	1	18	0
84	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
84	2	20250211T152516	0
84	3		0
84	8	RestApi	0
84	11	172.22.0.1	0
84	13	orthanc	0
84	9	1.2.840.10008.1.2.4.51	0
84	14	2770	0
84	10	1.2.840.10008.5.1.4.1.1.2	0
84	1	171	0
85	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
85	2	20250211T152516	0
85	3		0
85	8	RestApi	0
85	11	172.22.0.1	0
85	13	orthanc	0
85	9	1.2.840.10008.1.2.4.51	0
85	14	2772	0
85	10	1.2.840.10008.5.1.4.1.1.2	0
85	1	172	0
86	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
86	2	20250211T152516	0
86	3		0
86	8	RestApi	0
86	11	172.22.0.1	0
86	13	orthanc	0
86	9	1.2.840.10008.1.2.4.51	0
86	14	2772	0
86	10	1.2.840.10008.5.1.4.1.1.2	0
86	1	173	0
87	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
87	2	20250211T152516	0
87	3		0
87	8	RestApi	0
87	11	172.22.0.1	0
87	13	orthanc	0
87	9	1.2.840.10008.1.2.4.51	0
87	14	2772	0
87	10	1.2.840.10008.5.1.4.1.1.2	0
87	1	174	0
88	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
88	2	20250211T152516	0
88	3		0
88	8	RestApi	0
88	11	172.22.0.1	0
88	13	orthanc	0
88	9	1.2.840.10008.1.2.4.51	0
88	14	2772	0
88	10	1.2.840.10008.5.1.4.1.1.2	0
88	1	175	0
89	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
89	2	20250211T152516	0
89	3		0
89	8	RestApi	0
89	11	172.22.0.1	0
89	13	orthanc	0
89	9	1.2.840.10008.1.2.4.51	0
89	14	2772	0
89	10	1.2.840.10008.5.1.4.1.1.2	0
89	1	176	0
90	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
90	2	20250211T152516	0
90	3		0
90	8	RestApi	0
90	11	172.22.0.1	0
90	13	orthanc	0
90	9	1.2.840.10008.1.2.4.51	0
90	14	2772	0
90	10	1.2.840.10008.5.1.4.1.1.2	0
90	1	177	0
91	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
91	2	20250211T152516	0
91	3		0
91	8	RestApi	0
91	11	172.22.0.1	0
91	13	orthanc	0
91	9	1.2.840.10008.1.2.4.51	0
91	14	2772	0
91	10	1.2.840.10008.5.1.4.1.1.2	0
91	1	178	0
92	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
92	2	20250211T152516	0
92	3		0
92	8	RestApi	0
92	11	172.22.0.1	0
92	13	orthanc	0
92	9	1.2.840.10008.1.2.4.51	0
92	14	2772	0
92	10	1.2.840.10008.5.1.4.1.1.2	0
92	1	179	0
93	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
93	2	20250211T152516	0
93	3		0
93	8	RestApi	0
93	11	172.22.0.1	0
93	13	orthanc	0
93	9	1.2.840.10008.1.2.4.51	0
93	14	2772	0
93	10	1.2.840.10008.5.1.4.1.1.2	0
93	1	180	0
94	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
525	15	0008,0021;0008,0031;0008,0060;0008,0070;0008,0201;0008,1010;0008,103e;0008,1070;0018,0010;0018,0015;0018,0024;0018,1030;0018,1090;0018,1400;0020,000e;0020,0011;0020,0037;0020,0105;0020,1002;0040,0244;0040,0245;0040,0254;0040,0275;0054,0081;0054,0101;0054,1000	0
94	2	20250211T152516	0
94	3		0
94	8	RestApi	0
94	11	172.22.0.1	0
94	13	orthanc	0
94	9	1.2.840.10008.1.2.4.51	0
94	14	2770	0
94	10	1.2.840.10008.5.1.4.1.1.2	0
94	1	19	0
95	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
95	2	20250211T152516	0
95	3		0
95	8	RestApi	0
95	11	172.22.0.1	0
95	13	orthanc	0
95	9	1.2.840.10008.1.2.4.51	0
95	14	2772	0
95	10	1.2.840.10008.5.1.4.1.1.2	0
95	1	181	0
96	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
96	2	20250211T152516	0
96	3		0
96	8	RestApi	0
96	11	172.22.0.1	0
96	13	orthanc	0
96	9	1.2.840.10008.1.2.4.51	0
96	14	2772	0
96	10	1.2.840.10008.5.1.4.1.1.2	0
96	1	182	0
97	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
97	2	20250211T152516	0
97	3		0
97	8	RestApi	0
97	11	172.22.0.1	0
97	13	orthanc	0
97	9	1.2.840.10008.1.2.4.51	0
97	14	2770	0
97	10	1.2.840.10008.5.1.4.1.1.2	0
97	1	183	0
98	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
98	2	20250211T152516	0
98	3		0
98	8	RestApi	0
98	11	172.22.0.1	0
98	13	orthanc	0
98	9	1.2.840.10008.1.2.4.51	0
98	14	2772	0
98	10	1.2.840.10008.5.1.4.1.1.2	0
98	1	184	0
99	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
99	2	20250211T152516	0
99	3		0
99	8	RestApi	0
99	11	172.22.0.1	0
99	13	orthanc	0
99	9	1.2.840.10008.1.2.4.51	0
99	14	2772	0
99	10	1.2.840.10008.5.1.4.1.1.2	0
99	1	185	0
100	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
100	2	20250211T152516	0
100	3		0
100	8	RestApi	0
100	11	172.22.0.1	0
100	13	orthanc	0
100	9	1.2.840.10008.1.2.4.51	0
100	14	2772	0
100	10	1.2.840.10008.5.1.4.1.1.2	0
100	1	186	0
101	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
101	2	20250211T152516	0
101	3		0
101	8	RestApi	0
101	11	172.22.0.1	0
101	13	orthanc	0
101	9	1.2.840.10008.1.2.4.51	0
101	14	2772	0
101	10	1.2.840.10008.5.1.4.1.1.2	0
101	1	187	0
102	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
102	2	20250211T152516	0
102	3		0
102	8	RestApi	0
102	11	172.22.0.1	0
102	13	orthanc	0
102	9	1.2.840.10008.1.2.4.51	0
102	14	2772	0
102	10	1.2.840.10008.5.1.4.1.1.2	0
102	1	188	0
103	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
103	2	20250211T152516	0
103	3		0
103	8	RestApi	0
103	11	172.22.0.1	0
103	13	orthanc	0
103	9	1.2.840.10008.1.2.4.51	0
103	14	2772	0
103	10	1.2.840.10008.5.1.4.1.1.2	0
103	1	189	0
104	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
104	2	20250211T152516	0
104	3		0
104	8	RestApi	0
104	11	172.22.0.1	0
104	13	orthanc	0
104	9	1.2.840.10008.1.2.4.51	0
104	14	2772	0
104	10	1.2.840.10008.5.1.4.1.1.2	0
104	1	190	0
105	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
525	3		0
105	2	20250211T152516	0
105	3		0
105	8	RestApi	0
105	11	172.22.0.1	0
105	13	orthanc	0
105	9	1.2.840.10008.1.2.4.51	0
105	14	2770	0
105	10	1.2.840.10008.5.1.4.1.1.2	0
105	1	20	0
106	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
526	2	20250211T154521	0
106	2	20250211T152516	0
106	3		0
106	8	RestApi	0
106	11	172.22.0.1	0
106	13	orthanc	0
106	9	1.2.840.10008.1.2.4.51	0
106	14	2772	0
106	10	1.2.840.10008.5.1.4.1.1.2	0
106	1	191	0
107	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
107	2	20250211T152516	0
107	3		0
107	8	RestApi	0
107	11	172.22.0.1	0
107	13	orthanc	0
107	9	1.2.840.10008.1.2.4.51	0
107	14	2772	0
107	10	1.2.840.10008.5.1.4.1.1.2	0
107	1	192	0
108	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
108	2	20250211T152516	0
108	3		0
108	8	RestApi	0
108	11	172.22.0.1	0
108	13	orthanc	0
108	9	1.2.840.10008.1.2.4.51	0
108	14	2772	0
108	10	1.2.840.10008.5.1.4.1.1.2	0
108	1	193	0
109	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
109	2	20250211T152516	0
109	3		0
109	8	RestApi	0
109	11	172.22.0.1	0
109	13	orthanc	0
109	9	1.2.840.10008.1.2.4.51	0
109	14	2772	0
109	10	1.2.840.10008.5.1.4.1.1.2	0
109	1	194	0
110	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
110	2	20250211T152516	0
110	3		0
110	8	RestApi	0
110	11	172.22.0.1	0
110	13	orthanc	0
110	9	1.2.840.10008.1.2.4.51	0
110	14	2772	0
110	10	1.2.840.10008.5.1.4.1.1.2	0
110	1	195	0
111	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
111	2	20250211T152516	0
111	3		0
111	8	RestApi	0
111	11	172.22.0.1	0
111	13	orthanc	0
111	9	1.2.840.10008.1.2.4.51	0
111	14	2772	0
111	10	1.2.840.10008.5.1.4.1.1.2	0
111	1	196	0
112	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
112	2	20250211T152516	0
112	3		0
112	8	RestApi	0
112	11	172.22.0.1	0
112	13	orthanc	0
112	9	1.2.840.10008.1.2.4.51	0
112	14	2772	0
112	10	1.2.840.10008.5.1.4.1.1.2	0
112	1	197	0
113	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
113	2	20250211T152516	0
113	3		0
113	8	RestApi	0
113	11	172.22.0.1	0
113	13	orthanc	0
113	9	1.2.840.10008.1.2.4.51	0
113	14	2772	0
113	10	1.2.840.10008.5.1.4.1.1.2	0
113	1	198	0
114	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
114	2	20250211T152516	0
114	3		0
114	8	RestApi	0
114	11	172.22.0.1	0
114	13	orthanc	0
114	9	1.2.840.10008.1.2.4.51	0
114	14	2772	0
114	10	1.2.840.10008.5.1.4.1.1.2	0
114	1	199	0
115	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
115	2	20250211T152516	0
115	3		0
115	8	RestApi	0
115	11	172.22.0.1	0
115	13	orthanc	0
115	9	1.2.840.10008.1.2.4.51	0
115	14	2772	0
115	10	1.2.840.10008.5.1.4.1.1.2	0
115	1	200	0
116	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
526	3		0
526	8	RestApi	0
526	11	172.22.0.1	0
116	2	20250211T152516	0
116	3		0
116	8	RestApi	0
116	11	172.22.0.1	0
116	13	orthanc	0
116	9	1.2.840.10008.1.2.4.51	0
116	14	2768	0
116	10	1.2.840.10008.5.1.4.1.1.2	0
116	1	3	0
117	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
526	13	orthanc	0
526	9	1.2.840.10008.1.2.4.70	0
526	14	3196	0
117	2	20250211T152516	0
117	3		0
117	8	RestApi	0
117	11	172.22.0.1	0
117	13	orthanc	0
117	9	1.2.840.10008.1.2.4.51	0
117	14	2772	0
117	10	1.2.840.10008.5.1.4.1.1.2	0
117	1	21	0
118	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
542	9	1.2.840.10008.1.2.4.70	0
118	2	20250211T152516	0
118	3		0
118	8	RestApi	0
118	11	172.22.0.1	0
118	13	orthanc	0
118	9	1.2.840.10008.1.2.4.51	0
118	14	2772	0
118	10	1.2.840.10008.5.1.4.1.1.2	0
118	1	201	0
119	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
119	2	20250211T152516	0
119	3		0
119	8	RestApi	0
119	11	172.22.0.1	0
119	13	orthanc	0
119	9	1.2.840.10008.1.2.4.51	0
119	14	2772	0
119	10	1.2.840.10008.5.1.4.1.1.2	0
119	1	202	0
120	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
120	2	20250211T152516	0
120	3		0
120	8	RestApi	0
120	11	172.22.0.1	0
120	13	orthanc	0
120	9	1.2.840.10008.1.2.4.51	0
120	14	2772	0
120	10	1.2.840.10008.5.1.4.1.1.2	0
120	1	203	0
121	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
121	2	20250211T152516	0
121	3		0
121	8	RestApi	0
121	11	172.22.0.1	0
121	13	orthanc	0
121	9	1.2.840.10008.1.2.4.51	0
121	14	2772	0
121	10	1.2.840.10008.5.1.4.1.1.2	0
121	1	204	0
122	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
122	2	20250211T152516	0
122	3		0
122	8	RestApi	0
122	11	172.22.0.1	0
122	13	orthanc	0
122	9	1.2.840.10008.1.2.4.51	0
122	14	2772	0
122	10	1.2.840.10008.5.1.4.1.1.2	0
122	1	205	0
123	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
123	2	20250211T152516	0
123	3		0
123	8	RestApi	0
123	11	172.22.0.1	0
123	13	orthanc	0
123	9	1.2.840.10008.1.2.4.51	0
123	14	2772	0
123	10	1.2.840.10008.5.1.4.1.1.2	0
123	1	206	0
124	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
124	2	20250211T152516	0
124	3		0
124	8	RestApi	0
124	11	172.22.0.1	0
124	13	orthanc	0
124	9	1.2.840.10008.1.2.4.51	0
124	14	2772	0
124	10	1.2.840.10008.5.1.4.1.1.2	0
124	1	207	0
125	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
125	2	20250211T152516	0
125	3		0
125	8	RestApi	0
125	11	172.22.0.1	0
125	13	orthanc	0
125	9	1.2.840.10008.1.2.4.51	0
125	14	2772	0
125	10	1.2.840.10008.5.1.4.1.1.2	0
125	1	208	0
126	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
126	2	20250211T152516	0
126	3		0
126	8	RestApi	0
126	11	172.22.0.1	0
126	13	orthanc	0
126	9	1.2.840.10008.1.2.4.51	0
126	14	2772	0
126	10	1.2.840.10008.5.1.4.1.1.2	0
126	1	209	0
127	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
127	2	20250211T152516	0
127	3		0
127	8	RestApi	0
127	11	172.22.0.1	0
127	13	orthanc	0
127	9	1.2.840.10008.1.2.4.51	0
127	14	2772	0
127	10	1.2.840.10008.5.1.4.1.1.2	0
127	1	210	0
128	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
526	10	1.2.840.10008.5.1.4.1.1.2	0
526	1	9	0
528	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
128	2	20250211T152516	0
128	3		0
128	8	RestApi	0
128	11	172.22.0.1	0
128	13	orthanc	0
128	9	1.2.840.10008.1.2.4.51	0
128	14	2770	0
128	10	1.2.840.10008.5.1.4.1.1.2	0
128	1	22	0
129	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
542	14	2630	0
129	2	20250211T152516	0
129	3		0
129	8	RestApi	0
129	11	172.22.0.1	0
129	13	orthanc	0
129	9	1.2.840.10008.1.2.4.51	0
129	14	2772	0
129	10	1.2.840.10008.5.1.4.1.1.2	0
129	1	211	0
130	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
130	2	20250211T152516	0
130	3		0
130	8	RestApi	0
130	11	172.22.0.1	0
130	13	orthanc	0
130	9	1.2.840.10008.1.2.4.51	0
130	14	2772	0
130	10	1.2.840.10008.5.1.4.1.1.2	0
130	1	212	0
131	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
131	2	20250211T152516	0
131	3		0
131	8	RestApi	0
131	11	172.22.0.1	0
131	13	orthanc	0
131	9	1.2.840.10008.1.2.4.51	0
131	14	2772	0
131	10	1.2.840.10008.5.1.4.1.1.2	0
131	1	213	0
132	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
132	2	20250211T152516	0
132	3		0
132	8	RestApi	0
132	11	172.22.0.1	0
132	13	orthanc	0
132	9	1.2.840.10008.1.2.4.51	0
132	14	2772	0
132	10	1.2.840.10008.5.1.4.1.1.2	0
132	1	214	0
133	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
133	2	20250211T152516	0
133	3		0
133	8	RestApi	0
133	11	172.22.0.1	0
133	13	orthanc	0
133	9	1.2.840.10008.1.2.4.51	0
133	14	2772	0
133	10	1.2.840.10008.5.1.4.1.1.2	0
133	1	215	0
134	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
134	2	20250211T152516	0
134	3		0
134	8	RestApi	0
134	11	172.22.0.1	0
134	13	orthanc	0
134	9	1.2.840.10008.1.2.4.51	0
134	14	2772	0
134	10	1.2.840.10008.5.1.4.1.1.2	0
134	1	216	0
135	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
135	2	20250211T152516	0
135	3		0
135	8	RestApi	0
135	11	172.22.0.1	0
135	13	orthanc	0
135	9	1.2.840.10008.1.2.4.51	0
135	14	2772	0
135	10	1.2.840.10008.5.1.4.1.1.2	0
135	1	217	0
136	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
136	2	20250211T152516	0
136	3		0
136	8	RestApi	0
136	11	172.22.0.1	0
136	13	orthanc	0
136	9	1.2.840.10008.1.2.4.51	0
136	14	2772	0
136	10	1.2.840.10008.5.1.4.1.1.2	0
136	1	218	0
137	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
137	2	20250211T152516	0
137	3		0
137	8	RestApi	0
137	11	172.22.0.1	0
137	13	orthanc	0
137	9	1.2.840.10008.1.2.4.51	0
137	14	2772	0
137	10	1.2.840.10008.5.1.4.1.1.2	0
137	1	219	0
138	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
138	2	20250211T152516	0
138	3		0
138	8	RestApi	0
138	11	172.22.0.1	0
138	13	orthanc	0
138	9	1.2.840.10008.1.2.4.51	0
138	14	2772	0
138	10	1.2.840.10008.5.1.4.1.1.2	0
138	1	220	0
139	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
542	10	1.2.840.10008.5.1.4.1.1.2	0
542	1	10	0
543	9	1.2.840.10008.1.2.4.70	0
139	2	20250211T152516	0
139	3		0
139	8	RestApi	0
139	11	172.22.0.1	0
139	13	orthanc	0
139	9	1.2.840.10008.1.2.4.51	0
139	14	2770	0
139	10	1.2.840.10008.5.1.4.1.1.2	0
139	1	23	0
140	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
140	2	20250211T152516	0
140	3		0
140	8	RestApi	0
140	11	172.22.0.1	0
140	13	orthanc	0
140	9	1.2.840.10008.1.2.4.51	0
140	14	2772	0
140	10	1.2.840.10008.5.1.4.1.1.2	0
140	1	221	0
141	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
141	2	20250211T152516	0
141	3		0
141	8	RestApi	0
141	11	172.22.0.1	0
141	13	orthanc	0
141	9	1.2.840.10008.1.2.4.51	0
141	14	2772	0
141	10	1.2.840.10008.5.1.4.1.1.2	0
141	1	222	0
142	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
142	2	20250211T152516	0
142	3		0
142	8	RestApi	0
142	11	172.22.0.1	0
142	13	orthanc	0
142	9	1.2.840.10008.1.2.4.51	0
142	14	2772	0
142	10	1.2.840.10008.5.1.4.1.1.2	0
142	1	223	0
143	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
143	2	20250211T152516	0
143	3		0
143	8	RestApi	0
143	11	172.22.0.1	0
143	13	orthanc	0
143	9	1.2.840.10008.1.2.4.51	0
143	14	2772	0
143	10	1.2.840.10008.5.1.4.1.1.2	0
143	1	224	0
144	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
144	2	20250211T152516	0
144	3		0
144	8	RestApi	0
144	11	172.22.0.1	0
144	13	orthanc	0
144	9	1.2.840.10008.1.2.4.51	0
144	14	2772	0
144	10	1.2.840.10008.5.1.4.1.1.2	0
144	1	225	0
145	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
145	2	20250211T152516	0
145	3		0
145	8	RestApi	0
145	11	172.22.0.1	0
145	13	orthanc	0
145	9	1.2.840.10008.1.2.4.51	0
145	14	2772	0
145	10	1.2.840.10008.5.1.4.1.1.2	0
145	1	226	0
146	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
146	2	20250211T152516	0
146	3		0
146	8	RestApi	0
146	11	172.22.0.1	0
146	13	orthanc	0
146	9	1.2.840.10008.1.2.4.51	0
146	14	2772	0
146	10	1.2.840.10008.5.1.4.1.1.2	0
146	1	227	0
147	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
147	2	20250211T152516	0
147	3		0
147	8	RestApi	0
147	11	172.22.0.1	0
147	13	orthanc	0
147	9	1.2.840.10008.1.2.4.51	0
147	14	2772	0
147	10	1.2.840.10008.5.1.4.1.1.2	0
147	1	228	0
148	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
148	2	20250211T152516	0
148	3		0
148	8	RestApi	0
148	11	172.22.0.1	0
148	13	orthanc	0
148	9	1.2.840.10008.1.2.4.51	0
148	14	2772	0
148	10	1.2.840.10008.5.1.4.1.1.2	0
148	1	229	0
149	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
149	2	20250211T152516	0
149	3		0
149	8	RestApi	0
149	11	172.22.0.1	0
149	13	orthanc	0
149	9	1.2.840.10008.1.2.4.51	0
149	14	2772	0
149	10	1.2.840.10008.5.1.4.1.1.2	0
149	1	230	0
150	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
527	15	0008,0021;0008,0031;0008,0060;0008,0070;0008,0201;0008,1010;0008,103e;0008,1070;0018,0010;0018,0015;0018,0024;0018,1030;0018,1090;0018,1400;0020,000e;0020,0011;0020,0037;0020,0105;0020,1002;0040,0244;0040,0245;0040,0254;0040,0275;0054,0081;0054,0101;0054,1000	0
150	2	20250211T152516	0
150	3		0
150	8	RestApi	0
150	11	172.22.0.1	0
150	13	orthanc	0
150	9	1.2.840.10008.1.2.4.51	0
150	14	2770	0
150	10	1.2.840.10008.5.1.4.1.1.2	0
150	1	24	0
151	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
151	2	20250211T152516	0
151	3		0
151	8	RestApi	0
151	11	172.22.0.1	0
151	13	orthanc	0
151	9	1.2.840.10008.1.2.4.51	0
151	14	2772	0
151	10	1.2.840.10008.5.1.4.1.1.2	0
151	1	231	0
152	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
152	2	20250211T152516	0
152	3		0
152	8	RestApi	0
152	11	172.22.0.1	0
152	13	orthanc	0
152	9	1.2.840.10008.1.2.4.51	0
152	14	2772	0
152	10	1.2.840.10008.5.1.4.1.1.2	0
152	1	232	0
153	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
153	2	20250211T152516	0
153	3		0
153	8	RestApi	0
153	11	172.22.0.1	0
153	13	orthanc	0
153	9	1.2.840.10008.1.2.4.51	0
153	14	2772	0
153	10	1.2.840.10008.5.1.4.1.1.2	0
153	1	233	0
154	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
154	2	20250211T152516	0
154	3		0
154	8	RestApi	0
154	11	172.22.0.1	0
154	13	orthanc	0
154	9	1.2.840.10008.1.2.4.51	0
154	14	2772	0
154	10	1.2.840.10008.5.1.4.1.1.2	0
154	1	234	0
155	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
155	2	20250211T152516	0
155	3		0
155	8	RestApi	0
155	11	172.22.0.1	0
155	13	orthanc	0
155	9	1.2.840.10008.1.2.4.51	0
155	14	2772	0
155	10	1.2.840.10008.5.1.4.1.1.2	0
155	1	235	0
156	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
156	2	20250211T152516	0
156	3		0
156	8	RestApi	0
156	11	172.22.0.1	0
156	13	orthanc	0
156	9	1.2.840.10008.1.2.4.51	0
156	14	2772	0
156	10	1.2.840.10008.5.1.4.1.1.2	0
156	1	236	0
157	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
157	2	20250211T152516	0
157	3		0
157	8	RestApi	0
157	11	172.22.0.1	0
157	13	orthanc	0
157	9	1.2.840.10008.1.2.4.51	0
157	14	2772	0
157	10	1.2.840.10008.5.1.4.1.1.2	0
157	1	237	0
158	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
158	2	20250211T152516	0
158	3		0
158	8	RestApi	0
158	11	172.22.0.1	0
158	13	orthanc	0
158	9	1.2.840.10008.1.2.4.51	0
158	14	2772	0
158	10	1.2.840.10008.5.1.4.1.1.2	0
158	1	238	0
159	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
159	2	20250211T152516	0
159	3		0
159	8	RestApi	0
159	11	172.22.0.1	0
159	13	orthanc	0
159	9	1.2.840.10008.1.2.4.51	0
159	14	2772	0
159	10	1.2.840.10008.5.1.4.1.1.2	0
159	1	239	0
160	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
160	2	20250211T152516	0
160	3		0
160	8	RestApi	0
160	11	172.22.0.1	0
160	13	orthanc	0
160	9	1.2.840.10008.1.2.4.51	0
160	14	2772	0
160	10	1.2.840.10008.5.1.4.1.1.2	0
160	1	240	0
161	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
161	2	20250211T152516	0
161	3		0
161	8	RestApi	0
161	11	172.22.0.1	0
161	13	orthanc	0
161	9	1.2.840.10008.1.2.4.51	0
161	14	2770	0
161	10	1.2.840.10008.5.1.4.1.1.2	0
161	1	25	0
162	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
527	3		0
162	2	20250211T152516	0
162	3		0
162	8	RestApi	0
162	11	172.22.0.1	0
162	13	orthanc	0
162	9	1.2.840.10008.1.2.4.51	0
162	14	2772	0
162	10	1.2.840.10008.5.1.4.1.1.2	0
162	1	241	0
163	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
528	2	20250211T154521	0
528	3		0
528	8	RestApi	0
163	2	20250211T152516	0
163	3		0
163	8	RestApi	0
163	11	172.22.0.1	0
163	13	orthanc	0
163	9	1.2.840.10008.1.2.4.51	0
163	14	2772	0
163	10	1.2.840.10008.5.1.4.1.1.2	0
163	1	242	0
164	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
528	11	172.22.0.1	0
164	2	20250211T152516	0
164	3		0
164	8	RestApi	0
164	11	172.22.0.1	0
164	13	orthanc	0
164	9	1.2.840.10008.1.2.4.51	0
164	14	2772	0
164	10	1.2.840.10008.5.1.4.1.1.2	0
164	1	243	0
165	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
165	2	20250211T152516	0
165	3		0
165	8	RestApi	0
165	11	172.22.0.1	0
165	13	orthanc	0
165	9	1.2.840.10008.1.2.4.51	0
165	14	2772	0
165	10	1.2.840.10008.5.1.4.1.1.2	0
165	1	244	0
166	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
166	2	20250211T152516	0
166	3		0
166	8	RestApi	0
166	11	172.22.0.1	0
166	13	orthanc	0
166	9	1.2.840.10008.1.2.4.51	0
166	14	2772	0
166	10	1.2.840.10008.5.1.4.1.1.2	0
166	1	245	0
167	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
167	2	20250211T152516	0
167	3		0
167	8	RestApi	0
167	11	172.22.0.1	0
167	13	orthanc	0
167	9	1.2.840.10008.1.2.4.51	0
167	14	2772	0
167	10	1.2.840.10008.5.1.4.1.1.2	0
167	1	246	0
168	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
168	2	20250211T152516	0
168	3		0
168	8	RestApi	0
168	11	172.22.0.1	0
168	13	orthanc	0
168	9	1.2.840.10008.1.2.4.51	0
168	14	2772	0
168	10	1.2.840.10008.5.1.4.1.1.2	0
168	1	247	0
169	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
169	2	20250211T152516	0
169	3		0
169	8	RestApi	0
169	11	172.22.0.1	0
169	13	orthanc	0
169	9	1.2.840.10008.1.2.4.51	0
169	14	2772	0
169	10	1.2.840.10008.5.1.4.1.1.2	0
169	1	248	0
170	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
170	2	20250211T152517	0
170	3		0
170	8	RestApi	0
170	11	172.22.0.1	0
170	13	orthanc	0
170	9	1.2.840.10008.1.2.4.51	0
170	14	2772	0
170	10	1.2.840.10008.5.1.4.1.1.2	0
170	1	249	0
171	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
171	2	20250211T152517	0
171	3		0
171	8	RestApi	0
171	11	172.22.0.1	0
171	13	orthanc	0
171	9	1.2.840.10008.1.2.4.51	0
171	14	2772	0
171	10	1.2.840.10008.5.1.4.1.1.2	0
171	1	250	0
172	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
172	2	20250211T152517	0
172	3		0
172	8	RestApi	0
172	11	172.22.0.1	0
172	13	orthanc	0
172	9	1.2.840.10008.1.2.4.51	0
172	14	2770	0
172	10	1.2.840.10008.5.1.4.1.1.2	0
172	1	26	0
173	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
528	13	orthanc	0
528	9	1.2.840.10008.1.2.4.70	0
528	14	3200	0
173	2	20250211T152517	0
173	3		0
173	8	RestApi	0
173	11	172.22.0.1	0
173	13	orthanc	0
173	9	1.2.840.10008.1.2.4.51	0
173	14	2772	0
173	10	1.2.840.10008.5.1.4.1.1.2	0
173	1	251	0
174	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
174	2	20250211T152517	0
174	3		0
174	8	RestApi	0
174	11	172.22.0.1	0
174	13	orthanc	0
174	9	1.2.840.10008.1.2.4.51	0
174	14	2772	0
174	10	1.2.840.10008.5.1.4.1.1.2	0
174	1	252	0
175	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
175	2	20250211T152517	0
175	3		0
175	8	RestApi	0
175	11	172.22.0.1	0
175	13	orthanc	0
175	9	1.2.840.10008.1.2.4.51	0
175	14	2772	0
175	10	1.2.840.10008.5.1.4.1.1.2	0
175	1	253	0
176	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
176	2	20250211T152517	0
176	3		0
176	8	RestApi	0
176	11	172.22.0.1	0
176	13	orthanc	0
176	9	1.2.840.10008.1.2.4.51	0
176	14	2772	0
176	10	1.2.840.10008.5.1.4.1.1.2	0
176	1	254	0
177	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
177	2	20250211T152517	0
177	3		0
177	8	RestApi	0
177	11	172.22.0.1	0
177	13	orthanc	0
177	9	1.2.840.10008.1.2.4.51	0
177	14	2772	0
177	10	1.2.840.10008.5.1.4.1.1.2	0
177	1	255	0
178	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
178	2	20250211T152517	0
178	3		0
178	8	RestApi	0
178	11	172.22.0.1	0
178	13	orthanc	0
178	9	1.2.840.10008.1.2.4.51	0
178	14	2772	0
178	10	1.2.840.10008.5.1.4.1.1.2	0
178	1	256	0
179	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
179	2	20250211T152517	0
179	3		0
179	8	RestApi	0
179	11	172.22.0.1	0
179	13	orthanc	0
179	9	1.2.840.10008.1.2.4.51	0
179	14	2772	0
179	10	1.2.840.10008.5.1.4.1.1.2	0
179	1	257	0
180	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
180	2	20250211T152517	0
180	3		0
180	8	RestApi	0
180	11	172.22.0.1	0
180	13	orthanc	0
180	9	1.2.840.10008.1.2.4.51	0
180	14	2772	0
180	10	1.2.840.10008.5.1.4.1.1.2	0
180	1	258	0
181	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
181	2	20250211T152517	0
181	3		0
181	8	RestApi	0
181	11	172.22.0.1	0
181	13	orthanc	0
181	9	1.2.840.10008.1.2.4.51	0
181	14	2772	0
181	10	1.2.840.10008.5.1.4.1.1.2	0
181	1	259	0
182	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
182	2	20250211T152517	0
182	3		0
182	8	RestApi	0
182	11	172.22.0.1	0
182	13	orthanc	0
182	9	1.2.840.10008.1.2.4.51	0
182	14	2772	0
182	10	1.2.840.10008.5.1.4.1.1.2	0
182	1	260	0
183	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
183	2	20250211T152517	0
183	3		0
183	8	RestApi	0
183	11	172.22.0.1	0
183	13	orthanc	0
183	9	1.2.840.10008.1.2.4.51	0
183	14	2770	0
183	10	1.2.840.10008.5.1.4.1.1.2	0
183	1	27	0
184	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
528	10	1.2.840.10008.5.1.4.1.1.2	0
528	1	65	0
529	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
184	2	20250211T152517	0
184	3		0
184	8	RestApi	0
184	11	172.22.0.1	0
184	13	orthanc	0
184	9	1.2.840.10008.1.2.4.51	0
184	14	2772	0
184	10	1.2.840.10008.5.1.4.1.1.2	0
184	1	261	0
185	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
185	2	20250211T152517	0
185	3		0
185	8	RestApi	0
185	11	172.22.0.1	0
185	13	orthanc	0
185	9	1.2.840.10008.1.2.4.51	0
185	14	2772	0
185	10	1.2.840.10008.5.1.4.1.1.2	0
185	1	262	0
186	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
186	2	20250211T152517	0
186	3		0
186	8	RestApi	0
186	11	172.22.0.1	0
186	13	orthanc	0
186	9	1.2.840.10008.1.2.4.51	0
186	14	2772	0
186	10	1.2.840.10008.5.1.4.1.1.2	0
186	1	263	0
187	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
187	2	20250211T152517	0
187	3		0
187	8	RestApi	0
187	11	172.22.0.1	0
187	13	orthanc	0
187	9	1.2.840.10008.1.2.4.51	0
187	14	2772	0
187	10	1.2.840.10008.5.1.4.1.1.2	0
187	1	264	0
188	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
188	2	20250211T152517	0
188	3		0
188	8	RestApi	0
188	11	172.22.0.1	0
188	13	orthanc	0
188	9	1.2.840.10008.1.2.4.51	0
188	14	2772	0
188	10	1.2.840.10008.5.1.4.1.1.2	0
188	1	265	0
189	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
189	2	20250211T152517	0
189	3		0
189	8	RestApi	0
189	11	172.22.0.1	0
189	13	orthanc	0
189	9	1.2.840.10008.1.2.4.51	0
189	14	2772	0
189	10	1.2.840.10008.5.1.4.1.1.2	0
189	1	266	0
190	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
190	2	20250211T152517	0
190	3		0
190	8	RestApi	0
190	11	172.22.0.1	0
190	13	orthanc	0
190	9	1.2.840.10008.1.2.4.51	0
190	14	2772	0
190	10	1.2.840.10008.5.1.4.1.1.2	0
190	1	267	0
191	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
191	2	20250211T152517	0
191	3		0
191	8	RestApi	0
191	11	172.22.0.1	0
191	13	orthanc	0
191	9	1.2.840.10008.1.2.4.51	0
191	14	2772	0
191	10	1.2.840.10008.5.1.4.1.1.2	0
191	1	268	0
192	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
192	2	20250211T152517	0
192	3		0
192	8	RestApi	0
192	11	172.22.0.1	0
192	13	orthanc	0
192	9	1.2.840.10008.1.2.4.51	0
192	14	2772	0
192	10	1.2.840.10008.5.1.4.1.1.2	0
192	1	269	0
193	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
193	2	20250211T152517	0
193	3		0
193	8	RestApi	0
193	11	172.22.0.1	0
193	13	orthanc	0
193	9	1.2.840.10008.1.2.4.51	0
193	14	2772	0
193	10	1.2.840.10008.5.1.4.1.1.2	0
193	1	270	0
194	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
194	2	20250211T152517	0
194	3		0
194	8	RestApi	0
194	11	172.22.0.1	0
194	13	orthanc	0
194	9	1.2.840.10008.1.2.4.51	0
194	14	2772	0
194	10	1.2.840.10008.5.1.4.1.1.2	0
194	1	28	0
195	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
195	2	20250211T152517	0
195	3		0
195	8	RestApi	0
195	11	172.22.0.1	0
195	13	orthanc	0
195	9	1.2.840.10008.1.2.4.51	0
195	14	2772	0
195	10	1.2.840.10008.5.1.4.1.1.2	0
195	1	271	0
196	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
529	2	20250211T154521	0
196	2	20250211T152517	0
196	3		0
196	8	RestApi	0
196	11	172.22.0.1	0
196	13	orthanc	0
196	9	1.2.840.10008.1.2.4.51	0
196	14	2772	0
196	10	1.2.840.10008.5.1.4.1.1.2	0
196	1	272	0
197	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
529	3		0
529	8	RestApi	0
529	11	172.22.0.1	0
197	2	20250211T152517	0
197	3		0
197	8	RestApi	0
197	11	172.22.0.1	0
197	13	orthanc	0
197	9	1.2.840.10008.1.2.4.51	0
197	14	2772	0
197	10	1.2.840.10008.5.1.4.1.1.2	0
197	1	273	0
198	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
529	13	orthanc	0
198	2	20250211T152517	0
198	3		0
198	8	RestApi	0
198	11	172.22.0.1	0
198	13	orthanc	0
198	9	1.2.840.10008.1.2.4.51	0
198	14	2772	0
198	10	1.2.840.10008.5.1.4.1.1.2	0
198	1	274	0
199	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
199	2	20250211T152517	0
199	3		0
199	8	RestApi	0
199	11	172.22.0.1	0
199	13	orthanc	0
199	9	1.2.840.10008.1.2.4.51	0
199	14	2772	0
199	10	1.2.840.10008.5.1.4.1.1.2	0
199	1	275	0
200	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
200	2	20250211T152517	0
200	3		0
200	8	RestApi	0
200	11	172.22.0.1	0
200	13	orthanc	0
200	9	1.2.840.10008.1.2.4.51	0
200	14	2772	0
200	10	1.2.840.10008.5.1.4.1.1.2	0
200	1	276	0
201	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
201	2	20250211T152517	0
201	3		0
201	8	RestApi	0
201	11	172.22.0.1	0
201	13	orthanc	0
201	9	1.2.840.10008.1.2.4.51	0
201	14	2772	0
201	10	1.2.840.10008.5.1.4.1.1.2	0
201	1	277	0
202	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
202	2	20250211T152517	0
202	3		0
202	8	RestApi	0
202	11	172.22.0.1	0
202	13	orthanc	0
202	9	1.2.840.10008.1.2.4.51	0
202	14	2772	0
202	10	1.2.840.10008.5.1.4.1.1.2	0
202	1	278	0
203	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
203	2	20250211T152517	0
203	3		0
203	8	RestApi	0
203	11	172.22.0.1	0
203	13	orthanc	0
203	9	1.2.840.10008.1.2.4.51	0
203	14	2772	0
203	10	1.2.840.10008.5.1.4.1.1.2	0
203	1	279	0
204	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
204	2	20250211T152517	0
204	3		0
204	8	RestApi	0
204	11	172.22.0.1	0
204	13	orthanc	0
204	9	1.2.840.10008.1.2.4.51	0
204	14	2772	0
204	10	1.2.840.10008.5.1.4.1.1.2	0
204	1	280	0
205	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
205	2	20250211T152517	0
205	3		0
205	8	RestApi	0
205	11	172.22.0.1	0
205	13	orthanc	0
205	9	1.2.840.10008.1.2.4.51	0
205	14	2772	0
205	10	1.2.840.10008.5.1.4.1.1.2	0
205	1	29	0
206	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
206	2	20250211T152517	0
206	3		0
206	8	RestApi	0
206	11	172.22.0.1	0
206	13	orthanc	0
206	9	1.2.840.10008.1.2.4.51	0
206	14	2772	0
206	10	1.2.840.10008.5.1.4.1.1.2	0
206	1	281	0
207	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
529	9	1.2.840.10008.1.2.4.70	0
529	14	3200	0
529	10	1.2.840.10008.5.1.4.1.1.2	0
207	2	20250211T152517	0
207	3		0
207	8	RestApi	0
207	11	172.22.0.1	0
207	13	orthanc	0
207	9	1.2.840.10008.1.2.4.51	0
207	14	2772	0
207	10	1.2.840.10008.5.1.4.1.1.2	0
207	1	282	0
208	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
208	2	20250211T152517	0
208	3		0
208	8	RestApi	0
208	11	172.22.0.1	0
208	13	orthanc	0
208	9	1.2.840.10008.1.2.4.51	0
208	14	2772	0
208	10	1.2.840.10008.5.1.4.1.1.2	0
208	1	283	0
209	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
209	2	20250211T152517	0
209	3		0
209	8	RestApi	0
209	11	172.22.0.1	0
209	13	orthanc	0
209	9	1.2.840.10008.1.2.4.51	0
209	14	2772	0
209	10	1.2.840.10008.5.1.4.1.1.2	0
209	1	284	0
210	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
210	2	20250211T152517	0
210	3		0
210	8	RestApi	0
210	11	172.22.0.1	0
210	13	orthanc	0
210	9	1.2.840.10008.1.2.4.51	0
210	14	2772	0
210	10	1.2.840.10008.5.1.4.1.1.2	0
210	1	285	0
211	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
211	2	20250211T152517	0
211	3		0
211	8	RestApi	0
211	11	172.22.0.1	0
211	13	orthanc	0
211	9	1.2.840.10008.1.2.4.51	0
211	14	2772	0
211	10	1.2.840.10008.5.1.4.1.1.2	0
211	1	286	0
212	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
212	2	20250211T152517	0
212	3		0
212	8	RestApi	0
212	11	172.22.0.1	0
212	13	orthanc	0
212	9	1.2.840.10008.1.2.4.51	0
212	14	2772	0
212	10	1.2.840.10008.5.1.4.1.1.2	0
212	1	287	0
213	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
213	2	20250211T152517	0
213	3		0
213	8	RestApi	0
213	11	172.22.0.1	0
213	13	orthanc	0
213	9	1.2.840.10008.1.2.4.51	0
213	14	2772	0
213	10	1.2.840.10008.5.1.4.1.1.2	0
213	1	288	0
214	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
214	2	20250211T152517	0
214	3		0
214	8	RestApi	0
214	11	172.22.0.1	0
214	13	orthanc	0
214	9	1.2.840.10008.1.2.4.51	0
214	14	2772	0
214	10	1.2.840.10008.5.1.4.1.1.2	0
214	1	289	0
215	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
215	2	20250211T152517	0
215	3		0
215	8	RestApi	0
215	11	172.22.0.1	0
215	13	orthanc	0
215	9	1.2.840.10008.1.2.4.51	0
215	14	2772	0
215	10	1.2.840.10008.5.1.4.1.1.2	0
215	1	290	0
216	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
216	2	20250211T152517	0
216	3		0
216	8	RestApi	0
216	11	172.22.0.1	0
216	13	orthanc	0
216	9	1.2.840.10008.1.2.4.51	0
216	14	2770	0
216	10	1.2.840.10008.5.1.4.1.1.2	0
216	1	30	0
217	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
217	2	20250211T152517	0
217	3		0
217	8	RestApi	0
217	11	172.22.0.1	0
217	13	orthanc	0
217	9	1.2.840.10008.1.2.4.51	0
217	14	2772	0
217	10	1.2.840.10008.5.1.4.1.1.2	0
217	1	291	0
218	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
529	1	66	0
530	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
218	2	20250211T152517	0
218	3		0
218	8	RestApi	0
218	11	172.22.0.1	0
218	13	orthanc	0
218	9	1.2.840.10008.1.2.4.51	0
218	14	2772	0
218	10	1.2.840.10008.5.1.4.1.1.2	0
218	1	292	0
219	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
219	2	20250211T152517	0
219	3		0
219	8	RestApi	0
219	11	172.22.0.1	0
219	13	orthanc	0
219	9	1.2.840.10008.1.2.4.51	0
219	14	2772	0
219	10	1.2.840.10008.5.1.4.1.1.2	0
219	1	293	0
220	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
220	2	20250211T152517	0
220	3		0
220	8	RestApi	0
220	11	172.22.0.1	0
220	13	orthanc	0
220	9	1.2.840.10008.1.2.4.51	0
220	14	2772	0
220	10	1.2.840.10008.5.1.4.1.1.2	0
220	1	294	0
221	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
221	2	20250211T152517	0
221	3		0
221	8	RestApi	0
221	11	172.22.0.1	0
221	13	orthanc	0
221	9	1.2.840.10008.1.2.4.51	0
221	14	2772	0
221	10	1.2.840.10008.5.1.4.1.1.2	0
221	1	295	0
222	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
222	2	20250211T152517	0
222	3		0
222	8	RestApi	0
222	11	172.22.0.1	0
222	13	orthanc	0
222	9	1.2.840.10008.1.2.4.51	0
222	14	2772	0
222	10	1.2.840.10008.5.1.4.1.1.2	0
222	1	296	0
223	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
223	2	20250211T152517	0
223	3		0
223	8	RestApi	0
223	11	172.22.0.1	0
223	13	orthanc	0
223	9	1.2.840.10008.1.2.4.51	0
223	14	2772	0
223	10	1.2.840.10008.5.1.4.1.1.2	0
223	1	297	0
224	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
224	2	20250211T152517	0
224	3		0
224	8	RestApi	0
224	11	172.22.0.1	0
224	13	orthanc	0
224	9	1.2.840.10008.1.2.4.51	0
224	14	2772	0
224	10	1.2.840.10008.5.1.4.1.1.2	0
224	1	298	0
225	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
225	2	20250211T152517	0
225	3		0
225	8	RestApi	0
225	11	172.22.0.1	0
225	13	orthanc	0
225	9	1.2.840.10008.1.2.4.51	0
225	14	2772	0
225	10	1.2.840.10008.5.1.4.1.1.2	0
225	1	299	0
226	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
226	2	20250211T152517	0
226	3		0
226	8	RestApi	0
226	11	172.22.0.1	0
226	13	orthanc	0
226	9	1.2.840.10008.1.2.4.51	0
226	14	2772	0
226	10	1.2.840.10008.5.1.4.1.1.2	0
226	1	300	0
227	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
227	2	20250211T152517	0
227	3		0
227	8	RestApi	0
227	11	172.22.0.1	0
227	13	orthanc	0
227	9	1.2.840.10008.1.2.4.51	0
227	14	2770	0
227	10	1.2.840.10008.5.1.4.1.1.2	0
227	1	4	0
228	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
228	2	20250211T152517	0
228	3		0
228	8	RestApi	0
228	11	172.22.0.1	0
228	13	orthanc	0
228	9	1.2.840.10008.1.2.4.51	0
228	14	2770	0
228	10	1.2.840.10008.5.1.4.1.1.2	0
228	1	31	0
229	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
229	2	20250211T152517	0
229	3		0
229	8	RestApi	0
229	11	172.22.0.1	0
229	13	orthanc	0
229	9	1.2.840.10008.1.2.4.51	0
229	14	2772	0
229	10	1.2.840.10008.5.1.4.1.1.2	0
229	1	301	0
230	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
530	2	20250211T154521	0
530	3		0
530	8	RestApi	0
230	2	20250211T152517	0
230	3		0
230	8	RestApi	0
230	11	172.22.0.1	0
230	13	orthanc	0
230	9	1.2.840.10008.1.2.4.51	0
230	14	2772	0
230	10	1.2.840.10008.5.1.4.1.1.2	0
230	1	302	0
231	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
530	11	172.22.0.1	0
530	13	orthanc	0
530	9	1.2.840.10008.1.2.4.70	0
231	2	20250211T152517	0
231	3		0
231	8	RestApi	0
231	11	172.22.0.1	0
231	13	orthanc	0
231	9	1.2.840.10008.1.2.4.51	0
231	14	2772	0
231	10	1.2.840.10008.5.1.4.1.1.2	0
231	1	303	0
232	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
530	14	3200	0
232	2	20250211T152517	0
232	3		0
232	8	RestApi	0
232	11	172.22.0.1	0
232	13	orthanc	0
232	9	1.2.840.10008.1.2.4.51	0
232	14	2772	0
232	10	1.2.840.10008.5.1.4.1.1.2	0
232	1	304	0
233	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
233	2	20250211T152517	0
233	3		0
233	8	RestApi	0
233	11	172.22.0.1	0
233	13	orthanc	0
233	9	1.2.840.10008.1.2.4.51	0
233	14	2772	0
233	10	1.2.840.10008.5.1.4.1.1.2	0
233	1	305	0
234	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
234	2	20250211T152517	0
234	3		0
234	8	RestApi	0
234	11	172.22.0.1	0
234	13	orthanc	0
234	9	1.2.840.10008.1.2.4.51	0
234	14	2772	0
234	10	1.2.840.10008.5.1.4.1.1.2	0
234	1	306	0
235	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
235	2	20250211T152517	0
235	3		0
235	8	RestApi	0
235	11	172.22.0.1	0
235	13	orthanc	0
235	9	1.2.840.10008.1.2.4.51	0
235	14	2772	0
235	10	1.2.840.10008.5.1.4.1.1.2	0
235	1	307	0
236	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
236	2	20250211T152517	0
236	3		0
236	8	RestApi	0
236	11	172.22.0.1	0
236	13	orthanc	0
236	9	1.2.840.10008.1.2.4.51	0
236	14	2772	0
236	10	1.2.840.10008.5.1.4.1.1.2	0
236	1	308	0
237	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
237	2	20250211T152517	0
237	3		0
237	8	RestApi	0
237	11	172.22.0.1	0
237	13	orthanc	0
237	9	1.2.840.10008.1.2.4.51	0
237	14	2772	0
237	10	1.2.840.10008.5.1.4.1.1.2	0
237	1	309	0
238	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
238	2	20250211T152517	0
238	3		0
238	8	RestApi	0
238	11	172.22.0.1	0
238	13	orthanc	0
238	9	1.2.840.10008.1.2.4.51	0
238	14	2772	0
238	10	1.2.840.10008.5.1.4.1.1.2	0
238	1	310	0
239	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
239	2	20250211T152517	0
239	3		0
239	8	RestApi	0
239	11	172.22.0.1	0
239	13	orthanc	0
239	9	1.2.840.10008.1.2.4.51	0
239	14	2770	0
239	10	1.2.840.10008.5.1.4.1.1.2	0
239	1	32	0
240	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
240	2	20250211T152517	0
240	3		0
240	8	RestApi	0
240	11	172.22.0.1	0
240	13	orthanc	0
240	9	1.2.840.10008.1.2.4.51	0
240	14	2772	0
240	10	1.2.840.10008.5.1.4.1.1.2	0
240	1	311	0
241	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
530	10	1.2.840.10008.5.1.4.1.1.2	0
530	1	67	0
543	14	2630	0
241	2	20250211T152517	0
241	3		0
241	8	RestApi	0
241	11	172.22.0.1	0
241	13	orthanc	0
241	9	1.2.840.10008.1.2.4.51	0
241	14	2772	0
241	10	1.2.840.10008.5.1.4.1.1.2	0
241	1	312	0
242	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
242	2	20250211T152517	0
242	3		0
242	8	RestApi	0
242	11	172.22.0.1	0
242	13	orthanc	0
242	9	1.2.840.10008.1.2.4.51	0
242	14	2772	0
242	10	1.2.840.10008.5.1.4.1.1.2	0
242	1	313	0
243	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
243	2	20250211T152517	0
243	3		0
243	8	RestApi	0
243	11	172.22.0.1	0
243	13	orthanc	0
243	9	1.2.840.10008.1.2.4.51	0
243	14	2772	0
243	10	1.2.840.10008.5.1.4.1.1.2	0
243	1	314	0
244	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
244	2	20250211T152517	0
244	3		0
244	8	RestApi	0
244	11	172.22.0.1	0
244	13	orthanc	0
244	9	1.2.840.10008.1.2.4.51	0
244	14	2772	0
244	10	1.2.840.10008.5.1.4.1.1.2	0
244	1	315	0
245	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
245	2	20250211T152517	0
245	3		0
245	8	RestApi	0
245	11	172.22.0.1	0
245	13	orthanc	0
245	9	1.2.840.10008.1.2.4.51	0
245	14	2772	0
245	10	1.2.840.10008.5.1.4.1.1.2	0
245	1	316	0
246	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
246	2	20250211T152517	0
246	3		0
246	8	RestApi	0
246	11	172.22.0.1	0
246	13	orthanc	0
246	9	1.2.840.10008.1.2.4.51	0
246	14	2772	0
246	10	1.2.840.10008.5.1.4.1.1.2	0
246	1	317	0
247	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
247	2	20250211T152517	0
247	3		0
247	8	RestApi	0
247	11	172.22.0.1	0
247	13	orthanc	0
247	9	1.2.840.10008.1.2.4.51	0
247	14	2772	0
247	10	1.2.840.10008.5.1.4.1.1.2	0
247	1	318	0
248	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
248	2	20250211T152517	0
248	3		0
248	8	RestApi	0
248	11	172.22.0.1	0
248	13	orthanc	0
248	9	1.2.840.10008.1.2.4.51	0
248	14	2772	0
248	10	1.2.840.10008.5.1.4.1.1.2	0
248	1	319	0
249	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
249	2	20250211T152517	0
249	3		0
249	8	RestApi	0
249	11	172.22.0.1	0
249	13	orthanc	0
249	9	1.2.840.10008.1.2.4.51	0
249	14	2772	0
249	10	1.2.840.10008.5.1.4.1.1.2	0
249	1	320	0
250	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
250	2	20250211T152517	0
250	3		0
250	8	RestApi	0
250	11	172.22.0.1	0
250	13	orthanc	0
250	9	1.2.840.10008.1.2.4.51	0
250	14	2770	0
250	10	1.2.840.10008.5.1.4.1.1.2	0
250	1	33	0
251	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
251	2	20250211T152517	0
251	3		0
251	8	RestApi	0
251	11	172.22.0.1	0
251	13	orthanc	0
251	9	1.2.840.10008.1.2.4.51	0
251	14	2772	0
251	10	1.2.840.10008.5.1.4.1.1.2	0
251	1	321	0
252	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
532	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
543	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
252	2	20250211T152517	0
252	3		0
252	8	RestApi	0
252	11	172.22.0.1	0
252	13	orthanc	0
252	9	1.2.840.10008.1.2.4.51	0
252	14	2772	0
252	10	1.2.840.10008.5.1.4.1.1.2	0
252	1	322	0
253	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
253	2	20250211T152517	0
253	3		0
253	8	RestApi	0
253	11	172.22.0.1	0
253	13	orthanc	0
253	9	1.2.840.10008.1.2.4.51	0
253	14	2772	0
253	10	1.2.840.10008.5.1.4.1.1.2	0
253	1	323	0
254	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
254	2	20250211T152517	0
254	3		0
254	8	RestApi	0
254	11	172.22.0.1	0
254	13	orthanc	0
254	9	1.2.840.10008.1.2.4.51	0
254	14	2772	0
254	10	1.2.840.10008.5.1.4.1.1.2	0
254	1	324	0
255	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
255	2	20250211T152517	0
255	3		0
255	8	RestApi	0
255	11	172.22.0.1	0
255	13	orthanc	0
255	9	1.2.840.10008.1.2.4.51	0
255	14	2774	0
255	10	1.2.840.10008.5.1.4.1.1.2	0
255	1	325	0
256	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
256	2	20250211T152517	0
256	3		0
256	8	RestApi	0
256	11	172.22.0.1	0
256	13	orthanc	0
256	9	1.2.840.10008.1.2.4.51	0
256	14	2774	0
256	10	1.2.840.10008.5.1.4.1.1.2	0
256	1	326	0
257	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
257	2	20250211T152517	0
257	3		0
257	8	RestApi	0
257	11	172.22.0.1	0
257	13	orthanc	0
257	9	1.2.840.10008.1.2.4.51	0
257	14	2774	0
257	10	1.2.840.10008.5.1.4.1.1.2	0
257	1	327	0
258	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
258	2	20250211T152517	0
258	3		0
258	8	RestApi	0
258	11	172.22.0.1	0
258	13	orthanc	0
258	9	1.2.840.10008.1.2.4.51	0
258	14	2774	0
258	10	1.2.840.10008.5.1.4.1.1.2	0
258	1	328	0
259	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
259	2	20250211T152517	0
259	3		0
259	8	RestApi	0
259	11	172.22.0.1	0
259	13	orthanc	0
259	9	1.2.840.10008.1.2.4.51	0
259	14	2772	0
259	10	1.2.840.10008.5.1.4.1.1.2	0
259	1	329	0
260	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
260	2	20250211T152517	0
260	3		0
260	8	RestApi	0
260	11	172.22.0.1	0
260	13	orthanc	0
260	9	1.2.840.10008.1.2.4.51	0
260	14	2772	0
260	10	1.2.840.10008.5.1.4.1.1.2	0
260	1	330	0
261	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
261	2	20250211T152517	0
261	3		0
261	8	RestApi	0
261	11	172.22.0.1	0
261	13	orthanc	0
261	9	1.2.840.10008.1.2.4.51	0
261	14	2772	0
261	10	1.2.840.10008.5.1.4.1.1.2	0
261	1	34	0
262	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
262	2	20250211T152517	0
262	3		0
262	8	RestApi	0
262	11	172.22.0.1	0
262	13	orthanc	0
262	9	1.2.840.10008.1.2.4.51	0
262	14	2772	0
262	10	1.2.840.10008.5.1.4.1.1.2	0
262	1	331	0
263	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
263	2	20250211T152517	0
263	3		0
263	8	RestApi	0
263	11	172.22.0.1	0
263	13	orthanc	0
263	9	1.2.840.10008.1.2.4.51	0
263	14	2772	0
263	10	1.2.840.10008.5.1.4.1.1.2	0
263	1	332	0
264	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
531	15	0008,0021;0008,0031;0008,0060;0008,0070;0008,0201;0008,1010;0008,103e;0008,1070;0018,0010;0018,0015;0018,0024;0018,1030;0018,1090;0018,1400;0020,000e;0020,0011;0020,0037;0020,0105;0020,1002;0040,0244;0040,0245;0040,0254;0040,0275;0054,0081;0054,0101;0054,1000	0
264	2	20250211T152517	0
264	3		0
264	8	RestApi	0
264	11	172.22.0.1	0
264	13	orthanc	0
264	9	1.2.840.10008.1.2.4.51	0
264	14	2772	0
264	10	1.2.840.10008.5.1.4.1.1.2	0
264	1	333	0
265	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
265	2	20250211T152517	0
265	3		0
265	8	RestApi	0
265	11	172.22.0.1	0
265	13	orthanc	0
265	9	1.2.840.10008.1.2.4.51	0
265	14	2772	0
265	10	1.2.840.10008.5.1.4.1.1.2	0
265	1	334	0
266	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
266	2	20250211T152517	0
266	3		0
266	8	RestApi	0
266	11	172.22.0.1	0
266	13	orthanc	0
266	9	1.2.840.10008.1.2.4.51	0
266	14	2772	0
266	10	1.2.840.10008.5.1.4.1.1.2	0
266	1	335	0
267	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
267	2	20250211T152517	0
267	3		0
267	8	RestApi	0
267	11	172.22.0.1	0
267	13	orthanc	0
267	9	1.2.840.10008.1.2.4.51	0
267	14	2772	0
267	10	1.2.840.10008.5.1.4.1.1.2	0
267	1	336	0
268	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
268	2	20250211T152517	0
268	3		0
268	8	RestApi	0
268	11	172.22.0.1	0
268	13	orthanc	0
268	9	1.2.840.10008.1.2.4.51	0
268	14	2772	0
268	10	1.2.840.10008.5.1.4.1.1.2	0
268	1	337	0
269	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
269	2	20250211T152517	0
269	3		0
269	8	RestApi	0
269	11	172.22.0.1	0
269	13	orthanc	0
269	9	1.2.840.10008.1.2.4.51	0
269	14	2772	0
269	10	1.2.840.10008.5.1.4.1.1.2	0
269	1	338	0
270	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
270	2	20250211T152517	0
270	3		0
270	8	RestApi	0
270	11	172.22.0.1	0
270	13	orthanc	0
270	9	1.2.840.10008.1.2.4.51	0
270	14	2772	0
270	10	1.2.840.10008.5.1.4.1.1.2	0
270	1	339	0
271	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
271	2	20250211T152517	0
271	3		0
271	8	RestApi	0
271	11	172.22.0.1	0
271	13	orthanc	0
271	9	1.2.840.10008.1.2.4.51	0
271	14	2772	0
271	10	1.2.840.10008.5.1.4.1.1.2	0
271	1	340	0
272	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
272	2	20250211T152517	0
272	3		0
272	8	RestApi	0
272	11	172.22.0.1	0
272	13	orthanc	0
272	9	1.2.840.10008.1.2.4.51	0
272	14	2770	0
272	10	1.2.840.10008.5.1.4.1.1.2	0
272	1	35	0
273	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
273	2	20250211T152517	0
273	3		0
273	8	RestApi	0
273	11	172.22.0.1	0
273	13	orthanc	0
273	9	1.2.840.10008.1.2.4.51	0
273	14	2772	0
273	10	1.2.840.10008.5.1.4.1.1.2	0
273	1	341	0
274	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
274	2	20250211T152517	0
274	3		0
274	8	RestApi	0
274	11	172.22.0.1	0
274	13	orthanc	0
274	9	1.2.840.10008.1.2.4.51	0
274	14	2772	0
274	10	1.2.840.10008.5.1.4.1.1.2	0
274	1	342	0
275	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
531	3		0
275	2	20250211T152517	0
275	3		0
275	8	RestApi	0
275	11	172.22.0.1	0
275	13	orthanc	0
275	9	1.2.840.10008.1.2.4.51	0
275	14	2772	0
275	10	1.2.840.10008.5.1.4.1.1.2	0
275	1	343	0
276	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
532	2	20250211T154521	0
276	2	20250211T152517	0
276	3		0
276	8	RestApi	0
276	11	172.22.0.1	0
276	13	orthanc	0
276	9	1.2.840.10008.1.2.4.51	0
276	14	2772	0
276	10	1.2.840.10008.5.1.4.1.1.2	0
276	1	344	0
277	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
277	2	20250211T152517	0
277	3		0
277	8	RestApi	0
277	11	172.22.0.1	0
277	13	orthanc	0
277	9	1.2.840.10008.1.2.4.51	0
277	14	2772	0
277	10	1.2.840.10008.5.1.4.1.1.2	0
277	1	345	0
278	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
278	2	20250211T152517	0
278	3		0
278	8	RestApi	0
278	11	172.22.0.1	0
278	13	orthanc	0
278	9	1.2.840.10008.1.2.4.51	0
278	14	2772	0
278	10	1.2.840.10008.5.1.4.1.1.2	0
278	1	346	0
279	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
279	2	20250211T152517	0
279	3		0
279	8	RestApi	0
279	11	172.22.0.1	0
279	13	orthanc	0
279	9	1.2.840.10008.1.2.4.51	0
279	14	2772	0
279	10	1.2.840.10008.5.1.4.1.1.2	0
279	1	347	0
280	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
280	2	20250211T152517	0
280	3		0
280	8	RestApi	0
280	11	172.22.0.1	0
280	13	orthanc	0
280	9	1.2.840.10008.1.2.4.51	0
280	14	2772	0
280	10	1.2.840.10008.5.1.4.1.1.2	0
280	1	348	0
281	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
281	2	20250211T152517	0
281	3		0
281	8	RestApi	0
281	11	172.22.0.1	0
281	13	orthanc	0
281	9	1.2.840.10008.1.2.4.51	0
281	14	2772	0
281	10	1.2.840.10008.5.1.4.1.1.2	0
281	1	349	0
282	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
282	2	20250211T152517	0
282	3		0
282	8	RestApi	0
282	11	172.22.0.1	0
282	13	orthanc	0
282	9	1.2.840.10008.1.2.4.51	0
282	14	2772	0
282	10	1.2.840.10008.5.1.4.1.1.2	0
282	1	350	0
283	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
283	2	20250211T152517	0
283	3		0
283	8	RestApi	0
283	11	172.22.0.1	0
283	13	orthanc	0
283	9	1.2.840.10008.1.2.4.51	0
283	14	2770	0
283	10	1.2.840.10008.5.1.4.1.1.2	0
283	1	36	0
284	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
284	2	20250211T152517	0
284	3		0
284	8	RestApi	0
284	11	172.22.0.1	0
284	13	orthanc	0
284	9	1.2.840.10008.1.2.4.51	0
284	14	2774	0
284	10	1.2.840.10008.5.1.4.1.1.2	0
284	1	351	0
285	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
285	2	20250211T152517	0
285	3		0
285	8	RestApi	0
285	11	172.22.0.1	0
285	13	orthanc	0
285	9	1.2.840.10008.1.2.4.51	0
285	14	2774	0
285	10	1.2.840.10008.5.1.4.1.1.2	0
285	1	352	0
286	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
532	3		0
532	8	RestApi	0
532	11	172.22.0.1	0
286	2	20250211T152517	0
286	3		0
286	8	RestApi	0
286	11	172.22.0.1	0
286	13	orthanc	0
286	9	1.2.840.10008.1.2.4.51	0
286	14	2772	0
286	10	1.2.840.10008.5.1.4.1.1.2	0
286	1	353	0
287	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
532	13	orthanc	0
532	9	1.2.840.10008.1.2.4.70	0
532	14	2622	0
287	2	20250211T152517	0
287	3		0
287	8	RestApi	0
287	11	172.22.0.1	0
287	13	orthanc	0
287	9	1.2.840.10008.1.2.4.51	0
287	14	2772	0
287	10	1.2.840.10008.5.1.4.1.1.2	0
287	1	354	0
288	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
288	2	20250211T152517	0
288	3		0
288	8	RestApi	0
288	11	172.22.0.1	0
288	13	orthanc	0
288	9	1.2.840.10008.1.2.4.51	0
288	14	2772	0
288	10	1.2.840.10008.5.1.4.1.1.2	0
288	1	355	0
289	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
289	2	20250211T152517	0
289	3		0
289	8	RestApi	0
289	11	172.22.0.1	0
289	13	orthanc	0
289	9	1.2.840.10008.1.2.4.51	0
289	14	2772	0
289	10	1.2.840.10008.5.1.4.1.1.2	0
289	1	356	0
290	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
290	2	20250211T152517	0
290	3		0
290	8	RestApi	0
290	11	172.22.0.1	0
290	13	orthanc	0
290	9	1.2.840.10008.1.2.4.51	0
290	14	2772	0
290	10	1.2.840.10008.5.1.4.1.1.2	0
290	1	357	0
291	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
291	2	20250211T152517	0
291	3		0
291	8	RestApi	0
291	11	172.22.0.1	0
291	13	orthanc	0
291	9	1.2.840.10008.1.2.4.51	0
291	14	2772	0
291	10	1.2.840.10008.5.1.4.1.1.2	0
291	1	358	0
292	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
292	2	20250211T152517	0
292	3		0
292	8	RestApi	0
292	11	172.22.0.1	0
292	13	orthanc	0
292	9	1.2.840.10008.1.2.4.51	0
292	14	2772	0
292	10	1.2.840.10008.5.1.4.1.1.2	0
292	1	359	0
293	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
293	2	20250211T152517	0
293	3		0
293	8	RestApi	0
293	11	172.22.0.1	0
293	13	orthanc	0
293	9	1.2.840.10008.1.2.4.51	0
293	14	2772	0
293	10	1.2.840.10008.5.1.4.1.1.2	0
293	1	360	0
294	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
294	2	20250211T152517	0
294	3		0
294	8	RestApi	0
294	11	172.22.0.1	0
294	13	orthanc	0
294	9	1.2.840.10008.1.2.4.51	0
294	14	2770	0
294	10	1.2.840.10008.5.1.4.1.1.2	0
294	1	37	0
295	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
295	2	20250211T152517	0
295	3		0
295	8	RestApi	0
295	11	172.22.0.1	0
295	13	orthanc	0
295	9	1.2.840.10008.1.2.4.51	0
295	14	2772	0
295	10	1.2.840.10008.5.1.4.1.1.2	0
295	1	361	0
296	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
296	2	20250211T152517	0
296	3		0
296	8	RestApi	0
296	11	172.22.0.1	0
296	13	orthanc	0
296	9	1.2.840.10008.1.2.4.51	0
296	14	2772	0
296	10	1.2.840.10008.5.1.4.1.1.2	0
296	1	362	0
297	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
297	2	20250211T152517	0
297	3		0
297	8	RestApi	0
297	11	172.22.0.1	0
297	13	orthanc	0
297	9	1.2.840.10008.1.2.4.51	0
297	14	2772	0
297	10	1.2.840.10008.5.1.4.1.1.2	0
297	1	363	0
298	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
532	10	1.2.840.10008.5.1.4.1.1.2	0
532	1	1	0
533	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
298	2	20250211T152517	0
298	3		0
298	8	RestApi	0
298	11	172.22.0.1	0
298	13	orthanc	0
298	9	1.2.840.10008.1.2.4.51	0
298	14	2772	0
298	10	1.2.840.10008.5.1.4.1.1.2	0
298	1	364	0
299	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
299	2	20250211T152517	0
299	3		0
299	8	RestApi	0
299	11	172.22.0.1	0
299	13	orthanc	0
299	9	1.2.840.10008.1.2.4.51	0
299	14	2772	0
299	10	1.2.840.10008.5.1.4.1.1.2	0
299	1	365	0
300	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
300	2	20250211T152517	0
300	3		0
300	8	RestApi	0
300	11	172.22.0.1	0
300	13	orthanc	0
300	9	1.2.840.10008.1.2.4.51	0
300	14	2772	0
300	10	1.2.840.10008.5.1.4.1.1.2	0
300	1	366	0
301	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
301	2	20250211T152517	0
301	3		0
301	8	RestApi	0
301	11	172.22.0.1	0
301	13	orthanc	0
301	9	1.2.840.10008.1.2.4.51	0
301	14	2772	0
301	10	1.2.840.10008.5.1.4.1.1.2	0
301	1	367	0
302	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
302	2	20250211T152517	0
302	3		0
302	8	RestApi	0
302	11	172.22.0.1	0
302	13	orthanc	0
302	9	1.2.840.10008.1.2.4.51	0
302	14	2772	0
302	10	1.2.840.10008.5.1.4.1.1.2	0
302	1	368	0
303	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
303	2	20250211T152517	0
303	3		0
303	8	RestApi	0
303	11	172.22.0.1	0
303	13	orthanc	0
303	9	1.2.840.10008.1.2.4.51	0
303	14	2772	0
303	10	1.2.840.10008.5.1.4.1.1.2	0
303	1	369	0
304	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
304	2	20250211T152517	0
304	3		0
304	8	RestApi	0
304	11	172.22.0.1	0
304	13	orthanc	0
304	9	1.2.840.10008.1.2.4.51	0
304	14	2772	0
304	10	1.2.840.10008.5.1.4.1.1.2	0
304	1	370	0
305	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
305	2	20250211T152517	0
305	3		0
305	8	RestApi	0
305	11	172.22.0.1	0
305	13	orthanc	0
305	9	1.2.840.10008.1.2.4.51	0
305	14	2770	0
305	10	1.2.840.10008.5.1.4.1.1.2	0
305	1	38	0
306	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
306	2	20250211T152517	0
306	3		0
306	8	RestApi	0
306	11	172.22.0.1	0
306	13	orthanc	0
306	9	1.2.840.10008.1.2.4.51	0
306	14	2772	0
306	10	1.2.840.10008.5.1.4.1.1.2	0
306	1	371	0
307	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
307	2	20250211T152517	0
307	3		0
307	8	RestApi	0
307	11	172.22.0.1	0
307	13	orthanc	0
307	9	1.2.840.10008.1.2.4.51	0
307	14	2772	0
307	10	1.2.840.10008.5.1.4.1.1.2	0
307	1	372	0
308	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
308	2	20250211T152517	0
308	3		0
308	8	RestApi	0
308	11	172.22.0.1	0
308	13	orthanc	0
308	9	1.2.840.10008.1.2.4.51	0
308	14	2772	0
308	10	1.2.840.10008.5.1.4.1.1.2	0
308	1	373	0
309	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
533	2	20250211T154521	0
309	2	20250211T152517	0
309	3		0
309	8	RestApi	0
309	11	172.22.0.1	0
309	13	orthanc	0
309	9	1.2.840.10008.1.2.4.51	0
309	14	2772	0
309	10	1.2.840.10008.5.1.4.1.1.2	0
309	1	374	0
310	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
533	3		0
310	2	20250211T152517	0
310	3		0
310	8	RestApi	0
310	11	172.22.0.1	0
310	13	orthanc	0
310	9	1.2.840.10008.1.2.4.51	0
310	14	2772	0
310	10	1.2.840.10008.5.1.4.1.1.2	0
310	1	375	0
311	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
311	2	20250211T152517	0
311	3		0
311	8	RestApi	0
311	11	172.22.0.1	0
311	13	orthanc	0
311	9	1.2.840.10008.1.2.4.51	0
311	14	2772	0
311	10	1.2.840.10008.5.1.4.1.1.2	0
311	1	376	0
312	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
312	2	20250211T152517	0
312	3		0
312	8	RestApi	0
312	11	172.22.0.1	0
312	13	orthanc	0
312	9	1.2.840.10008.1.2.4.51	0
312	14	2772	0
312	10	1.2.840.10008.5.1.4.1.1.2	0
312	1	377	0
313	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
313	2	20250211T152517	0
313	3		0
313	8	RestApi	0
313	11	172.22.0.1	0
313	13	orthanc	0
313	9	1.2.840.10008.1.2.4.51	0
313	14	2772	0
313	10	1.2.840.10008.5.1.4.1.1.2	0
313	1	378	0
314	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
314	2	20250211T152517	0
314	3		0
314	8	RestApi	0
314	11	172.22.0.1	0
314	13	orthanc	0
314	9	1.2.840.10008.1.2.4.51	0
314	14	2774	0
314	10	1.2.840.10008.5.1.4.1.1.2	0
314	1	379	0
315	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
315	2	20250211T152517	0
315	3		0
315	8	RestApi	0
315	11	172.22.0.1	0
315	13	orthanc	0
315	9	1.2.840.10008.1.2.4.51	0
315	14	2774	0
315	10	1.2.840.10008.5.1.4.1.1.2	0
315	1	380	0
316	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
316	2	20250211T152517	0
316	3		0
316	8	RestApi	0
316	11	172.22.0.1	0
316	13	orthanc	0
316	9	1.2.840.10008.1.2.4.51	0
316	14	2768	0
316	10	1.2.840.10008.5.1.4.1.1.2	0
316	1	39	0
317	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
317	2	20250211T152517	0
317	3		0
317	8	RestApi	0
317	11	172.22.0.1	0
317	13	orthanc	0
317	9	1.2.840.10008.1.2.4.51	0
317	14	2774	0
317	10	1.2.840.10008.5.1.4.1.1.2	0
317	1	381	0
318	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
318	2	20250211T152517	0
318	3		0
318	8	RestApi	0
318	11	172.22.0.1	0
318	13	orthanc	0
318	9	1.2.840.10008.1.2.4.51	0
318	14	2772	0
318	10	1.2.840.10008.5.1.4.1.1.2	0
318	1	382	0
319	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
319	2	20250211T152517	0
319	3		0
319	8	RestApi	0
319	11	172.22.0.1	0
319	13	orthanc	0
319	9	1.2.840.10008.1.2.4.51	0
319	14	2772	0
319	10	1.2.840.10008.5.1.4.1.1.2	0
319	1	383	0
320	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
533	8	RestApi	0
533	11	172.22.0.1	0
533	13	orthanc	0
320	2	20250211T152517	0
320	3		0
320	8	RestApi	0
320	11	172.22.0.1	0
320	13	orthanc	0
320	9	1.2.840.10008.1.2.4.51	0
320	14	2772	0
320	10	1.2.840.10008.5.1.4.1.1.2	0
320	1	384	0
321	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
533	9	1.2.840.10008.1.2.4.70	0
533	14	2630	0
533	10	1.2.840.10008.5.1.4.1.1.2	0
321	2	20250211T152517	0
321	3		0
321	8	RestApi	0
321	11	172.22.0.1	0
321	13	orthanc	0
321	9	1.2.840.10008.1.2.4.51	0
321	14	2772	0
321	10	1.2.840.10008.5.1.4.1.1.2	0
321	1	385	0
322	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
322	2	20250211T152517	0
322	3		0
322	8	RestApi	0
322	11	172.22.0.1	0
322	13	orthanc	0
322	9	1.2.840.10008.1.2.4.51	0
322	14	2772	0
322	10	1.2.840.10008.5.1.4.1.1.2	0
322	1	386	0
323	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
323	2	20250211T152517	0
323	3		0
323	8	RestApi	0
323	11	172.22.0.1	0
323	13	orthanc	0
323	9	1.2.840.10008.1.2.4.51	0
323	14	2772	0
323	10	1.2.840.10008.5.1.4.1.1.2	0
323	1	387	0
324	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
324	2	20250211T152517	0
324	3		0
324	8	RestApi	0
324	11	172.22.0.1	0
324	13	orthanc	0
324	9	1.2.840.10008.1.2.4.51	0
324	14	2772	0
324	10	1.2.840.10008.5.1.4.1.1.2	0
324	1	388	0
325	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
325	2	20250211T152517	0
325	3		0
325	8	RestApi	0
325	11	172.22.0.1	0
325	13	orthanc	0
325	9	1.2.840.10008.1.2.4.51	0
325	14	2772	0
325	10	1.2.840.10008.5.1.4.1.1.2	0
325	1	389	0
326	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
326	2	20250211T152517	0
326	3		0
326	8	RestApi	0
326	11	172.22.0.1	0
326	13	orthanc	0
326	9	1.2.840.10008.1.2.4.51	0
326	14	2772	0
326	10	1.2.840.10008.5.1.4.1.1.2	0
326	1	390	0
327	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
327	2	20250211T152517	0
327	3		0
327	8	RestApi	0
327	11	172.22.0.1	0
327	13	orthanc	0
327	9	1.2.840.10008.1.2.4.51	0
327	14	2770	0
327	10	1.2.840.10008.5.1.4.1.1.2	0
327	1	40	0
328	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
328	2	20250211T152517	0
328	3		0
328	8	RestApi	0
328	11	172.22.0.1	0
328	13	orthanc	0
328	9	1.2.840.10008.1.2.4.51	0
328	14	2772	0
328	10	1.2.840.10008.5.1.4.1.1.2	0
328	1	391	0
329	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
329	2	20250211T152517	0
329	3		0
329	8	RestApi	0
329	11	172.22.0.1	0
329	13	orthanc	0
329	9	1.2.840.10008.1.2.4.51	0
329	14	2772	0
329	10	1.2.840.10008.5.1.4.1.1.2	0
329	1	392	0
330	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
330	2	20250211T152517	0
330	3		0
330	8	RestApi	0
330	11	172.22.0.1	0
330	13	orthanc	0
330	9	1.2.840.10008.1.2.4.51	0
330	14	2772	0
330	10	1.2.840.10008.5.1.4.1.1.2	0
330	1	393	0
331	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
331	2	20250211T152517	0
331	3		0
331	8	RestApi	0
331	11	172.22.0.1	0
331	13	orthanc	0
331	9	1.2.840.10008.1.2.4.51	0
331	14	2772	0
331	10	1.2.840.10008.5.1.4.1.1.2	0
331	1	394	0
332	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
533	1	2	0
534	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
332	2	20250211T152517	0
332	3		0
332	8	RestApi	0
332	11	172.22.0.1	0
332	13	orthanc	0
332	9	1.2.840.10008.1.2.4.51	0
332	14	2770	0
332	10	1.2.840.10008.5.1.4.1.1.2	0
332	1	395	0
333	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
333	2	20250211T152517	0
333	3		0
333	8	RestApi	0
333	11	172.22.0.1	0
333	13	orthanc	0
333	9	1.2.840.10008.1.2.4.51	0
333	14	2772	0
333	10	1.2.840.10008.5.1.4.1.1.2	0
333	1	396	0
334	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
334	2	20250211T152517	0
334	3		0
334	8	RestApi	0
334	11	172.22.0.1	0
334	13	orthanc	0
334	9	1.2.840.10008.1.2.4.51	0
334	14	2772	0
334	10	1.2.840.10008.5.1.4.1.1.2	0
334	1	397	0
335	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
335	2	20250211T152517	0
335	3		0
335	8	RestApi	0
335	11	172.22.0.1	0
335	13	orthanc	0
335	9	1.2.840.10008.1.2.4.51	0
335	14	2772	0
335	10	1.2.840.10008.5.1.4.1.1.2	0
335	1	398	0
336	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
336	2	20250211T152517	0
336	3		0
336	8	RestApi	0
336	11	172.22.0.1	0
336	13	orthanc	0
336	9	1.2.840.10008.1.2.4.51	0
336	14	2772	0
336	10	1.2.840.10008.5.1.4.1.1.2	0
336	1	399	0
337	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
337	2	20250211T152517	0
337	3		0
337	8	RestApi	0
337	11	172.22.0.1	0
337	13	orthanc	0
337	9	1.2.840.10008.1.2.4.51	0
337	14	2774	0
337	10	1.2.840.10008.5.1.4.1.1.2	0
337	1	400	0
338	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
338	2	20250211T152517	0
338	3		0
338	8	RestApi	0
338	11	172.22.0.1	0
338	13	orthanc	0
338	9	1.2.840.10008.1.2.4.51	0
338	14	2770	0
338	10	1.2.840.10008.5.1.4.1.1.2	0
338	1	5	0
339	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
339	2	20250211T152517	0
339	3		0
339	8	RestApi	0
339	11	172.22.0.1	0
339	13	orthanc	0
339	9	1.2.840.10008.1.2.4.51	0
339	14	2770	0
339	10	1.2.840.10008.5.1.4.1.1.2	0
339	1	41	0
340	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
340	2	20250211T152517	0
340	3		0
340	8	RestApi	0
340	11	172.22.0.1	0
340	13	orthanc	0
340	9	1.2.840.10008.1.2.4.51	0
340	14	2778	0
340	10	1.2.840.10008.5.1.4.1.1.2	0
340	1	401	0
341	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
341	2	20250211T152517	0
341	3		0
341	8	RestApi	0
341	11	172.22.0.1	0
341	13	orthanc	0
341	9	1.2.840.10008.1.2.4.51	0
341	14	2776	0
341	10	1.2.840.10008.5.1.4.1.1.2	0
341	1	402	0
342	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
342	2	20250211T152517	0
342	3		0
342	8	RestApi	0
342	11	172.22.0.1	0
342	13	orthanc	0
342	9	1.2.840.10008.1.2.4.51	0
342	14	2776	0
342	10	1.2.840.10008.5.1.4.1.1.2	0
342	1	403	0
343	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
534	2	20250211T154521	0
534	3		0
534	8	RestApi	0
343	2	20250211T152517	0
343	3		0
343	8	RestApi	0
343	11	172.22.0.1	0
343	13	orthanc	0
343	9	1.2.840.10008.1.2.4.51	0
343	14	2776	0
343	10	1.2.840.10008.5.1.4.1.1.2	0
343	1	404	0
344	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
534	11	172.22.0.1	0
344	2	20250211T152517	0
344	3		0
344	8	RestApi	0
344	11	172.22.0.1	0
344	13	orthanc	0
344	9	1.2.840.10008.1.2.4.51	0
344	14	2776	0
344	10	1.2.840.10008.5.1.4.1.1.2	0
344	1	405	0
345	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
345	2	20250211T152517	0
345	3		0
345	8	RestApi	0
345	11	172.22.0.1	0
345	13	orthanc	0
345	9	1.2.840.10008.1.2.4.51	0
345	14	2776	0
345	10	1.2.840.10008.5.1.4.1.1.2	0
345	1	406	0
346	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
346	2	20250211T152517	0
346	3		0
346	8	RestApi	0
346	11	172.22.0.1	0
346	13	orthanc	0
346	9	1.2.840.10008.1.2.4.51	0
346	14	2776	0
346	10	1.2.840.10008.5.1.4.1.1.2	0
346	1	407	0
347	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
347	2	20250211T152517	0
347	3		0
347	8	RestApi	0
347	11	172.22.0.1	0
347	13	orthanc	0
347	9	1.2.840.10008.1.2.4.51	0
347	14	2776	0
347	10	1.2.840.10008.5.1.4.1.1.2	0
347	1	408	0
348	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
348	2	20250211T152517	0
348	3		0
348	8	RestApi	0
348	11	172.22.0.1	0
348	13	orthanc	0
348	9	1.2.840.10008.1.2.4.51	0
348	14	2776	0
348	10	1.2.840.10008.5.1.4.1.1.2	0
348	1	409	0
349	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
349	2	20250211T152517	0
349	3		0
349	8	RestApi	0
349	11	172.22.0.1	0
349	13	orthanc	0
349	9	1.2.840.10008.1.2.4.51	0
349	14	2776	0
349	10	1.2.840.10008.5.1.4.1.1.2	0
349	1	410	0
350	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
350	2	20250211T152517	0
350	3		0
350	8	RestApi	0
350	11	172.22.0.1	0
350	13	orthanc	0
350	9	1.2.840.10008.1.2.4.51	0
350	14	2770	0
350	10	1.2.840.10008.5.1.4.1.1.2	0
350	1	42	0
351	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
351	2	20250211T152517	0
351	3		0
351	8	RestApi	0
351	11	172.22.0.1	0
351	13	orthanc	0
351	9	1.2.840.10008.1.2.4.51	0
351	14	2778	0
351	10	1.2.840.10008.5.1.4.1.1.2	0
351	1	411	0
352	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
352	2	20250211T152517	0
352	3		0
352	8	RestApi	0
352	11	172.22.0.1	0
352	13	orthanc	0
352	9	1.2.840.10008.1.2.4.51	0
352	14	2776	0
352	10	1.2.840.10008.5.1.4.1.1.2	0
352	1	412	0
353	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
353	2	20250211T152517	0
353	3		0
353	8	RestApi	0
353	11	172.22.0.1	0
353	13	orthanc	0
353	9	1.2.840.10008.1.2.4.51	0
353	14	2776	0
353	10	1.2.840.10008.5.1.4.1.1.2	0
353	1	413	0
354	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
534	13	orthanc	0
534	9	1.2.840.10008.1.2.4.70	0
534	14	2630	0
354	2	20250211T152517	0
354	3		0
354	8	RestApi	0
354	11	172.22.0.1	0
354	13	orthanc	0
354	9	1.2.840.10008.1.2.4.51	0
354	14	2776	0
354	10	1.2.840.10008.5.1.4.1.1.2	0
354	1	414	0
355	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
534	10	1.2.840.10008.5.1.4.1.1.2	0
534	1	3	0
355	2	20250211T152517	0
355	3		0
355	8	RestApi	0
355	11	172.22.0.1	0
355	13	orthanc	0
355	9	1.2.840.10008.1.2.4.51	0
355	14	2776	0
355	10	1.2.840.10008.5.1.4.1.1.2	0
355	1	415	0
356	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
356	2	20250211T152517	0
356	3		0
356	8	RestApi	0
356	11	172.22.0.1	0
356	13	orthanc	0
356	9	1.2.840.10008.1.2.4.51	0
356	14	2776	0
356	10	1.2.840.10008.5.1.4.1.1.2	0
356	1	416	0
357	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
357	2	20250211T152517	0
357	3		0
357	8	RestApi	0
357	11	172.22.0.1	0
357	13	orthanc	0
357	9	1.2.840.10008.1.2.4.51	0
357	14	2776	0
357	10	1.2.840.10008.5.1.4.1.1.2	0
357	1	417	0
358	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
358	2	20250211T152517	0
358	3		0
358	8	RestApi	0
358	11	172.22.0.1	0
358	13	orthanc	0
358	9	1.2.840.10008.1.2.4.51	0
358	14	2776	0
358	10	1.2.840.10008.5.1.4.1.1.2	0
358	1	418	0
359	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
359	2	20250211T152517	0
359	3		0
359	8	RestApi	0
359	11	172.22.0.1	0
359	13	orthanc	0
359	9	1.2.840.10008.1.2.4.51	0
359	14	2776	0
359	10	1.2.840.10008.5.1.4.1.1.2	0
359	1	419	0
360	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
360	2	20250211T152517	0
360	3		0
360	8	RestApi	0
360	11	172.22.0.1	0
360	13	orthanc	0
360	9	1.2.840.10008.1.2.4.51	0
360	14	2776	0
360	10	1.2.840.10008.5.1.4.1.1.2	0
360	1	420	0
361	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
361	2	20250211T152517	0
361	3		0
361	8	RestApi	0
361	11	172.22.0.1	0
361	13	orthanc	0
361	9	1.2.840.10008.1.2.4.51	0
361	14	2772	0
361	10	1.2.840.10008.5.1.4.1.1.2	0
361	1	43	0
362	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
362	2	20250211T152517	0
362	3		0
362	8	RestApi	0
362	11	172.22.0.1	0
362	13	orthanc	0
362	9	1.2.840.10008.1.2.4.51	0
362	14	2776	0
362	10	1.2.840.10008.5.1.4.1.1.2	0
362	1	421	0
363	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
363	2	20250211T152517	0
363	3		0
363	8	RestApi	0
363	11	172.22.0.1	0
363	13	orthanc	0
363	9	1.2.840.10008.1.2.4.51	0
363	14	2776	0
363	10	1.2.840.10008.5.1.4.1.1.2	0
363	1	422	0
364	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
364	2	20250211T152517	0
364	3		0
364	8	RestApi	0
364	11	172.22.0.1	0
364	13	orthanc	0
364	9	1.2.840.10008.1.2.4.51	0
364	14	2776	0
364	10	1.2.840.10008.5.1.4.1.1.2	0
364	1	423	0
365	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
365	2	20250211T152517	0
365	3		0
365	8	RestApi	0
365	11	172.22.0.1	0
365	13	orthanc	0
365	9	1.2.840.10008.1.2.4.51	0
365	14	2776	0
365	10	1.2.840.10008.5.1.4.1.1.2	0
365	1	424	0
366	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
535	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
366	2	20250211T152517	0
366	3		0
366	8	RestApi	0
366	11	172.22.0.1	0
366	13	orthanc	0
366	9	1.2.840.10008.1.2.4.51	0
366	14	2776	0
366	10	1.2.840.10008.5.1.4.1.1.2	0
366	1	425	0
367	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
367	2	20250211T152517	0
367	3		0
367	8	RestApi	0
367	11	172.22.0.1	0
367	13	orthanc	0
367	9	1.2.840.10008.1.2.4.51	0
367	14	2776	0
367	10	1.2.840.10008.5.1.4.1.1.2	0
367	1	426	0
368	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
368	2	20250211T152517	0
368	3		0
368	8	RestApi	0
368	11	172.22.0.1	0
368	13	orthanc	0
368	9	1.2.840.10008.1.2.4.51	0
368	14	2776	0
368	10	1.2.840.10008.5.1.4.1.1.2	0
368	1	427	0
369	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
369	2	20250211T152517	0
369	3		0
369	8	RestApi	0
369	11	172.22.0.1	0
369	13	orthanc	0
369	9	1.2.840.10008.1.2.4.51	0
369	14	2776	0
369	10	1.2.840.10008.5.1.4.1.1.2	0
369	1	428	0
370	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
370	2	20250211T152517	0
370	3		0
370	8	RestApi	0
370	11	172.22.0.1	0
370	13	orthanc	0
370	9	1.2.840.10008.1.2.4.51	0
370	14	2776	0
370	10	1.2.840.10008.5.1.4.1.1.2	0
370	1	429	0
371	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
371	2	20250211T152517	0
371	3		0
371	8	RestApi	0
371	11	172.22.0.1	0
371	13	orthanc	0
371	9	1.2.840.10008.1.2.4.51	0
371	14	2776	0
371	10	1.2.840.10008.5.1.4.1.1.2	0
371	1	430	0
372	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
372	2	20250211T152517	0
372	3		0
372	8	RestApi	0
372	11	172.22.0.1	0
372	13	orthanc	0
372	9	1.2.840.10008.1.2.4.51	0
372	14	2772	0
372	10	1.2.840.10008.5.1.4.1.1.2	0
372	1	44	0
373	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
373	2	20250211T152517	0
373	3		0
373	8	RestApi	0
373	11	172.22.0.1	0
373	13	orthanc	0
373	9	1.2.840.10008.1.2.4.51	0
373	14	2776	0
373	10	1.2.840.10008.5.1.4.1.1.2	0
373	1	431	0
374	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
374	2	20250211T152518	0
374	3		0
374	8	RestApi	0
374	11	172.22.0.1	0
374	13	orthanc	0
374	9	1.2.840.10008.1.2.4.51	0
374	14	2776	0
374	10	1.2.840.10008.5.1.4.1.1.2	0
374	1	432	0
375	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
375	2	20250211T152518	0
375	3		0
375	8	RestApi	0
375	11	172.22.0.1	0
375	13	orthanc	0
375	9	1.2.840.10008.1.2.4.51	0
375	14	2778	0
375	10	1.2.840.10008.5.1.4.1.1.2	0
375	1	433	0
376	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
376	2	20250211T152518	0
376	3		0
376	8	RestApi	0
376	11	172.22.0.1	0
376	13	orthanc	0
376	9	1.2.840.10008.1.2.4.51	0
376	14	2776	0
376	10	1.2.840.10008.5.1.4.1.1.2	0
376	1	434	0
377	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
535	2	20250211T154521	0
535	3		0
535	8	RestApi	0
377	2	20250211T152518	0
377	3		0
377	8	RestApi	0
377	11	172.22.0.1	0
377	13	orthanc	0
377	9	1.2.840.10008.1.2.4.51	0
377	14	2776	0
377	10	1.2.840.10008.5.1.4.1.1.2	0
377	1	435	0
378	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
535	11	172.22.0.1	0
378	2	20250211T152518	0
378	3		0
378	8	RestApi	0
378	11	172.22.0.1	0
378	13	orthanc	0
378	9	1.2.840.10008.1.2.4.51	0
378	14	2776	0
378	10	1.2.840.10008.5.1.4.1.1.2	0
378	1	436	0
379	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
379	2	20250211T152518	0
379	3		0
379	8	RestApi	0
379	11	172.22.0.1	0
379	13	orthanc	0
379	9	1.2.840.10008.1.2.4.51	0
379	14	2776	0
379	10	1.2.840.10008.5.1.4.1.1.2	0
379	1	437	0
380	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
380	2	20250211T152518	0
380	3		0
380	8	RestApi	0
380	11	172.22.0.1	0
380	13	orthanc	0
380	9	1.2.840.10008.1.2.4.51	0
380	14	2776	0
380	10	1.2.840.10008.5.1.4.1.1.2	0
380	1	438	0
381	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
381	2	20250211T152518	0
381	3		0
381	8	RestApi	0
381	11	172.22.0.1	0
381	13	orthanc	0
381	9	1.2.840.10008.1.2.4.51	0
381	14	2776	0
381	10	1.2.840.10008.5.1.4.1.1.2	0
381	1	439	0
382	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
382	2	20250211T152518	0
382	3		0
382	8	RestApi	0
382	11	172.22.0.1	0
382	13	orthanc	0
382	9	1.2.840.10008.1.2.4.51	0
382	14	2776	0
382	10	1.2.840.10008.5.1.4.1.1.2	0
382	1	440	0
383	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
383	2	20250211T152518	0
383	3		0
383	8	RestApi	0
383	11	172.22.0.1	0
383	13	orthanc	0
383	9	1.2.840.10008.1.2.4.51	0
383	14	2770	0
383	10	1.2.840.10008.5.1.4.1.1.2	0
383	1	45	0
384	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
384	2	20250211T152518	0
384	3		0
384	8	RestApi	0
384	11	172.22.0.1	0
384	13	orthanc	0
384	9	1.2.840.10008.1.2.4.51	0
384	14	2776	0
384	10	1.2.840.10008.5.1.4.1.1.2	0
384	1	441	0
385	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
385	2	20250211T152518	0
385	3		0
385	8	RestApi	0
385	11	172.22.0.1	0
385	13	orthanc	0
385	9	1.2.840.10008.1.2.4.51	0
385	14	2776	0
385	10	1.2.840.10008.5.1.4.1.1.2	0
385	1	442	0
386	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
386	2	20250211T152518	0
386	3		0
386	8	RestApi	0
386	11	172.22.0.1	0
386	13	orthanc	0
386	9	1.2.840.10008.1.2.4.51	0
386	14	2776	0
386	10	1.2.840.10008.5.1.4.1.1.2	0
386	1	443	0
387	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
387	2	20250211T152518	0
387	3		0
387	8	RestApi	0
387	11	172.22.0.1	0
387	13	orthanc	0
387	9	1.2.840.10008.1.2.4.51	0
387	14	2776	0
387	10	1.2.840.10008.5.1.4.1.1.2	0
387	1	444	0
388	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
535	13	orthanc	0
535	9	1.2.840.10008.1.2.4.70	0
535	14	2630	0
388	2	20250211T152518	0
388	3		0
388	8	RestApi	0
388	11	172.22.0.1	0
388	13	orthanc	0
388	9	1.2.840.10008.1.2.4.51	0
388	14	2776	0
388	10	1.2.840.10008.5.1.4.1.1.2	0
388	1	445	0
389	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
535	10	1.2.840.10008.5.1.4.1.1.2	0
535	1	4	0
543	2	20250211T154521	0
389	2	20250211T152518	0
389	3		0
389	8	RestApi	0
389	11	172.22.0.1	0
389	13	orthanc	0
389	9	1.2.840.10008.1.2.4.51	0
389	14	2776	0
389	10	1.2.840.10008.5.1.4.1.1.2	0
389	1	446	0
390	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
390	2	20250211T152518	0
390	3		0
390	8	RestApi	0
390	11	172.22.0.1	0
390	13	orthanc	0
390	9	1.2.840.10008.1.2.4.51	0
390	14	2776	0
390	10	1.2.840.10008.5.1.4.1.1.2	0
390	1	447	0
391	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
391	2	20250211T152518	0
391	3		0
391	8	RestApi	0
391	11	172.22.0.1	0
391	13	orthanc	0
391	9	1.2.840.10008.1.2.4.51	0
391	14	2776	0
391	10	1.2.840.10008.5.1.4.1.1.2	0
391	1	448	0
392	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
392	2	20250211T152518	0
392	3		0
392	8	RestApi	0
392	11	172.22.0.1	0
392	13	orthanc	0
392	9	1.2.840.10008.1.2.4.51	0
392	14	2776	0
392	10	1.2.840.10008.5.1.4.1.1.2	0
392	1	449	0
393	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
393	2	20250211T152518	0
393	3		0
393	8	RestApi	0
393	11	172.22.0.1	0
393	13	orthanc	0
393	9	1.2.840.10008.1.2.4.51	0
393	14	2776	0
393	10	1.2.840.10008.5.1.4.1.1.2	0
393	1	450	0
394	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
394	2	20250211T152518	0
394	3		0
394	8	RestApi	0
394	11	172.22.0.1	0
394	13	orthanc	0
394	9	1.2.840.10008.1.2.4.51	0
394	14	2770	0
394	10	1.2.840.10008.5.1.4.1.1.2	0
394	1	46	0
395	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
395	2	20250211T152518	0
395	3		0
395	8	RestApi	0
395	11	172.22.0.1	0
395	13	orthanc	0
395	9	1.2.840.10008.1.2.4.51	0
395	14	2776	0
395	10	1.2.840.10008.5.1.4.1.1.2	0
395	1	451	0
396	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
396	2	20250211T152518	0
396	3		0
396	8	RestApi	0
396	11	172.22.0.1	0
396	13	orthanc	0
396	9	1.2.840.10008.1.2.4.51	0
396	14	2776	0
396	10	1.2.840.10008.5.1.4.1.1.2	0
396	1	452	0
397	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
397	2	20250211T152518	0
397	3		0
397	8	RestApi	0
397	11	172.22.0.1	0
397	13	orthanc	0
397	9	1.2.840.10008.1.2.4.51	0
397	14	2776	0
397	10	1.2.840.10008.5.1.4.1.1.2	0
397	1	453	0
398	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
398	2	20250211T152518	0
398	3		0
398	8	RestApi	0
398	11	172.22.0.1	0
398	13	orthanc	0
398	9	1.2.840.10008.1.2.4.51	0
398	14	2776	0
398	10	1.2.840.10008.5.1.4.1.1.2	0
398	1	454	0
399	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
399	2	20250211T152518	0
399	3		0
399	8	RestApi	0
399	11	172.22.0.1	0
399	13	orthanc	0
399	9	1.2.840.10008.1.2.4.51	0
399	14	2776	0
399	10	1.2.840.10008.5.1.4.1.1.2	0
399	1	455	0
400	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
536	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
400	2	20250211T152518	0
400	3		0
400	8	RestApi	0
400	11	172.22.0.1	0
400	13	orthanc	0
400	9	1.2.840.10008.1.2.4.51	0
400	14	2776	0
400	10	1.2.840.10008.5.1.4.1.1.2	0
400	1	456	0
401	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
401	2	20250211T152518	0
401	3		0
401	8	RestApi	0
401	11	172.22.0.1	0
401	13	orthanc	0
401	9	1.2.840.10008.1.2.4.51	0
401	14	2776	0
401	10	1.2.840.10008.5.1.4.1.1.2	0
401	1	457	0
402	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
402	2	20250211T152518	0
402	3		0
402	8	RestApi	0
402	11	172.22.0.1	0
402	13	orthanc	0
402	9	1.2.840.10008.1.2.4.51	0
402	14	2776	0
402	10	1.2.840.10008.5.1.4.1.1.2	0
402	1	458	0
403	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
403	2	20250211T152518	0
403	3		0
403	8	RestApi	0
403	11	172.22.0.1	0
403	13	orthanc	0
403	9	1.2.840.10008.1.2.4.51	0
403	14	2776	0
403	10	1.2.840.10008.5.1.4.1.1.2	0
403	1	459	0
404	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
404	2	20250211T152518	0
404	3		0
404	8	RestApi	0
404	11	172.22.0.1	0
404	13	orthanc	0
404	9	1.2.840.10008.1.2.4.51	0
404	14	2776	0
404	10	1.2.840.10008.5.1.4.1.1.2	0
404	1	460	0
405	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
405	2	20250211T152518	0
405	3		0
405	8	RestApi	0
405	11	172.22.0.1	0
405	13	orthanc	0
405	9	1.2.840.10008.1.2.4.51	0
405	14	2770	0
405	10	1.2.840.10008.5.1.4.1.1.2	0
405	1	47	0
406	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
406	2	20250211T152518	0
406	3		0
406	8	RestApi	0
406	11	172.22.0.1	0
406	13	orthanc	0
406	9	1.2.840.10008.1.2.4.51	0
406	14	2776	0
406	10	1.2.840.10008.5.1.4.1.1.2	0
406	1	461	0
407	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
407	2	20250211T152518	0
407	3		0
407	8	RestApi	0
407	11	172.22.0.1	0
407	13	orthanc	0
407	9	1.2.840.10008.1.2.4.51	0
407	14	2776	0
407	10	1.2.840.10008.5.1.4.1.1.2	0
407	1	462	0
408	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
408	2	20250211T152518	0
408	3		0
408	8	RestApi	0
408	11	172.22.0.1	0
408	13	orthanc	0
408	9	1.2.840.10008.1.2.4.51	0
408	14	2776	0
408	10	1.2.840.10008.5.1.4.1.1.2	0
408	1	463	0
409	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
409	2	20250211T152518	0
409	3		0
409	8	RestApi	0
409	11	172.22.0.1	0
409	13	orthanc	0
409	9	1.2.840.10008.1.2.4.51	0
409	14	2776	0
409	10	1.2.840.10008.5.1.4.1.1.2	0
409	1	464	0
410	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
410	2	20250211T152518	0
410	3		0
410	8	RestApi	0
410	11	172.22.0.1	0
410	13	orthanc	0
410	9	1.2.840.10008.1.2.4.51	0
410	14	2778	0
410	10	1.2.840.10008.5.1.4.1.1.2	0
410	1	465	0
411	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
536	2	20250211T154521	0
536	3		0
536	8	RestApi	0
411	2	20250211T152518	0
411	3		0
411	8	RestApi	0
411	11	172.22.0.1	0
411	13	orthanc	0
411	9	1.2.840.10008.1.2.4.51	0
411	14	2776	0
411	10	1.2.840.10008.5.1.4.1.1.2	0
411	1	466	0
412	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
536	11	172.22.0.1	0
412	2	20250211T152518	0
412	3		0
412	8	RestApi	0
412	11	172.22.0.1	0
412	13	orthanc	0
412	9	1.2.840.10008.1.2.4.51	0
412	14	2776	0
412	10	1.2.840.10008.5.1.4.1.1.2	0
412	1	467	0
413	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
413	2	20250211T152518	0
413	3		0
413	8	RestApi	0
413	11	172.22.0.1	0
413	13	orthanc	0
413	9	1.2.840.10008.1.2.4.51	0
413	14	2776	0
413	10	1.2.840.10008.5.1.4.1.1.2	0
413	1	468	0
414	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
414	2	20250211T152518	0
414	3		0
414	8	RestApi	0
414	11	172.22.0.1	0
414	13	orthanc	0
414	9	1.2.840.10008.1.2.4.51	0
414	14	2776	0
414	10	1.2.840.10008.5.1.4.1.1.2	0
414	1	469	0
415	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
415	2	20250211T152518	0
415	3		0
415	8	RestApi	0
415	11	172.22.0.1	0
415	13	orthanc	0
415	9	1.2.840.10008.1.2.4.51	0
415	14	2776	0
415	10	1.2.840.10008.5.1.4.1.1.2	0
415	1	470	0
416	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
416	2	20250211T152518	0
416	3		0
416	8	RestApi	0
416	11	172.22.0.1	0
416	13	orthanc	0
416	9	1.2.840.10008.1.2.4.51	0
416	14	2770	0
416	10	1.2.840.10008.5.1.4.1.1.2	0
416	1	48	0
417	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
417	2	20250211T152518	0
417	3		0
417	8	RestApi	0
417	11	172.22.0.1	0
417	13	orthanc	0
417	9	1.2.840.10008.1.2.4.51	0
417	14	2776	0
417	10	1.2.840.10008.5.1.4.1.1.2	0
417	1	471	0
418	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
418	2	20250211T152518	0
418	3		0
418	8	RestApi	0
418	11	172.22.0.1	0
418	13	orthanc	0
418	9	1.2.840.10008.1.2.4.51	0
418	14	2778	0
418	10	1.2.840.10008.5.1.4.1.1.2	0
418	1	472	0
419	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
419	2	20250211T152518	0
419	3		0
419	8	RestApi	0
419	11	172.22.0.1	0
419	13	orthanc	0
419	9	1.2.840.10008.1.2.4.51	0
419	14	2778	0
419	10	1.2.840.10008.5.1.4.1.1.2	0
419	1	473	0
420	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
420	2	20250211T152518	0
420	3		0
420	8	RestApi	0
420	11	172.22.0.1	0
420	13	orthanc	0
420	9	1.2.840.10008.1.2.4.51	0
420	14	2776	0
420	10	1.2.840.10008.5.1.4.1.1.2	0
420	1	474	0
421	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
421	2	20250211T152518	0
421	3		0
421	8	RestApi	0
421	11	172.22.0.1	0
421	13	orthanc	0
421	9	1.2.840.10008.1.2.4.51	0
421	14	2776	0
421	10	1.2.840.10008.5.1.4.1.1.2	0
421	1	475	0
422	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
536	13	orthanc	0
536	9	1.2.840.10008.1.2.4.70	0
536	14	2630	0
422	2	20250211T152518	0
422	3		0
422	8	RestApi	0
422	11	172.22.0.1	0
422	13	orthanc	0
422	9	1.2.840.10008.1.2.4.51	0
422	14	2776	0
422	10	1.2.840.10008.5.1.4.1.1.2	0
422	1	476	0
423	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
536	10	1.2.840.10008.5.1.4.1.1.2	0
536	1	5	0
543	3		0
423	2	20250211T152518	0
423	3		0
423	8	RestApi	0
423	11	172.22.0.1	0
423	13	orthanc	0
423	9	1.2.840.10008.1.2.4.51	0
423	14	2776	0
423	10	1.2.840.10008.5.1.4.1.1.2	0
423	1	477	0
424	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
543	8	RestApi	0
424	2	20250211T152518	0
424	3		0
424	8	RestApi	0
424	11	172.22.0.1	0
424	13	orthanc	0
424	9	1.2.840.10008.1.2.4.51	0
424	14	2776	0
424	10	1.2.840.10008.5.1.4.1.1.2	0
424	1	478	0
425	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
425	2	20250211T152518	0
425	3		0
425	8	RestApi	0
425	11	172.22.0.1	0
425	13	orthanc	0
425	9	1.2.840.10008.1.2.4.51	0
425	14	2778	0
425	10	1.2.840.10008.5.1.4.1.1.2	0
425	1	479	0
426	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
426	2	20250211T152518	0
426	3		0
426	8	RestApi	0
426	11	172.22.0.1	0
426	13	orthanc	0
426	9	1.2.840.10008.1.2.4.51	0
426	14	2776	0
426	10	1.2.840.10008.5.1.4.1.1.2	0
426	1	480	0
427	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
427	2	20250211T152518	0
427	3		0
427	8	RestApi	0
427	11	172.22.0.1	0
427	13	orthanc	0
427	9	1.2.840.10008.1.2.4.51	0
427	14	2770	0
427	10	1.2.840.10008.5.1.4.1.1.2	0
427	1	49	0
428	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
428	2	20250211T152518	0
428	3		0
428	8	RestApi	0
428	11	172.22.0.1	0
428	13	orthanc	0
428	9	1.2.840.10008.1.2.4.51	0
428	14	2776	0
428	10	1.2.840.10008.5.1.4.1.1.2	0
428	1	481	0
429	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
429	2	20250211T152518	0
429	3		0
429	8	RestApi	0
429	11	172.22.0.1	0
429	13	orthanc	0
429	9	1.2.840.10008.1.2.4.51	0
429	14	2776	0
429	10	1.2.840.10008.5.1.4.1.1.2	0
429	1	482	0
430	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
430	2	20250211T152518	0
430	3		0
430	8	RestApi	0
430	11	172.22.0.1	0
430	13	orthanc	0
430	9	1.2.840.10008.1.2.4.51	0
430	14	2776	0
430	10	1.2.840.10008.5.1.4.1.1.2	0
430	1	483	0
431	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
431	2	20250211T152518	0
431	3		0
431	8	RestApi	0
431	11	172.22.0.1	0
431	13	orthanc	0
431	9	1.2.840.10008.1.2.4.51	0
431	14	2776	0
431	10	1.2.840.10008.5.1.4.1.1.2	0
431	1	484	0
432	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
432	2	20250211T152518	0
432	3		0
432	8	RestApi	0
432	11	172.22.0.1	0
432	13	orthanc	0
432	9	1.2.840.10008.1.2.4.51	0
432	14	2776	0
432	10	1.2.840.10008.5.1.4.1.1.2	0
432	1	485	0
433	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
433	2	20250211T152518	0
433	3		0
433	8	RestApi	0
433	11	172.22.0.1	0
433	13	orthanc	0
433	9	1.2.840.10008.1.2.4.51	0
433	14	2776	0
433	10	1.2.840.10008.5.1.4.1.1.2	0
433	1	486	0
434	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
537	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
434	2	20250211T152518	0
434	3		0
434	8	RestApi	0
434	11	172.22.0.1	0
434	13	orthanc	0
434	9	1.2.840.10008.1.2.4.51	0
434	14	2776	0
434	10	1.2.840.10008.5.1.4.1.1.2	0
434	1	487	0
435	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
435	2	20250211T152518	0
435	3		0
435	8	RestApi	0
435	11	172.22.0.1	0
435	13	orthanc	0
435	9	1.2.840.10008.1.2.4.51	0
435	14	2776	0
435	10	1.2.840.10008.5.1.4.1.1.2	0
435	1	488	0
436	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
436	2	20250211T152518	0
436	3		0
436	8	RestApi	0
436	11	172.22.0.1	0
436	13	orthanc	0
436	9	1.2.840.10008.1.2.4.51	0
436	14	2778	0
436	10	1.2.840.10008.5.1.4.1.1.2	0
436	1	489	0
437	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
437	2	20250211T152518	0
437	3		0
437	8	RestApi	0
437	11	172.22.0.1	0
437	13	orthanc	0
437	9	1.2.840.10008.1.2.4.51	0
437	14	2776	0
437	10	1.2.840.10008.5.1.4.1.1.2	0
437	1	490	0
438	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
438	2	20250211T152518	0
438	3		0
438	8	RestApi	0
438	11	172.22.0.1	0
438	13	orthanc	0
438	9	1.2.840.10008.1.2.4.51	0
438	14	2770	0
438	10	1.2.840.10008.5.1.4.1.1.2	0
438	1	50	0
439	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
439	2	20250211T152518	0
439	3		0
439	8	RestApi	0
439	11	172.22.0.1	0
439	13	orthanc	0
439	9	1.2.840.10008.1.2.4.51	0
439	14	2776	0
439	10	1.2.840.10008.5.1.4.1.1.2	0
439	1	491	0
440	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
440	2	20250211T152518	0
440	3		0
440	8	RestApi	0
440	11	172.22.0.1	0
440	13	orthanc	0
440	9	1.2.840.10008.1.2.4.51	0
440	14	2776	0
440	10	1.2.840.10008.5.1.4.1.1.2	0
440	1	492	0
441	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
441	2	20250211T152518	0
441	3		0
441	8	RestApi	0
441	11	172.22.0.1	0
441	13	orthanc	0
441	9	1.2.840.10008.1.2.4.51	0
441	14	2776	0
441	10	1.2.840.10008.5.1.4.1.1.2	0
441	1	493	0
442	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
442	2	20250211T152518	0
442	3		0
442	8	RestApi	0
442	11	172.22.0.1	0
442	13	orthanc	0
442	9	1.2.840.10008.1.2.4.51	0
442	14	2776	0
442	10	1.2.840.10008.5.1.4.1.1.2	0
442	1	494	0
443	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
443	2	20250211T152518	0
443	3		0
443	8	RestApi	0
443	11	172.22.0.1	0
443	13	orthanc	0
443	9	1.2.840.10008.1.2.4.51	0
443	14	2776	0
443	10	1.2.840.10008.5.1.4.1.1.2	0
443	1	495	0
444	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
444	2	20250211T152518	0
444	3		0
444	8	RestApi	0
444	11	172.22.0.1	0
444	13	orthanc	0
444	9	1.2.840.10008.1.2.4.51	0
444	14	2778	0
444	10	1.2.840.10008.5.1.4.1.1.2	0
444	1	496	0
445	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
537	2	20250211T154521	0
537	3		0
537	8	RestApi	0
445	2	20250211T152518	0
445	3		0
445	8	RestApi	0
445	11	172.22.0.1	0
445	13	orthanc	0
445	9	1.2.840.10008.1.2.4.51	0
445	14	2776	0
445	10	1.2.840.10008.5.1.4.1.1.2	0
445	1	497	0
446	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
537	11	172.22.0.1	0
446	2	20250211T152518	0
446	3		0
446	8	RestApi	0
446	11	172.22.0.1	0
446	13	orthanc	0
446	9	1.2.840.10008.1.2.4.51	0
446	14	2780	0
446	10	1.2.840.10008.5.1.4.1.1.2	0
446	1	498	0
447	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
447	2	20250211T152518	0
447	3		0
447	8	RestApi	0
447	11	172.22.0.1	0
447	13	orthanc	0
447	9	1.2.840.10008.1.2.4.51	0
447	14	2782	0
447	10	1.2.840.10008.5.1.4.1.1.2	0
447	1	499	0
448	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
448	2	20250211T152518	0
448	3		0
448	8	RestApi	0
448	11	172.22.0.1	0
448	13	orthanc	0
448	9	1.2.840.10008.1.2.4.51	0
448	14	2782	0
448	10	1.2.840.10008.5.1.4.1.1.2	0
448	1	500	0
449	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
449	2	20250211T152518	0
449	3		0
449	8	RestApi	0
449	11	172.22.0.1	0
449	13	orthanc	0
449	9	1.2.840.10008.1.2.4.51	0
449	14	2770	0
449	10	1.2.840.10008.5.1.4.1.1.2	0
449	1	6	0
450	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
450	2	20250211T152518	0
450	3		0
450	8	RestApi	0
450	11	172.22.0.1	0
450	13	orthanc	0
450	9	1.2.840.10008.1.2.4.51	0
450	14	2770	0
450	10	1.2.840.10008.5.1.4.1.1.2	0
450	1	51	0
451	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
451	2	20250211T152518	0
451	3		0
451	8	RestApi	0
451	11	172.22.0.1	0
451	13	orthanc	0
451	9	1.2.840.10008.1.2.4.51	0
451	14	2782	0
451	10	1.2.840.10008.5.1.4.1.1.2	0
451	1	501	0
452	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
452	2	20250211T152518	0
452	3		0
452	8	RestApi	0
452	11	172.22.0.1	0
452	13	orthanc	0
452	9	1.2.840.10008.1.2.4.51	0
452	14	2782	0
452	10	1.2.840.10008.5.1.4.1.1.2	0
452	1	502	0
453	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
453	2	20250211T152518	0
453	3		0
453	8	RestApi	0
453	11	172.22.0.1	0
453	13	orthanc	0
453	9	1.2.840.10008.1.2.4.51	0
453	14	2784	0
453	10	1.2.840.10008.5.1.4.1.1.2	0
453	1	503	0
454	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
454	2	20250211T152518	0
454	3		0
454	8	RestApi	0
454	11	172.22.0.1	0
454	13	orthanc	0
454	9	1.2.840.10008.1.2.4.51	0
454	14	2782	0
454	10	1.2.840.10008.5.1.4.1.1.2	0
454	1	504	0
455	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
455	2	20250211T152518	0
455	3		0
455	8	RestApi	0
455	11	172.22.0.1	0
455	13	orthanc	0
455	9	1.2.840.10008.1.2.4.51	0
455	14	2782	0
455	10	1.2.840.10008.5.1.4.1.1.2	0
455	1	505	0
456	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
537	13	orthanc	0
537	9	1.2.840.10008.1.2.4.70	0
537	14	2630	0
456	2	20250211T152518	0
456	3		0
456	8	RestApi	0
456	11	172.22.0.1	0
456	13	orthanc	0
456	9	1.2.840.10008.1.2.4.51	0
456	14	2782	0
456	10	1.2.840.10008.5.1.4.1.1.2	0
456	1	506	0
457	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
537	10	1.2.840.10008.5.1.4.1.1.2	0
537	1	6	0
543	11	172.22.0.1	0
457	2	20250211T152518	0
457	3		0
457	8	RestApi	0
457	11	172.22.0.1	0
457	13	orthanc	0
457	9	1.2.840.10008.1.2.4.51	0
457	14	2782	0
457	10	1.2.840.10008.5.1.4.1.1.2	0
457	1	507	0
458	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
458	2	20250211T152518	0
458	3		0
458	8	RestApi	0
458	11	172.22.0.1	0
458	13	orthanc	0
458	9	1.2.840.10008.1.2.4.51	0
458	14	2782	0
458	10	1.2.840.10008.5.1.4.1.1.2	0
458	1	508	0
459	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
459	2	20250211T152518	0
459	3		0
459	8	RestApi	0
459	11	172.22.0.1	0
459	13	orthanc	0
459	9	1.2.840.10008.1.2.4.51	0
459	14	2782	0
459	10	1.2.840.10008.5.1.4.1.1.2	0
459	1	509	0
460	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
460	2	20250211T152518	0
460	3		0
460	8	RestApi	0
460	11	172.22.0.1	0
460	13	orthanc	0
460	9	1.2.840.10008.1.2.4.51	0
460	14	2782	0
460	10	1.2.840.10008.5.1.4.1.1.2	0
460	1	510	0
461	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
461	2	20250211T152518	0
461	3		0
461	8	RestApi	0
461	11	172.22.0.1	0
461	13	orthanc	0
461	9	1.2.840.10008.1.2.4.51	0
461	14	2770	0
461	10	1.2.840.10008.5.1.4.1.1.2	0
461	1	52	0
462	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
462	2	20250211T152518	0
462	3		0
462	8	RestApi	0
462	11	172.22.0.1	0
462	13	orthanc	0
462	9	1.2.840.10008.1.2.4.51	0
462	14	2782	0
462	10	1.2.840.10008.5.1.4.1.1.2	0
462	1	511	0
463	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
463	2	20250211T152518	0
463	3		0
463	8	RestApi	0
463	11	172.22.0.1	0
463	13	orthanc	0
463	9	1.2.840.10008.1.2.4.51	0
463	14	2782	0
463	10	1.2.840.10008.5.1.4.1.1.2	0
463	1	512	0
464	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
464	2	20250211T152518	0
464	3		0
464	8	RestApi	0
464	11	172.22.0.1	0
464	13	orthanc	0
464	9	1.2.840.10008.1.2.4.51	0
464	14	2782	0
464	10	1.2.840.10008.5.1.4.1.1.2	0
464	1	513	0
465	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
465	2	20250211T152518	0
465	3		0
465	8	RestApi	0
465	11	172.22.0.1	0
465	13	orthanc	0
465	9	1.2.840.10008.1.2.4.51	0
465	14	2782	0
465	10	1.2.840.10008.5.1.4.1.1.2	0
465	1	514	0
466	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
466	2	20250211T152518	0
466	3		0
466	8	RestApi	0
466	11	172.22.0.1	0
466	13	orthanc	0
466	9	1.2.840.10008.1.2.4.51	0
466	14	2782	0
466	10	1.2.840.10008.5.1.4.1.1.2	0
466	1	515	0
467	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
467	2	20250211T152518	0
467	3		0
467	8	RestApi	0
467	11	172.22.0.1	0
467	13	orthanc	0
467	9	1.2.840.10008.1.2.4.51	0
467	14	2782	0
467	10	1.2.840.10008.5.1.4.1.1.2	0
467	1	516	0
468	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
538	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
468	2	20250211T152518	0
468	3		0
468	8	RestApi	0
468	11	172.22.0.1	0
468	13	orthanc	0
468	9	1.2.840.10008.1.2.4.51	0
468	14	2784	0
468	10	1.2.840.10008.5.1.4.1.1.2	0
468	1	517	0
469	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
469	2	20250211T152518	0
469	3		0
469	8	RestApi	0
469	11	172.22.0.1	0
469	13	orthanc	0
469	9	1.2.840.10008.1.2.4.51	0
469	14	2770	0
469	10	1.2.840.10008.5.1.4.1.1.2	0
469	1	53	0
470	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
470	2	20250211T152518	0
470	3		0
470	8	RestApi	0
470	11	172.22.0.1	0
470	13	orthanc	0
470	9	1.2.840.10008.1.2.4.51	0
470	14	2770	0
470	10	1.2.840.10008.5.1.4.1.1.2	0
470	1	54	0
471	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
471	2	20250211T152518	0
471	3		0
471	8	RestApi	0
471	11	172.22.0.1	0
471	13	orthanc	0
471	9	1.2.840.10008.1.2.4.51	0
471	14	2770	0
471	10	1.2.840.10008.5.1.4.1.1.2	0
471	1	55	0
472	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
472	2	20250211T152518	0
472	3		0
472	8	RestApi	0
472	11	172.22.0.1	0
472	13	orthanc	0
472	9	1.2.840.10008.1.2.4.51	0
472	14	2770	0
472	10	1.2.840.10008.5.1.4.1.1.2	0
472	1	56	0
473	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
473	2	20250211T152518	0
473	3		0
473	8	RestApi	0
473	11	172.22.0.1	0
473	13	orthanc	0
473	9	1.2.840.10008.1.2.4.51	0
473	14	2770	0
473	10	1.2.840.10008.5.1.4.1.1.2	0
473	1	57	0
474	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
474	2	20250211T152518	0
474	3		0
474	8	RestApi	0
474	11	172.22.0.1	0
474	13	orthanc	0
474	9	1.2.840.10008.1.2.4.51	0
474	14	2770	0
474	10	1.2.840.10008.5.1.4.1.1.2	0
474	1	58	0
475	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
475	2	20250211T152518	0
475	3		0
475	8	RestApi	0
475	11	172.22.0.1	0
475	13	orthanc	0
475	9	1.2.840.10008.1.2.4.51	0
475	14	2770	0
475	10	1.2.840.10008.5.1.4.1.1.2	0
475	1	59	0
476	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
476	2	20250211T152518	0
476	3		0
476	8	RestApi	0
476	11	172.22.0.1	0
476	13	orthanc	0
476	9	1.2.840.10008.1.2.4.51	0
476	14	2770	0
476	10	1.2.840.10008.5.1.4.1.1.2	0
476	1	60	0
477	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
477	2	20250211T152518	0
477	3		0
477	8	RestApi	0
477	11	172.22.0.1	0
477	13	orthanc	0
477	9	1.2.840.10008.1.2.4.51	0
477	14	2770	0
477	10	1.2.840.10008.5.1.4.1.1.2	0
477	1	7	0
478	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
478	2	20250211T152518	0
478	3		0
478	8	RestApi	0
478	11	172.22.0.1	0
478	13	orthanc	0
478	9	1.2.840.10008.1.2.4.51	0
478	14	2770	0
478	10	1.2.840.10008.5.1.4.1.1.2	0
478	1	61	0
479	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
538	2	20250211T154521	0
538	3		0
538	8	RestApi	0
479	2	20250211T152518	0
479	3		0
479	8	RestApi	0
479	11	172.22.0.1	0
479	13	orthanc	0
479	9	1.2.840.10008.1.2.4.51	0
479	14	2770	0
479	10	1.2.840.10008.5.1.4.1.1.2	0
479	1	62	0
480	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
538	11	172.22.0.1	0
480	2	20250211T152518	0
480	3		0
480	8	RestApi	0
480	11	172.22.0.1	0
480	13	orthanc	0
480	9	1.2.840.10008.1.2.4.51	0
480	14	2770	0
480	10	1.2.840.10008.5.1.4.1.1.2	0
480	1	63	0
481	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
481	2	20250211T152518	0
481	3		0
481	8	RestApi	0
481	11	172.22.0.1	0
481	13	orthanc	0
481	9	1.2.840.10008.1.2.4.51	0
481	14	2770	0
481	10	1.2.840.10008.5.1.4.1.1.2	0
481	1	64	0
482	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
482	2	20250211T152518	0
482	3		0
482	8	RestApi	0
482	11	172.22.0.1	0
482	13	orthanc	0
482	9	1.2.840.10008.1.2.4.51	0
482	14	2770	0
482	10	1.2.840.10008.5.1.4.1.1.2	0
482	1	65	0
483	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
483	2	20250211T152518	0
483	3		0
483	8	RestApi	0
483	11	172.22.0.1	0
483	13	orthanc	0
483	9	1.2.840.10008.1.2.4.51	0
483	14	2770	0
483	10	1.2.840.10008.5.1.4.1.1.2	0
483	1	66	0
484	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
484	2	20250211T152518	0
484	3		0
484	8	RestApi	0
484	11	172.22.0.1	0
484	13	orthanc	0
484	9	1.2.840.10008.1.2.4.51	0
484	14	2772	0
484	10	1.2.840.10008.5.1.4.1.1.2	0
484	1	67	0
485	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
485	2	20250211T152518	0
485	3		0
485	8	RestApi	0
485	11	172.22.0.1	0
485	13	orthanc	0
485	9	1.2.840.10008.1.2.4.51	0
485	14	2772	0
485	10	1.2.840.10008.5.1.4.1.1.2	0
485	1	68	0
486	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
486	2	20250211T152518	0
486	3		0
486	8	RestApi	0
486	11	172.22.0.1	0
486	13	orthanc	0
486	9	1.2.840.10008.1.2.4.51	0
486	14	2772	0
486	10	1.2.840.10008.5.1.4.1.1.2	0
486	1	69	0
487	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
487	2	20250211T152518	0
487	3		0
487	8	RestApi	0
487	11	172.22.0.1	0
487	13	orthanc	0
487	9	1.2.840.10008.1.2.4.51	0
487	14	2770	0
487	10	1.2.840.10008.5.1.4.1.1.2	0
487	1	70	0
488	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
488	2	20250211T152518	0
488	3		0
488	8	RestApi	0
488	11	172.22.0.1	0
488	13	orthanc	0
488	9	1.2.840.10008.1.2.4.51	0
488	14	2770	0
488	10	1.2.840.10008.5.1.4.1.1.2	0
488	1	8	0
489	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
489	2	20250211T152518	0
489	3		0
489	8	RestApi	0
489	11	172.22.0.1	0
489	13	orthanc	0
489	9	1.2.840.10008.1.2.4.51	0
489	14	2770	0
489	10	1.2.840.10008.5.1.4.1.1.2	0
489	1	71	0
490	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
538	13	orthanc	0
538	9	1.2.840.10008.1.2.4.70	0
538	14	2630	0
490	2	20250211T152518	0
490	3		0
490	8	RestApi	0
490	11	172.22.0.1	0
490	13	orthanc	0
490	9	1.2.840.10008.1.2.4.51	0
490	14	2770	0
490	10	1.2.840.10008.5.1.4.1.1.2	0
490	1	72	0
491	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
538	10	1.2.840.10008.5.1.4.1.1.2	0
538	1	7	0
543	13	orthanc	0
491	2	20250211T152518	0
491	3		0
491	8	RestApi	0
491	11	172.22.0.1	0
491	13	orthanc	0
491	9	1.2.840.10008.1.2.4.51	0
491	14	2768	0
491	10	1.2.840.10008.5.1.4.1.1.2	0
491	1	73	0
492	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
492	2	20250211T152518	0
492	3		0
492	8	RestApi	0
492	11	172.22.0.1	0
492	13	orthanc	0
492	9	1.2.840.10008.1.2.4.51	0
492	14	2770	0
492	10	1.2.840.10008.5.1.4.1.1.2	0
492	1	74	0
493	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
493	2	20250211T152518	0
493	3		0
493	8	RestApi	0
493	11	172.22.0.1	0
493	13	orthanc	0
493	9	1.2.840.10008.1.2.4.51	0
493	14	2772	0
493	10	1.2.840.10008.5.1.4.1.1.2	0
493	1	75	0
494	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
494	2	20250211T152518	0
494	3		0
494	8	RestApi	0
494	11	172.22.0.1	0
494	13	orthanc	0
494	9	1.2.840.10008.1.2.4.51	0
494	14	2772	0
494	10	1.2.840.10008.5.1.4.1.1.2	0
494	1	76	0
495	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
495	2	20250211T152518	0
495	3		0
495	8	RestApi	0
495	11	172.22.0.1	0
495	13	orthanc	0
495	9	1.2.840.10008.1.2.4.51	0
495	14	2772	0
495	10	1.2.840.10008.5.1.4.1.1.2	0
495	1	77	0
496	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
496	2	20250211T152518	0
496	3		0
496	8	RestApi	0
496	11	172.22.0.1	0
496	13	orthanc	0
496	9	1.2.840.10008.1.2.4.51	0
496	14	2770	0
496	10	1.2.840.10008.5.1.4.1.1.2	0
496	1	78	0
497	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
497	2	20250211T152518	0
497	3		0
497	8	RestApi	0
497	11	172.22.0.1	0
497	13	orthanc	0
497	9	1.2.840.10008.1.2.4.51	0
497	14	2770	0
497	10	1.2.840.10008.5.1.4.1.1.2	0
497	1	79	0
498	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
498	2	20250211T152518	0
498	3		0
498	8	RestApi	0
498	11	172.22.0.1	0
498	13	orthanc	0
498	9	1.2.840.10008.1.2.4.51	0
498	14	2772	0
498	10	1.2.840.10008.5.1.4.1.1.2	0
498	1	80	0
499	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
499	2	20250211T152518	0
499	3		0
499	8	RestApi	0
499	11	172.22.0.1	0
499	13	orthanc	0
499	9	1.2.840.10008.1.2.4.51	0
499	14	2770	0
499	10	1.2.840.10008.5.1.4.1.1.2	0
499	1	9	0
500	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
500	2	20250211T152518	0
500	3		0
500	8	RestApi	0
500	11	172.22.0.1	0
500	13	orthanc	0
500	9	1.2.840.10008.1.2.4.51	0
500	14	2772	0
500	10	1.2.840.10008.5.1.4.1.1.2	0
500	1	81	0
501	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
501	2	20250211T152518	0
501	3		0
501	8	RestApi	0
501	11	172.22.0.1	0
501	13	orthanc	0
501	9	1.2.840.10008.1.2.4.51	0
501	14	2772	0
501	10	1.2.840.10008.5.1.4.1.1.2	0
501	1	82	0
502	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
539	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
502	2	20250211T152518	0
502	3		0
502	8	RestApi	0
502	11	172.22.0.1	0
502	13	orthanc	0
502	9	1.2.840.10008.1.2.4.51	0
502	14	2770	0
502	10	1.2.840.10008.5.1.4.1.1.2	0
502	1	83	0
503	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
503	2	20250211T152518	0
503	3		0
503	8	RestApi	0
503	11	172.22.0.1	0
503	13	orthanc	0
503	9	1.2.840.10008.1.2.4.51	0
503	14	2770	0
503	10	1.2.840.10008.5.1.4.1.1.2	0
503	1	84	0
504	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
504	2	20250211T152518	0
504	3		0
504	8	RestApi	0
504	11	172.22.0.1	0
504	13	orthanc	0
504	9	1.2.840.10008.1.2.4.51	0
504	14	2770	0
504	10	1.2.840.10008.5.1.4.1.1.2	0
504	1	85	0
505	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
505	2	20250211T152518	0
505	3		0
505	8	RestApi	0
505	11	172.22.0.1	0
505	13	orthanc	0
505	9	1.2.840.10008.1.2.4.51	0
505	14	2770	0
505	10	1.2.840.10008.5.1.4.1.1.2	0
505	1	86	0
506	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
506	2	20250211T152518	0
506	3		0
506	8	RestApi	0
506	11	172.22.0.1	0
506	13	orthanc	0
506	9	1.2.840.10008.1.2.4.51	0
506	14	2770	0
506	10	1.2.840.10008.5.1.4.1.1.2	0
506	1	87	0
507	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
507	2	20250211T152518	0
507	3		0
507	8	RestApi	0
507	11	172.22.0.1	0
507	13	orthanc	0
507	9	1.2.840.10008.1.2.4.51	0
507	14	2770	0
507	10	1.2.840.10008.5.1.4.1.1.2	0
507	1	88	0
508	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
508	2	20250211T152518	0
508	3		0
508	8	RestApi	0
508	11	172.22.0.1	0
508	13	orthanc	0
508	9	1.2.840.10008.1.2.4.51	0
508	14	2770	0
508	10	1.2.840.10008.5.1.4.1.1.2	0
508	1	89	0
509	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
509	2	20250211T152518	0
509	3		0
509	8	RestApi	0
509	11	172.22.0.1	0
509	13	orthanc	0
509	9	1.2.840.10008.1.2.4.51	0
509	14	2770	0
509	10	1.2.840.10008.5.1.4.1.1.2	0
509	1	90	0
510	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
510	2	20250211T152518	0
510	3		0
510	8	RestApi	0
510	11	172.22.0.1	0
510	13	orthanc	0
510	9	1.2.840.10008.1.2.4.51	0
510	14	2770	0
510	10	1.2.840.10008.5.1.4.1.1.2	0
510	1	10	0
511	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
511	2	20250211T152518	0
511	3		0
511	8	RestApi	0
511	11	172.22.0.1	0
511	13	orthanc	0
511	9	1.2.840.10008.1.2.4.51	0
511	14	2770	0
511	10	1.2.840.10008.5.1.4.1.1.2	0
511	1	91	0
512	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
512	2	20250211T152518	0
512	3		0
512	8	RestApi	0
512	11	172.22.0.1	0
512	13	orthanc	0
512	9	1.2.840.10008.1.2.4.51	0
512	14	2770	0
512	10	1.2.840.10008.5.1.4.1.1.2	0
512	1	92	0
513	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
539	2	20250211T154521	0
539	3		0
539	8	RestApi	0
513	2	20250211T152518	0
513	3		0
513	8	RestApi	0
513	11	172.22.0.1	0
513	13	orthanc	0
513	9	1.2.840.10008.1.2.4.51	0
513	14	2770	0
513	10	1.2.840.10008.5.1.4.1.1.2	0
513	1	93	0
514	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
539	11	172.22.0.1	0
539	13	orthanc	0
539	9	1.2.840.10008.1.2.4.70	0
514	2	20250211T152518	0
514	3		0
514	8	RestApi	0
514	11	172.22.0.1	0
514	13	orthanc	0
514	9	1.2.840.10008.1.2.4.51	0
514	14	2770	0
514	10	1.2.840.10008.5.1.4.1.1.2	0
514	1	94	0
515	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
539	14	3196	0
539	10	1.2.840.10008.5.1.4.1.1.2	0
539	1	10	0
515	2	20250211T152518	0
515	3		0
515	8	RestApi	0
515	11	172.22.0.1	0
515	13	orthanc	0
515	9	1.2.840.10008.1.2.4.51	0
515	14	2770	0
515	10	1.2.840.10008.5.1.4.1.1.2	0
515	1	95	0
516	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
540	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
516	2	20250211T152518	0
516	3		0
516	8	RestApi	0
516	11	172.22.0.1	0
516	13	orthanc	0
516	9	1.2.840.10008.1.2.4.51	0
516	14	2770	0
516	10	1.2.840.10008.5.1.4.1.1.2	0
516	1	96	0
517	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
540	2	20250211T154521	0
540	3		0
517	2	20250211T152518	0
517	3		0
517	8	RestApi	0
517	11	172.22.0.1	0
517	13	orthanc	0
517	9	1.2.840.10008.1.2.4.51	0
517	14	2770	0
517	10	1.2.840.10008.5.1.4.1.1.2	0
517	1	97	0
518	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
540	8	RestApi	0
540	11	172.22.0.1	0
540	13	orthanc	0
518	2	20250211T152518	0
518	3		0
518	8	RestApi	0
518	11	172.22.0.1	0
518	13	orthanc	0
518	9	1.2.840.10008.1.2.4.51	0
518	14	2770	0
518	10	1.2.840.10008.5.1.4.1.1.2	0
518	1	98	0
519	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
540	9	1.2.840.10008.1.2.4.70	0
540	14	2630	0
540	10	1.2.840.10008.5.1.4.1.1.2	0
519	2	20250211T152518	0
519	3		0
519	8	RestApi	0
519	11	172.22.0.1	0
519	13	orthanc	0
519	9	1.2.840.10008.1.2.4.51	0
519	14	2770	0
519	10	1.2.840.10008.5.1.4.1.1.2	0
519	1	99	0
520	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
3	7	20250211T152518	0
2	7	20250211T152518	0
520	2	20250211T152518	0
520	3		0
520	8	RestApi	0
520	11	172.22.0.1	0
520	13	orthanc	0
520	9	1.2.840.10008.1.2.4.51	0
520	14	2774	0
520	10	1.2.840.10008.5.1.4.1.1.2	0
520	1	100	0
540	1	8	0
541	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
541	2	20250211T154521	0
541	3		0
541	8	RestApi	0
541	11	172.22.0.1	0
541	13	orthanc	0
541	9	1.2.840.10008.1.2.4.70	0
541	14	2630	0
541	10	1.2.840.10008.5.1.4.1.1.2	0
541	1	9	0
542	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
543	10	1.2.840.10008.5.1.4.1.1.2	0
543	1	11	0
544	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
544	2	20250211T154521	0
544	3		0
544	8	RestApi	0
544	11	172.22.0.1	0
544	13	orthanc	0
544	9	1.2.840.10008.1.2.4.70	0
544	14	2630	0
544	10	1.2.840.10008.5.1.4.1.1.2	0
544	1	12	0
545	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
545	2	20250211T154521	0
545	3		0
545	8	RestApi	0
545	11	172.22.0.1	0
545	13	orthanc	0
545	9	1.2.840.10008.1.2.4.70	0
545	14	2630	0
545	10	1.2.840.10008.5.1.4.1.1.2	0
545	1	13	0
546	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
546	2	20250211T154521	0
546	3		0
546	8	RestApi	0
546	11	172.22.0.1	0
546	13	orthanc	0
546	9	1.2.840.10008.1.2.4.70	0
546	14	2630	0
546	10	1.2.840.10008.5.1.4.1.1.2	0
546	1	14	0
547	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
547	2	20250211T154521	0
547	3		0
547	8	RestApi	0
547	11	172.22.0.1	0
547	13	orthanc	0
547	9	1.2.840.10008.1.2.4.70	0
547	14	2630	0
547	10	1.2.840.10008.5.1.4.1.1.2	0
547	1	15	0
548	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
548	2	20250211T154521	0
548	3		0
548	8	RestApi	0
548	11	172.22.0.1	0
548	13	orthanc	0
548	9	1.2.840.10008.1.2.4.70	0
548	14	2630	0
548	10	1.2.840.10008.5.1.4.1.1.2	0
548	1	16	0
549	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
549	2	20250211T154521	0
549	3		0
549	8	RestApi	0
549	11	172.22.0.1	0
549	13	orthanc	0
549	9	1.2.840.10008.1.2.4.70	0
549	14	2630	0
549	10	1.2.840.10008.5.1.4.1.1.2	0
549	1	17	0
550	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
550	2	20250211T154521	0
550	3		0
550	8	RestApi	0
550	11	172.22.0.1	0
550	13	orthanc	0
550	9	1.2.840.10008.1.2.4.70	0
550	14	3196	0
550	10	1.2.840.10008.5.1.4.1.1.2	0
550	1	11	0
551	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
551	2	20250211T154521	0
551	3		0
551	8	RestApi	0
551	11	172.22.0.1	0
551	13	orthanc	0
551	9	1.2.840.10008.1.2.4.70	0
551	14	2630	0
551	10	1.2.840.10008.5.1.4.1.1.2	0
551	1	18	0
552	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
552	2	20250211T154521	0
552	3		0
552	8	RestApi	0
552	11	172.22.0.1	0
552	13	orthanc	0
552	9	1.2.840.10008.1.2.4.70	0
552	14	2630	0
552	10	1.2.840.10008.5.1.4.1.1.2	0
552	1	19	0
553	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
553	2	20250211T154521	0
553	3		0
553	8	RestApi	0
553	11	172.22.0.1	0
553	13	orthanc	0
553	9	1.2.840.10008.1.2.4.70	0
553	14	2630	0
553	10	1.2.840.10008.5.1.4.1.1.2	0
553	1	20	0
554	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
554	2	20250211T154521	0
554	3		0
554	8	RestApi	0
554	11	172.22.0.1	0
554	13	orthanc	0
554	9	1.2.840.10008.1.2.4.70	0
554	14	2630	0
554	10	1.2.840.10008.5.1.4.1.1.2	0
554	1	21	0
555	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
555	2	20250211T154521	0
555	3		0
555	8	RestApi	0
555	11	172.22.0.1	0
555	13	orthanc	0
555	9	1.2.840.10008.1.2.4.70	0
555	14	2630	0
555	10	1.2.840.10008.5.1.4.1.1.2	0
555	1	22	0
556	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
556	2	20250211T154521	0
556	3		0
556	8	RestApi	0
556	11	172.22.0.1	0
556	13	orthanc	0
556	9	1.2.840.10008.1.2.4.70	0
556	14	2630	0
556	10	1.2.840.10008.5.1.4.1.1.2	0
556	1	23	0
557	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
557	2	20250211T154521	0
557	3		0
557	8	RestApi	0
557	11	172.22.0.1	0
557	13	orthanc	0
557	9	1.2.840.10008.1.2.4.70	0
557	14	2630	0
557	10	1.2.840.10008.5.1.4.1.1.2	0
557	1	24	0
558	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
558	2	20250211T154521	0
558	3		0
558	8	RestApi	0
558	11	172.22.0.1	0
558	13	orthanc	0
558	9	1.2.840.10008.1.2.4.70	0
558	14	2630	0
558	10	1.2.840.10008.5.1.4.1.1.2	0
558	1	25	0
559	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
559	2	20250211T154521	0
559	3		0
559	8	RestApi	0
559	11	172.22.0.1	0
559	13	orthanc	0
559	9	1.2.840.10008.1.2.4.70	0
559	14	2630	0
559	10	1.2.840.10008.5.1.4.1.1.2	0
559	1	26	0
560	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
560	2	20250211T154521	0
560	3		0
560	8	RestApi	0
560	11	172.22.0.1	0
560	13	orthanc	0
560	9	1.2.840.10008.1.2.4.70	0
560	14	2630	0
560	10	1.2.840.10008.5.1.4.1.1.2	0
560	1	27	0
561	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
561	2	20250211T154521	0
561	3		0
561	8	RestApi	0
561	11	172.22.0.1	0
561	13	orthanc	0
561	9	1.2.840.10008.1.2.4.70	0
561	14	3196	0
561	10	1.2.840.10008.5.1.4.1.1.2	0
561	1	12	0
562	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
562	2	20250211T154521	0
562	3		0
562	8	RestApi	0
562	11	172.22.0.1	0
562	13	orthanc	0
562	9	1.2.840.10008.1.2.4.70	0
562	14	2630	0
562	10	1.2.840.10008.5.1.4.1.1.2	0
562	1	28	0
563	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
563	2	20250211T154521	0
563	3		0
563	8	RestApi	0
563	11	172.22.0.1	0
563	13	orthanc	0
563	9	1.2.840.10008.1.2.4.70	0
563	14	2630	0
563	10	1.2.840.10008.5.1.4.1.1.2	0
563	1	29	0
564	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
564	2	20250211T154521	0
564	3		0
564	8	RestApi	0
564	11	172.22.0.1	0
564	13	orthanc	0
564	9	1.2.840.10008.1.2.4.70	0
564	14	2630	0
564	10	1.2.840.10008.5.1.4.1.1.2	0
564	1	30	0
565	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
565	2	20250211T154521	0
565	3		0
565	8	RestApi	0
565	11	172.22.0.1	0
565	13	orthanc	0
565	9	1.2.840.10008.1.2.4.70	0
565	14	2630	0
565	10	1.2.840.10008.5.1.4.1.1.2	0
565	1	31	0
566	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
566	2	20250211T154521	0
566	3		0
566	8	RestApi	0
566	11	172.22.0.1	0
566	13	orthanc	0
566	9	1.2.840.10008.1.2.4.70	0
566	14	2630	0
566	10	1.2.840.10008.5.1.4.1.1.2	0
566	1	32	0
567	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
567	2	20250211T154521	0
567	3		0
567	8	RestApi	0
567	11	172.22.0.1	0
567	13	orthanc	0
567	9	1.2.840.10008.1.2.4.70	0
567	14	2630	0
567	10	1.2.840.10008.5.1.4.1.1.2	0
567	1	33	0
568	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
568	2	20250211T154521	0
568	3		0
568	8	RestApi	0
568	11	172.22.0.1	0
568	13	orthanc	0
568	9	1.2.840.10008.1.2.4.70	0
568	14	2630	0
568	10	1.2.840.10008.5.1.4.1.1.2	0
568	1	34	0
569	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
569	2	20250211T154521	0
569	3		0
569	8	RestApi	0
569	11	172.22.0.1	0
569	13	orthanc	0
569	9	1.2.840.10008.1.2.4.70	0
569	14	2630	0
569	10	1.2.840.10008.5.1.4.1.1.2	0
569	1	35	0
570	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
570	2	20250211T154521	0
570	3		0
570	8	RestApi	0
570	11	172.22.0.1	0
570	13	orthanc	0
570	9	1.2.840.10008.1.2.4.70	0
570	14	2630	0
570	10	1.2.840.10008.5.1.4.1.1.2	0
570	1	36	0
571	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
571	2	20250211T154521	0
571	3		0
571	8	RestApi	0
571	11	172.22.0.1	0
571	13	orthanc	0
571	9	1.2.840.10008.1.2.4.70	0
571	14	2630	0
571	10	1.2.840.10008.5.1.4.1.1.2	0
571	1	37	0
572	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
572	2	20250211T154521	0
572	3		0
572	8	RestApi	0
572	11	172.22.0.1	0
572	13	orthanc	0
572	9	1.2.840.10008.1.2.4.70	0
572	14	3196	0
572	10	1.2.840.10008.5.1.4.1.1.2	0
572	1	13	0
573	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
573	2	20250211T154521	0
573	3		0
573	8	RestApi	0
573	11	172.22.0.1	0
573	13	orthanc	0
573	9	1.2.840.10008.1.2.4.70	0
573	14	2630	0
573	10	1.2.840.10008.5.1.4.1.1.2	0
573	1	38	0
574	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
574	2	20250211T154521	0
574	3		0
574	8	RestApi	0
574	11	172.22.0.1	0
574	13	orthanc	0
574	9	1.2.840.10008.1.2.4.70	0
574	14	2630	0
574	10	1.2.840.10008.5.1.4.1.1.2	0
574	1	39	0
575	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
575	2	20250211T154521	0
575	3		0
575	8	RestApi	0
575	11	172.22.0.1	0
575	13	orthanc	0
575	9	1.2.840.10008.1.2.4.70	0
575	14	2630	0
575	10	1.2.840.10008.5.1.4.1.1.2	0
575	1	40	0
576	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
576	2	20250211T154521	0
576	3		0
576	8	RestApi	0
576	11	172.22.0.1	0
576	13	orthanc	0
576	9	1.2.840.10008.1.2.4.70	0
576	14	2630	0
576	10	1.2.840.10008.5.1.4.1.1.2	0
576	1	41	0
577	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
577	2	20250211T154521	0
577	3		0
577	8	RestApi	0
577	11	172.22.0.1	0
577	13	orthanc	0
577	9	1.2.840.10008.1.2.4.70	0
577	14	2630	0
577	10	1.2.840.10008.5.1.4.1.1.2	0
577	1	42	0
578	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
578	2	20250211T154521	0
578	3		0
578	8	RestApi	0
578	11	172.22.0.1	0
578	13	orthanc	0
578	9	1.2.840.10008.1.2.4.70	0
578	14	2630	0
578	10	1.2.840.10008.5.1.4.1.1.2	0
578	1	43	0
579	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
579	2	20250211T154521	0
579	3		0
579	8	RestApi	0
579	11	172.22.0.1	0
579	13	orthanc	0
579	9	1.2.840.10008.1.2.4.70	0
579	14	2630	0
579	10	1.2.840.10008.5.1.4.1.1.2	0
579	1	44	0
580	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
580	2	20250211T154521	0
580	3		0
580	8	RestApi	0
580	11	172.22.0.1	0
580	13	orthanc	0
580	9	1.2.840.10008.1.2.4.70	0
580	14	2630	0
580	10	1.2.840.10008.5.1.4.1.1.2	0
580	1	45	0
581	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
581	2	20250211T154521	0
581	3		0
581	8	RestApi	0
581	11	172.22.0.1	0
581	13	orthanc	0
581	9	1.2.840.10008.1.2.4.70	0
581	14	2630	0
581	10	1.2.840.10008.5.1.4.1.1.2	0
581	1	46	0
582	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
582	2	20250211T154521	0
582	3		0
582	8	RestApi	0
582	11	172.22.0.1	0
582	13	orthanc	0
582	9	1.2.840.10008.1.2.4.70	0
582	14	2626	0
582	10	1.2.840.10008.5.1.4.1.1.2	0
582	1	47	0
583	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
583	2	20250211T154521	0
583	3		0
583	8	RestApi	0
583	11	172.22.0.1	0
583	13	orthanc	0
583	9	1.2.840.10008.1.2.4.70	0
583	14	3196	0
583	10	1.2.840.10008.5.1.4.1.1.2	0
583	1	14	0
584	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
584	2	20250211T154521	0
584	3		0
584	8	RestApi	0
584	11	172.22.0.1	0
584	13	orthanc	0
584	9	1.2.840.10008.1.2.4.70	0
584	14	2626	0
584	10	1.2.840.10008.5.1.4.1.1.2	0
584	1	48	0
585	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
585	2	20250211T154521	0
585	3		0
585	8	RestApi	0
585	11	172.22.0.1	0
585	13	orthanc	0
585	9	1.2.840.10008.1.2.4.70	0
585	14	2626	0
585	10	1.2.840.10008.5.1.4.1.1.2	0
585	1	49	0
586	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
586	2	20250211T154521	0
586	3		0
586	8	RestApi	0
586	11	172.22.0.1	0
586	13	orthanc	0
586	9	1.2.840.10008.1.2.4.70	0
586	14	2626	0
586	10	1.2.840.10008.5.1.4.1.1.2	0
586	1	50	0
587	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
587	2	20250211T154521	0
587	3		0
587	8	RestApi	0
587	11	172.22.0.1	0
587	13	orthanc	0
587	9	1.2.840.10008.1.2.4.70	0
587	14	2626	0
587	10	1.2.840.10008.5.1.4.1.1.2	0
587	1	51	0
588	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
588	2	20250211T154521	0
588	3		0
588	8	RestApi	0
588	11	172.22.0.1	0
588	13	orthanc	0
588	9	1.2.840.10008.1.2.4.70	0
588	14	2628	0
588	10	1.2.840.10008.5.1.4.1.1.2	0
588	1	52	0
589	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
589	2	20250211T154521	0
589	3		0
589	8	RestApi	0
589	11	172.22.0.1	0
589	13	orthanc	0
589	9	1.2.840.10008.1.2.4.70	0
589	14	2628	0
589	10	1.2.840.10008.5.1.4.1.1.2	0
589	1	53	0
590	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
590	2	20250211T154521	0
590	3		0
590	8	RestApi	0
590	11	172.22.0.1	0
590	13	orthanc	0
590	9	1.2.840.10008.1.2.4.70	0
590	14	2628	0
590	10	1.2.840.10008.5.1.4.1.1.2	0
590	1	54	0
591	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
591	2	20250211T154521	0
591	3		0
591	8	RestApi	0
591	11	172.22.0.1	0
591	13	orthanc	0
591	9	1.2.840.10008.1.2.4.70	0
591	14	2628	0
591	10	1.2.840.10008.5.1.4.1.1.2	0
591	1	55	0
592	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
592	2	20250211T154521	0
592	3		0
592	8	RestApi	0
592	11	172.22.0.1	0
592	13	orthanc	0
592	9	1.2.840.10008.1.2.4.70	0
592	14	2628	0
592	10	1.2.840.10008.5.1.4.1.1.2	0
592	1	56	0
593	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
593	2	20250211T154521	0
593	3		0
593	8	RestApi	0
593	11	172.22.0.1	0
593	13	orthanc	0
593	9	1.2.840.10008.1.2.4.70	0
593	14	2630	0
593	10	1.2.840.10008.5.1.4.1.1.2	0
593	1	57	0
594	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
594	2	20250211T154521	0
594	3		0
594	8	RestApi	0
594	11	172.22.0.1	0
594	13	orthanc	0
594	9	1.2.840.10008.1.2.4.70	0
594	14	3196	0
594	10	1.2.840.10008.5.1.4.1.1.2	0
594	1	15	0
595	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
595	2	20250211T154521	0
595	3		0
595	8	RestApi	0
595	11	172.22.0.1	0
595	13	orthanc	0
595	9	1.2.840.10008.1.2.4.70	0
595	14	2630	0
595	10	1.2.840.10008.5.1.4.1.1.2	0
595	1	58	0
596	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
596	2	20250211T154521	0
596	3		0
596	8	RestApi	0
596	11	172.22.0.1	0
596	13	orthanc	0
596	9	1.2.840.10008.1.2.4.70	0
596	14	2630	0
596	10	1.2.840.10008.5.1.4.1.1.2	0
596	1	59	0
597	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
597	2	20250211T154521	0
597	3		0
597	8	RestApi	0
597	11	172.22.0.1	0
597	13	orthanc	0
597	9	1.2.840.10008.1.2.4.70	0
597	14	2630	0
597	10	1.2.840.10008.5.1.4.1.1.2	0
597	1	60	0
598	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
598	2	20250211T154521	0
598	3		0
598	8	RestApi	0
598	11	172.22.0.1	0
598	13	orthanc	0
598	9	1.2.840.10008.1.2.4.70	0
598	14	2630	0
598	10	1.2.840.10008.5.1.4.1.1.2	0
598	1	61	0
599	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
599	2	20250211T154521	0
599	3		0
599	8	RestApi	0
599	11	172.22.0.1	0
599	13	orthanc	0
599	9	1.2.840.10008.1.2.4.70	0
599	14	2630	0
599	10	1.2.840.10008.5.1.4.1.1.2	0
599	1	62	0
600	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
600	2	20250211T154521	0
600	3		0
600	8	RestApi	0
600	11	172.22.0.1	0
600	13	orthanc	0
600	9	1.2.840.10008.1.2.4.70	0
600	14	2630	0
600	10	1.2.840.10008.5.1.4.1.1.2	0
600	1	63	0
601	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
601	2	20250211T154521	0
601	3		0
601	8	RestApi	0
601	11	172.22.0.1	0
601	13	orthanc	0
601	9	1.2.840.10008.1.2.4.70	0
601	14	2630	0
601	10	1.2.840.10008.5.1.4.1.1.2	0
601	1	64	0
602	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
602	2	20250211T154521	0
602	3		0
602	8	RestApi	0
602	11	172.22.0.1	0
602	13	orthanc	0
602	9	1.2.840.10008.1.2.4.70	0
602	14	2630	0
602	10	1.2.840.10008.5.1.4.1.1.2	0
602	1	65	0
603	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
603	2	20250211T154521	0
603	3		0
603	8	RestApi	0
603	11	172.22.0.1	0
603	13	orthanc	0
603	9	1.2.840.10008.1.2.4.70	0
603	14	2630	0
603	10	1.2.840.10008.5.1.4.1.1.2	0
603	1	66	0
604	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
604	2	20250211T154521	0
604	3		0
604	8	RestApi	0
604	11	172.22.0.1	0
604	13	orthanc	0
604	9	1.2.840.10008.1.2.4.70	0
604	14	2630	0
604	10	1.2.840.10008.5.1.4.1.1.2	0
604	1	67	0
605	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
605	2	20250211T154521	0
605	3		0
605	8	RestApi	0
605	11	172.22.0.1	0
605	13	orthanc	0
605	9	1.2.840.10008.1.2.4.70	0
605	14	3196	0
605	10	1.2.840.10008.5.1.4.1.1.2	0
605	1	16	0
606	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
606	2	20250211T154521	0
606	3		0
606	8	RestApi	0
606	11	172.22.0.1	0
606	13	orthanc	0
606	9	1.2.840.10008.1.2.4.70	0
606	14	2630	0
606	10	1.2.840.10008.5.1.4.1.1.2	0
606	1	68	0
607	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
607	2	20250211T154521	0
607	3		0
607	8	RestApi	0
607	11	172.22.0.1	0
607	13	orthanc	0
607	9	1.2.840.10008.1.2.4.70	0
607	14	2630	0
607	10	1.2.840.10008.5.1.4.1.1.2	0
607	1	69	0
608	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
608	2	20250211T154521	0
608	3		0
608	8	RestApi	0
608	11	172.22.0.1	0
608	13	orthanc	0
608	9	1.2.840.10008.1.2.4.70	0
608	14	2630	0
608	10	1.2.840.10008.5.1.4.1.1.2	0
608	1	70	0
609	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
609	2	20250211T154521	0
609	3		0
609	8	RestApi	0
609	11	172.22.0.1	0
609	13	orthanc	0
609	9	1.2.840.10008.1.2.4.70	0
609	14	2630	0
609	10	1.2.840.10008.5.1.4.1.1.2	0
609	1	71	0
610	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
610	2	20250211T154521	0
610	3		0
610	8	RestApi	0
610	11	172.22.0.1	0
610	13	orthanc	0
610	9	1.2.840.10008.1.2.4.70	0
610	14	2630	0
610	10	1.2.840.10008.5.1.4.1.1.2	0
610	1	72	0
611	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
611	2	20250211T154521	0
611	3		0
611	8	RestApi	0
611	11	172.22.0.1	0
611	13	orthanc	0
611	9	1.2.840.10008.1.2.4.70	0
611	14	2630	0
611	10	1.2.840.10008.5.1.4.1.1.2	0
611	1	73	0
612	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
612	2	20250211T154521	0
612	3		0
612	8	RestApi	0
612	11	172.22.0.1	0
612	13	orthanc	0
612	9	1.2.840.10008.1.2.4.70	0
612	14	2630	0
612	10	1.2.840.10008.5.1.4.1.1.2	0
612	1	74	0
613	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
613	2	20250211T154521	0
613	3		0
613	8	RestApi	0
613	11	172.22.0.1	0
613	13	orthanc	0
613	9	1.2.840.10008.1.2.4.70	0
613	14	2630	0
613	10	1.2.840.10008.5.1.4.1.1.2	0
613	1	75	0
614	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
614	2	20250211T154521	0
614	3		0
614	8	RestApi	0
614	11	172.22.0.1	0
614	13	orthanc	0
614	9	1.2.840.10008.1.2.4.70	0
614	14	2630	0
614	10	1.2.840.10008.5.1.4.1.1.2	0
614	1	76	0
615	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
615	2	20250211T154521	0
615	3		0
615	8	RestApi	0
615	11	172.22.0.1	0
615	13	orthanc	0
615	9	1.2.840.10008.1.2.4.70	0
615	14	2630	0
615	10	1.2.840.10008.5.1.4.1.1.2	0
615	1	77	0
616	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
616	2	20250211T154521	0
616	3		0
616	8	RestApi	0
616	11	172.22.0.1	0
616	13	orthanc	0
616	9	1.2.840.10008.1.2.4.70	0
616	14	3196	0
616	10	1.2.840.10008.5.1.4.1.1.2	0
616	1	17	0
617	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
617	2	20250211T154521	0
617	3		0
617	8	RestApi	0
617	11	172.22.0.1	0
617	13	orthanc	0
617	9	1.2.840.10008.1.2.4.70	0
617	14	2630	0
617	10	1.2.840.10008.5.1.4.1.1.2	0
617	1	78	0
618	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
618	2	20250211T154521	0
618	3		0
618	8	RestApi	0
618	11	172.22.0.1	0
618	13	orthanc	0
618	9	1.2.840.10008.1.2.4.70	0
618	14	2630	0
618	10	1.2.840.10008.5.1.4.1.1.2	0
618	1	79	0
619	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
619	2	20250211T154521	0
619	3		0
619	8	RestApi	0
619	11	172.22.0.1	0
619	13	orthanc	0
619	9	1.2.840.10008.1.2.4.70	0
619	14	2630	0
619	10	1.2.840.10008.5.1.4.1.1.2	0
619	1	80	0
620	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
620	2	20250211T154521	0
620	3		0
620	8	RestApi	0
620	11	172.22.0.1	0
620	13	orthanc	0
620	9	1.2.840.10008.1.2.4.70	0
620	14	2630	0
620	10	1.2.840.10008.5.1.4.1.1.2	0
620	1	81	0
621	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
621	2	20250211T154521	0
621	3		0
621	8	RestApi	0
621	11	172.22.0.1	0
621	13	orthanc	0
621	9	1.2.840.10008.1.2.4.70	0
621	14	2630	0
621	10	1.2.840.10008.5.1.4.1.1.2	0
621	1	82	0
622	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
622	2	20250211T154521	0
622	3		0
622	8	RestApi	0
622	11	172.22.0.1	0
622	13	orthanc	0
622	9	1.2.840.10008.1.2.4.70	0
622	14	2630	0
622	10	1.2.840.10008.5.1.4.1.1.2	0
622	1	83	0
623	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
623	2	20250211T154521	0
623	3		0
623	8	RestApi	0
623	11	172.22.0.1	0
623	13	orthanc	0
623	9	1.2.840.10008.1.2.4.70	0
623	14	2630	0
623	10	1.2.840.10008.5.1.4.1.1.2	0
623	1	84	0
624	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
624	2	20250211T154521	0
624	3		0
624	8	RestApi	0
624	11	172.22.0.1	0
624	13	orthanc	0
624	9	1.2.840.10008.1.2.4.70	0
624	14	2630	0
624	10	1.2.840.10008.5.1.4.1.1.2	0
624	1	85	0
625	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
625	2	20250211T154521	0
625	3		0
625	8	RestApi	0
625	11	172.22.0.1	0
625	13	orthanc	0
625	9	1.2.840.10008.1.2.4.70	0
625	14	2630	0
625	10	1.2.840.10008.5.1.4.1.1.2	0
625	1	86	0
626	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
626	2	20250211T154521	0
626	3		0
626	8	RestApi	0
626	11	172.22.0.1	0
626	13	orthanc	0
626	9	1.2.840.10008.1.2.4.70	0
626	14	2630	0
626	10	1.2.840.10008.5.1.4.1.1.2	0
626	1	87	0
627	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
627	2	20250211T154521	0
627	3		0
627	8	RestApi	0
627	11	172.22.0.1	0
627	13	orthanc	0
627	9	1.2.840.10008.1.2.4.70	0
627	14	3196	0
627	10	1.2.840.10008.5.1.4.1.1.2	0
627	1	18	0
628	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
628	2	20250211T154521	0
628	3		0
628	8	RestApi	0
628	11	172.22.0.1	0
628	13	orthanc	0
628	9	1.2.840.10008.1.2.4.70	0
628	14	2630	0
628	10	1.2.840.10008.5.1.4.1.1.2	0
628	1	88	0
629	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
629	2	20250211T154521	0
629	3		0
629	8	RestApi	0
629	11	172.22.0.1	0
629	13	orthanc	0
629	9	1.2.840.10008.1.2.4.70	0
629	14	2630	0
629	10	1.2.840.10008.5.1.4.1.1.2	0
629	1	89	0
630	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
630	2	20250211T154521	0
630	3		0
630	8	RestApi	0
630	11	172.22.0.1	0
630	13	orthanc	0
630	9	1.2.840.10008.1.2.4.70	0
630	14	2630	0
630	10	1.2.840.10008.5.1.4.1.1.2	0
630	1	90	0
631	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
631	2	20250211T154521	0
631	3		0
631	8	RestApi	0
631	11	172.22.0.1	0
631	13	orthanc	0
631	9	1.2.840.10008.1.2.4.70	0
631	14	2630	0
631	10	1.2.840.10008.5.1.4.1.1.2	0
631	1	91	0
632	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
632	2	20250211T154521	0
632	3		0
632	8	RestApi	0
632	11	172.22.0.1	0
632	13	orthanc	0
632	9	1.2.840.10008.1.2.4.70	0
632	14	2630	0
632	10	1.2.840.10008.5.1.4.1.1.2	0
632	1	92	0
633	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
633	2	20250211T154521	0
633	3		0
633	8	RestApi	0
633	11	172.22.0.1	0
633	13	orthanc	0
633	9	1.2.840.10008.1.2.4.70	0
633	14	2630	0
633	10	1.2.840.10008.5.1.4.1.1.2	0
633	1	93	0
634	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
634	2	20250211T154521	0
634	3		0
634	8	RestApi	0
634	11	172.22.0.1	0
634	13	orthanc	0
634	9	1.2.840.10008.1.2.4.70	0
634	14	2630	0
634	10	1.2.840.10008.5.1.4.1.1.2	0
634	1	94	0
635	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
635	2	20250211T154521	0
635	3		0
635	8	RestApi	0
635	11	172.22.0.1	0
635	13	orthanc	0
635	9	1.2.840.10008.1.2.4.70	0
635	14	2630	0
635	10	1.2.840.10008.5.1.4.1.1.2	0
635	1	95	0
636	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
636	2	20250211T154521	0
636	3		0
636	8	RestApi	0
636	11	172.22.0.1	0
636	13	orthanc	0
636	9	1.2.840.10008.1.2.4.70	0
636	14	2630	0
636	10	1.2.840.10008.5.1.4.1.1.2	0
636	1	96	0
637	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
637	2	20250211T154521	0
637	3		0
637	8	RestApi	0
637	11	172.22.0.1	0
637	13	orthanc	0
637	9	1.2.840.10008.1.2.4.70	0
637	14	2630	0
637	10	1.2.840.10008.5.1.4.1.1.2	0
637	1	97	0
638	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
638	2	20250211T154521	0
638	3		0
638	8	RestApi	0
638	11	172.22.0.1	0
638	13	orthanc	0
638	9	1.2.840.10008.1.2.4.70	0
638	14	3200	0
638	10	1.2.840.10008.5.1.4.1.1.2	0
638	1	1	0
639	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
639	2	20250211T154521	0
639	3		0
639	8	RestApi	0
639	11	172.22.0.1	0
639	13	orthanc	0
639	9	1.2.840.10008.1.2.4.70	0
639	14	3196	0
639	10	1.2.840.10008.5.1.4.1.1.2	0
639	1	19	0
640	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
640	2	20250211T154521	0
640	3		0
640	8	RestApi	0
640	11	172.22.0.1	0
640	13	orthanc	0
640	9	1.2.840.10008.1.2.4.70	0
640	14	2630	0
640	10	1.2.840.10008.5.1.4.1.1.2	0
640	1	98	0
641	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
641	2	20250211T154521	0
641	3		0
641	8	RestApi	0
641	11	172.22.0.1	0
641	13	orthanc	0
641	9	1.2.840.10008.1.2.4.70	0
641	14	2630	0
641	10	1.2.840.10008.5.1.4.1.1.2	0
641	1	99	0
642	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
642	2	20250211T154521	0
642	3		0
642	8	RestApi	0
642	11	172.22.0.1	0
642	13	orthanc	0
642	9	1.2.840.10008.1.2.4.70	0
642	14	2632	0
642	10	1.2.840.10008.5.1.4.1.1.2	0
642	1	100	0
643	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
643	2	20250211T154521	0
643	3		0
643	8	RestApi	0
643	11	172.22.0.1	0
643	13	orthanc	0
643	9	1.2.840.10008.1.2.4.70	0
643	14	2632	0
643	10	1.2.840.10008.5.1.4.1.1.2	0
643	1	101	0
644	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
644	2	20250211T154521	0
644	3		0
644	8	RestApi	0
644	11	172.22.0.1	0
644	13	orthanc	0
644	9	1.2.840.10008.1.2.4.70	0
644	14	2634	0
644	10	1.2.840.10008.5.1.4.1.1.2	0
644	1	102	0
645	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
645	2	20250211T154521	0
645	3		0
645	8	RestApi	0
645	11	172.22.0.1	0
645	13	orthanc	0
645	9	1.2.840.10008.1.2.4.70	0
645	14	2634	0
645	10	1.2.840.10008.5.1.4.1.1.2	0
645	1	103	0
646	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
646	2	20250211T154521	0
646	3		0
646	8	RestApi	0
646	11	172.22.0.1	0
646	13	orthanc	0
646	9	1.2.840.10008.1.2.4.70	0
646	14	2634	0
646	10	1.2.840.10008.5.1.4.1.1.2	0
646	1	104	0
647	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
647	2	20250211T154521	0
647	3		0
647	8	RestApi	0
647	11	172.22.0.1	0
647	13	orthanc	0
647	9	1.2.840.10008.1.2.4.70	0
647	14	2634	0
647	10	1.2.840.10008.5.1.4.1.1.2	0
647	1	105	0
648	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
648	2	20250211T154521	0
648	3		0
648	8	RestApi	0
648	11	172.22.0.1	0
648	13	orthanc	0
648	9	1.2.840.10008.1.2.4.70	0
648	14	2634	0
648	10	1.2.840.10008.5.1.4.1.1.2	0
648	1	106	0
649	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
649	2	20250211T154521	0
649	3		0
649	8	RestApi	0
649	11	172.22.0.1	0
649	13	orthanc	0
649	9	1.2.840.10008.1.2.4.70	0
649	14	2634	0
649	10	1.2.840.10008.5.1.4.1.1.2	0
649	1	107	0
650	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
650	2	20250211T154521	0
650	3		0
650	8	RestApi	0
650	11	172.22.0.1	0
650	13	orthanc	0
650	9	1.2.840.10008.1.2.4.70	0
650	14	3196	0
650	10	1.2.840.10008.5.1.4.1.1.2	0
650	1	20	0
651	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
651	2	20250211T154521	0
651	3		0
651	8	RestApi	0
651	11	172.22.0.1	0
651	13	orthanc	0
651	9	1.2.840.10008.1.2.4.70	0
651	14	2634	0
651	10	1.2.840.10008.5.1.4.1.1.2	0
651	1	108	0
652	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
652	2	20250211T154521	0
652	3		0
652	8	RestApi	0
652	11	172.22.0.1	0
652	13	orthanc	0
652	9	1.2.840.10008.1.2.4.70	0
652	14	2634	0
652	10	1.2.840.10008.5.1.4.1.1.2	0
652	1	109	0
653	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
653	2	20250211T154521	0
653	3		0
653	8	RestApi	0
653	11	172.22.0.1	0
653	13	orthanc	0
653	9	1.2.840.10008.1.2.4.70	0
653	14	2634	0
653	10	1.2.840.10008.5.1.4.1.1.2	0
653	1	110	0
654	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
531	7	20250211T154521	0
654	2	20250211T154521	0
654	3		0
654	8	RestApi	0
654	11	172.22.0.1	0
654	13	orthanc	0
654	9	1.2.840.10008.1.2.4.70	0
654	14	2634	0
654	10	1.2.840.10008.5.1.4.1.1.2	0
654	1	111	0
656	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
655	15	0008,0021;0008,0031;0008,0060;0008,0070;0008,0201;0008,1010;0008,103e;0008,1070;0018,0010;0018,0015;0018,0024;0018,1030;0018,1090;0018,1400;0020,000e;0020,0011;0020,0037;0020,0105;0020,1002;0040,0244;0040,0245;0040,0254;0040,0275;0054,0081;0054,0101;0054,1000	0
655	3		0
656	2	20250211T154521	0
656	3		0
656	8	RestApi	0
656	11	172.22.0.1	0
656	13	orthanc	0
656	9	1.2.840.10008.1.2.4.70	0
656	14	2630	0
656	10	1.2.840.10008.5.1.4.1.1.2	0
656	1	1	0
657	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
657	2	20250211T154521	0
657	3		0
657	8	RestApi	0
657	11	172.22.0.1	0
657	13	orthanc	0
657	9	1.2.840.10008.1.2.4.70	0
657	14	2628	0
657	10	1.2.840.10008.5.1.4.1.1.2	0
657	1	2	0
658	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
658	2	20250211T154521	0
658	3		0
658	8	RestApi	0
658	11	172.22.0.1	0
658	13	orthanc	0
658	9	1.2.840.10008.1.2.4.70	0
658	14	2628	0
658	10	1.2.840.10008.5.1.4.1.1.2	0
658	1	3	0
659	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
659	2	20250211T154521	0
659	3		0
659	8	RestApi	0
659	11	172.22.0.1	0
659	13	orthanc	0
659	9	1.2.840.10008.1.2.4.70	0
659	14	2628	0
659	10	1.2.840.10008.5.1.4.1.1.2	0
659	1	4	0
660	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
660	2	20250211T154521	0
660	3		0
660	8	RestApi	0
660	11	172.22.0.1	0
660	13	orthanc	0
660	9	1.2.840.10008.1.2.4.70	0
660	14	2628	0
660	10	1.2.840.10008.5.1.4.1.1.2	0
660	1	5	0
661	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
661	2	20250211T154522	0
661	3		0
661	8	RestApi	0
661	11	172.22.0.1	0
661	13	orthanc	0
661	9	1.2.840.10008.1.2.4.70	0
661	14	2628	0
661	10	1.2.840.10008.5.1.4.1.1.2	0
661	1	6	0
662	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
662	2	20250211T154522	0
662	3		0
662	8	RestApi	0
662	11	172.22.0.1	0
662	13	orthanc	0
662	9	1.2.840.10008.1.2.4.70	0
662	14	3196	0
662	10	1.2.840.10008.5.1.4.1.1.2	0
662	1	21	0
663	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
663	2	20250211T154522	0
663	3		0
663	8	RestApi	0
663	11	172.22.0.1	0
663	13	orthanc	0
663	9	1.2.840.10008.1.2.4.70	0
663	14	2628	0
663	10	1.2.840.10008.5.1.4.1.1.2	0
663	1	7	0
664	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
664	2	20250211T154522	0
664	3		0
664	8	RestApi	0
664	11	172.22.0.1	0
664	13	orthanc	0
664	9	1.2.840.10008.1.2.4.70	0
664	14	2628	0
664	10	1.2.840.10008.5.1.4.1.1.2	0
664	1	8	0
665	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
665	2	20250211T154522	0
665	3		0
665	8	RestApi	0
665	11	172.22.0.1	0
665	13	orthanc	0
665	9	1.2.840.10008.1.2.4.70	0
665	14	2628	0
665	10	1.2.840.10008.5.1.4.1.1.2	0
665	1	9	0
666	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
666	2	20250211T154522	0
666	3		0
666	8	RestApi	0
666	11	172.22.0.1	0
666	13	orthanc	0
666	9	1.2.840.10008.1.2.4.70	0
666	14	2628	0
666	10	1.2.840.10008.5.1.4.1.1.2	0
666	1	10	0
667	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
667	2	20250211T154522	0
667	3		0
667	8	RestApi	0
667	11	172.22.0.1	0
667	13	orthanc	0
667	9	1.2.840.10008.1.2.4.70	0
667	14	2628	0
667	10	1.2.840.10008.5.1.4.1.1.2	0
667	1	11	0
668	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
668	2	20250211T154522	0
668	3		0
668	8	RestApi	0
668	11	172.22.0.1	0
668	13	orthanc	0
668	9	1.2.840.10008.1.2.4.70	0
668	14	2628	0
668	10	1.2.840.10008.5.1.4.1.1.2	0
668	1	12	0
669	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
669	2	20250211T154522	0
669	3		0
669	8	RestApi	0
669	11	172.22.0.1	0
669	13	orthanc	0
669	9	1.2.840.10008.1.2.4.70	0
669	14	2628	0
669	10	1.2.840.10008.5.1.4.1.1.2	0
669	1	13	0
670	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
670	2	20250211T154522	0
670	3		0
670	8	RestApi	0
670	11	172.22.0.1	0
670	13	orthanc	0
670	9	1.2.840.10008.1.2.4.70	0
670	14	2628	0
670	10	1.2.840.10008.5.1.4.1.1.2	0
670	1	14	0
671	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
671	2	20250211T154522	0
671	3		0
671	8	RestApi	0
671	11	172.22.0.1	0
671	13	orthanc	0
671	9	1.2.840.10008.1.2.4.70	0
671	14	2628	0
671	10	1.2.840.10008.5.1.4.1.1.2	0
671	1	15	0
672	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
672	2	20250211T154522	0
672	3		0
672	8	RestApi	0
672	11	172.22.0.1	0
672	13	orthanc	0
672	9	1.2.840.10008.1.2.4.70	0
672	14	2628	0
672	10	1.2.840.10008.5.1.4.1.1.2	0
672	1	16	0
673	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
673	2	20250211T154522	0
673	3		0
673	8	RestApi	0
673	11	172.22.0.1	0
673	13	orthanc	0
673	9	1.2.840.10008.1.2.4.70	0
673	14	3196	0
673	10	1.2.840.10008.5.1.4.1.1.2	0
673	1	22	0
674	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
674	2	20250211T154522	0
674	3		0
674	8	RestApi	0
674	11	172.22.0.1	0
674	13	orthanc	0
674	9	1.2.840.10008.1.2.4.70	0
674	14	2628	0
674	10	1.2.840.10008.5.1.4.1.1.2	0
674	1	17	0
675	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
675	2	20250211T154522	0
675	3		0
675	8	RestApi	0
675	11	172.22.0.1	0
675	13	orthanc	0
675	9	1.2.840.10008.1.2.4.70	0
675	14	2628	0
675	10	1.2.840.10008.5.1.4.1.1.2	0
675	1	18	0
676	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
676	2	20250211T154522	0
676	3		0
676	8	RestApi	0
676	11	172.22.0.1	0
676	13	orthanc	0
676	9	1.2.840.10008.1.2.4.70	0
676	14	2628	0
676	10	1.2.840.10008.5.1.4.1.1.2	0
676	1	19	0
677	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
677	2	20250211T154522	0
677	3		0
677	8	RestApi	0
677	11	172.22.0.1	0
677	13	orthanc	0
677	9	1.2.840.10008.1.2.4.70	0
677	14	2628	0
677	10	1.2.840.10008.5.1.4.1.1.2	0
677	1	20	0
678	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
678	2	20250211T154522	0
678	3		0
678	8	RestApi	0
678	11	172.22.0.1	0
678	13	orthanc	0
678	9	1.2.840.10008.1.2.4.70	0
678	14	2628	0
678	10	1.2.840.10008.5.1.4.1.1.2	0
678	1	21	0
679	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
679	2	20250211T154522	0
679	3		0
679	8	RestApi	0
679	11	172.22.0.1	0
679	13	orthanc	0
679	9	1.2.840.10008.1.2.4.70	0
679	14	2628	0
679	10	1.2.840.10008.5.1.4.1.1.2	0
679	1	22	0
680	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
680	2	20250211T154522	0
680	3		0
680	8	RestApi	0
680	11	172.22.0.1	0
680	13	orthanc	0
680	9	1.2.840.10008.1.2.4.70	0
680	14	2628	0
680	10	1.2.840.10008.5.1.4.1.1.2	0
680	1	23	0
681	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
681	2	20250211T154522	0
681	3		0
681	8	RestApi	0
681	11	172.22.0.1	0
681	13	orthanc	0
681	9	1.2.840.10008.1.2.4.70	0
681	14	2628	0
681	10	1.2.840.10008.5.1.4.1.1.2	0
681	1	24	0
682	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
682	2	20250211T154522	0
682	3		0
682	8	RestApi	0
682	11	172.22.0.1	0
682	13	orthanc	0
682	9	1.2.840.10008.1.2.4.70	0
682	14	2628	0
682	10	1.2.840.10008.5.1.4.1.1.2	0
682	1	25	0
683	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
683	2	20250211T154522	0
683	3		0
683	8	RestApi	0
683	11	172.22.0.1	0
683	13	orthanc	0
683	9	1.2.840.10008.1.2.4.70	0
683	14	2628	0
683	10	1.2.840.10008.5.1.4.1.1.2	0
683	1	26	0
684	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
684	2	20250211T154522	0
684	3		0
684	8	RestApi	0
684	11	172.22.0.1	0
684	13	orthanc	0
684	9	1.2.840.10008.1.2.4.70	0
684	14	3196	0
684	10	1.2.840.10008.5.1.4.1.1.2	0
684	1	23	0
685	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
685	2	20250211T154522	0
685	3		0
685	8	RestApi	0
685	11	172.22.0.1	0
685	13	orthanc	0
685	9	1.2.840.10008.1.2.4.70	0
685	14	2628	0
685	10	1.2.840.10008.5.1.4.1.1.2	0
685	1	27	0
686	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
686	2	20250211T154522	0
686	3		0
686	8	RestApi	0
686	11	172.22.0.1	0
686	13	orthanc	0
686	9	1.2.840.10008.1.2.4.70	0
686	14	2628	0
686	10	1.2.840.10008.5.1.4.1.1.2	0
686	1	28	0
687	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
687	2	20250211T154522	0
687	3		0
687	8	RestApi	0
687	11	172.22.0.1	0
687	13	orthanc	0
687	9	1.2.840.10008.1.2.4.70	0
687	14	2628	0
687	10	1.2.840.10008.5.1.4.1.1.2	0
687	1	29	0
688	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
688	2	20250211T154522	0
688	3		0
688	8	RestApi	0
688	11	172.22.0.1	0
688	13	orthanc	0
688	9	1.2.840.10008.1.2.4.70	0
688	14	2628	0
688	10	1.2.840.10008.5.1.4.1.1.2	0
688	1	30	0
689	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
689	2	20250211T154522	0
689	3		0
689	8	RestApi	0
689	11	172.22.0.1	0
689	13	orthanc	0
689	9	1.2.840.10008.1.2.4.70	0
689	14	2628	0
689	10	1.2.840.10008.5.1.4.1.1.2	0
689	1	31	0
690	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
690	2	20250211T154522	0
690	3		0
690	8	RestApi	0
690	11	172.22.0.1	0
690	13	orthanc	0
690	9	1.2.840.10008.1.2.4.70	0
690	14	2628	0
690	10	1.2.840.10008.5.1.4.1.1.2	0
690	1	32	0
691	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
691	2	20250211T154522	0
691	3		0
691	8	RestApi	0
691	11	172.22.0.1	0
691	13	orthanc	0
691	9	1.2.840.10008.1.2.4.70	0
691	14	2628	0
691	10	1.2.840.10008.5.1.4.1.1.2	0
691	1	33	0
692	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
692	2	20250211T154522	0
692	3		0
692	8	RestApi	0
692	11	172.22.0.1	0
692	13	orthanc	0
692	9	1.2.840.10008.1.2.4.70	0
692	14	2628	0
692	10	1.2.840.10008.5.1.4.1.1.2	0
692	1	34	0
693	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
693	2	20250211T154522	0
693	3		0
693	8	RestApi	0
693	11	172.22.0.1	0
693	13	orthanc	0
693	9	1.2.840.10008.1.2.4.70	0
693	14	2628	0
693	10	1.2.840.10008.5.1.4.1.1.2	0
693	1	35	0
694	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
694	2	20250211T154522	0
694	3		0
694	8	RestApi	0
694	11	172.22.0.1	0
694	13	orthanc	0
694	9	1.2.840.10008.1.2.4.70	0
694	14	2628	0
694	10	1.2.840.10008.5.1.4.1.1.2	0
694	1	36	0
695	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
695	2	20250211T154522	0
695	3		0
695	8	RestApi	0
695	11	172.22.0.1	0
695	13	orthanc	0
695	9	1.2.840.10008.1.2.4.70	0
695	14	3196	0
695	10	1.2.840.10008.5.1.4.1.1.2	0
695	1	24	0
696	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
696	2	20250211T154522	0
696	3		0
696	8	RestApi	0
696	11	172.22.0.1	0
696	13	orthanc	0
696	9	1.2.840.10008.1.2.4.70	0
696	14	2628	0
696	10	1.2.840.10008.5.1.4.1.1.2	0
696	1	37	0
697	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
697	2	20250211T154522	0
697	3		0
697	8	RestApi	0
697	11	172.22.0.1	0
697	13	orthanc	0
697	9	1.2.840.10008.1.2.4.70	0
697	14	2628	0
697	10	1.2.840.10008.5.1.4.1.1.2	0
697	1	38	0
698	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
698	2	20250211T154522	0
698	3		0
698	8	RestApi	0
698	11	172.22.0.1	0
698	13	orthanc	0
698	9	1.2.840.10008.1.2.4.70	0
698	14	2628	0
698	10	1.2.840.10008.5.1.4.1.1.2	0
698	1	39	0
699	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
699	2	20250211T154522	0
699	3		0
699	8	RestApi	0
699	11	172.22.0.1	0
699	13	orthanc	0
699	9	1.2.840.10008.1.2.4.70	0
699	14	2628	0
699	10	1.2.840.10008.5.1.4.1.1.2	0
699	1	40	0
700	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
700	2	20250211T154522	0
700	3		0
700	8	RestApi	0
700	11	172.22.0.1	0
700	13	orthanc	0
700	9	1.2.840.10008.1.2.4.70	0
700	14	2628	0
700	10	1.2.840.10008.5.1.4.1.1.2	0
700	1	41	0
701	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
701	2	20250211T154522	0
701	3		0
701	8	RestApi	0
701	11	172.22.0.1	0
701	13	orthanc	0
701	9	1.2.840.10008.1.2.4.70	0
701	14	2628	0
701	10	1.2.840.10008.5.1.4.1.1.2	0
701	1	42	0
702	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
702	2	20250211T154522	0
702	3		0
702	8	RestApi	0
702	11	172.22.0.1	0
702	13	orthanc	0
702	9	1.2.840.10008.1.2.4.70	0
702	14	2628	0
702	10	1.2.840.10008.5.1.4.1.1.2	0
702	1	43	0
703	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
703	2	20250211T154522	0
703	3		0
703	8	RestApi	0
703	11	172.22.0.1	0
703	13	orthanc	0
703	9	1.2.840.10008.1.2.4.70	0
703	14	2628	0
703	10	1.2.840.10008.5.1.4.1.1.2	0
703	1	44	0
704	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
704	2	20250211T154522	0
704	3		0
704	8	RestApi	0
704	11	172.22.0.1	0
704	13	orthanc	0
704	9	1.2.840.10008.1.2.4.70	0
704	14	2626	0
704	10	1.2.840.10008.5.1.4.1.1.2	0
704	1	45	0
705	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
705	2	20250211T154522	0
705	3		0
705	8	RestApi	0
705	11	172.22.0.1	0
705	13	orthanc	0
705	9	1.2.840.10008.1.2.4.70	0
705	14	2626	0
705	10	1.2.840.10008.5.1.4.1.1.2	0
705	1	46	0
706	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
706	2	20250211T154522	0
706	3		0
706	8	RestApi	0
706	11	172.22.0.1	0
706	13	orthanc	0
706	9	1.2.840.10008.1.2.4.70	0
706	14	3200	0
706	10	1.2.840.10008.5.1.4.1.1.2	0
706	1	25	0
707	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
707	2	20250211T154522	0
707	3		0
707	8	RestApi	0
707	11	172.22.0.1	0
707	13	orthanc	0
707	9	1.2.840.10008.1.2.4.70	0
707	14	2626	0
707	10	1.2.840.10008.5.1.4.1.1.2	0
707	1	47	0
708	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
708	2	20250211T154522	0
708	3		0
708	8	RestApi	0
708	11	172.22.0.1	0
708	13	orthanc	0
708	9	1.2.840.10008.1.2.4.70	0
708	14	2626	0
708	10	1.2.840.10008.5.1.4.1.1.2	0
708	1	48	0
709	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
709	2	20250211T154522	0
709	3		0
709	8	RestApi	0
709	11	172.22.0.1	0
709	13	orthanc	0
709	9	1.2.840.10008.1.2.4.70	0
709	14	2626	0
709	10	1.2.840.10008.5.1.4.1.1.2	0
709	1	49	0
710	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
710	2	20250211T154522	0
710	3		0
710	8	RestApi	0
710	11	172.22.0.1	0
710	13	orthanc	0
710	9	1.2.840.10008.1.2.4.70	0
710	14	2630	0
710	10	1.2.840.10008.5.1.4.1.1.2	0
710	1	50	0
711	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
711	2	20250211T154522	0
711	3		0
711	8	RestApi	0
711	11	172.22.0.1	0
711	13	orthanc	0
711	9	1.2.840.10008.1.2.4.70	0
711	14	2630	0
711	10	1.2.840.10008.5.1.4.1.1.2	0
711	1	51	0
712	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
712	2	20250211T154522	0
712	3		0
712	8	RestApi	0
712	11	172.22.0.1	0
712	13	orthanc	0
712	9	1.2.840.10008.1.2.4.70	0
712	14	2630	0
712	10	1.2.840.10008.5.1.4.1.1.2	0
712	1	52	0
713	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
713	2	20250211T154522	0
713	3		0
713	8	RestApi	0
713	11	172.22.0.1	0
713	13	orthanc	0
713	9	1.2.840.10008.1.2.4.70	0
713	14	2630	0
713	10	1.2.840.10008.5.1.4.1.1.2	0
713	1	53	0
714	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
714	2	20250211T154522	0
714	3		0
714	8	RestApi	0
714	11	172.22.0.1	0
714	13	orthanc	0
714	9	1.2.840.10008.1.2.4.70	0
714	14	2630	0
714	10	1.2.840.10008.5.1.4.1.1.2	0
714	1	54	0
715	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
715	2	20250211T154522	0
715	3		0
715	8	RestApi	0
715	11	172.22.0.1	0
715	13	orthanc	0
715	9	1.2.840.10008.1.2.4.70	0
715	14	2630	0
715	10	1.2.840.10008.5.1.4.1.1.2	0
715	1	55	0
716	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
716	2	20250211T154522	0
716	3		0
716	8	RestApi	0
716	11	172.22.0.1	0
716	13	orthanc	0
716	9	1.2.840.10008.1.2.4.70	0
716	14	2630	0
716	10	1.2.840.10008.5.1.4.1.1.2	0
716	1	56	0
717	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
717	2	20250211T154522	0
717	3		0
717	8	RestApi	0
717	11	172.22.0.1	0
717	13	orthanc	0
717	9	1.2.840.10008.1.2.4.70	0
717	14	3200	0
717	10	1.2.840.10008.5.1.4.1.1.2	0
717	1	26	0
718	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
718	2	20250211T154522	0
718	3		0
718	8	RestApi	0
718	11	172.22.0.1	0
718	13	orthanc	0
718	9	1.2.840.10008.1.2.4.70	0
718	14	2630	0
718	10	1.2.840.10008.5.1.4.1.1.2	0
718	1	57	0
719	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
719	2	20250211T154522	0
719	3		0
719	8	RestApi	0
719	11	172.22.0.1	0
719	13	orthanc	0
719	9	1.2.840.10008.1.2.4.70	0
719	14	2630	0
719	10	1.2.840.10008.5.1.4.1.1.2	0
719	1	58	0
720	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
720	2	20250211T154522	0
720	3		0
720	8	RestApi	0
720	11	172.22.0.1	0
720	13	orthanc	0
720	9	1.2.840.10008.1.2.4.70	0
720	14	2630	0
720	10	1.2.840.10008.5.1.4.1.1.2	0
720	1	59	0
721	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
721	2	20250211T154522	0
721	3		0
721	8	RestApi	0
721	11	172.22.0.1	0
721	13	orthanc	0
721	9	1.2.840.10008.1.2.4.70	0
721	14	2630	0
721	10	1.2.840.10008.5.1.4.1.1.2	0
721	1	60	0
722	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
722	2	20250211T154522	0
722	3		0
722	8	RestApi	0
722	11	172.22.0.1	0
722	13	orthanc	0
722	9	1.2.840.10008.1.2.4.70	0
722	14	2630	0
722	10	1.2.840.10008.5.1.4.1.1.2	0
722	1	61	0
723	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
723	2	20250211T154522	0
723	3		0
723	8	RestApi	0
723	11	172.22.0.1	0
723	13	orthanc	0
723	9	1.2.840.10008.1.2.4.70	0
723	14	2630	0
723	10	1.2.840.10008.5.1.4.1.1.2	0
723	1	62	0
724	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
724	2	20250211T154522	0
724	3		0
724	8	RestApi	0
724	11	172.22.0.1	0
724	13	orthanc	0
724	9	1.2.840.10008.1.2.4.70	0
724	14	2630	0
724	10	1.2.840.10008.5.1.4.1.1.2	0
724	1	63	0
725	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
725	2	20250211T154522	0
725	3		0
725	8	RestApi	0
725	11	172.22.0.1	0
725	13	orthanc	0
725	9	1.2.840.10008.1.2.4.70	0
725	14	2630	0
725	10	1.2.840.10008.5.1.4.1.1.2	0
725	1	64	0
726	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
726	2	20250211T154522	0
726	3		0
726	8	RestApi	0
726	11	172.22.0.1	0
726	13	orthanc	0
726	9	1.2.840.10008.1.2.4.70	0
726	14	2630	0
726	10	1.2.840.10008.5.1.4.1.1.2	0
726	1	65	0
727	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
727	2	20250211T154522	0
727	3		0
727	8	RestApi	0
727	11	172.22.0.1	0
727	13	orthanc	0
727	9	1.2.840.10008.1.2.4.70	0
727	14	2630	0
727	10	1.2.840.10008.5.1.4.1.1.2	0
727	1	66	0
728	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
728	2	20250211T154522	0
728	3		0
728	8	RestApi	0
728	11	172.22.0.1	0
728	13	orthanc	0
728	9	1.2.840.10008.1.2.4.70	0
728	14	3200	0
728	10	1.2.840.10008.5.1.4.1.1.2	0
728	1	27	0
729	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
729	2	20250211T154522	0
729	3		0
729	8	RestApi	0
729	11	172.22.0.1	0
729	13	orthanc	0
729	9	1.2.840.10008.1.2.4.70	0
729	14	2630	0
729	10	1.2.840.10008.5.1.4.1.1.2	0
729	1	67	0
730	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
730	2	20250211T154522	0
730	3		0
730	8	RestApi	0
730	11	172.22.0.1	0
730	13	orthanc	0
730	9	1.2.840.10008.1.2.4.70	0
730	14	2630	0
730	10	1.2.840.10008.5.1.4.1.1.2	0
730	1	68	0
731	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
731	2	20250211T154522	0
731	3		0
731	8	RestApi	0
731	11	172.22.0.1	0
731	13	orthanc	0
731	9	1.2.840.10008.1.2.4.70	0
731	14	2630	0
731	10	1.2.840.10008.5.1.4.1.1.2	0
731	1	69	0
732	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
732	2	20250211T154522	0
732	3		0
732	8	RestApi	0
732	11	172.22.0.1	0
732	13	orthanc	0
732	9	1.2.840.10008.1.2.4.70	0
732	14	2630	0
732	10	1.2.840.10008.5.1.4.1.1.2	0
732	1	70	0
733	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
733	2	20250211T154522	0
733	3		0
733	8	RestApi	0
733	11	172.22.0.1	0
733	13	orthanc	0
733	9	1.2.840.10008.1.2.4.70	0
733	14	2630	0
733	10	1.2.840.10008.5.1.4.1.1.2	0
733	1	71	0
734	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
734	2	20250211T154522	0
734	3		0
734	8	RestApi	0
734	11	172.22.0.1	0
734	13	orthanc	0
734	9	1.2.840.10008.1.2.4.70	0
734	14	2630	0
734	10	1.2.840.10008.5.1.4.1.1.2	0
734	1	72	0
735	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
735	2	20250211T154522	0
735	3		0
735	8	RestApi	0
735	11	172.22.0.1	0
735	13	orthanc	0
735	9	1.2.840.10008.1.2.4.70	0
735	14	2630	0
735	10	1.2.840.10008.5.1.4.1.1.2	0
735	1	73	0
736	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
736	2	20250211T154522	0
736	3		0
736	8	RestApi	0
736	11	172.22.0.1	0
736	13	orthanc	0
736	9	1.2.840.10008.1.2.4.70	0
736	14	2630	0
736	10	1.2.840.10008.5.1.4.1.1.2	0
736	1	74	0
737	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
737	2	20250211T154522	0
737	3		0
737	8	RestApi	0
737	11	172.22.0.1	0
737	13	orthanc	0
737	9	1.2.840.10008.1.2.4.70	0
737	14	2630	0
737	10	1.2.840.10008.5.1.4.1.1.2	0
737	1	75	0
738	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
738	2	20250211T154522	0
738	3		0
738	8	RestApi	0
738	11	172.22.0.1	0
738	13	orthanc	0
738	9	1.2.840.10008.1.2.4.70	0
738	14	2630	0
738	10	1.2.840.10008.5.1.4.1.1.2	0
738	1	76	0
739	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
739	2	20250211T154522	0
739	3		0
739	8	RestApi	0
739	11	172.22.0.1	0
739	13	orthanc	0
739	9	1.2.840.10008.1.2.4.70	0
739	14	3200	0
739	10	1.2.840.10008.5.1.4.1.1.2	0
739	1	28	0
740	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
740	2	20250211T154522	0
740	3		0
740	8	RestApi	0
740	11	172.22.0.1	0
740	13	orthanc	0
740	9	1.2.840.10008.1.2.4.70	0
740	14	2630	0
740	10	1.2.840.10008.5.1.4.1.1.2	0
740	1	77	0
741	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
741	2	20250211T154522	0
741	3		0
741	8	RestApi	0
741	11	172.22.0.1	0
741	13	orthanc	0
741	9	1.2.840.10008.1.2.4.70	0
741	14	2630	0
741	10	1.2.840.10008.5.1.4.1.1.2	0
741	1	78	0
742	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
742	2	20250211T154522	0
742	3		0
742	8	RestApi	0
742	11	172.22.0.1	0
742	13	orthanc	0
742	9	1.2.840.10008.1.2.4.70	0
742	14	2630	0
742	10	1.2.840.10008.5.1.4.1.1.2	0
742	1	79	0
743	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
743	2	20250211T154522	0
743	3		0
743	8	RestApi	0
743	11	172.22.0.1	0
743	13	orthanc	0
743	9	1.2.840.10008.1.2.4.70	0
743	14	2630	0
743	10	1.2.840.10008.5.1.4.1.1.2	0
743	1	80	0
744	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
744	2	20250211T154522	0
744	3		0
744	8	RestApi	0
744	11	172.22.0.1	0
744	13	orthanc	0
744	9	1.2.840.10008.1.2.4.70	0
744	14	2630	0
744	10	1.2.840.10008.5.1.4.1.1.2	0
744	1	81	0
745	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
745	2	20250211T154522	0
745	3		0
745	8	RestApi	0
745	11	172.22.0.1	0
745	13	orthanc	0
745	9	1.2.840.10008.1.2.4.70	0
745	14	2630	0
745	10	1.2.840.10008.5.1.4.1.1.2	0
745	1	82	0
746	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
746	2	20250211T154522	0
746	3		0
746	8	RestApi	0
746	11	172.22.0.1	0
746	13	orthanc	0
746	9	1.2.840.10008.1.2.4.70	0
746	14	2630	0
746	10	1.2.840.10008.5.1.4.1.1.2	0
746	1	83	0
747	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
747	2	20250211T154522	0
747	3		0
747	8	RestApi	0
747	11	172.22.0.1	0
747	13	orthanc	0
747	9	1.2.840.10008.1.2.4.70	0
747	14	2630	0
747	10	1.2.840.10008.5.1.4.1.1.2	0
747	1	84	0
748	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
748	2	20250211T154522	0
748	3		0
748	8	RestApi	0
748	11	172.22.0.1	0
748	13	orthanc	0
748	9	1.2.840.10008.1.2.4.70	0
748	14	2630	0
748	10	1.2.840.10008.5.1.4.1.1.2	0
748	1	85	0
749	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
749	2	20250211T154522	0
749	3		0
749	8	RestApi	0
749	11	172.22.0.1	0
749	13	orthanc	0
749	9	1.2.840.10008.1.2.4.70	0
749	14	2630	0
749	10	1.2.840.10008.5.1.4.1.1.2	0
749	1	86	0
750	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
750	2	20250211T154522	0
750	3		0
750	8	RestApi	0
750	11	172.22.0.1	0
750	13	orthanc	0
750	9	1.2.840.10008.1.2.4.70	0
750	14	3200	0
750	10	1.2.840.10008.5.1.4.1.1.2	0
750	1	2	0
751	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
751	2	20250211T154522	0
751	3		0
751	8	RestApi	0
751	11	172.22.0.1	0
751	13	orthanc	0
751	9	1.2.840.10008.1.2.4.70	0
751	14	3200	0
751	10	1.2.840.10008.5.1.4.1.1.2	0
751	1	29	0
752	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
752	2	20250211T154522	0
752	3		0
752	8	RestApi	0
752	11	172.22.0.1	0
752	13	orthanc	0
752	9	1.2.840.10008.1.2.4.70	0
752	14	2630	0
752	10	1.2.840.10008.5.1.4.1.1.2	0
752	1	87	0
753	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
753	2	20250211T154522	0
753	3		0
753	8	RestApi	0
753	11	172.22.0.1	0
753	13	orthanc	0
753	9	1.2.840.10008.1.2.4.70	0
753	14	2630	0
753	10	1.2.840.10008.5.1.4.1.1.2	0
753	1	88	0
754	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
655	7	20250211T154522	0
754	2	20250211T154522	0
754	3		0
754	8	RestApi	0
754	11	172.22.0.1	0
754	13	orthanc	0
754	9	1.2.840.10008.1.2.4.70	0
754	14	2630	0
754	10	1.2.840.10008.5.1.4.1.1.2	0
754	1	89	0
755	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
755	2	20250211T154522	0
755	3		0
755	8	RestApi	0
755	11	172.22.0.1	0
755	13	orthanc	0
755	9	1.2.840.10008.1.2.4.70	0
755	14	3200	0
755	10	1.2.840.10008.5.1.4.1.1.2	0
755	1	30	0
756	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
756	2	20250211T154522	0
756	3		0
756	8	RestApi	0
756	11	172.22.0.1	0
756	13	orthanc	0
756	9	1.2.840.10008.1.2.4.70	0
756	14	3200	0
756	10	1.2.840.10008.5.1.4.1.1.2	0
756	1	31	0
757	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
757	2	20250211T154522	0
757	3		0
757	8	RestApi	0
757	11	172.22.0.1	0
757	13	orthanc	0
757	9	1.2.840.10008.1.2.4.70	0
757	14	3200	0
757	10	1.2.840.10008.5.1.4.1.1.2	0
757	1	32	0
758	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
758	2	20250211T154522	0
758	3		0
758	8	RestApi	0
758	11	172.22.0.1	0
758	13	orthanc	0
758	9	1.2.840.10008.1.2.4.70	0
758	14	3200	0
758	10	1.2.840.10008.5.1.4.1.1.2	0
758	1	33	0
759	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
759	2	20250211T154522	0
759	3		0
759	8	RestApi	0
759	11	172.22.0.1	0
759	13	orthanc	0
759	9	1.2.840.10008.1.2.4.70	0
759	14	3200	0
759	10	1.2.840.10008.5.1.4.1.1.2	0
759	1	34	0
760	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
760	2	20250211T154522	0
760	3		0
760	8	RestApi	0
760	11	172.22.0.1	0
760	13	orthanc	0
760	9	1.2.840.10008.1.2.4.70	0
760	14	3200	0
760	10	1.2.840.10008.5.1.4.1.1.2	0
760	1	1	0
761	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
761	2	20250211T154522	0
761	3		0
761	8	RestApi	0
761	11	172.22.0.1	0
761	13	orthanc	0
761	9	1.2.840.10008.1.2.4.70	0
761	14	3200	0
761	10	1.2.840.10008.5.1.4.1.1.2	0
761	1	2	0
762	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
762	2	20250211T154522	0
762	3		0
762	8	RestApi	0
762	11	172.22.0.1	0
762	13	orthanc	0
762	9	1.2.840.10008.1.2.4.70	0
762	14	3200	0
762	10	1.2.840.10008.5.1.4.1.1.2	0
762	1	3	0
763	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
763	2	20250211T154522	0
763	3		0
763	8	RestApi	0
763	11	172.22.0.1	0
763	13	orthanc	0
763	9	1.2.840.10008.1.2.4.70	0
763	14	3200	0
763	10	1.2.840.10008.5.1.4.1.1.2	0
763	1	4	0
764	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
764	2	20250211T154522	0
764	3		0
764	8	RestApi	0
764	11	172.22.0.1	0
764	13	orthanc	0
764	9	1.2.840.10008.1.2.4.70	0
764	14	3196	0
764	10	1.2.840.10008.5.1.4.1.1.2	0
764	1	3	0
765	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
765	2	20250211T154522	0
765	3		0
765	8	RestApi	0
765	11	172.22.0.1	0
765	13	orthanc	0
765	9	1.2.840.10008.1.2.4.70	0
765	14	3196	0
765	10	1.2.840.10008.5.1.4.1.1.2	0
765	1	5	0
766	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
766	2	20250211T154522	0
766	3		0
766	8	RestApi	0
766	11	172.22.0.1	0
766	13	orthanc	0
766	9	1.2.840.10008.1.2.4.70	0
766	14	3196	0
766	10	1.2.840.10008.5.1.4.1.1.2	0
766	1	6	0
767	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
767	2	20250211T154522	0
767	3		0
767	8	RestApi	0
767	11	172.22.0.1	0
767	13	orthanc	0
767	9	1.2.840.10008.1.2.4.70	0
767	14	3196	0
767	10	1.2.840.10008.5.1.4.1.1.2	0
767	1	7	0
768	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
768	2	20250211T154522	0
768	3		0
768	8	RestApi	0
768	11	172.22.0.1	0
768	13	orthanc	0
768	9	1.2.840.10008.1.2.4.70	0
768	14	3196	0
768	10	1.2.840.10008.5.1.4.1.1.2	0
768	1	8	0
769	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
769	2	20250211T154522	0
769	3		0
769	8	RestApi	0
769	11	172.22.0.1	0
769	13	orthanc	0
769	9	1.2.840.10008.1.2.4.70	0
769	14	3196	0
769	10	1.2.840.10008.5.1.4.1.1.2	0
769	1	9	0
770	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
770	2	20250211T154522	0
770	3		0
770	8	RestApi	0
770	11	172.22.0.1	0
770	13	orthanc	0
770	9	1.2.840.10008.1.2.4.70	0
770	14	3196	0
770	10	1.2.840.10008.5.1.4.1.1.2	0
770	1	10	0
771	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
771	2	20250211T154522	0
771	3		0
771	8	RestApi	0
771	11	172.22.0.1	0
771	13	orthanc	0
771	9	1.2.840.10008.1.2.4.70	0
771	14	3196	0
771	10	1.2.840.10008.5.1.4.1.1.2	0
771	1	11	0
772	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
772	2	20250211T154522	0
772	3		0
772	8	RestApi	0
772	11	172.22.0.1	0
772	13	orthanc	0
772	9	1.2.840.10008.1.2.4.70	0
772	14	3196	0
772	10	1.2.840.10008.5.1.4.1.1.2	0
772	1	12	0
773	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
773	2	20250211T154522	0
773	3		0
773	8	RestApi	0
773	11	172.22.0.1	0
773	13	orthanc	0
773	9	1.2.840.10008.1.2.4.70	0
773	14	3196	0
773	10	1.2.840.10008.5.1.4.1.1.2	0
773	1	13	0
774	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
774	2	20250211T154522	0
774	3		0
774	8	RestApi	0
774	11	172.22.0.1	0
774	13	orthanc	0
774	9	1.2.840.10008.1.2.4.70	0
774	14	3196	0
774	10	1.2.840.10008.5.1.4.1.1.2	0
774	1	14	0
775	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
775	2	20250211T154522	0
775	3		0
775	8	RestApi	0
775	11	172.22.0.1	0
775	13	orthanc	0
775	9	1.2.840.10008.1.2.4.70	0
775	14	3196	0
775	10	1.2.840.10008.5.1.4.1.1.2	0
775	1	4	0
776	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
776	2	20250211T154522	0
776	3		0
776	8	RestApi	0
776	11	172.22.0.1	0
776	13	orthanc	0
776	9	1.2.840.10008.1.2.4.70	0
776	14	3196	0
776	10	1.2.840.10008.5.1.4.1.1.2	0
776	1	15	0
777	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
777	2	20250211T154522	0
777	3		0
777	8	RestApi	0
777	11	172.22.0.1	0
777	13	orthanc	0
777	9	1.2.840.10008.1.2.4.70	0
777	14	3196	0
777	10	1.2.840.10008.5.1.4.1.1.2	0
777	1	16	0
778	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
778	2	20250211T154522	0
778	3		0
778	8	RestApi	0
778	11	172.22.0.1	0
778	13	orthanc	0
778	9	1.2.840.10008.1.2.4.70	0
778	14	3196	0
778	10	1.2.840.10008.5.1.4.1.1.2	0
778	1	17	0
779	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
779	2	20250211T154522	0
779	3		0
779	8	RestApi	0
779	11	172.22.0.1	0
779	13	orthanc	0
779	9	1.2.840.10008.1.2.4.70	0
779	14	3196	0
779	10	1.2.840.10008.5.1.4.1.1.2	0
779	1	18	0
780	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
780	2	20250211T154522	0
780	3		0
780	8	RestApi	0
780	11	172.22.0.1	0
780	13	orthanc	0
780	9	1.2.840.10008.1.2.4.70	0
780	14	3196	0
780	10	1.2.840.10008.5.1.4.1.1.2	0
780	1	19	0
781	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
781	2	20250211T154522	0
781	3		0
781	8	RestApi	0
781	11	172.22.0.1	0
781	13	orthanc	0
781	9	1.2.840.10008.1.2.4.70	0
781	14	3196	0
781	10	1.2.840.10008.5.1.4.1.1.2	0
781	1	20	0
782	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
782	2	20250211T154522	0
782	3		0
782	8	RestApi	0
782	11	172.22.0.1	0
782	13	orthanc	0
782	9	1.2.840.10008.1.2.4.70	0
782	14	3196	0
782	10	1.2.840.10008.5.1.4.1.1.2	0
782	1	21	0
783	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
783	2	20250211T154522	0
783	3		0
783	8	RestApi	0
783	11	172.22.0.1	0
783	13	orthanc	0
783	9	1.2.840.10008.1.2.4.70	0
783	14	3196	0
783	10	1.2.840.10008.5.1.4.1.1.2	0
783	1	22	0
784	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
784	2	20250211T154522	0
784	3		0
784	8	RestApi	0
784	11	172.22.0.1	0
784	13	orthanc	0
784	9	1.2.840.10008.1.2.4.70	0
784	14	3196	0
784	10	1.2.840.10008.5.1.4.1.1.2	0
784	1	23	0
785	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
785	2	20250211T154522	0
785	3		0
785	8	RestApi	0
785	11	172.22.0.1	0
785	13	orthanc	0
785	9	1.2.840.10008.1.2.4.70	0
785	14	3196	0
785	10	1.2.840.10008.5.1.4.1.1.2	0
785	1	24	0
786	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
786	2	20250211T154522	0
786	3		0
786	8	RestApi	0
786	11	172.22.0.1	0
786	13	orthanc	0
786	9	1.2.840.10008.1.2.4.70	0
786	14	3196	0
786	10	1.2.840.10008.5.1.4.1.1.2	0
786	1	5	0
787	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
787	2	20250211T154522	0
787	3		0
787	8	RestApi	0
787	11	172.22.0.1	0
787	13	orthanc	0
787	9	1.2.840.10008.1.2.4.70	0
787	14	3196	0
787	10	1.2.840.10008.5.1.4.1.1.2	0
787	1	25	0
788	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
788	2	20250211T154522	0
788	3		0
788	8	RestApi	0
788	11	172.22.0.1	0
788	13	orthanc	0
788	9	1.2.840.10008.1.2.4.70	0
788	14	3196	0
788	10	1.2.840.10008.5.1.4.1.1.2	0
788	1	26	0
789	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
789	2	20250211T154522	0
789	3		0
789	8	RestApi	0
789	11	172.22.0.1	0
789	13	orthanc	0
789	9	1.2.840.10008.1.2.4.70	0
789	14	3196	0
789	10	1.2.840.10008.5.1.4.1.1.2	0
789	1	27	0
790	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
790	2	20250211T154522	0
790	3		0
790	8	RestApi	0
790	11	172.22.0.1	0
790	13	orthanc	0
790	9	1.2.840.10008.1.2.4.70	0
790	14	3196	0
790	10	1.2.840.10008.5.1.4.1.1.2	0
790	1	28	0
791	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
791	2	20250211T154522	0
791	3		0
791	8	RestApi	0
791	11	172.22.0.1	0
791	13	orthanc	0
791	9	1.2.840.10008.1.2.4.70	0
791	14	3196	0
791	10	1.2.840.10008.5.1.4.1.1.2	0
791	1	29	0
792	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
792	2	20250211T154522	0
792	3		0
792	8	RestApi	0
792	11	172.22.0.1	0
792	13	orthanc	0
792	9	1.2.840.10008.1.2.4.70	0
792	14	3196	0
792	10	1.2.840.10008.5.1.4.1.1.2	0
792	1	30	0
793	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
793	2	20250211T154522	0
793	3		0
793	8	RestApi	0
793	11	172.22.0.1	0
793	13	orthanc	0
793	9	1.2.840.10008.1.2.4.70	0
793	14	3196	0
793	10	1.2.840.10008.5.1.4.1.1.2	0
793	1	31	0
794	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
794	2	20250211T154522	0
794	3		0
794	8	RestApi	0
794	11	172.22.0.1	0
794	13	orthanc	0
794	9	1.2.840.10008.1.2.4.70	0
794	14	3196	0
794	10	1.2.840.10008.5.1.4.1.1.2	0
794	1	32	0
795	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
795	2	20250211T154522	0
795	3		0
795	8	RestApi	0
795	11	172.22.0.1	0
795	13	orthanc	0
795	9	1.2.840.10008.1.2.4.70	0
795	14	3196	0
795	10	1.2.840.10008.5.1.4.1.1.2	0
795	1	33	0
796	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
796	2	20250211T154522	0
796	3		0
796	8	RestApi	0
796	11	172.22.0.1	0
796	13	orthanc	0
796	9	1.2.840.10008.1.2.4.70	0
796	14	3196	0
796	10	1.2.840.10008.5.1.4.1.1.2	0
796	1	34	0
797	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
797	2	20250211T154522	0
797	3		0
797	8	RestApi	0
797	11	172.22.0.1	0
797	13	orthanc	0
797	9	1.2.840.10008.1.2.4.70	0
797	14	3196	0
797	10	1.2.840.10008.5.1.4.1.1.2	0
797	1	6	0
798	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
798	2	20250211T154522	0
798	3		0
798	8	RestApi	0
798	11	172.22.0.1	0
798	13	orthanc	0
798	9	1.2.840.10008.1.2.4.70	0
798	14	3196	0
798	10	1.2.840.10008.5.1.4.1.1.2	0
798	1	35	0
799	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
799	2	20250211T154522	0
799	3		0
799	8	RestApi	0
799	11	172.22.0.1	0
799	13	orthanc	0
799	9	1.2.840.10008.1.2.4.70	0
799	14	3196	0
799	10	1.2.840.10008.5.1.4.1.1.2	0
799	1	36	0
800	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
800	2	20250211T154522	0
800	3		0
800	8	RestApi	0
800	11	172.22.0.1	0
800	13	orthanc	0
800	9	1.2.840.10008.1.2.4.70	0
800	14	3196	0
800	10	1.2.840.10008.5.1.4.1.1.2	0
800	1	37	0
801	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
801	2	20250211T154522	0
801	3		0
801	8	RestApi	0
801	11	172.22.0.1	0
801	13	orthanc	0
801	9	1.2.840.10008.1.2.4.70	0
801	14	3196	0
801	10	1.2.840.10008.5.1.4.1.1.2	0
801	1	38	0
802	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
802	2	20250211T154522	0
802	3		0
802	8	RestApi	0
802	11	172.22.0.1	0
802	13	orthanc	0
802	9	1.2.840.10008.1.2.4.70	0
802	14	3196	0
802	10	1.2.840.10008.5.1.4.1.1.2	0
802	1	39	0
803	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
803	2	20250211T154522	0
803	3		0
803	8	RestApi	0
803	11	172.22.0.1	0
803	13	orthanc	0
803	9	1.2.840.10008.1.2.4.70	0
803	14	3196	0
803	10	1.2.840.10008.5.1.4.1.1.2	0
803	1	40	0
804	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
804	2	20250211T154522	0
804	3		0
804	8	RestApi	0
804	11	172.22.0.1	0
804	13	orthanc	0
804	9	1.2.840.10008.1.2.4.70	0
804	14	3196	0
804	10	1.2.840.10008.5.1.4.1.1.2	0
804	1	41	0
805	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
805	2	20250211T154522	0
805	3		0
805	8	RestApi	0
805	11	172.22.0.1	0
805	13	orthanc	0
805	9	1.2.840.10008.1.2.4.70	0
805	14	3196	0
805	10	1.2.840.10008.5.1.4.1.1.2	0
805	1	42	0
806	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
806	2	20250211T154522	0
806	3		0
806	8	RestApi	0
806	11	172.22.0.1	0
806	13	orthanc	0
806	9	1.2.840.10008.1.2.4.70	0
806	14	3196	0
806	10	1.2.840.10008.5.1.4.1.1.2	0
806	1	43	0
807	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
807	2	20250211T154522	0
807	3		0
807	8	RestApi	0
807	11	172.22.0.1	0
807	13	orthanc	0
807	9	1.2.840.10008.1.2.4.70	0
807	14	3196	0
807	10	1.2.840.10008.5.1.4.1.1.2	0
807	1	44	0
808	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
808	2	20250211T154522	0
808	3		0
808	8	RestApi	0
808	11	172.22.0.1	0
808	13	orthanc	0
808	9	1.2.840.10008.1.2.4.70	0
808	14	3196	0
808	10	1.2.840.10008.5.1.4.1.1.2	0
808	1	7	0
809	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
809	2	20250211T154522	0
809	3		0
809	8	RestApi	0
809	11	172.22.0.1	0
809	13	orthanc	0
809	9	1.2.840.10008.1.2.4.70	0
809	14	3196	0
809	10	1.2.840.10008.5.1.4.1.1.2	0
809	1	45	0
810	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
810	2	20250211T154522	0
810	3		0
810	8	RestApi	0
810	11	172.22.0.1	0
810	13	orthanc	0
810	9	1.2.840.10008.1.2.4.70	0
810	14	3196	0
810	10	1.2.840.10008.5.1.4.1.1.2	0
810	1	46	0
811	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
811	2	20250211T154522	0
811	3		0
811	8	RestApi	0
811	11	172.22.0.1	0
811	13	orthanc	0
811	9	1.2.840.10008.1.2.4.70	0
811	14	3196	0
811	10	1.2.840.10008.5.1.4.1.1.2	0
811	1	47	0
812	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
812	2	20250211T154522	0
812	3		0
812	8	RestApi	0
812	11	172.22.0.1	0
812	13	orthanc	0
812	9	1.2.840.10008.1.2.4.70	0
812	14	3196	0
812	10	1.2.840.10008.5.1.4.1.1.2	0
812	1	48	0
813	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
813	2	20250211T154522	0
813	3		0
813	8	RestApi	0
813	11	172.22.0.1	0
813	13	orthanc	0
813	9	1.2.840.10008.1.2.4.70	0
813	14	3200	0
813	10	1.2.840.10008.5.1.4.1.1.2	0
813	1	49	0
814	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
814	2	20250211T154522	0
814	3		0
814	8	RestApi	0
814	11	172.22.0.1	0
814	13	orthanc	0
814	9	1.2.840.10008.1.2.4.70	0
814	14	3200	0
814	10	1.2.840.10008.5.1.4.1.1.2	0
814	1	50	0
815	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
815	2	20250211T154522	0
815	3		0
815	8	RestApi	0
815	11	172.22.0.1	0
815	13	orthanc	0
815	9	1.2.840.10008.1.2.4.70	0
815	14	3200	0
815	10	1.2.840.10008.5.1.4.1.1.2	0
815	1	51	0
816	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
816	2	20250211T154522	0
816	3		0
816	8	RestApi	0
816	11	172.22.0.1	0
816	13	orthanc	0
816	9	1.2.840.10008.1.2.4.70	0
816	14	3200	0
816	10	1.2.840.10008.5.1.4.1.1.2	0
816	1	52	0
817	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
817	2	20250211T154522	0
817	3		0
817	8	RestApi	0
817	11	172.22.0.1	0
817	13	orthanc	0
817	9	1.2.840.10008.1.2.4.70	0
817	14	3200	0
817	10	1.2.840.10008.5.1.4.1.1.2	0
817	1	53	0
818	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
818	2	20250211T154522	0
818	3		0
818	8	RestApi	0
818	11	172.22.0.1	0
818	13	orthanc	0
818	9	1.2.840.10008.1.2.4.70	0
818	14	3200	0
818	10	1.2.840.10008.5.1.4.1.1.2	0
818	1	54	0
819	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
525	7	20250211T154522	0
819	2	20250211T154522	0
819	3		0
819	8	RestApi	0
819	11	172.22.0.1	0
819	13	orthanc	0
819	9	1.2.840.10008.1.2.4.70	0
819	14	3196	0
819	10	1.2.840.10008.5.1.4.1.1.2	0
819	1	8	0
820	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
820	2	20250211T154522	0
820	3		0
820	8	RestApi	0
820	11	172.22.0.1	0
820	13	orthanc	0
820	9	1.2.840.10008.1.2.4.70	0
820	14	3200	0
820	10	1.2.840.10008.5.1.4.1.1.2	0
820	1	55	0
821	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
821	2	20250211T154522	0
821	3		0
821	8	RestApi	0
821	11	172.22.0.1	0
821	13	orthanc	0
821	9	1.2.840.10008.1.2.4.70	0
821	14	3200	0
821	10	1.2.840.10008.5.1.4.1.1.2	0
821	1	56	0
822	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
822	2	20250211T154522	0
822	3		0
822	8	RestApi	0
822	11	172.22.0.1	0
822	13	orthanc	0
822	9	1.2.840.10008.1.2.4.70	0
822	14	3200	0
822	10	1.2.840.10008.5.1.4.1.1.2	0
822	1	57	0
823	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
823	2	20250211T154522	0
823	3		0
823	8	RestApi	0
823	11	172.22.0.1	0
823	13	orthanc	0
823	9	1.2.840.10008.1.2.4.70	0
823	14	3200	0
823	10	1.2.840.10008.5.1.4.1.1.2	0
823	1	58	0
824	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
824	2	20250211T154522	0
824	3		0
824	8	RestApi	0
824	11	172.22.0.1	0
824	13	orthanc	0
824	9	1.2.840.10008.1.2.4.70	0
824	14	3200	0
824	10	1.2.840.10008.5.1.4.1.1.2	0
824	1	59	0
825	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
825	2	20250211T154522	0
825	3		0
825	8	RestApi	0
825	11	172.22.0.1	0
825	13	orthanc	0
825	9	1.2.840.10008.1.2.4.70	0
825	14	3200	0
825	10	1.2.840.10008.5.1.4.1.1.2	0
825	1	60	0
826	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
826	2	20250211T154522	0
826	3		0
826	8	RestApi	0
826	11	172.22.0.1	0
826	13	orthanc	0
826	9	1.2.840.10008.1.2.4.70	0
826	14	3200	0
826	10	1.2.840.10008.5.1.4.1.1.2	0
826	1	61	0
827	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
827	2	20250211T154522	0
827	3		0
827	8	RestApi	0
827	11	172.22.0.1	0
827	13	orthanc	0
827	9	1.2.840.10008.1.2.4.70	0
827	14	3200	0
827	10	1.2.840.10008.5.1.4.1.1.2	0
827	1	62	0
828	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
828	2	20250211T154522	0
828	3		0
828	8	RestApi	0
828	11	172.22.0.1	0
828	13	orthanc	0
828	9	1.2.840.10008.1.2.4.70	0
828	14	3200	0
828	10	1.2.840.10008.5.1.4.1.1.2	0
828	1	63	0
829	15	0008,0012;0008,0013;0008,0018;0020,0012;0020,0013;0020,0032;0020,0037;0020,0100;0020,4000;0028,0008;0054,1330	0
527	7	20250211T154522	0
521	7	20250211T154522	0
1	7	20250211T154522	0
829	2	20250211T154522	0
829	3		0
829	8	RestApi	0
829	11	172.22.0.1	0
829	13	orthanc	0
829	9	1.2.840.10008.1.2.4.70	0
829	14	3200	0
829	10	1.2.840.10008.5.1.4.1.1.2	0
829	1	64	0
\.


--
-- Data for Name: patientrecyclingorder; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.patientrecyclingorder (seq, patientid) FROM stdin;
1	1
\.


--
-- Data for Name: remainingancestor; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.remainingancestor (resourcetype, publicid) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.resources (internalid, resourcetype, publicid, parentid) FROM stdin;
1	0	8e9e8135-f9e05d3e-aa128825-97883040-ec6c49a5	\N
2	1	5ab616f0-6169ced1-69ec2916-20436671-a463f2ee	1
3	2	2547acac-db61a557-9c29659c-4f50464c-c01ca922	2
4	3	85bffd6f-8fd0a47b-6ca70de0-766f8676-96b6672f	3
5	3	c52a73a3-b5783f09-ef657588-9eac7be3-67e19c2d	3
6	3	cde652ea-b5bf2757-f16946ce-734ac6a3-a96f4b09	3
7	3	06af6123-222a29ce-5a7107b2-2ef2ebc6-6ce57337	3
8	3	fa1e0ad5-59c786ec-f60eb88a-724037eb-a5d1211e	3
9	3	ec5d423f-2bb09b99-57364ffb-70265432-0465136c	3
10	3	3750bf36-eb98524f-006ad50b-a5d4a3da-08c5c7bc	3
11	3	5487f056-c0435ee3-c6b85bb3-85976b2f-dab4d367	3
12	3	9c5723d7-fc1695fa-39e87fb9-02c22c5e-8ea54619	3
13	3	7984a310-adebb736-d27837b1-371c96d1-77d2a983	3
14	3	ce367bbe-ce8ecc9b-4f9aa783-89736272-4f8e2f65	3
15	3	e7865b91-7b6ef10b-2bcde462-ac7635c2-fe0ea310	3
16	3	9e33ec29-2ba09c1e-707db5a5-c379a900-cf8abbf9	3
17	3	d4de209a-5c23921b-1180bef3-f0699d2d-a288b4e9	3
18	3	e63f2a93-a32afc1f-5770c169-79c091f5-10c3af95	3
19	3	535de0f0-67ac41d0-fc44abd3-ffb134d1-593fcfcc	3
20	3	e9474fc5-0b834c57-22597b11-dd40b2b2-23bb409e	3
21	3	e5c49c6b-66bc19b7-b72c8647-5cd0efeb-8d383329	3
22	3	f01b5ebb-d540e4f2-5b93ad9a-849b7aec-e8f4c961	3
23	3	1921ded4-879cea9f-3da24a1a-4bd90a89-ff5d7703	3
24	3	0b8f040f-e19ccb02-e731bec4-d4b9b141-00af1b79	3
25	3	7e4a3056-df218616-95505efb-8ac5a183-911f5dfe	3
26	3	246a32e2-6e68bbc6-29b77e7d-30bf969e-39f50a23	3
27	3	9e327aa3-16d3411b-1fea17ac-ab7a4227-d28adf0d	3
28	3	f75c14cf-2651d941-e3edf5b5-ef38a730-d612ca9b	3
29	3	8a0957ad-9b5da169-2c243af0-882add5e-ac7e54ba	3
30	3	daf6afc6-fb55e680-e5412c66-ff33a7fe-b8caae69	3
31	3	c2efa14e-10a0ed48-0ebeaae5-13b6c1c2-a571617f	3
32	3	fbe73170-7f3121df-f857e08e-53726224-17449ddd	3
33	3	13f5f72e-8b45c1c3-8a3104a6-269176c7-8fcabb73	3
34	3	0c443aca-9a0ceedb-20184435-30af7cfd-ab024dde	3
35	3	dbaa1e58-a60aec1b-ba23101d-f9d6235f-6a99e8f1	3
36	3	03503603-2a55b250-ae0bd599-f2bc989a-89ed66a5	3
37	3	783b0788-10eec765-94b0b523-0ae20b97-d217bac4	3
38	3	b459fade-ab0ffba5-64458889-2a6c67d3-b933b86d	3
39	3	be64fb75-de4bfd29-965a27a1-cb4baf80-576d0453	3
40	3	8d171420-4990e8ec-01e7c534-b808b290-bbe48bd1	3
41	3	d2416d29-94acdaba-152e9a8b-4ce5e9e2-7118f8b9	3
42	3	d3eafb0a-59b532c8-4f53c7af-084b3853-dfa5b47c	3
43	3	7ca1a143-8ed42af3-1b698a84-14b5e0f4-d9f15809	3
44	3	3b3a3c14-5e62c51d-69585b39-8c9a5fc9-be65fbae	3
45	3	bdd8975c-a221e22f-8fd0689c-f5a0cd7c-3745d343	3
46	3	451fe13a-0ffffff0-1626c558-73d62c2e-0cb9cfef	3
47	3	da91c958-5ace5981-37ecb871-9468d2c5-331dd637	3
48	3	0612d616-b9d6b0b1-0adb4a7f-e8daf735-3b3f8858	3
49	3	d0128773-a798e47b-3ce73e57-a7959fd1-dbe3558b	3
50	3	22704e3f-c90d1c30-7832ae81-185cda55-c517e550	3
51	3	249fc16c-70d808e8-e91c6dfa-4e7a3b0c-842f28da	3
52	3	15102e3b-7308c791-ab2b8b65-a6db0a41-2a16cb4e	3
53	3	3c0b25ab-ee644723-14eafd64-56518e92-cb81ae10	3
54	3	04abde3a-5a7ef842-f8d99e5c-422e98b6-e4b1b192	3
55	3	8b5a6cb7-24fc3a3d-71eefea1-6f98880d-78cf0b4d	3
56	3	ec3e1662-e563a651-36f7ab4b-16b64f7b-7ad499ea	3
57	3	bf9925a0-fdcd3f91-5e63c205-d70a622f-75910bbf	3
58	3	bbdd14b2-3964ae00-804dd127-74e687d4-3b1e2caf	3
59	3	a52e41c8-0523d491-98c5f449-17053771-72cf9fdc	3
60	3	95adc7dc-315d3db2-e8267d75-57021643-12102d40	3
61	3	4fd8fe5b-5622e4e8-1ce9d134-863a7a6f-82b2cbcf	3
62	3	563eece8-11edb0d2-8b5f4f86-1c6e89ea-c05fcc8f	3
63	3	70d427b7-f515bd32-f59f941d-57dfa459-06ca16c9	3
64	3	24b73a74-c07c6998-4f882b4e-8e35d1a1-314a3834	3
65	3	fff17471-3153c5f7-f2c4803f-4c8218f5-3a5eeff9	3
66	3	5836e7ba-fb5b82ab-5128fa38-78a822c0-c3bd8d2d	3
67	3	460d89a3-b28a059b-3f7204e6-a3d18853-d9b0e1f1	3
68	3	cbdfebc5-2d1c1996-c7343756-aeb5e894-3fc85824	3
69	3	f7d52765-3f031c50-6e51e522-8af0a94c-c167ac41	3
70	3	38cfab26-12936b05-55cb61e8-ea1732f0-ec6e2aec	3
71	3	1fe04736-dbbf6641-8c9d17ea-8ccec5c8-4b9b3af5	3
72	3	658277be-5a6e18da-5ecc134f-e0213767-08c69abd	3
73	3	b4da8bd4-7dc75dc2-49941129-aa9f1c0a-611aef81	3
74	3	7148087e-94e8e1af-f4a72382-74d86fd1-bb7239e7	3
75	3	c879ed00-7fc68e3d-be666b9d-08fd5d28-76c5ea84	3
76	3	45962323-e715491b-f2a9a06a-890ba758-562c7386	3
77	3	4d1d22f2-df720f16-cfaa39aa-892815bd-b7ce710e	3
78	3	c2884beb-c371c5db-4f177b7f-050d0c03-3ef59ce4	3
79	3	60e4841d-c3494085-6cedb6f7-e5568028-e58d3405	3
80	3	93da56c2-4733f040-d4af1a04-1253c584-d2282fde	3
81	3	fae72f61-84a84e15-f1b14e89-98fcd68a-3edb2d1a	3
82	3	bc949a0a-da1f51e4-787dd4cc-b4105a79-4783ff45	3
83	3	2116fb09-d6f6baa1-387e6f49-82cec3e3-386341c7	3
84	3	882f5600-3297f2ca-cc8f207c-9bc6c2a9-e04e30cb	3
85	3	46a900a1-3c67f4e6-daf6908c-c0ff0e68-4b6a7364	3
86	3	b25eb24c-086d2655-32e8dfed-f129c873-15741b29	3
87	3	4245a843-70de2160-532ae3b1-5d4a1bb3-a29c773e	3
88	3	487e8c26-1a2bfef7-01ff2769-2308eacd-bb866761	3
89	3	e6692fb5-8f88960c-66c43808-a1bffbb2-2c7a94fa	3
90	3	c101bc09-1abb6e95-c33059bb-40cc7c62-64f3ab78	3
91	3	77818a8b-7371e79c-23b48142-58cf0989-24b8469c	3
92	3	c91f8ae1-36c8220d-57345453-c407232a-986f998b	3
93	3	5a69f724-f1817b14-79fffc7e-b19d3378-a6c16860	3
94	3	94dba692-62138b6e-41497458-ce4fc07b-cab53a75	3
95	3	e8c9ff23-b14d9887-be674717-4b639f4a-6694ea44	3
96	3	52ec3ba9-3f6704a1-d549564d-758096f5-b99d955b	3
97	3	0f5493ed-629e3c8d-74f92c91-f1ce0a0f-3db0f7bb	3
98	3	572b50be-c5b6846b-61f26f05-1a3230a0-09d065a3	3
99	3	5c409c48-622adfb9-9795b9e7-e1b9bd48-f7e1017a	3
100	3	30886ab6-14505c0d-f8ef2409-a23b7a4b-1199b67a	3
101	3	0e2c4fed-caf625c7-af559002-768fe839-da8d36a7	3
102	3	11bc974d-4dcf1123-6d02a21b-f1190914-88dc3db7	3
103	3	44469821-5c0b9594-027ad908-0b5f5793-883498ad	3
104	3	82e4e2a7-174454f6-9428762d-9d65292f-216c537b	3
105	3	cacbb89d-487ac8c7-10895ec8-864b3661-1b5ee698	3
106	3	2188c670-e8febc38-304ebfdf-1e9b3a28-2750f8e5	3
107	3	61791ff2-a066b55b-50a78cd8-96767ccc-5c56ed1d	3
108	3	a2fbe9d6-5de73364-3bc0b8ab-60dbe9d3-59a67757	3
109	3	37c953f1-5a7da13d-80f64eba-4439131d-c025d0f0	3
110	3	453f186d-30885507-e31bd418-9da0e622-29c104d4	3
111	3	e7b44cfb-8c3c2c54-e0af338c-d64f1b00-4f7d533a	3
112	3	4332fd17-7f56026e-1ee89356-d5ecfda9-5714a34f	3
113	3	34020fc6-3c229fad-1bea80c5-68251cc6-8e7ba93e	3
114	3	be62a039-af3a67e1-f6e38efb-3e404dd7-013144e0	3
115	3	35bb669d-64e39679-7009e1ec-dd849947-1150b331	3
116	3	7763e6a2-4e54ce86-b0ffdae9-001ef8b4-a66fe855	3
117	3	cf78b205-390af6d7-53dd5584-8a605ce1-10aa8c1f	3
118	3	6ad0af46-994b652c-f9af5358-7b5b88ee-dbb73b39	3
119	3	3ff87cfa-de6ec127-b47c9e9b-6cf7e425-6f789fa8	3
120	3	2e689f5f-6da7fbc1-e868e40f-a50bbbce-fe293790	3
121	3	cadf9fbe-67eb3b2b-6035ebf2-cba63063-d99c76b1	3
122	3	5807de62-6c409d42-2d49df88-da13ad03-348f40ef	3
123	3	c24a7e63-6180a90b-b1137251-6d764618-b26df491	3
124	3	3c5f265e-aca94274-d3f9d810-d3ce1080-be4f44d8	3
125	3	cb27c744-ac9d7855-5da75bf9-c9b9087b-14e19edf	3
126	3	cfaf7a47-c348697c-cc850f23-87972889-4d23b14e	3
127	3	1233776b-9478b7da-1976bfbc-ae423f80-7806b902	3
128	3	2fe4e968-ed69a350-f9731eac-cc57f503-c9288d05	3
129	3	8915887a-a4b89a64-f9fba7a2-7ec4d41a-06fc9ea1	3
130	3	92c1a64a-ca5ac009-dbed2014-10b10a00-85a32609	3
131	3	98f281e4-8f56a352-740e6276-ca79ba7c-64bf5274	3
132	3	54141943-cd04ddd3-82469a79-e5eb2d6c-c741cb45	3
133	3	8a8e7a1f-99361ce7-398fef1c-80243dbd-a636dfb1	3
134	3	59ad5832-6c6377fb-09fcad38-204e18ba-ba73de70	3
135	3	882fdafe-d11df46f-ca001c75-6ca8c7cc-36be6213	3
136	3	d99ae0cc-8d6c91dd-6261f020-21960dce-d1aceddd	3
137	3	826aafc7-85fb0276-8385b487-3a666739-fccca653	3
138	3	a82a774c-1e0e7b89-681c187e-36c68aaa-0406667d	3
139	3	40ce6229-298f1ff9-5dd12bf6-f3810347-ebbc1e88	3
140	3	5e280f82-941b2ff4-b1c4b59d-3aca5f8f-cccb2228	3
141	3	2cf7f760-781a2f4c-bf242493-a0979d26-0fad5452	3
142	3	d1cedb52-034f0138-e80862bb-e720240b-1086eb90	3
143	3	79144f00-46faaae9-421943f4-7ded1c5f-03dc18b5	3
144	3	a78cd855-d42667e0-6d864102-71791522-7363a833	3
145	3	bd3372c2-93a7deeb-0f72b1aa-c069a50a-6e25ae3f	3
146	3	289724d7-ba6ffb92-010773cd-009ebf50-9b26ad7f	3
147	3	d241cda4-81e411fc-e3ac6aa6-2e59ccca-6ff81e37	3
148	3	becae8c6-3179439e-5d55f0b8-2d8bbe84-222ab18b	3
149	3	2b0608c7-cb48059b-4a1b577b-86abeeb9-a63df93d	3
150	3	586beb43-db369654-fcc82f7a-f3095e05-3c1facff	3
151	3	f9bce098-342165da-66347588-3d25e05c-6e316088	3
152	3	9bf6f1eb-cedc103a-b2a53b07-8c295760-c588206d	3
153	3	ba977002-ebe74e89-09b2d0e5-a6226917-fe3fac14	3
154	3	6a098f56-c16dfbd1-dd51a50c-4c0d7d4e-009b4904	3
155	3	b8b39433-a5b20d21-b976b9c2-f72bf25b-9a963d07	3
156	3	42b772cb-930917a5-8cf10687-412cf91f-4adda905	3
157	3	c7b697cb-55e769d4-a77bf82a-3d05586f-61e997fd	3
158	3	ff886865-966f1054-c0da6d5e-688c5167-7ab1ec78	3
159	3	3dfbe4fe-6ab3cf16-a6c14ce0-9ff9cbda-3fd09a1e	3
160	3	94e5528f-ca265b07-e50c9156-9d40772d-ce9de92a	3
161	3	3cf6fb60-022c18c6-c6f1738e-a4d710ba-9c49cd1a	3
162	3	bf008fbf-6bd9e298-00c93041-cf4e9807-c6592031	3
163	3	65df9b7d-fe4b8d06-48bc93b8-b991a885-09169c52	3
164	3	09c3e0f3-e619af16-628d460a-1d01f368-0680c2ae	3
165	3	1c95230d-93ba01bb-426b28af-cf6e75ab-4600a4ca	3
166	3	ee948115-575bc993-5b9ef5e4-903abb4b-ddd6817b	3
167	3	f9a6d126-30a4a18a-d5101068-939e3e44-e6b0ee00	3
168	3	7907ad9d-fe77e0e7-98b0437d-5d428c06-b523fe16	3
169	3	0fa0a66b-6042f78e-0b324487-3e116675-4478c476	3
170	3	1f0fb661-8816e671-ca3a41fd-d97fa6ef-b70ad2e0	3
171	3	fc134556-b5b23c5b-d7cd3348-07d562e2-51d94968	3
172	3	06504a78-7caa4682-499f390d-7a782f8c-1c2dfaeb	3
173	3	b7e05ec7-ffefa755-7fd164cf-9503bc4f-5a72a9a7	3
174	3	85321e84-8f87ea53-c6c6edc4-77cb1195-3338a849	3
175	3	4f543f48-bf37e2d0-18301485-ebc0764f-2729a3be	3
176	3	c475210e-4218dd52-2e073da6-a98a9b46-1c71bcc1	3
177	3	bd351934-171f7b21-100bbfc8-3f5a8368-c9794e43	3
178	3	e0bc15ba-3917a9ba-a8853a89-86c70314-5d39bb73	3
179	3	9a5d69cd-46bf619a-bdcb65f5-08cbc4ca-0d009461	3
180	3	87eeee25-bc02f389-98bf9507-7784a6ac-fcf1b482	3
181	3	54510e37-931ab42a-a9ede10a-9904bc00-30fee686	3
182	3	3488f83e-4c733aae-f6a3e6a2-5bc36636-d49394cd	3
183	3	dd8e5ee2-aefa646d-324c3cca-c2e71e81-7c6aab0b	3
184	3	8978662b-975b5e98-66cfad98-513556f9-ecda3dd9	3
185	3	60978054-22534be1-b455992e-5b2546d2-2d1a65f3	3
186	3	7906ed57-ba19a447-ac597eff-8d191906-a1d77720	3
187	3	7ac0c7a6-6252d3b2-c0f81472-655317c3-4cd171a3	3
188	3	da0346b8-12d75906-abd093f6-7d21dc33-95232875	3
189	3	2bfd1a24-4461ef62-a57a061e-f28911d9-f5195e92	3
190	3	800ffc35-82fbc1d9-a4f0a221-90621ebc-599674e2	3
191	3	29f13e51-4a0c2082-c9d2b5f9-413b6796-2a650e50	3
192	3	c98d6add-09ce9db9-7da43230-eafd47e1-ac8635f2	3
193	3	5abb1dd0-5341db8b-dfa63658-2eb51e77-1f6bc97c	3
194	3	8a9860f6-0cb70720-8707e673-4de2ee31-ffe393ae	3
195	3	7ed7d7d6-5ccbe502-06ba5921-455bc760-a6d2da96	3
196	3	7cd3d816-390248b1-342fd6b2-d89fffd6-3e53b202	3
197	3	6d9f7958-1989c5c7-43781e31-c2ac43e5-7fe240d4	3
198	3	51569550-0d3f77fe-3dd667b7-c562c728-1701470f	3
199	3	62f4e30c-dac37471-4138ca1a-497afbea-f9fe2c2a	3
200	3	c73aa968-089ba919-69d369fd-07473127-c554bbb1	3
201	3	2545a0bf-4b34695d-c55c9cb5-03529689-99306606	3
202	3	cbb049a3-a1ed4259-6471c0f5-ba270663-fa602a38	3
203	3	778ae818-d7b4fea1-e9371943-26566a9c-88c8f754	3
204	3	fd3c7437-46e4ef35-0f869954-fd661eca-3ecc4140	3
205	3	2f655edd-392cc28c-6d68108d-8ed4342d-4f41dbbf	3
206	3	10d44ce1-66b08d0f-18d78704-59a38b82-d396fc5f	3
207	3	e5185d06-64230e8d-9c707101-474e1d17-3dcbd6c7	3
208	3	a2ebed11-e20a20d8-3b297a07-f58d24bc-f9204b20	3
209	3	b7c6e5dc-cc454d01-6f8e7625-12b75278-0b0a99a9	3
210	3	ef7a802c-85bc35c0-71316fcb-b32ce0c3-b2ec35a0	3
211	3	2f9259a0-9d4748b1-c5027722-63d0ef76-691d7595	3
212	3	aa53a7fc-5e0818d5-2d60982b-2bdfafc5-11d0ba15	3
213	3	e3174bc8-4ee2d983-e897766b-2d12e751-caeee202	3
214	3	26fd56af-3760fda9-e005457f-670f7e74-26161ae0	3
215	3	96eab919-2be1b67a-1de7a82d-2d1033b4-8b9ad0c8	3
216	3	0b034643-41bf193f-1ece3aae-9547e046-ffcf74b1	3
217	3	c5bf859a-7446d0fb-8a816545-925692e8-c982de87	3
218	3	3b2e7b90-98dbd57d-ff964042-f4a2df0a-e4aedd1a	3
219	3	430520c7-84ea858d-c2cdcb7a-c8e912c8-7f49ee5f	3
220	3	0b290bd6-f96e6281-be66c140-be842fc5-58286ab2	3
221	3	018e0d87-8c8a6b22-49aa5578-683f0998-60a22af3	3
222	3	aba9c254-0ed5e202-427540cf-bdbaba1c-e2c8c91e	3
223	3	8f7e518a-89c09434-d95668dd-615c5886-97e66edd	3
224	3	eb5abdde-a4f27d27-5b016701-4b30f024-83adac79	3
225	3	6524880a-2ad1055f-d088b375-8be9aaa6-376b14e5	3
226	3	1f64285c-96743990-3e7bfcbb-a0900381-77a54ad8	3
227	3	dc6f60f5-94744669-6d681cee-a91c7e0c-49e03617	3
228	3	98cb9e5a-a01016a1-802ba45d-dacad986-f9b194f5	3
229	3	5e9867a3-21c96554-44fd3061-b003dc73-57c46e79	3
230	3	193be2d6-9470e772-eaff5c3d-75647852-1c90e3b9	3
231	3	a253f2c9-3f9bb82e-7e8f1399-3d74d742-027d90d1	3
232	3	c428971e-b944210a-52a461a4-62d29f03-770461d9	3
233	3	8b85d16c-24a199f3-063f6206-61b82c9c-4c4c7849	3
234	3	8f8c812a-7df990dd-34c75b44-b86921ca-3786341a	3
235	3	8e25e703-31bd766b-c6d42fab-9195b3d1-04eb2ca6	3
236	3	fc09d70c-72e7c86b-8138dfba-45912467-3d85d08a	3
237	3	06ab5ae9-e298d38f-ca22901e-68f6eca2-4336b9a6	3
238	3	f048cbdb-3b4ed38c-2b7cfbb6-c9e9a604-e0a67c41	3
239	3	2de89c29-0a2ad9a8-ef863a22-2abdab9a-83dd11e6	3
240	3	6cbb332b-ae5b1c82-23a6161e-7ffe63e7-4c1d38c9	3
241	3	61b536c4-1c45d16a-868b50c5-79513b3e-ffc0ae62	3
242	3	c3e76b5f-0e9b10f1-21c38a7d-0244b080-0c078821	3
243	3	904222b0-36acc3d6-e788ad5e-5eabc8bb-25353af1	3
244	3	c1441b26-706c165c-a314f0db-c2ad261a-45b48992	3
245	3	c581ba08-7cb9af62-00eee488-1e7e383e-b333256f	3
246	3	4a7e7cd2-1d49c55c-d713124f-f7acb3b1-02fd4cf9	3
247	3	6e00cfec-35f37cda-20575226-f37c034d-0fc1565c	3
248	3	78dee38b-97aa6b3e-70672a14-27c156b4-6148817d	3
249	3	cc07acbb-f4b16925-4fa23d61-7951806b-51fb56ba	3
250	3	3af08ce2-41d3616b-c8aa5e8e-d8cfb435-f867b45f	3
251	3	44081479-5717b911-ed56064f-030a57c2-fe0ba18c	3
252	3	66c51538-915dad67-f4aac0a1-c4ae7e8f-3fe5e61b	3
253	3	2cac0d3f-9e3393d8-2eaaa8e7-2f198871-529d5093	3
254	3	139fa70a-abf693fe-d25ad12b-cfa266c8-72b6c378	3
255	3	f1e290de-3a4f7261-28e0ef78-9de2900f-3458e8c2	3
256	3	f2c73eb2-b46a2396-b868ec87-b26327f0-048fdfc8	3
257	3	4ea6cd04-e979c5f6-1c6f9619-6e36e1ff-cf1e6a45	3
258	3	925c9943-246ae2a2-2fd8f0f8-b41fbd2b-319a83fe	3
259	3	9c476865-5cc73a62-8ce59bfa-67bf3a13-204bf71d	3
260	3	77594b57-519a9c5d-b89ec085-3b26289f-830219b6	3
261	3	4da9cd84-7d13eb1e-3c9c67fb-0183444b-8fe71e17	3
262	3	829fb9d8-801ca8f7-4fc379aa-2631f2cb-562755e0	3
263	3	7a954816-9185bdf8-f1d366e4-992e83a5-4ff3ac36	3
264	3	e376542f-fcad3d58-8f3bc0b0-bbfce91f-f701afc6	3
265	3	9b074859-bef0ca6a-04139464-49f71989-3b0066c3	3
266	3	4c6e0adf-95e6c3f9-ef4b7229-59f34145-5939ca39	3
267	3	d452741a-2c2bd94a-20a1ed01-6802bfb8-16fa9372	3
268	3	52b62994-b492ec2f-a79eee5c-1af2af81-2a811277	3
269	3	ca2cd4ca-6e4d9fc4-98483efd-353f8e9e-9563d58a	3
270	3	32c2a78c-7e773f40-641aee30-fef3370e-6954e596	3
271	3	d3160dbf-3b571041-59b38ac5-d5c476de-d0874766	3
272	3	bb0a2754-af333c61-76059bd7-cc6b2bc4-5b8f42e9	3
273	3	24c7bf39-793510b1-2e705df8-258fe641-07e70051	3
274	3	8311acf3-e565790f-ea87de76-4abcd387-af4fd859	3
275	3	4fb9d245-8bd6872b-8ac8e381-76b3e209-1d4801ce	3
276	3	cc000787-1ec011af-06d3da87-7c2356f2-88e11546	3
277	3	5deeacc0-cde79fd3-3d826a9e-99ba21ff-f0504e46	3
278	3	ec6c265d-d1d4ea63-a61e105a-21a3f854-6471305d	3
279	3	9b7df282-6074af45-b5db317f-2f7d74e7-9b7b5e5d	3
280	3	0f112cbb-70669e72-993e2a64-301b1333-78043f6c	3
281	3	2fd10eb7-b42322e9-453558de-418d9ec8-74a3b5f5	3
282	3	2b15f4c0-54f395fc-e4c956ea-bbce2052-3be48e7e	3
283	3	d4f11fad-3ca25f09-157ba323-b4e06c18-4847aff0	3
284	3	5fc24882-00b9cf5d-f8d8f7d3-bb28fbb8-950a9da8	3
285	3	11934afb-03bc37b4-7387b91d-4c0f423d-87388d5d	3
286	3	f03e2938-10faa81c-450ea2a3-c35a2279-d352b9cf	3
287	3	9a708116-307b626d-f7d48961-4292939a-8533921f	3
288	3	0295faef-693652f6-ebe8d956-fce5aac3-87922716	3
289	3	ca9b32be-8a43f9f9-7db002bb-68d1c0e6-a42302a4	3
290	3	e87d7a6c-43c00466-2166783f-5aba2a38-808ee2eb	3
291	3	8247ea4c-5710d831-5bba092c-e16765ca-df96f3ae	3
292	3	2cee60be-c62fa84d-294835a7-b425fdb3-a562bc41	3
293	3	afeb8839-83a9459d-b1ecb413-c15d0732-c7e62fb5	3
294	3	9670f5e3-3cad0f0f-9bea5fa8-445f643b-86eba663	3
295	3	a04e82fa-7eeea9ad-9405944f-93b8c59f-f1c988be	3
296	3	7e85091d-e084df52-af647158-88b1972e-1517a8b8	3
297	3	76e45412-612e0bb4-f20b3e39-58391c7f-15d40c84	3
298	3	b33fd80a-4c8ee8a4-d4be6177-e8e1f3f9-99e2047e	3
299	3	a2cff2fc-9a941009-37d39fb3-314e1dcc-7c642c84	3
300	3	211e8fcf-9406c32e-5caf0b14-eae673e7-033a4b61	3
301	3	16692a26-f744e0a9-842cc38a-6dbeedb1-c5cded0e	3
302	3	7ba1caa2-077af892-3c447d22-10c92dcc-da8f0b76	3
303	3	3c369f0d-1fccec39-9d282da4-ede0023c-4a0d2e98	3
304	3	5d176e38-2b338773-c6db47b1-5969b90a-76b800a7	3
305	3	2cd1df00-e504171f-0899e21c-19a0d94f-fe825ad1	3
306	3	f94204ef-f3832796-4ced61ee-874fa47f-6e0df99a	3
307	3	73000eab-5a8ddb0a-374f92cf-f7380a42-5af259fa	3
308	3	1b8b763b-c6973b31-0479d060-10980d19-0e4c3df8	3
309	3	02c0f0fb-c47eb4e4-a9ccb88b-022371fe-83ccc6e4	3
310	3	b36a07ee-d79c96f7-65d23231-33f71549-7a5e03f4	3
311	3	f9d44b76-81ff7e81-ff666d7f-12f089bc-40e3b14d	3
312	3	4ac2ca1a-19b549b4-14f0f770-af9fb0c0-3a29fa41	3
313	3	3859701e-43d3d349-7885a2f6-1fddf7c8-cb9d3ba5	3
314	3	ec5aaa48-4534bc0f-5abd251d-03c1e72e-8f20de68	3
315	3	21e73332-b75a4877-be228585-6196b897-b67a0768	3
316	3	c38bd989-7b55b9c4-a3d5953c-4006616a-3d1ef7a3	3
317	3	3ee5feb8-34403c90-9b521183-fb971e5b-919dcf30	3
318	3	f2c140b3-a7e6f58e-b2b6754a-350d05e7-b59ba15c	3
319	3	3456e392-13d16c30-2018b134-5d496948-503cd15a	3
320	3	5d4966d7-ed68799d-503e461c-036152c5-3b9f5644	3
321	3	58611564-8e016771-63d958bf-45ca2531-4dd2c670	3
322	3	16d8ecf6-a758a610-344cbef1-32d3440c-7211aaa3	3
323	3	ddd5fc37-409a59d5-0eb17560-9bd085d6-4042d97c	3
324	3	79c8af5a-7c157f99-e5c8bbec-50d0e5d4-d0547360	3
325	3	5bf1cfc9-ab178a4d-443bb2ea-9e0c705e-6c8c5ace	3
326	3	721d7c04-e9541c2b-ce15417b-8f16b60b-90766e62	3
327	3	0346b8d9-7f4ae576-7e4666a9-9f92a6f6-a215bf48	3
328	3	9d9937f0-d9d77563-74df659b-922c93c5-9404ecc5	3
329	3	96e747d6-a3ea3041-3244abe2-f9176a1a-97d74c0d	3
330	3	5302030f-91b4b921-198ca7de-b73a8aa2-bcafe081	3
331	3	45f61c8e-84ae8c8d-c313599a-f7ed1d4a-1d75d2fd	3
332	3	66a8ee80-cad49841-03e73697-292da8f8-7935e116	3
333	3	e4c2e515-43e1c4d8-08da8a26-7f62f6fe-43962845	3
334	3	f756788f-c956216b-25d142df-cc4c7954-a0e1d070	3
335	3	134707ef-66308791-fd72d474-c0435a47-6e5c0741	3
336	3	d0aae201-1f107cbd-5e91554a-a5abcc69-9ead6090	3
337	3	97832a3b-0cca026b-8814ef20-abf39c9b-32ce660d	3
338	3	db351fbf-8ae1ab36-8c76be14-293ebf9f-ca59e8ce	3
339	3	63153fde-91cd9ce3-9096ecd0-f0646225-0da040f5	3
340	3	944c6834-8f788ea3-2be7f487-65a9da93-b52247a3	3
341	3	c59663ab-66818242-ef4ec21a-ed62b039-14416b86	3
342	3	a7bd631f-28b2acdc-a0ca313b-3fc56f28-4c548a1d	3
343	3	99d5161b-f63c961a-1733a78e-3f7ac43f-0630c77a	3
344	3	c6703032-6ea02592-46e6f5fa-d0f5352b-84b754dd	3
345	3	26a6e3bd-afdddc1e-8efc6571-5da6e277-ac0450da	3
346	3	c0dea5cb-7b07d5a4-a2ef0a06-326970b4-74890b94	3
347	3	afa31d10-815e1c98-db071040-51963318-83a479c5	3
348	3	208b58ce-3f47de9b-eeea5a03-ddb88046-c14ef82f	3
349	3	3a27123b-ebba20c5-94e64a26-486c2cd3-8fa4bdb1	3
350	3	9111552e-8174febe-bd6b355f-0210eda0-f2a0a21a	3
351	3	3072e009-d5cdef20-6607a693-341e5aee-34c83246	3
352	3	806ba666-b5d2b379-114cbc06-20fd18f8-9333d5b7	3
353	3	ac08b2d8-3704978b-2878e673-7806a453-d1a45881	3
354	3	4e5b9c45-ee211740-ea2cb3e8-05c51bdf-d109653e	3
355	3	0ead1584-0851a214-40d75550-c7eb2585-993a0e36	3
356	3	c49e175d-19b89b3f-dff115e9-0ec510d2-4dcf49e6	3
357	3	a2379fe5-6b12f7e8-83b16aaa-6616a773-567c869a	3
358	3	f25565ec-138c8228-2a7a0bbf-b4e399eb-c154af15	3
359	3	29575e93-fbd79cd1-c6ad8df3-9465e2a8-52389051	3
360	3	2c9c703e-04c5a975-482f9837-da1a8712-6e0b09aa	3
361	3	4d9520fd-88ecebc9-1e2ebde0-c4bde7cc-1c8cff56	3
362	3	809668f2-dbab03a9-806b3293-cac55123-19648333	3
363	3	ce72abd4-3436ea65-a3b0909b-8fb719bc-e826b96c	3
364	3	f31d28bb-cf5dfa41-801a4b0c-aa3540bf-2d499d6b	3
365	3	41c40e1c-15dfb2e8-fd131838-4321d7e9-02948eb5	3
366	3	16ebddc6-d5c13f75-790b895c-a89b61a9-7ec98f8c	3
367	3	32f51800-fdd0d8d2-b95c8efb-41628a5a-682568b3	3
368	3	005d2295-e0da5788-5d2faf8e-ce16cbda-26c95bd5	3
369	3	bbc86c94-df625a5c-dd829e02-1ca48204-8e1f8ae4	3
370	3	05ef295f-3a13c421-fa18ac22-38abbd84-43b6f698	3
371	3	40a68e77-a24f4632-4e78f3b6-0ed13bf7-2e0fc766	3
372	3	eba0de0e-6505c24d-740d4645-9ca152d0-14c8e3c3	3
373	3	a6395e8a-6842cbb4-c9969f9f-7db690ea-84499ef5	3
374	3	8aa178a4-7a6a8064-2cdff515-9603249c-c8eb9e99	3
375	3	bee94206-df26752c-8c438391-4e5a38b6-056861ad	3
376	3	222c084e-d0e5f79a-934b2b57-1b04288f-2a225642	3
377	3	6b5f6961-ffbd554c-644e8025-b7ead316-f3510917	3
378	3	2775684d-b5687b85-fc9a3c62-9a372f85-86da6313	3
379	3	35640258-26882e56-4568168b-741386d0-db9293b6	3
380	3	fc6ee866-ed3db6ff-85fa1913-8138bbc6-13d8a938	3
381	3	0e3fad9c-61264800-b5062392-30d8c5e8-e89b7718	3
382	3	a7e3f2db-5098a438-28865e91-ffb40949-42557272	3
383	3	f630e6bf-c2bc12d1-60262143-00bc6fd8-06859cc7	3
384	3	c04411e5-2b0af24c-52db2a15-4f1f7a2b-889bac14	3
385	3	1052cab2-c770d99e-cbbd6db8-152e2ae3-199eb353	3
386	3	83c9c2e0-0043ae36-f044220f-1a9950a6-b7830df9	3
387	3	0f299631-092da598-b1b37803-0eae3811-bda78546	3
388	3	a5f0af23-e57a136b-58ee8902-dae20fed-34e03de7	3
389	3	6eee3b80-ff9ff297-9d01d33a-88e48e04-9d3d82c6	3
390	3	53cb3f12-2229d5ec-00c06956-7c5bcae0-c7ff5e2d	3
391	3	fae92e92-e3a42ad4-0bb7762e-b1958ff3-eefb22e4	3
392	3	caae5661-b4ff2d41-9300fa8a-1a4736cf-ce016495	3
393	3	ef119895-60c34347-60718c03-d6812e80-791f7e1b	3
394	3	cb95a928-f8f7b6f4-f8d3fbb6-f5c0ae40-9b1014ab	3
395	3	5cfaf59b-c1f44d7d-11148f81-5307f23d-528c6d4f	3
396	3	7c819538-16714048-df6d6444-a006bc53-e64c5ef4	3
397	3	8b96f4f3-892d0de3-84826ced-47c4d1db-205a380f	3
398	3	447644df-44f3fcb8-177964f6-3484bfa3-4e42a873	3
399	3	f2b81a28-2167bf6b-8e23a2a3-1d583f3e-3af30e26	3
400	3	a3d05233-60f818f7-9b6c3a26-c050676d-ee107370	3
401	3	56f46bf3-e61b967c-6d0f686c-e9e5d065-0532a9d8	3
402	3	ad1969d7-4441b07e-dd72eb4f-2534cfa7-19313c19	3
403	3	49b0f983-7c837ef7-877fb75e-4168629a-87151401	3
404	3	04a7c6b0-e3c263b1-310d76fa-72951c63-5f08c473	3
405	3	0284397a-fe603cef-ea75861d-270d139b-b6b2ef00	3
406	3	cc198125-cf8ba00a-e8d7e22e-1199262e-60c21d1c	3
407	3	3153ffa1-224126b6-1e6b2afb-7833de6f-0c1b102d	3
408	3	d800dbae-8ea24272-10bec929-23c2722b-b8e367a2	3
409	3	b5082922-c02c289f-78fc6168-b93f33da-5f79bfaa	3
410	3	633adfab-e4d1b3b0-eee11f96-f82f4658-c55b06cd	3
411	3	e5574242-90a31c3c-56dcc647-4b3f15de-93f65299	3
412	3	f76384a8-a26172a6-314f0617-8cb46755-43a7660d	3
413	3	3aee82f5-0f618890-c03eae69-0988a6c5-16b859cc	3
414	3	c3533db2-d7914405-8f188585-2674bc19-d04da550	3
415	3	156a6275-51493740-fb0fcbce-8a49c930-57191c42	3
416	3	7bd2520f-dc12797c-98fd1bb0-c0d9b752-263831ba	3
417	3	fec3ae52-2ddeb356-c048876e-04876617-72c47201	3
418	3	2ee59d51-07781056-aa459699-d083ec86-36a4a099	3
419	3	a4eae226-86b7a19b-28051209-0b268e02-ba5fe91c	3
420	3	b995630f-2a129f58-406c6535-d075cdf9-58faebd5	3
421	3	dda42a03-bb408bf1-25613f5b-5aa7cb45-e88a586d	3
422	3	ff0cf8de-d0dd7b4e-c18dc058-ae98d77a-e1b243bf	3
423	3	c02fe126-4dfc99f3-e365b5a8-6a1a47bf-42ad286e	3
424	3	75bed74b-ab5707a7-fd6fec3c-e58684bd-acb96e91	3
425	3	33705677-b878fc81-42bc08ca-0edbafda-40e9b3b7	3
426	3	e69c7c1a-96b5520e-8a597689-6cfa447f-3486c327	3
427	3	df8f1cdb-e1438564-4152995b-00ddafb2-29b04289	3
428	3	a0a09f73-c69d7b15-5cad54ca-cbf0da8d-6df07891	3
429	3	ac2a5a39-72ed60d6-e8893386-2c1a8977-3865fd43	3
430	3	ac69803f-0ae16200-52bdffdb-892020e4-fc585cc2	3
431	3	367c0b5f-dd1493fe-511881b8-8338cb6e-b54bd92b	3
432	3	935bc0a1-88295663-da0927b3-514ac7fa-41d90a2f	3
433	3	4fcaf05b-c371a6ad-1be01cca-412e7f29-f6180577	3
434	3	2a924c02-3931a3f9-a8d27d2c-8c538b86-375e65a5	3
435	3	7583c9d1-495a6c10-87ce2b51-a53c4150-d8aa3066	3
436	3	eaa37c8e-59a5b2b4-92b4965d-88d38533-3ede8e65	3
437	3	70179f80-4831b5b5-3c387228-a29eb1c4-5c8a8cdf	3
438	3	3bf7f9d6-2076dfa6-abf4084b-5caa4f07-8e33e8aa	3
439	3	9a1e823a-123584a4-3fc39e3c-94ed95a1-1a4e136b	3
440	3	92b5c8bd-35727e29-ccd29bae-39477f56-3dd1a97d	3
441	3	87c626b2-8303672e-b8892ded-5c530f14-b2cef282	3
442	3	d57b1477-11dcc7d8-0dfe3c86-0669ac10-2e067e8b	3
443	3	6a7cf890-dbf6382c-da3160ad-3a1fccf0-1a0a919e	3
444	3	78bb1b07-69e163ad-454011ec-2ab6d64d-9856138b	3
445	3	27194ad7-b6815195-51b7c24f-73c356dd-7fe3a318	3
446	3	87268714-65df571f-9279c855-39338e44-32ff08d6	3
447	3	41a4a4f9-e6607567-144ba489-8578b029-59cd84b1	3
448	3	424cf794-f2e4b73f-26c5424e-39ecd476-9bb4bfe8	3
449	3	e3e7782e-0741c024-c57e8374-1ccc2840-e7961d43	3
450	3	4bb4dcca-72237252-f5a1ce0e-75da63e9-c56e9673	3
451	3	3850be5e-9ddd664e-80bb74a0-eed22319-1f27e594	3
452	3	756ce1d4-4e9e7908-4b8851c4-8ecd74cd-617fed21	3
453	3	b7ca0884-86bca6d6-04cd3172-5fb42ca9-00f6a773	3
454	3	e1e9e7c5-af587165-b527420a-29499b4f-7ff18912	3
455	3	5441608e-de546b6c-5c79c458-cf89eda9-9c3299df	3
456	3	23721647-a163bf13-c89bf00c-a823159e-75bd9142	3
457	3	dffc5a1b-74b7d867-1fab99d3-aa4672f2-e1099e07	3
458	3	4e14b3f8-5df28868-ebba0e6c-7ab4756c-a6235f4d	3
459	3	a415ff21-c148e322-301ab2cf-f97a6c0e-dc3926a3	3
460	3	263e2049-6cdd7199-91459188-1e3245d2-ec726b36	3
461	3	80904c21-c2bbd700-bade556d-081d4e92-59acee07	3
462	3	bade01f1-16148e32-7fed91c4-c9d2eef1-6ad919ac	3
463	3	4221886e-dde71fb9-876f117f-031da65d-2613bf35	3
464	3	b06773ed-375947c4-0a7d9a22-91833912-7e84bfc8	3
465	3	299afc33-3b1e0b00-d83c1ddd-8770cf0d-e05d1e92	3
466	3	700c6db4-b57e9685-4290b0c6-0883878d-6e77f09a	3
467	3	14092895-a13d9a7f-89932b1f-7a34fc00-3a054995	3
468	3	0d63ac76-8e3f4fec-ce456083-6ce3baaa-7038fd13	3
469	3	65787d01-af617310-381c5a1a-c9e3f031-76ad2251	3
470	3	f4fc120c-e16a4682-3a3aca00-7cc4bac9-7cd14242	3
471	3	00b308eb-e6197290-3e1865b4-caa6bd37-38b033ab	3
472	3	4bcff39f-45a96f04-53ce4b86-f9297dec-05bac4f2	3
473	3	773f1c71-b87ba09f-892e09ee-6933fe3d-4a6d3145	3
474	3	706cb702-658e8d81-ae414fd8-87d89d6c-8e47d055	3
475	3	cb164c19-df1a5988-6f37b12d-0336c8ee-169c25cf	3
476	3	219ac9e2-7b2bbe8b-8dfd9002-c2be96ae-9988ab9d	3
477	3	aa8405c5-21cd0eb5-a5b5de39-198ccc1e-836b9bc7	3
478	3	525621b6-0c256015-d87a1130-26a8d853-1f39e850	3
479	3	1095e599-3349200f-235d91c4-a5ece086-cbf818ef	3
480	3	cda0e548-ef830bca-8b153f52-0f8cd5db-aed1f726	3
481	3	0af3545d-465ffcb2-cd0caa27-74f73bd0-abc0af44	3
482	3	68018254-6364ff36-bc376e42-091933d5-46089970	3
483	3	d0e6a158-c7a4af87-34f2704c-203e0db9-d93da376	3
484	3	dab1f0e3-b457ee13-9513cccb-195c402c-952eafba	3
485	3	afe3fda8-0473cf35-004a1cbb-e4a5db3d-bc8cc468	3
486	3	576d786d-4f7d5e10-b8588066-3467ccde-0f6c2b10	3
487	3	05d85b0b-3bf8033a-df606cdb-4d665aae-09559f8e	3
488	3	02c4db31-2f983335-915981e9-af940a6e-9a7c5e8f	3
489	3	1d6a7e89-92e253ee-6a7f276d-d3d554e3-d34b449e	3
490	3	2e09c9bb-e7699f6e-e5ae8ae0-f09daa8f-1fa4c799	3
491	3	ff6f9a27-48508f20-d6fafab8-70f2c97e-4ede9e98	3
492	3	37ea99e1-c7b4da8a-7308b584-1cf06f51-3b7c179b	3
493	3	b2ca0d83-070c1776-8788ff3d-ae299444-656933b0	3
494	3	a8d0d37e-029c7c24-6c237af9-8a8d4c8f-3c77e94e	3
495	3	73e2a39f-17255882-50ec8ad9-2da418fb-aa64c33f	3
496	3	f36ce03a-7896c74c-9d2bad18-42a07639-f4770ef5	3
497	3	1fb9ea86-adcb0cd4-da0e8e07-f35bbe94-42367296	3
498	3	46d23026-ccc51f65-54c596f1-a1cba22f-8d7ca9ed	3
499	3	9f5ee5bb-d2c3de47-f2b467b6-8a523cf7-4c1e1cbe	3
500	3	e31e5b4c-648cebba-52ea3225-52c40cc2-fbc8bb7b	3
501	3	6a115ce9-4260f768-2515ccdf-4952ab0d-beef3543	3
502	3	e5729133-f5a88f38-76b5933e-dfb4c6de-e4eed27f	3
503	3	2b48eb47-0d7d1571-e4c07ed5-bb13784e-3ad1deb4	3
504	3	c6f78c76-73f0d94b-28e9c5f4-dac36f42-d1392fab	3
505	3	ba434bff-247b8b13-e22ee79c-f5be301c-fea03fa0	3
506	3	77122f5e-5ac2db64-eb7e75b8-68f02d33-b66be10d	3
507	3	4f580c68-896dc86e-5350dec7-22fb6e6a-750e7148	3
508	3	c69941ac-5f116a16-b2248e31-c0ef2c6e-92e646f8	3
509	3	0fde75d6-faecfa30-ff5b183d-324c7100-1538d45d	3
510	3	85c1c80c-f41f25b6-45724786-9f7f6b22-83959fa8	3
511	3	b3f12119-6c56fee0-44733f5c-8cf5af9f-1142db2f	3
512	3	36c26ae4-71065f80-5d65dac1-2e473b87-d6fe0d38	3
513	3	9757fa94-f923dde2-c892403a-450e74f4-110ad804	3
514	3	fdd8e214-4ff7dfa0-f28617ad-07d4e6ec-f1c437a2	3
515	3	028b461b-cba0f8db-f753c112-3c0d5c40-44804496	3
516	3	664741ee-b4ed052e-30a876fe-a7d7f5b6-624dbbfc	3
517	3	cfb055a2-107938af-5786c831-a946d6eb-fb0d7e24	3
518	3	e3edf498-c7a343b8-560bfde5-83adf3e1-1d1daec1	3
519	3	3138e1cb-0bb38568-549d4c15-71af399c-fc7a7821	3
520	3	95afd37a-ecba9ba1-8ab144cd-b0ce9437-f1e70131	3
521	1	750255f1-a6d57cdf-6f7692af-b6eb20e8-76b2cd54	1
522	2	efaa3f76-3f783699-fc03ebc1-478f63ce-ada73aed	521
523	3	3157f791-e5e24a34-560adce5-06775cf8-1e05a197	522
524	3	2326b69e-8022e335-b108b166-7ef1bccb-f9489382	522
525	2	9c578fc5-a4fbc569-32e66254-0ff74d68-67e2cb56	521
526	3	6b8049b2-ee32f541-8098e714-cdf36e6e-7a163c15	525
527	2	4ab1b21d-c1dbf462-a61e616a-77ea8f5e-1dc32979	521
528	3	f85160ab-09a7d48c-50451e25-095e0e80-788cbe8c	527
529	3	06ad4401-5e8b9d46-ab6c3913-5e4d24fe-eb7152eb	527
530	3	02e3ba6c-f6371ce4-00f69a06-e6bd0c9d-61fa4088	527
531	2	f464a6b5-34ecbc9b-46c91f87-58af8bc3-07c432ba	521
532	3	672020e7-d180b3a1-6d05e585-9280e617-129aac59	531
533	3	0a42b689-25b478b9-03bbac34-4c13f26b-73456e67	531
534	3	03a6ce20-08baf859-a581268e-9eeec286-91f7d101	531
535	3	e40ba4eb-8dee9b1f-777224fe-67eccb18-0a768e8a	531
536	3	2433eab8-5d254a6b-11306feb-ee5303ea-eb66b2ef	531
537	3	24ae94e0-a5f54724-c082046a-ca840fc4-ec00368b	531
538	3	d80554dc-83f6bc27-8e85d053-64beadd5-6ec24846	531
539	3	35c4b4d6-818c7616-9b7b376e-1e73816e-9b5485c0	525
540	3	95efee66-f9e71862-0187b4f7-9fa07b57-8d41a491	531
541	3	79acad98-010af990-3f68bdaa-be6f39aa-611e772f	531
542	3	980fe032-c2dbfac4-e8f2caaf-2cb3e6eb-2480e80e	531
543	3	c8931ff4-c5b09a5e-2c1a95fc-17411a64-9b15fe15	531
544	3	3466a722-aeb04ce7-09b8671b-8f1a93ef-0db5cbf7	531
545	3	9617c643-f0be9c99-a6a7d3c0-4d6f97ad-0501a269	531
546	3	37e764ee-a59b03b5-8d98c5a8-e1cb3eb2-c9f793ce	531
547	3	51b1cd0b-91656f8a-b0cdd19f-d62c88bd-c5644b1b	531
548	3	42b54f4d-2613cd94-a9e9f241-45e909f7-a277baba	531
549	3	8ab729f3-177569d5-ed32914e-ad012bae-a7e4b7ee	531
550	3	84b4084b-4c638e6b-8ca9d279-4d774aa0-22bed6ce	525
551	3	4f66f27e-ab2ea31d-4c5f6b6d-9ef8bf71-3e99c63f	531
552	3	3481cf32-ef3b04b1-138fc649-92d0ff21-70066c50	531
553	3	f90c829a-a8de4b4d-55cb46a5-ae110d21-0d121390	531
554	3	bdb08c25-a0308db1-7ac81fc2-60089697-b535d925	531
555	3	bc19f4d3-cb3c0925-1467221c-3d3889cb-52f55dea	531
556	3	31ac7313-fa3b484d-5f40f502-1446e535-743cac71	531
557	3	ee1f6e03-bb3b8565-39547e67-b3a66d18-0bb350bb	531
558	3	15c70f1a-35031353-6f0122df-cbd76880-96122e7f	531
559	3	eb8eb9b5-daf3c215-09c6e5ba-1591c49e-68fe8777	531
560	3	5a998138-2897acd8-beb3f144-13fc3bd5-7236daac	531
561	3	4b56f21d-2ba9c237-e27c608f-e5b2934a-0aacb542	525
562	3	845e98cc-4083f6e1-a860e6fd-347f8dae-2d8bf1cc	531
563	3	417e8c1c-5a646c24-a74ba06b-f2f4b0bf-a1f2d95e	531
564	3	c42c5b5c-107a778e-07e6fe36-8bbf3ec8-c7ec98f3	531
565	3	c76ca73a-75433994-7f2d2827-fe23df3a-c5756cbf	531
566	3	3494d2ba-c69810dd-7b8867ed-b1741005-9599c04d	531
567	3	49eddcb1-f619c871-0b580f41-20093a4f-e1952ad2	531
568	3	df3da8aa-3b00bb36-065b95c0-ed053a2e-35e985c7	531
569	3	301f69c9-10e2e890-d46d7218-d01b44b2-7f356e39	531
570	3	6f038135-a8a8d83c-06f74dc0-ba71a0a1-c6875090	531
571	3	920f45fa-73435a5a-8d7dc12d-1dae0f53-4e26efd3	531
572	3	c3953912-95313ced-a2b80143-a35bbbb4-1013106c	525
573	3	027e6353-e51fa146-db2ff1c7-f3a7c5a3-4e54a14d	531
574	3	c9ec8698-7702edda-5c5c0b56-635d0b3f-addc3493	531
575	3	477125de-cad1d7a8-85ce0552-6cf7b479-4dcfd64f	531
576	3	94724279-6c4ba0f7-6f1fbca1-59c9003e-df953315	531
577	3	562ebe94-10fcdcf7-42f9b165-7bd1f481-e8a23bd4	531
578	3	86b572d0-db2ab6ea-fa26834f-a91d1eab-4073b61a	531
579	3	b6fca057-7072369f-8413d9f0-c56d1277-8a821568	531
580	3	87c7090b-9eb26626-c27cb8c0-29fae0b5-89e82673	531
581	3	19a9ed5d-25097e65-2d36e9fa-6e39ce83-dd7f6f68	531
582	3	76e4d98e-2e389fcd-d240a05b-b1ba1e8e-9fcdc19d	531
583	3	9cf71c43-c4359e52-8f0f38cf-5e39ab15-1e9b8784	525
584	3	0a66a956-cd8185f9-6051d31e-61d78018-f9a774b3	531
585	3	add88e63-1b5cefd0-fe335843-12086d37-026d57f9	531
586	3	17d529b3-5abca972-82a737b0-13be84b5-1cfc16de	531
587	3	0f209ed5-0b437837-5a426b40-43cef72a-f64a0607	531
588	3	d4664f7c-4ad59e80-ddf97f07-b1b49162-7283c4f2	531
589	3	f021d56c-735bb570-9588012b-9c15b9d5-a9070f23	531
590	3	9d5f76fb-fd3f971c-352e20e5-2df62a10-76432aff	531
591	3	b0bccff3-df2487dc-7bd939bd-a392effe-e40e9d01	531
592	3	5ae7e9b1-048d5fda-822ffded-d43b2c4b-725f6057	531
593	3	578c5a6e-7c122715-ee863352-424c7e5e-b729951f	531
594	3	2b96f699-3d90f39c-12200523-a6d8b875-df098429	525
595	3	3c95cd9b-2fb1295f-83fbf53a-e6622539-e4d0526b	531
596	3	f1702963-813574c4-ac592aa2-36ecd4ae-2e0894ba	531
597	3	536b17af-3d4c8d28-4b85d6c6-293e40eb-ef7c1737	531
598	3	ec79034c-89774dca-a6dd7af8-91e33dab-949762fd	531
599	3	8cbfe3e9-79b98999-14c16f1f-c9638651-d9e61c30	531
600	3	05caf5f9-3f35385d-2147155b-83e3a008-d8b7a7b5	531
601	3	d4f331bc-58b4f2f4-e6c92878-5beba05c-62ffc411	531
602	3	c3ef250c-394ac18f-2807b03f-40a74c9f-79a1e7cc	531
603	3	321666fb-d586b6b4-f1263d7a-345a5d6e-61b9ee59	531
604	3	38b4f259-8e256a5a-a14b1736-de3557eb-bced8130	531
605	3	b1f942e2-ce668021-8b8fbb9e-a237baa1-c98e6e01	525
606	3	f7d8ac47-f99ce829-7b3d5f7e-12f3bfcf-1cff2929	531
607	3	f74c382a-e1eba5dd-929f60d2-1cbb0959-10e27e6f	531
608	3	e1150d15-ce0154c4-bfec00c2-55c1d678-bea2e5c2	531
609	3	4545edac-82be9cdd-84579e95-42b6202e-6bb18ff0	531
610	3	bc38479a-637a3fd1-487d02c3-28622541-823d7c1d	531
611	3	739f86af-9b7273ba-96d54cb9-f8b25c78-4070d064	531
612	3	758dc882-b495d758-cde8cd77-a393132e-d5089a0f	531
613	3	821e26bf-672d1765-733cb917-4785ebae-fb6d4056	531
614	3	67b14661-ad97b860-adbd950f-8e2801d7-c09dcf27	531
615	3	0d05e433-2f4ae338-73d2aa5e-6bf5f866-079ef4b6	531
616	3	4f92c976-81c5b00f-b7655f52-0fe2394a-fa87bc9c	525
617	3	2e7d07e3-d5cfd7a5-1b1c186b-945a4f9a-e8f92f6a	531
618	3	d9b59d87-50868497-47e980ff-034a1a34-a31f584b	531
619	3	120a04d5-c28a1a9b-2249b0d9-d59e6460-2ab60c68	531
620	3	1fc32e6f-fa5ae537-ceeac6ef-df048fb0-eeb6df71	531
621	3	5bb92ebe-dade0c78-73a7b50b-fe0ef85b-57cef77a	531
622	3	e6eea3b1-c3393f40-bf5e5cd3-e6e7dca0-f657f997	531
623	3	c76167b3-495f9942-921cd0e1-40aa2717-326568fb	531
624	3	a7e5b8b1-d4a33b2d-fd7c69b7-c24331c7-d2811c57	531
625	3	62c5ac42-32a763b9-1bc9b63f-c8e4193b-233f2cf5	531
626	3	6b593d4b-db945a41-eb26eaf1-4e763ca7-8442e5b8	531
627	3	7ade9058-446cffec-008b4468-b793a01c-b950517e	525
628	3	9f5c0205-9324cc2c-91645185-1c600e27-628ea2ff	531
629	3	660ca12b-7296358e-9a24d5e4-6bc2b1c3-6a36ea40	531
630	3	d4f1bb5d-aef1e270-6f44870c-26e0aa41-173169d4	531
631	3	9ce3a6ce-79e93e77-1ca32320-50b2e3da-b9a7a598	531
632	3	635e1283-a4d19623-470976e5-11ec6ade-944967ec	531
633	3	ef1d68e5-2dc321dc-09531500-5878ea46-411fb5f0	531
634	3	ffdb5133-6bc5ddcd-d81f3f9d-df3314b0-678f8223	531
635	3	d60182c6-f1d39c61-25425f4c-2b443800-5369dfe1	531
636	3	0edfb661-a8b7bc31-9f858ea4-e22964ff-3743d8f0	531
637	3	1e9e5f69-2d4f1332-2d1d6cc8-5dcc117f-e8406ca2	531
638	3	6e19ce67-c13dd9a4-23686bc1-455d86d2-3403b027	525
639	3	b14d87bf-179f5901-4a5ffdb6-90298cd2-bccefbd4	525
640	3	3f7eb822-c35678ed-7129a14c-2d2bfe1c-a4410857	531
641	3	fca74fbb-324f1e53-4fe303ac-accc5c71-0e6f13e1	531
642	3	b9b23cb4-2a34c79b-a7bd4a83-a08c704d-d307b387	531
643	3	29ead1d1-dbee3348-f3b2c045-9589baad-f702a5b0	531
644	3	1da56911-c0501e9d-aab93030-138316ee-bf819400	531
645	3	d738d3c9-de53795d-36960bfc-c9eba501-84ca7c77	531
646	3	a62a4f9e-fd639aef-a8b03e36-e75edbf9-e06186d3	531
647	3	1244c9bd-ed0e4702-115bbe2f-4f09c2d1-88d8f02b	531
648	3	700a9f38-e8441b26-6d583145-e211b862-200d2b64	531
649	3	97af77d6-942fb35c-a9565858-0be0d370-49a5aadc	531
650	3	a66a1884-32a93a3c-72b179a7-d99fab25-5ff2e58f	525
651	3	069086c9-efb58e14-356c7e46-6899e3a0-8b48d301	531
652	3	71a57b9c-ab026471-3e8e2124-3abe87e4-641b8bee	531
653	3	27aa8a71-ff42dfa7-3cd45405-31848681-02630470	531
654	3	bb990614-90fd6fdb-a797a3f3-7caabc5f-df170fa8	531
655	2	8130ff7b-cf14afb6-7bb081f7-bbda0108-c4048826	521
656	3	d6411433-44ead028-91c143f4-f431b487-b7a9c45f	655
657	3	3ef48c6a-3fff373a-ef4f9e59-ee5c8269-3b2f3a53	655
658	3	8bb78077-7a4026de-244796c6-ea816d92-5df7e0ec	655
659	3	9c04f8ae-0f422dd7-10ad9197-c163f821-7dc14a4d	655
660	3	1447bf02-1adad5ef-c7d14c28-2c12ce94-ea93d5da	655
661	3	73d96bcb-307919a4-f93fa574-5fe81f20-ddebb950	655
662	3	b6b1e751-b16a3ab4-bd162d24-4841d8cc-23b9b57f	525
663	3	5aab9519-8f06a921-85bc3293-4b4c9074-164ec923	655
664	3	3c25509c-8cb2f160-48d863ab-d371b37e-fb230538	655
665	3	5c3cc359-90a11cce-f0cff548-3c617577-0d1f5cf7	655
666	3	0c37080b-7e6ab40a-bb28b9e0-0392c682-9f9a94d7	655
667	3	e06b1ccb-e8836d49-5d3c3593-e770bcc4-c937707f	655
668	3	66433e5c-97f7e6c8-7596beac-e98a0013-c05e14f9	655
669	3	18a5b982-258abf30-d22271af-74a0f3f8-01eeff6c	655
670	3	c06eddb5-e00cdc1f-466ca0af-6e83b03c-2b48b87d	655
671	3	d1d66197-0d4cc4f5-82843f27-6fe53537-dc347ec4	655
672	3	3e88436e-4324fd6d-df76996c-ce387813-b75c67e9	655
673	3	29fa8236-99828438-cefec298-29f26b2e-ad5d6302	525
674	3	a4cf2e7f-5b17efa2-4a70ca8b-f04b751a-49794215	655
675	3	df0ffaa8-b4726c9b-0bfb097e-329fb8d3-ec5a6dea	655
676	3	0bd25e32-74d15027-3c680d2a-2bbf8a7e-ccaed95f	655
677	3	fea03dbc-834c9847-23cacd81-55b3d662-c62aec70	655
678	3	ffc5d023-f9cb8dc2-f8e9bac8-2a34f914-7faada44	655
679	3	ac05b65b-0b4734ce-fe9bc52d-2502cc6f-25464e26	655
680	3	83fc43cd-81a4bbfd-4e234e31-ed909eaa-65061ae1	655
681	3	66713bf0-e60a550f-f33e0506-52310b3f-45ff4200	655
682	3	102b1c05-e84a0eeb-21de48c9-0c8af85f-585495c2	655
683	3	355f4544-b745ff33-b79a2832-64f66670-09d6ca51	655
684	3	e74c1dfe-ef5374d5-2e6dffaa-0750081b-93791e2d	525
685	3	0507496d-dc879eed-d38d23d8-db08f854-e1afe974	655
686	3	67e2f2a5-f12a1edb-3eb833e9-90a85ad9-17d88c93	655
687	3	733a19cb-4fbab30d-77d16074-eafffa60-69b9dc2c	655
688	3	1f34dc95-180360df-272d173b-392df523-38a2c12a	655
689	3	e320e0b2-d5aa29ef-182cb70b-ef06ece6-2abf7b09	655
690	3	5a547468-00b09e43-696433d8-7e2b6211-225bfd56	655
691	3	20f82841-11b2e281-3f8df8e3-15c88e1e-9de0801e	655
692	3	d7b997fe-70138aeb-4d1e289f-20a8f74e-7d90b5a5	655
693	3	6b8938bc-bc6164e1-b7dddd8f-a49db456-765ec2d1	655
694	3	8bf7911c-ce4525f5-e96641b9-c86a1ad7-136d3d87	655
695	3	dd611f61-43090cfa-a3b51061-ca81bd4f-3ff68619	525
696	3	2171d3f7-1ed0ac4b-26ead27a-01cc874b-b13cb280	655
697	3	c3885b45-8b2fdcf0-fc81e0ae-f3f22e8f-b950aaeb	655
698	3	b23b97ce-33577236-0d275698-d25a7f07-fafa633c	655
699	3	b1f0c063-4f109a2a-697f0fb9-3b7350fd-e4b24ad3	655
700	3	fc29a3c3-539e5a2a-37c0429f-baa29aa9-3672e981	655
701	3	751f2e8b-07959f01-7c7de586-97172a2a-96bd4250	655
702	3	589d9e40-62f1d941-8447348a-11acfe2c-fed7543d	655
703	3	99bb8f06-6cf08a53-3025c99e-ea7812ad-deafee1f	655
704	3	9e53350e-6d824bbe-1c86182a-f865c365-dd3b39eb	655
705	3	c062508d-d671e795-84c37436-a29cb5ef-3cc6d8ee	655
706	3	f559d159-bf3e810f-df9d63d1-b6896220-3a6e9e17	525
707	3	9d06c5a7-d9feeb52-8c1e70d5-eaadfc7c-f0eede00	655
708	3	3f37f564-f026c925-dbf64551-6bbca8bd-87bec755	655
709	3	dd04c411-0227a29b-63df6ae7-36012c8d-6b5c2fb1	655
710	3	b0bddbac-2943f3f5-619e0500-d6915c7d-d41d4269	655
711	3	5cb2d91f-851d826b-62944184-4f14d446-1d65c753	655
712	3	10fe18be-2058da3e-e2acdec9-112eb4aa-b40ee3a8	655
713	3	cdb9b4ef-a23a9325-fa142541-f8832ae8-d98979d5	655
714	3	846a182d-f9d68a74-554d49f5-ef36767d-d4b9e268	655
715	3	dfe6cc12-e4a11dbe-534aa375-98967d70-eacf858c	655
716	3	cb76ca27-4d299f3d-01f24932-d83856f0-39b4049a	655
717	3	37ca3568-62402b79-5cbba347-0a4d0e84-2163bdbb	525
718	3	778ae5cd-b5d1d7af-445e6bfe-5a9fec06-f7cd0ed2	655
719	3	c9a0c14d-e752cc8a-8a338a34-f0208dbc-cb149403	655
720	3	a3a4e823-03a7d19b-0392f48b-32154de2-dae452b7	655
721	3	86db1571-4fcc57a2-59650042-4cd69500-a9791ab3	655
722	3	1e81dcee-a753a089-a26f399e-86ca104d-943beb84	655
723	3	f5269b81-905164ff-89d103b6-259d0c80-6f8dc7d0	655
724	3	d209a7ab-2d7c749a-d8eb2551-e0f4538f-9ecf48f2	655
725	3	b36db4cb-8f882f24-41716e61-e08a45d8-9b6f97e5	655
726	3	6d43b37a-7029b9d2-6022005b-7478639d-12bc64fb	655
727	3	86e39da2-4c78044b-23d6d410-cd2a69eb-6a12a7ca	655
728	3	8a009eef-b990dec2-f48bf1d3-0d0400a8-83982cbc	525
729	3	f40de865-71bff23f-854f8661-61b3a70c-e7b7dd5d	655
730	3	f402cf34-a7b17349-bbdefe63-4f715cac-5ebe3b8e	655
731	3	1bf7af73-1e3f3cfb-12c5f5ac-618ca036-a0d46959	655
732	3	ee9282c2-ba5f6364-4e2fd7e0-c6a37fa7-e1956e77	655
733	3	a4afe46c-3314a15d-e3fec1ed-78eb32dd-71568049	655
734	3	d6a5ecef-7abb8249-41c81918-81f00f01-05fa641b	655
735	3	b7f99211-ab44749c-e12fe915-d2218462-c69a2e86	655
736	3	e6ba22bc-7da9e849-d9f828a4-8707e410-6b6dcb06	655
737	3	654183bf-3046b604-78021cc1-df3aff53-32a18f6c	655
738	3	1e54fdc5-1fa1da6a-5d33ee61-79bc6019-0583050d	655
739	3	0cbcdb55-e024879b-eefcd55d-67c4acae-912e0a79	525
740	3	2f5bfa70-cbbe8d0d-1f64bd56-affef508-794272d0	655
741	3	1ad77d4b-6acb577c-8b0e30c6-cb8dc915-96172a32	655
742	3	cd3cc172-80f5b9af-deb39520-786d5840-0d0e5515	655
743	3	817428a9-ad8aa834-74fd8530-8c4f8ea7-fb385d63	655
744	3	a8137440-61bc888e-3451e2be-9a82d4bb-59580eaa	655
745	3	4d45fe4c-e179d9fb-a8b160d9-6a699ca8-f4b39d99	655
746	3	dbd96213-6b87c51c-f371cdab-e6f4f708-4fa084f5	655
747	3	77cdc9a5-5474afe6-50cd5d4e-cbc8a9a7-38791d65	655
748	3	fa4f8c75-57cec41b-4e4adee0-d708f8c9-a4df0af5	655
749	3	e83f45cc-2e15eb64-c16daba2-c831bbf9-43a8b57f	655
750	3	f9c8f1e8-2bb79751-8cca2487-0d0e925f-dbe5bbd8	525
751	3	8f03fa26-5fe97224-a2821f26-e519a36d-91320c0b	525
752	3	8b12987a-87a8a58d-bd0c304b-83a59f64-d6d77d43	655
753	3	15be8bc7-d86fef19-c6007821-d0ec25ba-b0e91fce	655
754	3	785e9473-1027fe64-0c617076-7186603b-28e0125a	655
755	3	2e1dfe85-fa50d5ce-e10370d6-6042608b-daeea1db	525
756	3	3776d9a7-c720afe0-d2129ebc-6f33cecb-08049f6a	525
757	3	06d5f7f6-5a6e3c6b-4ddfa7e8-557fe1e7-a571e915	525
758	3	2cb53d0c-6e63b8b1-0ac6ddb4-11ae386b-2d7dafc5	525
759	3	3b875761-6ac0fb9e-620bbf99-7b99acab-dbac8076	525
760	3	b87fdbb8-982069b2-21227ca7-82174552-fbceb52e	527
761	3	370cfad5-02269b80-f4875641-4deef663-9992d6da	527
762	3	fea2b554-27aeaf84-1525da7c-b8cecc6f-2c01fbba	527
763	3	68aa09c7-8c101a45-95eca4a0-5f815735-7458d7d4	527
764	3	24fb670a-5cb881c7-2a866c01-01e8abe7-91446f90	525
765	3	90fb77dc-6cf98114-782cc9d1-127dcea0-2f8f68b2	527
766	3	80d3aadb-6301b66d-bd296cbc-fa74cc2a-c8e20543	527
767	3	7d44f595-beee9fbf-ead96b43-227c22e6-cb162a25	527
768	3	3cb6876d-9248e556-f1349211-905b9587-58a5db8a	527
769	3	63c597e5-fdb95b75-799f3f82-ff2916bb-f1618eb5	527
770	3	36c9e395-cf9848ad-3a514586-fc0e5394-0e4e9bb4	527
771	3	55d12b4f-88a8586b-8879043e-30baae7e-1cc9966a	527
772	3	18c3dfcd-b210cc96-765d2a91-8b79a7d8-6e277b85	527
773	3	e8a80352-9cc5f420-d4eeb706-f0cf2cf1-f75ebe08	527
774	3	fccad335-64fc4483-64b49a57-e7d3177f-88fd871c	527
775	3	cf63db84-39698e60-01dc428b-107f2d41-3774cdd5	525
776	3	3827be15-0d02a64e-97ef17fb-a4f1ebcf-2066dd71	527
777	3	bbe716b2-6e612e8f-8d1f2a3f-39fbeca1-ff6cd480	527
778	3	573132c3-7fc15ee7-29bd71f7-fb25f0b6-481d0815	527
779	3	fa8f9351-584027f7-6ef1c522-b975e5a8-225ae6bb	527
780	3	e6c1b021-8e9c4edb-f981eee5-bcce2e89-6b4d6a73	527
781	3	c107404f-ffea4430-dc069295-dd1c7784-227cb8de	527
782	3	4b365287-0d00f879-3828b3b7-e1da150f-91bbebd8	527
783	3	a7b040c6-057d96cd-a923efae-2474dc29-5a989c41	527
784	3	7cd2ef6a-74842c91-33fb4d49-98592bdb-03a9641c	527
785	3	4facfa90-111e6d61-1748162a-1902bc14-4e1c5a8b	527
786	3	3e196500-70a18a69-60f7093f-03a358c4-61947625	525
787	3	f918f0eb-4c73102c-63877859-f25e2384-1d92c718	527
788	3	32358d55-ee9e99c4-5e050b5d-b0f94e3b-ba777855	527
789	3	5666afa7-072f29e0-eb451a92-aabf1d9b-16addfa7	527
790	3	7d9bf97f-4406eae0-c101888e-5cbeac6d-3a99a67f	527
791	3	585d061a-c06ac3b7-054af1ee-cc104b04-a5203c36	527
792	3	40e4eb2b-0eaea31c-a55551a2-d918ac01-068320aa	527
793	3	fa4b5268-3d5a74b4-be6bb7ea-ce291ca5-d10638a4	527
794	3	d83e5eb7-1c460a6a-aa9b59a9-3c4b54c1-a96e6b81	527
795	3	a38f7ec6-912bfcbc-d65e7d80-b6a46fde-5260d249	527
796	3	aec59710-100ef887-27936a0b-09a9213f-d248dac8	527
797	3	b22e8f4e-0bbce08b-891815e0-526bfce3-a150634e	525
798	3	8e9c3247-7aeb3eb1-2ade8ac2-073dcf8b-06028589	527
799	3	413c7a77-15ac43a3-4676e9a0-edafda3a-35ece050	527
800	3	8790b1e7-e5ee3b51-0cec0c06-bc86257e-781052e5	527
801	3	317aaa34-d0e58da4-9bcb4f54-1c397e34-39e5a6cd	527
802	3	0323e8df-0fb9b53d-42a4fcc9-8caa78eb-c2c8dd54	527
803	3	1bd042ea-7f7ae848-b341af99-c3803cde-e0bc5a58	527
804	3	66162475-318d0d54-8914e8cb-b625dcf7-b3cf2743	527
805	3	fde67632-1d89dd2c-1d6129de-417fd0e5-dcddfb09	527
806	3	a9e479e8-49eb47ae-13acb155-74f8b3c3-4945e65c	527
807	3	64c8763b-276c7c50-38487b78-50e4e2f1-efb8e2c0	527
808	3	58a02660-313c7720-91667919-85f0dd37-bdbd5fa5	525
809	3	763395eb-8724c4a2-788c684b-40d99ea0-ddb88f6a	527
810	3	b35f9f16-2b1bd101-dd4957bf-8dd8ace9-8909bd6c	527
811	3	c7654c81-b61e5824-c52426f8-69a6e4f8-df1dfe38	527
812	3	f27a7766-41bd9835-f6695f86-ca7a0609-16871d8f	527
813	3	97ef67c6-2d1ed87a-56cca277-dfa8a4dc-0cab1a35	527
814	3	13208b5f-d46f0a07-70c1efd8-e18313f1-06f13bc4	527
815	3	f2c883eb-1bdb7d7b-22644e30-25e99f41-95a0c4a9	527
816	3	7cea2699-bf5346f5-3a746cc0-b61fef53-d8a21d6c	527
817	3	c24ac946-64c341e0-a166f31f-4c37bd8e-2b96f0e0	527
818	3	e59eb98a-23378e10-394f18b5-0839d184-46a30b38	527
819	3	4f3c6e6b-0168ff29-21ac3fba-1f05ca94-0b75195b	525
820	3	f5ac7a12-8d112d73-778f3905-69b642f2-a024fcae	527
821	3	b3a29091-86376331-78d6195c-ea249915-e03178d8	527
822	3	2837cfc7-35c1a08d-5b7ce3b5-7509fc6e-892a7dd1	527
823	3	b2f0d3c0-0c32cc02-bfd3e44a-727d0697-8666544c	527
824	3	db3b1e77-28bdcd2a-4aa1eb35-d9eb5326-44bf295d	527
825	3	d4addc8b-c598d71d-07223bcd-6d4588db-75636278	527
826	3	fed616b0-d0c99a7e-69add4d8-5aa07048-8186fb9e	527
827	3	dd95d44b-5e656013-a5f79d8e-cec2d242-38b1be6f	527
828	3	ed64dde3-7011dee6-7b932cf1-d2fc6097-381547b8	527
829	3	fd0cef5e-04d916d9-1fc35fd9-aedd05aa-67901cee	527
\.


--
-- Data for Name: serverproperties; Type: TABLE DATA; Schema: public; Owner: orthanc
--

COPY public.serverproperties (server, property, value) FROM stdin;
7e9b9bb6-f6b90342-0068ff60-25df10ce-34c79f65	5	{"Jobs":{},"Type":"JobsRegistry"}\n
\.


--
-- Name: changes_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: orthanc
--

SELECT pg_catalog.setval('public.changes_seq_seq', 850, true);


--
-- Name: exportedresources_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: orthanc
--

SELECT pg_catalog.setval('public.exportedresources_seq_seq', 1, false);


--
-- Name: patientrecyclingorder_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: orthanc
--

SELECT pg_catalog.setval('public.patientrecyclingorder_seq_seq', 1, true);


--
-- Name: resources_internalid_seq; Type: SEQUENCE SET; Schema: public; Owner: orthanc
--

SELECT pg_catalog.setval('public.resources_internalid_seq', 829, true);


--
-- Name: attachedfiles attachedfiles_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.attachedfiles
    ADD CONSTRAINT attachedfiles_pkey PRIMARY KEY (id, filetype);


--
-- Name: changes changes_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.changes
    ADD CONSTRAINT changes_pkey PRIMARY KEY (seq);


--
-- Name: dicomidentifiers dicomidentifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.dicomidentifiers
    ADD CONSTRAINT dicomidentifiers_pkey PRIMARY KEY (id, taggroup, tagelement);


--
-- Name: exportedresources exportedresources_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.exportedresources
    ADD CONSTRAINT exportedresources_pkey PRIMARY KEY (seq);


--
-- Name: globalintegers globalintegers_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.globalintegers
    ADD CONSTRAINT globalintegers_pkey PRIMARY KEY (key);


--
-- Name: globalproperties globalproperties_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.globalproperties
    ADD CONSTRAINT globalproperties_pkey PRIMARY KEY (property);


--
-- Name: labels labels_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id, label);


--
-- Name: maindicomtags maindicomtags_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.maindicomtags
    ADD CONSTRAINT maindicomtags_pkey PRIMARY KEY (id, taggroup, tagelement);


--
-- Name: metadata metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT metadata_pkey PRIMARY KEY (id, type);


--
-- Name: patientrecyclingorder patientrecyclingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.patientrecyclingorder
    ADD CONSTRAINT patientrecyclingorder_pkey PRIMARY KEY (seq);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (internalid);


--
-- Name: serverproperties serverproperties_pkey; Type: CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.serverproperties
    ADD CONSTRAINT serverproperties_pkey PRIMARY KEY (server, property);


--
-- Name: changesindex; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX changesindex ON public.changes USING btree (internalid);


--
-- Name: childrenindex; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX childrenindex ON public.resources USING btree (parentid);


--
-- Name: dicomidentifiersindex1; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX dicomidentifiersindex1 ON public.dicomidentifiers USING btree (id);


--
-- Name: dicomidentifiersindex2; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX dicomidentifiersindex2 ON public.dicomidentifiers USING btree (taggroup, tagelement);


--
-- Name: dicomidentifiersindexvalues; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX dicomidentifiersindexvalues ON public.dicomidentifiers USING btree (value);


--
-- Name: dicomidentifiersindexvalues2; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX dicomidentifiersindexvalues2 ON public.dicomidentifiers USING gin (value public.gin_trgm_ops);


--
-- Name: labelsindex1; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX labelsindex1 ON public.labels USING btree (id);


--
-- Name: labelsindex2; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX labelsindex2 ON public.labels USING btree (label);


--
-- Name: maindicomtagsindex; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX maindicomtagsindex ON public.maindicomtags USING btree (id);


--
-- Name: patientrecyclingindex; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX patientrecyclingindex ON public.patientrecyclingorder USING btree (patientid);


--
-- Name: publicindex; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX publicindex ON public.resources USING btree (publicid);


--
-- Name: resourcetypeindex; Type: INDEX; Schema: public; Owner: orthanc
--

CREATE INDEX resourcetypeindex ON public.resources USING btree (resourcetype);


--
-- Name: attachedfiles attachedfiledecrementsize; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER attachedfiledecrementsize AFTER DELETE ON public.attachedfiles FOR EACH ROW EXECUTE FUNCTION public.attachedfiledecrementsizefunc();


--
-- Name: attachedfiles attachedfiledeleted; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER attachedfiledeleted AFTER DELETE ON public.attachedfiles FOR EACH ROW EXECUTE FUNCTION public.attachedfiledeletedfunc();


--
-- Name: attachedfiles attachedfileincrementsize; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER attachedfileincrementsize AFTER INSERT ON public.attachedfiles FOR EACH ROW EXECUTE FUNCTION public.attachedfileincrementsizefunc();


--
-- Name: resources countresourcestracker; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER countresourcestracker AFTER INSERT OR DELETE ON public.resources FOR EACH ROW EXECUTE FUNCTION public.countresourcestrackerfunc();


--
-- Name: changes insertedchange; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER insertedchange AFTER INSERT ON public.changes FOR EACH ROW EXECUTE FUNCTION public.insertedchangefunc();


--
-- Name: resources patientadded; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER patientadded AFTER INSERT ON public.resources FOR EACH ROW EXECUTE FUNCTION public.patientaddedfunc();


--
-- Name: resources resourcedeleted; Type: TRIGGER; Schema: public; Owner: orthanc
--

CREATE TRIGGER resourcedeleted AFTER DELETE ON public.resources FOR EACH ROW EXECUTE FUNCTION public.resourcedeletedfunc();


--
-- Name: attachedfiles attachedfiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.attachedfiles
    ADD CONSTRAINT attachedfiles_id_fkey FOREIGN KEY (id) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: changes changes_internalid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.changes
    ADD CONSTRAINT changes_internalid_fkey FOREIGN KEY (internalid) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: dicomidentifiers dicomidentifiers_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.dicomidentifiers
    ADD CONSTRAINT dicomidentifiers_id_fkey FOREIGN KEY (id) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: labels labels_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_id_fkey FOREIGN KEY (id) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: maindicomtags maindicomtags_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.maindicomtags
    ADD CONSTRAINT maindicomtags_id_fkey FOREIGN KEY (id) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: metadata metadata_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT metadata_id_fkey FOREIGN KEY (id) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: patientrecyclingorder patientrecyclingorder_patientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.patientrecyclingorder
    ADD CONSTRAINT patientrecyclingorder_patientid_fkey FOREIGN KEY (patientid) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- Name: resources resources_parentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: orthanc
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_parentid_fkey FOREIGN KEY (parentid) REFERENCES public.resources(internalid) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

